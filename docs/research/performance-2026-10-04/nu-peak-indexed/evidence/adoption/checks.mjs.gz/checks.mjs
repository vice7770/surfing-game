// Conditional adoption validation. Run only if root accepts the completed native comparison.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join, posix } from 'node:path';
import ts from '/Users/regina/Desktop/Projects/surfing-game/node_modules/typescript/lib/typescript.js';
import { build } from '/Users/regina/Desktop/Projects/surfing-game/node_modules/vite/dist/node/index.js';

const ROOT = '/Users/regina/Desktop/Projects/surfing-game';
const WORK = '/private/tmp/surf-nu-peak-adoption-20261004';
const FPS = '/private/tmp/surf-nu-peak-fps-20261004';
const hash = b => createHash('sha256').update(b).digest('hex');
const json = p => JSON.parse(readFileSync(p, 'utf8'));
const report = { valid: false, startedAt: new Date().toISOString(), commands: [], outputs: [], failure: null };
const target = join(ROOT, 'src/wave/BoussinesqSolver.ts');
const expectedSource = 'c1d87564677e35ece932831139426e31f19b69490d961dccaf8b8e665e3e0910';
const expectedWorker = '72b459831985855496621becf0ce8c301aa0882f134696b71b3a3ae712f846c2';
assert.equal(process.env.BUILD_ID, '306258296');
assert.equal(json(join(FPS, 'root-run/report.json')).valid, true, 'Complete native comparison must pass');
assert(!existsSync(join(WORK, 'terminal.json')) && !existsSync(join(WORK, 'dist')), 'Fresh adoption output');
mkdirSync(WORK, { recursive: true });
const sourceBefore = readFileSync(target);
assert.equal(sourceBefore.length, 38627);
assert.equal(hash(sourceBefore), expectedSource);

function outputs(dir, prefix = '') {
  const rows = [];
  for (const entry of readdirSync(join(dir, prefix), { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    assert(!entry.isSymbolicLink());
    const path = posix.join(prefix, entry.name);
    if (entry.isDirectory()) rows.push(...outputs(dir, path));
    else if (entry.isFile()) { const bytes = readFileSync(join(dir, path)); rows.push({ path, bytes: bytes.length, sha256: hash(bytes) }); }
  }
  return rows;
}
try {
  const config = ts.readConfigFile(join(ROOT, 'tsconfig.json'), ts.sys.readFile);
  assert.equal(config.error, undefined);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, ROOT, { noEmit: true, incremental: false }, join(ROOT, 'tsconfig.json'));
  assert.equal(parsed.errors.length, 0);
  const program = ts.createProgram(parsed.fileNames, parsed.options);
  const diagnostics = ts.getPreEmitDiagnostics(program);
  report.commands.push({ name: 'canonical whole-project strict', diagnostics: diagnostics.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')) });
  assert.equal(diagnostics.length, 0);
  await build({ root: ROOT, configFile: join(ROOT, 'vite.config.ts'), configLoader: 'runner', cacheDir: join(WORK, '.cache'), build: { outDir: join(WORK, 'dist'), copyPublicDir: false, emptyOutDir: false } });
  report.outputs = outputs(join(WORK, 'dist'));
  const measured = json(join(FPS, 'candidate/build-manifest.json'));
  assert.deepEqual(report.outputs, measured.outputRecords, 'All canonical outputs must equal the measured candidate');
  assert.equal(report.outputs.length, 11);
  assert(report.outputs.some(p => p.path.startsWith('assets/surfZoneWorker-') && p.sha256 === expectedWorker));
  assert.deepEqual(readFileSync(target), sourceBefore, 'Adoption checks changed runtime source');
  report.valid = true;
} catch (error) { report.failure = String(error); throw error; }
finally { report.endedAt = new Date().toISOString(); writeFileSync(join(WORK, 'terminal.json'), JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report)); }
