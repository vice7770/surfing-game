import assert from "node:assert/strict";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { performance } from "node:perf_hooks";
import { createHash } from "node:crypto";
import { inflateSync } from "node:zlib";
import { pathToFileURL } from "node:url";
//#region common.ts
const WORK = "/private/tmp/surf-nu-peak-indexed-20261004";
const sha = (b) => createHash("sha256").update(b).digest("hex");
const exact = (a, b, label) => {
	assert.equal(a.byteLength, b.byteLength, label);
	assert(Buffer.from(a.buffer, a.byteOffset, a.byteLength).equals(Buffer.from(b.buffer, b.byteOffset, b.byteLength)), label);
};
function pin(p) {
	const b = readFileSync(p.path);
	assert.equal(b.length, p.bytes, p.path);
	assert.equal(sha(b), p.sha256, p.path);
}
async function authority() {
	const raw = readFileSync(join(WORK, "ready.json")), readySha = sha(raw), ready = JSON.parse(raw.toString());
	assert.equal(readySha, process.env.NU_PEAK_INDEXED_READY_SHA256, "Reviewed source-ready pin required");
	const check = () => {
		for (const p of ready.inputs) pin(p);
	};
	check();
	const compiled = JSON.parse(readFileSync(join(WORK, "compiled.json"), "utf8"));
	assert.equal(compiled.readySha256, readySha);
	for (const p of compiled.outputs) pin(p);
	return {
		ready,
		readySha,
		check,
		baseline: await import(pathToFileURL(ready.baseline.path).href),
		candidate: await import(pathToFileURL(join(WORK, "compiled/candidate.mjs")).href)
	};
}
function heldInput(ready) {
	const capture = JSON.parse(readFileSync(ready.capture.path, "utf8")), compressed = readFileSync(capture.export.file.path);
	assert.equal(sha(compressed), capture.export.sha256);
	const bytes = inflateSync(compressed, { maxOutputLength: 8388608 });
	assert.equal(bytes.length, capture.export.expandedBytes);
	assert.equal(sha(bytes), capture.export.expandedSha256);
	const config = capture.plan.config, actual = capture.nativeAudit.observations[1].actual.config;
	assert.deepEqual(config, actual);
	assert.equal(config.spot, "padang");
	assert.equal(config.seed, 8761);
	assert.equal(config.componentCount, 64);
	return {
		config,
		bytes: new Uint8Array(bytes),
		authority: {
			captureIncomplete: true,
			f32CommittedExport: true,
			captureSha256: ready.capture.sha256,
			compressedSha256: capture.export.sha256,
			rawSha256: capture.export.expandedSha256,
			pausedSeaTime: capture.export.pausedSeaTime,
			solverTime: capture.export.header.solverTime,
			seaTimeOffset: capture.export.header.seaTimeOffset,
			limitation: "Paused F32 transport export, distinct from the earlier three drawn snapshots and full internal F64 precision; absent RATEH/NU remain constructor defaults, not measured native values."
		}
	};
}
//#endregion
//#region ../surf-feed-components-cache-20261004/mockGpu.ts
var BufferMemory = class {
	id;
	size;
	usage;
	owner;
	bytes;
	mapped = false;
	destroyed = false;
	constructor(id, size, usage, owner) {
		this.id = id;
		this.size = size;
		this.usage = usage;
		this.owner = owner;
		this.bytes = new ArrayBuffer(size);
	}
	async mapAsync(mode) {
		assert(!this.destroyed && !this.mapped);
		this.owner.event({
			kind: "map",
			id: this.id,
			mode
		});
		if (this.owner.failMap) {
			this.owner.failMap = false;
			throw Error("injected map rejection");
		}
		this.mapped = true;
	}
	getMappedRange() {
		assert(this.mapped && !this.destroyed);
		this.owner.event({
			kind: "mappedRange",
			id: this.id
		});
		return this.bytes;
	}
	unmap() {
		assert(this.mapped && !this.destroyed);
		this.mapped = false;
		this.owner.event({
			kind: "unmap",
			id: this.id
		});
	}
	destroy() {
		assert(!this.mapped);
		this.destroyed = true;
		this.owner.event({
			kind: "destroyBuffer",
			id: this.id
		});
	}
};
var RecordingGpu = class {
	recording;
	recordPayloads;
	buffers = [];
	events = [];
	failMap = false;
	destroyed = false;
	/** Protocol cases may inject recognizable device output; CPU cost leaves all dispatches as no-ops. */
	onCompute;
	constructor(recording = true, recordPayloads = true) {
		this.recording = recording;
		this.recordPayloads = recordPayloads;
	}
	event(e) {
		if (this.recording) this.events.push(e);
	}
	clear() {
		this.events.length = 0;
	}
	write(buffer, offset, data, dataOffset = 0, size) {
		assert(!buffer.mapped && !buffer.destroyed);
		const typed = ArrayBuffer.isView(data), element = typed && "BYTES_PER_ELEMENT" in data ? Number(data.BYTES_PER_ELEMENT) : 1;
		const start = (typed ? data.byteOffset : 0) + dataOffset * element, length = size === void 0 ? data.byteLength - dataOffset * element : size * element;
		assert(offset % 4 === 0 && length % 4 === 0 && offset >= 0 && offset + length <= buffer.size);
		const raw = new Uint8Array(typed ? data.buffer : data, start, length);
		new Uint8Array(buffer.bytes, offset, length).set(raw);
		this.event({
			kind: "write",
			id: buffer.id,
			offset,
			dataOffset,
			size: size ?? null,
			element,
			length: raw.length,
			bytes: this.recording && this.recordPayloads ? Array.from(raw) : null,
			sha256: this.recording && !this.recordPayloads ? createHash("sha256").update(raw).digest("hex") : null
		});
	}
	device = {
		queue: {
			writeBuffer: (buffer, offset, data, dataOffset, size) => this.write(buffer, offset, data, dataOffset, size),
			submit: (commands) => {
				this.event({
					kind: "submit",
					commands: commands.length
				});
				for (const c of commands) c.run();
			},
			onSubmittedWorkDone: async () => {
				this.event({ kind: "waitSubmitted" });
			}
		},
		createBuffer: ({ size, usage }) => {
			const b = new BufferMemory(this.buffers.length, size, usage, this);
			this.buffers.push(b);
			this.event({
				kind: "createBuffer",
				id: b.id,
				size,
				usage
			});
			return b;
		},
		createBindGroupLayout: () => ({}),
		createPipelineLayout: () => ({}),
		createBindGroup: ({ entries }) => {
			const id = entries.map((e) => [e.binding, e.resource.buffer.id]);
			this.event({
				kind: "bind",
				entries: id
			});
			return { id };
		},
		createComputePipeline: ({ compute }) => ({ entryPoint: compute.entryPoint }),
		createShaderModule: () => ({ getCompilationInfo: async () => ({ messages: [] }) }),
		createCommandEncoder: () => {
			const copies = [];
			let ended = false, finished = false;
			this.event({ kind: "encoder" });
			return {
				beginComputePass: () => {
					this.event({ kind: "beginPass" });
					return {
						setBindGroup: (index, b) => this.event({
							kind: "group",
							index,
							entries: b.id
						}),
						setPipeline: (p) => this.event({
							kind: "pipeline",
							entryPoint: p.entryPoint
						}),
						dispatchWorkgroups: (groups) => this.event({
							kind: "dispatch",
							groups
						}),
						end: () => {
							assert(!ended);
							ended = true;
							this.event({ kind: "endPass" });
						}
					};
				},
				copyBufferToBuffer: (from, source, to, target, size) => {
					assert(ended && !finished);
					assert(source >= 0 && source + size <= from.size && target >= 0 && target + size <= to.size);
					copies.push({
						from,
						source,
						to,
						target,
						size
					});
					this.event({
						kind: "copy",
						from: from.id,
						source,
						to: to.id,
						target,
						size
					});
				},
				finish: () => {
					assert(ended && !finished);
					finished = true;
					this.event({ kind: "finish" });
					return { run: () => {
						this.onCompute?.();
						for (const c of copies) {
							assert(!c.from.mapped && !c.to.mapped);
							new Uint8Array(c.to.bytes, c.target, c.size).set(new Uint8Array(c.from.bytes, c.source, c.size));
						}
					} };
				}
			};
		},
		destroy: () => {
			this.destroyed = true;
			this.event({ kind: "destroyDevice" });
		}
	};
	gpu = { requestAdapter: async () => ({
		limits: {
			maxStorageBufferBindingSize: 1e9,
			maxBufferSize: 1e9
		},
		requestDevice: async () => this.device
	}) };
};
function globals() {
	const values = {
		GPUBufferUsage: {
			STORAGE: 1,
			COPY_DST: 2,
			COPY_SRC: 4,
			MAP_READ: 8,
			UNIFORM: 16
		},
		GPUShaderStage: { COMPUTE: 1 },
		GPUMapMode: { READ: 1 }
	}, old = /* @__PURE__ */ new Map();
	for (const [k, v] of Object.entries(values)) {
		old.set(k, Object.getOwnPropertyDescriptor(globalThis, k));
		Object.defineProperty(globalThis, k, {
			configurable: true,
			writable: true,
			value: v
		});
	}
	return () => {
		for (const [k, v] of old) if (v) Object.defineProperty(globalThis, k, v);
		else delete globalThis[k];
	};
}
//#endregion
//#region cost.ts
const args = process.argv.slice(2);
assert(args.length <= 1 && args.every((a) => a === "--run=true"));
if (!args.includes("--run=true")) {
	console.log(JSON.stringify({
		planOnly: true,
		actualHeldCells: 116e3,
		components: 64,
		warmPairs: 8,
		measuredPairs: 32,
		wholeMethod: "runWaterStep via ordinary step(1/60)",
		usefulMeanGainRequiredMs: .1,
		noRealGpuDriverOrFps: true
	}));
	process.exit(0);
}
const OUT = join(WORK, "cost-first");
assert(!existsSync(OUT));
mkdirSync(OUT);
const report = {
	schema: "nu-peak-indexed-complete-mock-host-cost/v1",
	valid: false,
	rows: [],
	localCpuOnly: true
};
const save = () => {
	const b = Buffer.from(JSON.stringify(report, null, 2) + "\n");
	assert(b.length <= 524288);
	writeFileSync(join(OUT, "report.json"), b);
	return {
		path: join(OUT, "report.json"),
		bytes: b.length,
		sha256: sha(b)
	};
};
const restore = globals();
const live = [];
const wholeStart = performance.now();
const bound = () => assert(performance.now() - wholeStart < 15e3, "15 s complete cost operation budget");
try {
	const a = await authority();
	report.readySha256 = a.readySha;
	const proof = JSON.parse(readFileSync(join(WORK, "proof-first/terminal.json"), "utf8"));
	assert.equal(proof.valid, true);
	assert.equal(proof.readySha256, a.readySha);
	pin(proof.report);
	const input = heldInput(a.ready);
	report.inputAuthority = input.authority;
	report.config = input.config;
	const make = async (arm) => {
		const scene = new arm.SurfZoneSimulation(input.config, "warm"), state = arm.decodeSurfZoneState(input.bytes);
		scene.importState(state);
		assert.equal(scene.solver.h.length, 116e3);
		assert.equal(scene.sea.components.length, 64);
		assert.equal(scene.seaTime, input.authority.pausedSeaTime);
		assert(scene.solver instanceof arm.BoussinesqSolver);
		const solver = scene.solver, feed = solver.relaxationZones.find((z) => z instanceof arm.SideFeed);
		assert(feed);
		assert(feed.deviceShape().slots > 0);
		const mock = new RecordingGpu(false), host = await arm.GpuBoussinesq.create(solver, mock.gpu);
		assert(host);
		live.push(host);
		bound();
		return {
			arm,
			scene,
			solver,
			feed,
			mock,
			host,
			identities: arm.DEVICE_READBACK.map((i) => arm.readbackTarget(solver, i))
		};
	};
	const b = await make(a.baseline), c = await make(a.candidate), initialTime = b.solver.time;
	const equal = () => {
		assert.equal(b.solver.time, c.solver.time);
		assert.equal(b.solver.plungeVersion, c.solver.plungeVersion);
		assert.equal(b.host.lastSubsteps, c.host.lastSubsteps);
		assert.equal(b.mock.buffers.length, c.mock.buffers.length);
		for (let i = 0; i < b.mock.buffers.length; i++) {
			assert.equal(b.mock.buffers[i].size, c.mock.buffers[i].size);
			assert.equal(b.mock.buffers[i].mapped, false);
			assert.equal(c.mock.buffers[i].mapped, false);
			exact(new Uint8Array(b.mock.buffers[i].bytes), new Uint8Array(c.mock.buffers[i].bytes), "Actual mock device buffer" + i);
		}
		for (let k = 0; k < b.arm.DEVICE_READBACK.length; k++) {
			const i = b.arm.DEVICE_READBACK[k], vb = b.arm.readbackTarget(b.solver, i), vc = c.arm.readbackTarget(c.solver, i);
			assert.equal(vb, b.identities[k]);
			assert.equal(vc, c.identities[k]);
			exact(vb, vc, "Complete host feedback field" + i);
		}
		exact(b.solver.plungeHold, c.solver.plungeHold, "Plunge aging feedback");
		assert.equal(b.solver.maxStableStep(), c.solver.maxStableStep());
		bound();
	};
	const call = async (actor) => {
		const start = performance.now();
		await actor.host.step(1 / 60);
		return {
			total: performance.now() - start,
			diagnostics: { ...actor.host.diagnostics },
			lastStepMs: actor.host.lastStepMs,
			substeps: actor.host.lastSubsteps
		};
	};
	const orders = [
		"AB",
		"BA",
		"BA",
		"AB"
	];
	const pair = async (i) => {
		const order = orders[i % 4], first = await call(order === "AB" ? b : c), second = await call(order === "AB" ? c : b), bb = order === "AB" ? first : second, cc = order === "AB" ? second : first;
		equal();
		return {
			pair: i,
			order,
			baselineMs: bb.total,
			candidateMs: cc.total,
			savingMs: bb.total - cc.total,
			baselineDiagnostics: bb.diagnostics,
			candidateDiagnostics: cc.diagnostics,
			substeps: bb.substeps
		};
	};
	for (let i = 0; i < 8; i++) await pair(i);
	for (let i = 0; i < 32; i++) report.rows.push(await pair(i));
	equal();
	const savings = report.rows.map((r) => r.savingMs), mean = savings.reduce((s, v) => s + v, 0) / savings.length, variance = savings.reduce((s, v) => s + (v - mean) ** 2, 0) / (savings.length - 1), lower95 = mean - 1.96 * Math.sqrt(variance / savings.length), sorted = [...savings].sort((x, y) => x - y);
	const strata = ["AB", "BA"].map((order) => {
		const x = report.rows.filter((r) => r.order === order).map((r) => r.savingMs);
		return {
			order,
			pairs: x.length,
			meanSavingMs: x.reduce((s, v) => s + v, 0) / x.length
		};
	});
	report.statistics = {
		pairs: savings.length,
		meanSavingMs: mean,
		medianSavingMs: (sorted[15] + sorted[16]) / 2,
		pairedMeanLower95Ms: lower95,
		thresholdMs: .1,
		orderStrata: strata,
		thresholdPass: lower95 > .1 && strata.every((s) => s.meanSavingMs > .1),
		caveat: "Approximate paired-mean normal bound on one fixed CPU sample; order strata are retained. No bootstrap, adaptive extra pairs or retry. Not native performance or population inference."
	};
	report.work = {
		cells: 116e3,
		components: 64,
		initialSolverTime: initialTime,
		finalSolverTime: b.solver.time,
		completedStepCallsPerArm: 40,
		readbackFields: 9,
		candidateRetainsViscosityScan: true,
		indexedAdoptPeakOnly: true,
		sideFeedAndComponentCacheExcluded: true,
		queueByteLengthsOrderAndUniformsEstablishedByProof: true,
		allFinalDeviceBytesAndSolverOutputsExact: true,
		steadyBufferIdentitiesPreserved: true,
		timed: "Complete ordinary GpuBoussinesq.step/runWaterStep: upload conversion and mock memory queue writes, original CFL, uniforms including their unchanged slot scan, command/kernel dispatch bookkeeping, nine memory readback copies, async map microtask, unpack, indexed strict-greater viscosity peak and original plunge/time adoption.",
		excluded: "Real WGSL/GPU execution, driver/queue stalls, renderer/worker publication/FPS, physics CPU consumers. Mock dispatches are no-ops; imported held fields do not physically evolve. Construction/intake/equality/hashing and statistics outside timings.",
		fieldLimit: "Actual paused F32 imported water/breaking/predictor/plunge fields; absent RATEH/NU are constructor defaults. All original peak/clock feedback loops execute, but this is not the native evolved viscosity/CFL distribution."
	};
	a.check();
	report.elapsedMs = performance.now() - wholeStart;
	assert(report.statistics.thresholdPass, "No >0.1 ms useful paired complete-host gain");
	report.valid = true;
	const payload = save();
	writeFileSync(join(OUT, "terminal.json"), JSON.stringify({
		valid: true,
		readySha256: a.readySha,
		inputPinsUnchanged: true,
		usefulGainPass: true,
		report: payload
	}, null, 2) + "\n");
	console.log(JSON.stringify({
		valid: true,
		statistics: report.statistics,
		report: payload
	}));
} catch (error) {
	report.strictStop = true;
	report.firstFailure = String(error);
	const payload = save();
	writeFileSync(join(OUT, "terminal.json"), JSON.stringify({
		valid: false,
		strictStop: true,
		error: String(error),
		report: payload
	}, null, 2) + "\n");
	process.exitCode = 1;
	console.error(String(error));
} finally {
	for (const h of live) h.dispose();
	restore();
}
//#endregion
export {};
