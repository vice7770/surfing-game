import assert from "node:assert/strict";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { inflateSync } from "node:zlib";
import { pathToFileURL } from "node:url";
//#region common.ts
const WORK = "/private/tmp/surf-nu-peak-indexed-20261004";
const sha = (b) => createHash("sha256").update(b).digest("hex");
const exact = (a, b, label) => {
	assert.equal(a.byteLength, b.byteLength, label);
	assert(Buffer.from(a.buffer, a.byteOffset, a.byteLength).equals(Buffer.from(b.buffer, b.byteOffset, b.byteLength)), label);
};
function pin(p) {
	const b = readFileSync(p.path);
	assert.equal(b.length, p.bytes, p.path);
	assert.equal(sha(b), p.sha256, p.path);
}
async function authority() {
	const raw = readFileSync(join(WORK, "ready.json")), readySha = sha(raw), ready = JSON.parse(raw.toString());
	assert.equal(readySha, process.env.NU_PEAK_INDEXED_READY_SHA256, "Reviewed source-ready pin required");
	const check = () => {
		for (const p of ready.inputs) pin(p);
	};
	check();
	const compiled = JSON.parse(readFileSync(join(WORK, "compiled.json"), "utf8"));
	assert.equal(compiled.readySha256, readySha);
	for (const p of compiled.outputs) pin(p);
	return {
		ready,
		readySha,
		check,
		baseline: await import(pathToFileURL(ready.baseline.path).href),
		candidate: await import(pathToFileURL(join(WORK, "compiled/candidate.mjs")).href)
	};
}
function heldInput(ready) {
	const capture = JSON.parse(readFileSync(ready.capture.path, "utf8")), compressed = readFileSync(capture.export.file.path);
	assert.equal(sha(compressed), capture.export.sha256);
	const bytes = inflateSync(compressed, { maxOutputLength: 8388608 });
	assert.equal(bytes.length, capture.export.expandedBytes);
	assert.equal(sha(bytes), capture.export.expandedSha256);
	const config = capture.plan.config, actual = capture.nativeAudit.observations[1].actual.config;
	assert.deepEqual(config, actual);
	assert.equal(config.spot, "padang");
	assert.equal(config.seed, 8761);
	assert.equal(config.componentCount, 64);
	return {
		config,
		bytes: new Uint8Array(bytes),
		authority: {
			captureIncomplete: true,
			f32CommittedExport: true,
			captureSha256: ready.capture.sha256,
			compressedSha256: capture.export.sha256,
			rawSha256: capture.export.expandedSha256,
			pausedSeaTime: capture.export.pausedSeaTime,
			solverTime: capture.export.header.solverTime,
			seaTimeOffset: capture.export.header.seaTimeOffset,
			limitation: "Paused F32 transport export, distinct from the earlier three drawn snapshots and full internal F64 precision; absent RATEH/NU remain constructor defaults, not measured native values."
		}
	};
}
//#endregion
//#region ../surf-feed-components-cache-20261004/mockGpu.ts
var BufferMemory = class {
	id;
	size;
	usage;
	owner;
	bytes;
	mapped = false;
	destroyed = false;
	constructor(id, size, usage, owner) {
		this.id = id;
		this.size = size;
		this.usage = usage;
		this.owner = owner;
		this.bytes = new ArrayBuffer(size);
	}
	async mapAsync(mode) {
		assert(!this.destroyed && !this.mapped);
		this.owner.event({
			kind: "map",
			id: this.id,
			mode
		});
		if (this.owner.failMap) {
			this.owner.failMap = false;
			throw Error("injected map rejection");
		}
		this.mapped = true;
	}
	getMappedRange() {
		assert(this.mapped && !this.destroyed);
		this.owner.event({
			kind: "mappedRange",
			id: this.id
		});
		return this.bytes;
	}
	unmap() {
		assert(this.mapped && !this.destroyed);
		this.mapped = false;
		this.owner.event({
			kind: "unmap",
			id: this.id
		});
	}
	destroy() {
		assert(!this.mapped);
		this.destroyed = true;
		this.owner.event({
			kind: "destroyBuffer",
			id: this.id
		});
	}
};
var RecordingGpu = class {
	recording;
	recordPayloads;
	buffers = [];
	events = [];
	failMap = false;
	destroyed = false;
	/** Protocol cases may inject recognizable device output; CPU cost leaves all dispatches as no-ops. */
	onCompute;
	constructor(recording = true, recordPayloads = true) {
		this.recording = recording;
		this.recordPayloads = recordPayloads;
	}
	event(e) {
		if (this.recording) this.events.push(e);
	}
	clear() {
		this.events.length = 0;
	}
	write(buffer, offset, data, dataOffset = 0, size) {
		assert(!buffer.mapped && !buffer.destroyed);
		const typed = ArrayBuffer.isView(data), element = typed && "BYTES_PER_ELEMENT" in data ? Number(data.BYTES_PER_ELEMENT) : 1;
		const start = (typed ? data.byteOffset : 0) + dataOffset * element, length = size === void 0 ? data.byteLength - dataOffset * element : size * element;
		assert(offset % 4 === 0 && length % 4 === 0 && offset >= 0 && offset + length <= buffer.size);
		const raw = new Uint8Array(typed ? data.buffer : data, start, length);
		new Uint8Array(buffer.bytes, offset, length).set(raw);
		this.event({
			kind: "write",
			id: buffer.id,
			offset,
			dataOffset,
			size: size ?? null,
			element,
			length: raw.length,
			bytes: this.recording && this.recordPayloads ? Array.from(raw) : null,
			sha256: this.recording && !this.recordPayloads ? createHash("sha256").update(raw).digest("hex") : null
		});
	}
	device = {
		queue: {
			writeBuffer: (buffer, offset, data, dataOffset, size) => this.write(buffer, offset, data, dataOffset, size),
			submit: (commands) => {
				this.event({
					kind: "submit",
					commands: commands.length
				});
				for (const c of commands) c.run();
			},
			onSubmittedWorkDone: async () => {
				this.event({ kind: "waitSubmitted" });
			}
		},
		createBuffer: ({ size, usage }) => {
			const b = new BufferMemory(this.buffers.length, size, usage, this);
			this.buffers.push(b);
			this.event({
				kind: "createBuffer",
				id: b.id,
				size,
				usage
			});
			return b;
		},
		createBindGroupLayout: () => ({}),
		createPipelineLayout: () => ({}),
		createBindGroup: ({ entries }) => {
			const id = entries.map((e) => [e.binding, e.resource.buffer.id]);
			this.event({
				kind: "bind",
				entries: id
			});
			return { id };
		},
		createComputePipeline: ({ compute }) => ({ entryPoint: compute.entryPoint }),
		createShaderModule: () => ({ getCompilationInfo: async () => ({ messages: [] }) }),
		createCommandEncoder: () => {
			const copies = [];
			let ended = false, finished = false;
			this.event({ kind: "encoder" });
			return {
				beginComputePass: () => {
					this.event({ kind: "beginPass" });
					return {
						setBindGroup: (index, b) => this.event({
							kind: "group",
							index,
							entries: b.id
						}),
						setPipeline: (p) => this.event({
							kind: "pipeline",
							entryPoint: p.entryPoint
						}),
						dispatchWorkgroups: (groups) => this.event({
							kind: "dispatch",
							groups
						}),
						end: () => {
							assert(!ended);
							ended = true;
							this.event({ kind: "endPass" });
						}
					};
				},
				copyBufferToBuffer: (from, source, to, target, size) => {
					assert(ended && !finished);
					assert(source >= 0 && source + size <= from.size && target >= 0 && target + size <= to.size);
					copies.push({
						from,
						source,
						to,
						target,
						size
					});
					this.event({
						kind: "copy",
						from: from.id,
						source,
						to: to.id,
						target,
						size
					});
				},
				finish: () => {
					assert(ended && !finished);
					finished = true;
					this.event({ kind: "finish" });
					return { run: () => {
						this.onCompute?.();
						for (const c of copies) {
							assert(!c.from.mapped && !c.to.mapped);
							new Uint8Array(c.to.bytes, c.target, c.size).set(new Uint8Array(c.from.bytes, c.source, c.size));
						}
					} };
				}
			};
		},
		destroy: () => {
			this.destroyed = true;
			this.event({ kind: "destroyDevice" });
		}
	};
	gpu = { requestAdapter: async () => ({
		limits: {
			maxStorageBufferBindingSize: 1e9,
			maxBufferSize: 1e9
		},
		requestDevice: async () => this.device
	}) };
};
function globals() {
	const values = {
		GPUBufferUsage: {
			STORAGE: 1,
			COPY_DST: 2,
			COPY_SRC: 4,
			MAP_READ: 8,
			UNIFORM: 16
		},
		GPUShaderStage: { COMPUTE: 1 },
		GPUMapMode: { READ: 1 }
	}, old = /* @__PURE__ */ new Map();
	for (const [k, v] of Object.entries(values)) {
		old.set(k, Object.getOwnPropertyDescriptor(globalThis, k));
		Object.defineProperty(globalThis, k, {
			configurable: true,
			writable: true,
			value: v
		});
	}
	return () => {
		for (const [k, v] of old) if (v) Object.defineProperty(globalThis, k, v);
		else delete globalThis[k];
	};
}
//#endregion
//#region proof.ts
const DT = 1 / 60;
const args = process.argv.slice(2);
assert(args.length <= 1 && args.every((a) => a === "--run=true"));
if (!args.includes("--run=true")) {
	console.log(JSON.stringify({
		planOnly: true,
		candidate: "indexed strict-greater viscosity peak only",
		tests: "full canonical device paths, mutable feed weights and refresh, actual held import",
		realGpu: false
	}));
	process.exit(0);
}
const OUT = join(WORK, "proof-first");
assert(!existsSync(OUT));
mkdirSync(OUT);
const report = {
	schema: "nu-peak-indexed-complete-host-proof/v1",
	valid: false,
	cases: [],
	actualHeld: null
};
const save = () => {
	const b = Buffer.from(JSON.stringify(report, null, 2) + "\n");
	assert(b.length <= 1048576);
	writeFileSync(join(OUT, "report.json"), b);
	return {
		path: join(OUT, "report.json"),
		bytes: b.length,
		sha256: sha(b)
	};
};
const restore = globals();
const live = [];
try {
	const a = await authority();
	report.readySha256 = a.readySha;
	const config = {
		spot: "padang",
		seed: 5,
		significantHeight: 1.2,
		peakPeriod: 16,
		directionDegrees: 10,
		spreading: 12,
		tide: 0,
		windSpeed: 0,
		stage: 2,
		alongShore: 32,
		dx: 4,
		fineSpacing: 8,
		coarseSpacing: 16,
		spinUpPeriods: 1,
		componentCount: 7
	};
	async function pair(options = {}) {
		const make = async (arm) => {
			const scene = new arm.SurfZoneSimulation({
				...config,
				spot: options.spot ?? "padang",
				componentCount: options.components ?? 7
			}, "warm");
			assert(scene.solver instanceof arm.BoussinesqSolver);
			const solver = scene.solver, feed = solver.relaxationZones.find((z) => z instanceof arm.SideFeed);
			const originalWeights = feed?.weights.slice();
			if (options.zeroBeforeCreate) feed.weights.fill(0);
			const mock = new RecordingGpu(), host = await arm.GpuBoussinesq.create(solver, mock.gpu);
			assert(host);
			live.push(host);
			return {
				arm,
				scene,
				solver,
				feed,
				originalWeights,
				mock,
				host,
				identities: arm.DEVICE_READBACK.map((index) => arm.readbackTarget(solver, index))
			};
		};
		const b = await make(a.baseline), c = await make(a.candidate);
		assert.deepEqual(c.mock.events, b.mock.events, "Creation protocol");
		b.mock.clear();
		c.mock.clear();
		return {
			b,
			c
		};
	}
	const equal = (p, label) => {
		assert.deepEqual(p.c.mock.events, p.b.mock.events, label + " ordered queue/encode/map protocol and write bytes");
		assert.equal(p.b.mock.buffers.length, p.c.mock.buffers.length);
		for (let i = 0; i < p.b.mock.buffers.length; i++) {
			const b = p.b.mock.buffers[i], c = p.c.mock.buffers[i];
			assert.equal(c.size, b.size);
			assert.equal(c.mapped, b.mapped);
			assert.equal(c.destroyed, b.destroyed);
			exact(new Uint8Array(c.bytes), new Uint8Array(b.bytes), label + " device buffer" + i);
		}
		for (let i = 0; i < p.b.arm.DEVICE_READBACK.length; i++) {
			const index = p.b.arm.DEVICE_READBACK[i], b = p.b.arm.readbackTarget(p.b.solver, index), c = p.c.arm.readbackTarget(p.c.solver, index);
			assert.equal(b, p.b.identities[i]);
			assert.equal(c, p.c.identities[i]);
			exact(b, c, label + " solver destination" + index);
		}
		exact(p.b.solver.plungeHold, p.c.solver.plungeHold, label + " plunge clock aging");
		assert.equal(p.b.solver.time, p.c.solver.time);
		assert.equal(p.b.solver.plungeVersion, p.c.solver.plungeVersion);
		assert.equal(p.b.host.lastSubsteps, p.c.host.lastSubsteps);
		assert.equal(p.b.host.diagnostics.substeps, p.c.host.diagnostics.substeps);
		assert.equal(p.b.solver.maxStableStep(), p.c.solver.maxStableStep(), label + " adopted peak/CFL feedback");
	};
	const step = async (p, label, dt = DT) => {
		p.b.mock.clear();
		p.c.mock.clear();
		await p.b.host.step(dt);
		await p.c.host.step(dt);
		equal(p, label);
	};
	const done = (name, p) => {
		report.cases.push({
			name,
			queueBytesOrderAndLengthExact: true,
			allDeviceBuffersAndNineDestinationsExact: true,
			identitiesClocksCflAndPlungeExact: true,
			protocolEvents: p.b.mock.events.length,
			protocolSha256: sha(Buffer.from(JSON.stringify(p.b.mock.events)))
		});
		p.b.host.dispose();
		p.c.host.dispose();
		save();
	};
	{
		const p = await pair(), dt = .125;
		const cases = [
			{
				label: "nonpositive and NaN",
				values: [
					NaN,
					-Infinity,
					-Number.MAX_VALUE,
					-Number.MIN_VALUE,
					-0,
					0
				],
				peak: 0
			},
			{
				label: "positive finite duplicates",
				values: [
					NaN,
					-0,
					Number.MIN_VALUE,
					Number.EPSILON,
					2.5,
					2.5,
					-1
				],
				peak: 2.5
			},
			{
				label: "descending and ties",
				values: [
					8,
					NaN,
					8,
					7,
					Number.MIN_VALUE,
					-Infinity
				],
				peak: 8
			},
			{
				label: "positive Infinity",
				values: [
					Infinity,
					NaN,
					1,
					-Infinity,
					-0
				],
				peak: Infinity
			},
			{
				label: "reset to positive zero",
				values: [
					-0,
					NaN,
					-3
				],
				peak: 0
			},
			{
				label: "positive subnormal",
				values: [
					Number.MIN_VALUE,
					0,
					-0,
					NaN
				],
				peak: Number.MIN_VALUE
			}
		];
		const originals = [p.b.solver.viscosity.slice(), p.c.solver.viscosity.slice()], holds = [p.b.solver.plungeHold.slice(), p.c.solver.plungeHold.slice()];
		const identities = [p.b.solver.viscosity, p.c.solver.viscosity], holdIdentities = [p.b.solver.plungeHold, p.c.solver.plungeHold];
		for (const scenario of cases) {
			for (const actor of [p.b, p.c]) {
				const solver = actor.solver, state = solver;
				assert(solver.viscosity.length >= scenario.values.length && solver.plungeHold.length >= 5);
				solver.viscosity.fill(-0);
				solver.viscosity.set(scenario.values);
				const before = solver.viscosity.slice(), time = solver.time;
				solver.plungeHold.fill(0);
				solver.plungeHold.set([
					dt / 2,
					dt * 2,
					-0,
					NaN,
					Infinity
				]);
				const version = ++solver.plungeVersion;
				const originalAge = state.agePlunge;
				let calls = 0;
				state.agePlunge = (elapsed) => {
					calls++;
					assert.equal(elapsed, dt);
					assert.equal(solver.time, time + dt);
					assert(Object.is(state.viscosityPeak, scenario.peak), scenario.label + " peak stored before aging");
					assert.equal(solver.plungeVersion, version);
					originalAge.call(solver, elapsed);
				};
				try {
					solver.adoptDeviceStep(dt);
				} finally {
					state.agePlunge = originalAge;
				}
				assert.equal(calls, 1);
				assert.equal(solver.time, time + dt);
				assert(Object.is(state.viscosityPeak, scenario.peak));
				exact(solver.viscosity, before, scenario.label + " native F64 source bits unchanged");
				assert.equal(solver.plungeHold[0], 0);
				assert.equal(solver.plungeHold[1], dt);
				assert(Object.is(solver.plungeHold[2], -0));
				assert(Number.isNaN(solver.plungeHold[3]));
				assert.equal(solver.plungeHold[4], Infinity);
				assert.equal(solver.plungeVersion, version + 1);
				if (scenario.peak === Infinity) assert.equal(solver.maxStableStep(), 0);
			}
			equal(p, "Direct adoption " + scenario.label);
		}
		for (const [i, actor] of [p.b, p.c].entries()) {
			assert.equal(actor.solver.viscosity, identities[i]);
			assert.equal(actor.solver.plungeHold, holdIdentities[i]);
			actor.solver.viscosity.set(originals[i]);
			actor.solver.plungeHold.set(holds[i]);
			actor.solver.adoptDeviceStep(0);
			assert(Number.isFinite(actor.solver.maxStableStep()) && actor.solver.maxStableStep() > 0);
		}
		await step(p, "Restored valid fields after direct special-value adoption");
		done("direct native F64 peak special values, source bits, identities, time/peak/plunge chronology", p);
	}
	for (const components of [
		1,
		7,
		64
	]) {
		const p = await pair({ components });
		assert(p.b.feed && p.c.feed);
		assert(p.b.feed.deviceShape().slots > 0);
		await step(p, "initial feed C" + components);
		await step(p, "steady feed C" + components);
		assert.equal(p.b.feed.deviceShape().components, components);
		assert.equal(p.c.feed.deviceShape().components, components);
		done("actual SideFeed complete steps C" + components, p);
	}
	{
		const p = await pair();
		await step(p, "initial");
		const feedB = p.b.feed, feedC = p.c.feed, weightsB = feedB.weights.slice(), weightsC = feedC.weights.slice();
		const cell = weightsB.findIndex((w) => w > 0);
		assert(cell >= 0);
		feedB.weights[cell] = 0;
		feedC.weights[cell] = 0;
		await step(p, "public individual weight mutation without invalidation");
		feedB.weights.fill(0);
		feedC.weights.fill(0);
		await step(p, "public all-zero weights without invalidation");
		feedB.weights.set(weightsB);
		feedC.weights.set(weightsC);
		await step(p, "public restored weights without invalidation");
		feedB.weights.fill(0);
		feedC.weights.fill(0);
		p.b.solver.invalidateDeviceLayout();
		p.c.solver.invalidateDeviceLayout();
		await step(p, "zero weights with layout refresh");
		feedB.weights.set(weightsB);
		feedC.weights.set(weightsC);
		await step(p, "restored weights without refresh: retain baseline stale feedSlots oddity");
		p.b.solver.invalidateDeviceLayout();
		p.c.solver.invalidateDeviceLayout();
		await step(p, "restored weights with layout refresh");
		for (const column of [2, -3]) {
			p.b.solver.shiftAlongShore(column);
			p.c.solver.shiftAlongShore(column);
			assert.equal(feedB.deviceShape().components, 7);
			assert.equal(feedC.deviceShape().components, 7);
			await step(p, "window shift" + column);
		}
		feedB.timeOffset += 1.25;
		feedC.timeOffset += 1.25;
		await step(p, "time offset");
		const params = (actor) => {
			const out = /* @__PURE__ */ new ArrayBuffer(actor.arm.PARAM_WORDS * 4), layout = actor.solver.deviceLayout();
			actor.arm.writeParams(actor.solver, layout, {
				boundary: layout.zones[0],
				firstRow: 0,
				rows: 1,
				feed: actor.feed
			}, DT, DT, out);
			return out;
		};
		const before = new Uint32Array(params(p.b))[20];
		assert(before > 0);
		feedB.weights.fill(0);
		feedC.weights.fill(0);
		const b0 = params(p.b), c0 = params(p.c);
		exact(new Uint8Array(b0), new Uint8Array(c0), "exported writeParams remains literal");
		assert.equal(new Uint32Array(b0)[20], 0);
		assert.equal(new Uint32Array(b0)[21], 7);
		done("mutable weights, zero/restored slots, layout/window/time refresh, generic uniforms", p);
	}
	{
		const p = await pair({ zeroBeforeCreate: true });
		await step(p, "initial zero-slot feed");
		await step(p, "steady zero-slot feed");
		p.b.feed.weights.set(p.b.originalWeights);
		p.c.feed.weights.set(p.c.originalWeights);
		await step(p, "restored without layout refresh");
		p.b.solver.invalidateDeviceLayout();
		p.c.solver.invalidateDeviceLayout();
		await step(p, "restored after layout refresh");
		done("zero-slot creation and restoration", p);
	}
	{
		const p = await pair({ spot: "point" });
		assert(!p.b.feed && !p.c.feed);
		await step(p, "no-feed initial");
		await step(p, "no-feed steady");
		done("no-feed supported solver", p);
	}
	{
		const p = await pair();
		for (const actor of [p.b, p.c]) {
			const n = actor.solver.h.length;
			actor.mock.onCompute = () => {
				const f = new Float32Array(actor.mock.buffers[0].bytes);
				f[actor.arm.FIELD.H * n + 3] = 2.125;
				f[actor.arm.FIELD.NU * n + 3] = 100;
				f[actor.arm.FIELD.RATEH * n + 3] = -.125;
			};
			actor.solver.plungeHold[5] = DT / 2;
			actor.solver.plungeVersion++;
		}
		const tb = p.b.solver.time, tc = p.c.solver.time;
		const hb = p.b.solver.h.slice(), hc = p.c.solver.h.slice();
		p.b.mock.clear();
		p.c.mock.clear();
		const rb = await p.b.host.prepareStep(DT), rc = await p.c.host.prepareStep(DT);
		assert(rb && rc);
		assert.equal(p.b.solver.time, tb);
		assert.equal(p.c.solver.time, tc);
		exact(p.b.solver.h, hb, "deferred water unpublished");
		exact(p.c.solver.h, hc, "deferred candidate water unpublished");
		assert.equal(rb.commit(), true);
		assert.equal(rc.commit(), true);
		equal(p, "prepared result commit");
		assert.equal(p.b.solver.h[3], 2.125);
		assert.equal(p.b.solver.viscosity[3], 100);
		assert.equal(p.b.solver.surfaceRiseRate[3], -.125);
		assert.equal(p.b.solver.plungeHold[5], 0);
		await step(p, "next full step after returned peak/clock feedback", p.b.solver.maxStableStep() * 2.1);
		assert(p.b.host.lastSubsteps > 1);
		p.b.mock.clear();
		p.c.mock.clear();
		const db = await p.b.host.prepareStep(DT), dc = await p.c.host.prepareStep(DT);
		assert(db && dc);
		db.discard();
		dc.discard();
		equal(p, "discard");
		await step(p, "rebased layout after discard");
		done("deferred commit, multiple substeps, real adoption feedback, discard/rebase", p);
	}
	{
		const p = await pair();
		await step(p, "before failure");
		const time = p.b.solver.time;
		p.b.mock.failMap = true;
		p.c.mock.failMap = true;
		await assert.rejects(p.b.host.prepareStep(DT), /injected map rejection/);
		await assert.rejects(p.c.host.prepareStep(DT), /injected map rejection/);
		equal(p, "map failure protocol");
		assert.equal(p.b.solver.time, time);
		await step(p, "recovery layout after deferred map failure");
		p.b.host.readback = false;
		p.c.host.readback = false;
		await step(p, "diagnostic no readback");
		assert.equal(p.b.host.diagnostics.unpack, 0);
		done("map rejection, rebase and diagnostic no-readback parity", p);
	}
	const input = heldInput(a.ready), makeHeld = async (arm) => {
		const scene = new arm.SurfZoneSimulation(input.config, "warm"), state = arm.decodeSurfZoneState(input.bytes);
		scene.importState(state);
		assert(scene.solver instanceof arm.BoussinesqSolver);
		assert.equal(scene.solver.h.length, 116e3);
		assert.equal(scene.seaTime, input.authority.pausedSeaTime);
		const mock = new RecordingGpu(true, false), solver = scene.solver, host = await arm.GpuBoussinesq.create(solver, mock.gpu);
		assert(host);
		live.push(host);
		return {
			arm,
			scene,
			solver,
			feed: solver.relaxationZones.find((z) => z instanceof arm.SideFeed),
			mock,
			host,
			originalWeights: void 0,
			identities: arm.DEVICE_READBACK.map((i) => arm.readbackTarget(solver, i))
		};
	};
	const held = {
		b: await makeHeld(a.baseline),
		c: await makeHeld(a.candidate)
	};
	assert(held.b.feed.deviceShape().slots > 0);
	assert.deepEqual(held.b.mock.events, held.c.mock.events);
	await step(held, "actual imported held initial");
	await step(held, "actual imported held steady");
	report.actualHeld = {
		...input.authority,
		cells: 116e3,
		components: 64,
		allQueuePayloadHashesAndStateBitsExact: true,
		noWgslExecution: true
	};
	done("actual retained ordinary-size complete host protocol", held);
	a.check();
	report.valid = true;
	report.scope = "Literal canonical versus one adoptDeviceStep indexed-loop candidate. Queue and host protocol only; no numerical WGSL/GPU/render/FPS validation.";
	const payload = save();
	writeFileSync(join(OUT, "terminal.json"), JSON.stringify({
		valid: true,
		readySha256: a.readySha,
		inputPinsUnchanged: true,
		report: payload
	}, null, 2) + "\n");
	console.log(JSON.stringify({
		valid: true,
		cases: report.cases.length,
		report: payload
	}));
} catch (error) {
	report.strictStop = true;
	report.firstFailure = String(error);
	const payload = save();
	writeFileSync(join(OUT, "terminal.json"), JSON.stringify({
		valid: false,
		strictStop: true,
		error: String(error),
		report: payload
	}, null, 2) + "\n");
	process.exitCode = 1;
	console.error(String(error));
} finally {
	for (const h of live) h.dispose();
	restore();
}
//#endregion
export {};
