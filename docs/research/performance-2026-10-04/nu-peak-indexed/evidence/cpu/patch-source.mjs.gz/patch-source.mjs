// Source-only one-loop transform; preserve original clock/peak/plunge order.
import assert from 'node:assert/strict';
export function candidateSource(source) {
  const before = '    for (const nu of this.viscosity) if (nu > peak) peak = nu;';
  const after = '    const viscosity = this.viscosity;\n    for (let i = 0; i < viscosity.length; i += 1) if (viscosity[i] > peak) peak = viscosity[i];';
  assert.equal(source.split(before).length - 1, 1, 'Unique canonical adoptDeviceStep loop');
  return source.replace(before, after);
}
