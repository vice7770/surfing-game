#!/usr/bin/env python3
"""Root-only reviewed four-arm lease,715s command+5s owned process-group cleanup."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, signal, subprocess, sys, time
W=Path('/private/tmp/surf-nu-peak-fps-20261004')
started=time.monotonic()
child=None
def hard_stop(signum, frame):
 if child is not None:
  try: os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError: pass
 # Keep all partial evidence; an unconditional OS alarm owns the12m boundary.
 os._exit(124)
def now(): return datetime.now(timezone.utc).isoformat()
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p): return json.loads(p.read_text())
def verify(pin):
 actual=rec(Path(pin['path']));assert actual==pin,pin['path'];return actual
args={}
for value in sys.argv[1:]:
 assert value.startswith('--') and '=' in value,'Use --name=value'
 key,text=value[2:].split('=',1);assert key not in args,'Duplicate arg';args[key]=text
assert set(args)<= {'run','out'} and args.get('run') in [None,'false','true']
if args.get('run')!='true':
 print(json.dumps({'planOnly':True,'plan':read(W/'plan.json'),'commandSeconds':715,'cleanupSeconds':5,'processGroupOwned':True,'browserStarted':False,'serverStarted':False}));sys.exit(0)
signal.signal(signal.SIGALRM,hard_stop)
signal.setitimer(signal.ITIMER_REAL,max(.001,720-(time.monotonic()-started)))
ready=rec(W/'ready.json');assert ready['sha256']==os.environ['NU_PEAK_FPS_READY_SHA256']
self_ready=rec(W/'native-driver-ready.json');assert self_ready['sha256']==os.environ['NU_PEAK_FPS_NATIVE_DRIVER_READY_SHA256']
meta=read(W/'native-driver-ready.json');assert meta['sourceReady']==ready and meta['executed'] is False
verify(meta['driver']);verify(meta['coordinator']);verify(meta['plan'])
bindings=rec(W/'bindings.json');assert bindings['sha256']==os.environ['NU_PEAK_FPS_BINDINGS_SHA256']
assert read(W/'checks/terminal.json')['status']=='passed','Reviewed CPU gate must pass first'
assert read(W/'bindings.json')['buildReady']==ready
out=Path(args.get('out',str(W/'run'))).resolve();assert out.is_relative_to(W) and out!=W and not out.exists(),'Fresh owned run output'
wrapper=out.parent/(out.name+'.native-driver.json');log=out.parent/(out.name+'.native-driver.log')
assert not wrapper.exists() and not log.exists() and out.parent.is_dir(),'Fresh owned wrapper/log output'
terminal={'schema':'nu-peak-fps-native-driver/v1','valid':False,'startedAt':now(),'ready':ready,'driverReady':self_ready,'bindings':bindings,'commandSeconds':715,'cleanupSeconds':5,'wholeSeconds':720,'command':['node',str(W/'pair.mjs'),'--run=true','--out='+str(out)],'rootPid':os.getpid(),'firstFailure':None}
def save(): wrapper.write_text(json.dumps(terminal,indent=2)+'\n')
save()
try:
 with log.open('xb') as stream:
  child=subprocess.Popen(terminal['command'],cwd=W,env=os.environ.copy(),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  terminal['ownedProcessGroup']=child.pid;terminal['childPid']=child.pid;save();print(json.dumps({'stage':'START','pid':child.pid,'ports':[4247,9657,4248,9658,4249,9659,4250,9660],'wrapper':str(wrapper),'log':str(log)}),flush=True)
  try: terminal['exitCode']=child.wait(timeout=max(.001,715-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:
   terminal['timedOut']=True
   try: os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError: pass
   try: terminal['exitCode']=child.wait(timeout=max(.001,719-(time.monotonic()-started)))
   except subprocess.TimeoutExpired:
    try: os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError: pass
    terminal['exitCode']=child.wait(timeout=max(.001,720-(time.monotonic()-started)))
  assert terminal['exitCode']==0 and not terminal.get('timedOut'),'First native command failure; no retry'
 result=read(out/'report.json');assert result['valid'] is True and result['incomplete'] is False and len(result['arms'])==4
 assert [r['id'] for r in result['arms']]==['AB-baseline','AB-candidate','BA-candidate','BA-baseline']
 assert all(r['valid'] and r['cdpClosure']['closed'] is True and r['serverClosure']['closed'] is True and r['port4200End']['closed'] is True and r['elapsedSeconds']<=180 and r['cleanupElapsedSeconds']<=5 for r in result['arms'])
 assert time.monotonic()-started<=720,'Whole native comparison exceeded12m'
 terminal['report']=rec(out/'report.json');terminal['valid']=True
except BaseException as error:
 terminal['firstFailure']=str(error)
 if child is not None:
  # This fresh start_new_session group contains only the spawned coordinator/surveys/Chrome.
  try: os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError: pass
finally:
 terminal['endedAt']=now();terminal['elapsedSeconds']=time.monotonic()-started;terminal['log']=rec(log) if log.exists() else None;save();print(json.dumps(terminal),flush=True)
signal.setitimer(signal.ITIMER_REAL,0)
sys.exit(0 if terminal['valid'] else 1)
