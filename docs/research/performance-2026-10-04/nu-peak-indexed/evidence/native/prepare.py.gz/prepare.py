"""Source bytes/metadata only; no transform/runtime imports, checks, build or browser."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, difflib
W = Path('/private/tmp/surf-nu-peak-fps-20261004')
assert not (W/'ready.json').exists(), 'Frozen source-ready closure must not be rewritten'
P = Path('/private/tmp/surf-feed-indexed-fps-20261004')
N = Path('/private/tmp/surf-nu-peak-indexed-20261004')
R = Path('/Users/regina/Desktop/Projects/surfing-game')
BASE = 'b0e003b8670c9d0be83bc9bb24c30b5382a54499'
def rec(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p): return json.loads(p.read_text())
def save(name,value): (W/name).write_text(json.dumps(value,indent=2)+'\n')
def rename(text): return text.replace(str(P),str(W)).replace('FEED_INDEXED_FPS','NU_PEAK_FPS').replace('feed-indexed','nu-peak')
assert rec(P/'ready.json')['sha256']=='61edfddf81a246ba51a15da257638adb447b464e73c09be58e6b67506c6ba2d9'
assert rec(N/'ready.json')['sha256']=='0e421b1a74f6cd5f2b641138d2a3923270b40012cfc9575ec4c19ccadba4d8df'
for name in ['survey.mjs','native-owned.mjs','passive-guard.mjs','public-assets.json']:
 (W/name).write_bytes((P/name).read_bytes())
target=R/'src/wave/BoussinesqSolver.ts'; original=target.read_text()
before='    for (const nu of this.viscosity) if (nu > peak) peak = nu;'
after='    const viscosity = this.viscosity;\n    for (let i = 0; i < viscosity.length; i += 1) if (viscosity[i] > peak) peak = viscosity[i];'
assert original.count(before)==1
virtual=original.replace(before,after)
virtual_pin={'bytes':len(virtual.encode()),'sha256':hashlib.sha256(virtual.encode()).hexdigest()}
assert virtual_pin=={'bytes':38627,'sha256':'c1d87564677e35ece932831139426e31f19b69490d961dccaf8b8e665e3e0910'}
assert rec(target)['sha256']=='66cdbb3eb83f7d03ade33c11a429889b217d3b81cd6246b6dd5006a40b0e5d79'
assert rec(N/'patch-source.mjs')['sha256']=='234a4c1e24ca1a8c11d3851f581bdb5226235e5bec67601f6568d09921e6325c'
gpu=rec(R/'src/wave/gpu/GpuBoussinesq.ts'); side=rec(R/'src/wave/SideFeed.ts')
assert gpu['sha256']=='41e212604f0d7b889445edb17a05f38edf5044f66dceaa9eddaee4ebf69d8094'
assert side['sha256']=='ebdfb6924197f5ae59ed0f56bff1121622bf687fd28d0985b9fd2f26980efabd'
spec={'path':str(target),'relativePath':'src/wave/BoussinesqSolver.ts','original':rec(target),
 'transform':rec(N/'patch-source.mjs'),'virtualCandidate':virtual_pin,'editCount':1,
 'mode':'one virtual canonical readFile/load substitution; no source tree clone',
 'scope':'Only adoptDeviceStep viscosity strict-greater peak scan: local alias and ascending indexed native Float64Array scan; peak0/time/peak/plunge chronology preserved',
 'componentCacheAndSideFeedIndexExcluded':True,'canonicalGpuUnchanged':gpu,'canonicalSideFeedUnchanged':side,
 'classPrefixPreserved':True,'supportedArrays':'Constructor-owned ordinary non-detached Float64Array; customized iterators/prototypes/replacement excluded'}
borrow_source=read(P/'source-manifest.json'); assert borrow_source['baseline']==BASE
assert all(a['fileCount']==554 and len(a['files'])==554 for a in borrow_source['arms'])
save('source-manifest.json',{'schema':'nu-peak-fps-source/v1','baseline':BASE,'commonBuildId':'306258296',
 'canonicalSourceAuthority':rec(P/'source-manifest.json'),
 'sourceCheckpointAuthority':borrow_source['sourceCheckpointAuthority'],
 'arms':[{'arm':a,'root':str(R),'fileCount':554,'effectiveSourceMode':'literal canonical' if a=='baseline' else 'same literal closure plus single Boussinesq virtual transform'} for a in ['baseline','candidate']],
 'onlyRuntimeDifference':spec,'sourceBytePreparationOnly':True,'noSourceClones':True,'borrowedFilesReadOnly':True})
reuse=read(P/'baseline-reuse.json'); reuse['schema']='nu-peak-fps-baseline-reuse/v1'; save('baseline-reuse.json',reuse)
dep=read(P/'dependency-authority.json'); dep['schema']='nu-peak-fps-dependencies/v1'; dep['sourceOnlyBorrow']=rec(P/'dependency-authority.json'); save('dependency-authority.json',dep)
for name in ['authority.mjs','strict.mjs','build-only.mjs','bind-launch.py','checks-driver.py']:
 text=rename((P/name).read_text())
 if name=='authority.mjs':
  anchor='export function captureAuthority(){'
  resolve_source="""export function source(){
 const own=json(join(WORK,'source-manifest.json'));verify(own.canonicalSourceAuthority.path,own.canonicalSourceAuthority);
 const borrowed=json(own.canonicalSourceAuthority.path);assert.equal(borrowed.baseline,own.baseline);
 return {...own,arms:own.arms.map(arm=>{const old=borrowed.arms.find(a=>a.arm===arm.arm);assert(old&&old.root===arm.root&&old.fileCount===554&&old.files.length===554);return {...arm,files:old.files};})};
}
"""
  assert text.count(anchor)==1; text=text.replace(anchor,resolve_source+anchor)
  text=text.replace("source=json(join(WORK,'source-manifest.json'))","resolved=source()")
  text=text.replace('for(const arm of source.arms)','for(const arm of resolved.arms)')
 elif name in ['strict.mjs','build-only.mjs']:
  text=text.replace(str('/private/tmp/surf-nu-peak-scan-20261004/patch-source.mjs'),str(N/'patch-source.mjs'))
  text=text.replace('captureAuthority }','captureAuthority,source as resolvedSource }')
  text=text.replace("source=json(join(WORK,'source-manifest.json'))","source=resolvedSource()")
  text=text.replace('source=json(sourcePath)','source=resolvedSource()')
  text=text.replace('export class SideFeed','export class BoussinesqSolver')
  text=text.replace('single-reviewed-indexed-side-feed-source-','single-reviewed-indexed-nu-peak-source-')
  text=text.replace('Canonical SideFeed candidate','Canonical Boussinesq candidate')
 elif name=='checks-driver.py':
  anchor="    assets = read(W / 'public-assets.json'); dependency = read(W / 'dependency-authority.json')"
  replacement="""    verify(source['canonicalSourceAuthority'])
    canonical = read(source['canonicalSourceAuthority']['path'])
    assert canonical['baseline'] == source['baseline']
    for arm in source['arms']:
        old = next(a for a in canonical['arms'] if a['arm'] == arm['arm'])
        assert old['root'] == arm['root'] and old['fileCount'] == arm['fileCount'] == 554
        arm['files'] = old['files']
"""+anchor
  assert text.count(anchor)==1; text=text.replace(anchor,replacement)
 (W/name).write_text(text)
 (W/(name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),text.splitlines(True),fromfile=str(P/name),tofile=str(W/name))))
# One coordinator, with the same ordinary survey and owned resource checks.
text=rename((P/'pair.mjs').read_text())
text=text.replace('// QA-only serial passive pair.','// QA-only predeclared serial AB then BA passive comparison.')
text=text.replace("import { sleep, tcpProof } from './native-owned.mjs';","import { sleep, tcpProof } from './native-owned.mjs';\nimport { source as resolvedSource } from './authority.mjs';\nconst processStarted = Date.now();")
text=text.replace('const source = json(bindings.sourceManifest.path)','const source = resolvedSource()')
text=text.replace("schema: 'nu-peak-passive-pair/v1'","schema: 'nu-peak-passive-four-arms/v1'")
text=text.replace("const slots = [{ name: 'baseline', port: 4243, cdp: 9653 }, { name: 'candidate', port: 4244, cdp: 9654 }];", "const slots = [{ id: 'AB-baseline', order: 'AB', name: 'baseline', port: 4247, cdp: 9657 }, { id: 'AB-candidate', order: 'AB', name: 'candidate', port: 4248, cdp: 9658 }, { id: 'BA-candidate', order: 'BA', name: 'candidate', port: 4249, cdp: 9659 }, { id: 'BA-baseline', order: 'BA', name: 'baseline', port: 4250, cdp: 9660 }];\nassert.deepEqual(slots, plan.arms.map(({id,order,name,port,cdp}) => ({id,order,name,port,cdp})), 'Predeclared four slots must stay exact');")
text=text.replace("const root = join(OUT, slot.name); mkdirSync(root);","const root = join(OUT, slot.id); mkdirSync(root);")
text=text.replace('const row = { arm: slot.name,','const row = { id: slot.id, order: slot.order, arm: slot.name,')
text=text.replace("  let child, server, deadline, commandLog, abortOperation;","  let child, server, deadline, commandLog, abortOperation, aborted = false;\n  const assertActive = () => assert(!aborted && Date.now() - processStarted < 715000, 'Whole comparison abort; cleanup only');")
text=text.replace("  try {\n    row.port4200", "  try {\n    if (baselinePath) { const reference = json(baselinePath); assert.equal(reference.valid, true); assert.equal(reference.nativeAudit.valid, true); assert.equal(reference.results.length, 1); assert.equal(reference.results[0].ordinaryConfigMatches, true); row.nativeSettingsReference = record(baselinePath); row.referencePurpose = 'Native tuple/settings equality only; no metric reuse'; }\n    const abortDelay = Math.max(1, Math.min(175000 - (Date.now() - started), 715000 - (Date.now() - processStarted)));\n    deadline = setTimeout(() => { aborted = true; row.hardDeadline = '175s arm or715s whole command bound; cleanup only'; child?.kill('SIGTERM'); abortOperation(Error('Hard command deadline; no retry')); }, abortDelay);\n    return await Promise.race([operationFailure, (async () => {\n    assertActive();\n    row.port4200")
text=text.replace("    server = createServer", "    assertActive();\n    server = createServer")
text=text.replace("    for (const pin of manifest.outputRecords) {\n      const response", "    assertActive();\n    for (const pin of manifest.outputRecords) {\n      assertActive();\n      const response")
text=text.replace("      row.compiledServed.push", "      assertActive();\n      row.compiledServed.push")
text=text.replace("    const fps = join(root, 'fps.json');", "    assertActive();\n    const fps = join(root, 'fps.json');")
start=text.index('    const remaining = Math.max(1, 175000 - (Date.now() - started));')
end=text.index('    console.log(JSON.stringify({ stage:',start)
text=text[:start]+text[end:]
text=text.replace('Promise.race([hardDeadline, operationFailure,','Promise.race([operationFailure,')
text=text.replace("stage: 'START', arm: slot.name", "stage: 'START', id: slot.id, order: slot.order, arm: slot.name")
text=text.replace('    clearTimeout(deadline); commandLog.end(); row.terminal = terminal;','    commandLog.end(); row.terminal = terminal; assertActive();')
text=text.replace('    return fps;\n  } catch', "    if (row.nativeSettingsReference) verify(row.nativeSettingsReference.path, row.nativeSettingsReference);\n    return fps;\n    })()]);\n  } catch")
text=text.replace('    clearTimeout(deadline);\n    if (child', "    clearTimeout(deadline); aborted = true;\n    const cleanupStarted = Date.now();\n    if (child")
text=text.replace('Date.now() - started <= 180000;', 'Date.now() - started <= 180000 && Date.now() - cleanupStarted <= 5000 && Date.now() - processStarted <= 720000;\n    row.cleanupElapsedSeconds = (Date.now() - cleanupStarted) / 1000;')
old="""  const baseline = await runArm(slots[0]); assert.equal(report.arms[0].valid, true, 'Baseline cleanup invalid; candidate prohibited');
  await runArm(slots[1], baseline); assert.equal(report.arms[1].valid, true);
  report.valid = true; report.incomplete = false;"""
new="""  const baseline = await runArm(slots[0]); assert.equal(report.arms[0].valid, true, 'AB baseline invalid or not fully closed; stop');
  await runArm(slots[1], baseline); assert.equal(report.arms[1].valid, true, 'AB candidate invalid or not fully closed; stop');
  const reverseCandidate = await runArm(slots[2], baseline); assert.equal(report.arms[2].valid, true, 'BA candidate invalid or not fully closed; stop');
  await runArm(slots[3], reverseCandidate); assert.equal(report.arms[3].valid, true, 'BA baseline invalid or not fully closed; stop');
  assert(Date.now() - processStarted <= 720000, 'Whole comparison12m bound');
  report.valid = true; report.incomplete = false;"""
assert old in text; text=text.replace(old,new)
text=text.replace("finally { report.endedAt", "finally { report.elapsedSeconds = (Date.now() - processStarted) / 1000; report.endedAt")
(W/'pair.mjs').write_text(text)
(W/'pair.mjs.diff').write_text(''.join(difflib.unified_diff((P/'pair.mjs').read_text().splitlines(True),text.splitlines(True),fromfile=str(P/'pair.mjs'),tofile=str(W/'pair.mjs'))))
commands=read(P/'commands.json'); commands=json.loads(rename(json.dumps(commands)))
commands['hardwareEntry']=['python3','native-driver.py','--run=true','--out=<fresh owned path>']
commands['hardwareBoundSecondsIncludingCleanup']=720; commands['hardwareCommandBudgetSeconds']=715; commands['hardwareCleanupSeconds']=5
commands['hardwareEnvironment'] += ['NU_PEAK_FPS_NATIVE_DRIVER_READY_SHA256=<reviewed native driver readiness>']
save('commands.json',commands)
plan=json.loads(rename(json.dumps(read(P/'plan.json'))))
plan['schema']='nu-peak-passive-four-arm-plan/v1'; plan['purpose']='Predeclared AB and BA orders for only exact indexed NU peak scan; one candidate compilation, literal b0 baseline, no cache or SideFeed index'
plan['arms']=[{'id':i,'order':o,'name':n,'port':p,'cdp':c,'url':f'http://127.0.0.1:{p}/?diagnostics','manifest':str(W/n/'build-manifest.json'),'internalSoloOneStep':True,'condition':'All earlier arms valid and fully closed' if p!=4247 else 'All owned ports closed'} for i,o,n,p,c in [('AB-baseline','AB','baseline',4247,9657),('AB-candidate','AB','candidate',4248,9658),('BA-candidate','BA','candidate',4249,9659),('BA-baseline','BA','baseline',4250,9660)]]
plan['stage']='source-only; checks/build/browser unexecuted'
plan['schedule'].update(wholeComparisonSecondsIncludingCleanup=720,wholeCommandAbortSeconds=715,orders=['AB','BA'],rebuildBetweenOrders=False)
plan['failure']='Stop first guard/command/serving/authority/cleanup failure; no later arm, repair or retry. Each175s command/5s cleanup; whole715s command/5s process-group cleanup. Only owned survey/Chrome/server PIDs/ports may close;4200 stays closed;5173 untouched.'
plan['limits']=['Both fixed orders retained; independent sessions/wall bins are not phase-matched, thermal or causal proof','Only virtual BoussinesqSolver.adoptDeviceStep NU loop changes; GPU/SideFeed/cache/shaders/grid/contact/prefetch/renderer literal b0','Prior complete mock-host cost is not physical evolution or native FPS evidence','No checks/builds/imports/network/browser executed by source preparer; separate root CPU and exclusive native lease required']
plan['proposedBuild']['sourceStrategy']='Borrowed canonical554-file closure, pinned single BoussinesqSolver virtual transform in main/worker plugin factories; original imports/GPU/SideFeed preserved'
plan['proposedBuild']['sourceFiles']=[554,554]
plan['proposedHardwareCommand']={'command':'env NU_PEAK_FPS_READY_SHA256=<reviewed> NU_PEAK_FPS_BINDINGS_SHA256=<reviewed> NU_PEAK_FPS_NATIVE_DRIVER_READY_SHA256=<reviewed> python3 native-driver.py --run=true --out=<fresh owned path>','requires':'Root CPU/compiled binding review and separately granted exclusive native lease'}
plan.pop('indexedSideFeedScope');plan['nuPeakScope']={'runtimeSource':spec,'parentReady':rec(N/'ready.json'),'proofAndCost':'Root passed separate10-case proof and32-pair mock-host cost; retained original gates, no rerun in native package','nativeResultPending':True}
plan['referencePolicy']={'AB-candidate':'Produced valid fully closed AB-baseline','BA-candidate':'Same produced AB-baseline native tuple/settings only','BA-baseline':'Produced valid fully closed BA-candidate','statisticsOrHistoryReuse':False}
plan['remainingChecks']=['root source review','whole-project strict','candidate Vite build','bindings','four syntax checks','unarmed coordinator','compiled review','exclusive native lease']
plan['proposedChecksBeforeHardware']=['Whole-project Boussinesq virtual-readFile TypeScript strict','Candidate-only Vite build and local compiled binding','Four Node syntax checks and unarmed four-arm coordinator','Separate compiled review and exclusive native lease; existing NU CPU proof/cost retained without rerun']
plan['proposedBuild']['flags']['outDir']=str(W/'candidate/dist');plan['proposedBuild']['flags']['cacheDir']=str(W/'.cache/vite-build');plan['cachePolicy']['vite']['path']=str(W/'.cache/vite-build')
save('plan.json',plan)
# Reuse pins from old manifests; hash only small source/metadata at preparation.
borrow=[rec(P/name) for name in ['ready.json','freeze.json','source-manifest.json','baseline-reuse.json','dependency-authority.json','survey.mjs','native-owned.mjs','passive-guard.mjs','public-assets.json','pair.mjs','pair-reversed.mjs','authority.mjs','strict.mjs','build-only.mjs','checks-driver.py','bind-launch.py','bindings.json','checks/terminal.json']]
borrow += [rec(N/name) for name in ['ready.json','patch-source.mjs','proposal.md','root-checks/terminal.json','root-proof-first/terminal.json','proof-first/terminal.json','proof-first/report.json','root-cost-first/terminal.json','cost-first/terminal.json','cost-first/report.json']]
borrow += [reuse[k] for k in ['originalCompilation','originalTerminal','sourceAfter','buildFlagsAuthority']]
save('borrowed-authorities.json',{'schema':'nu-peak-fps-borrowed/v1','records':borrow,'runtimeComposition':False,'parentIndexedAndComponentCacheCandidatesExcluded':True,'sourceClosure':'Only original file rows from parent manifest; parent virtual SideFeed specification is not used','physicalCaptureNotUsedByNativeRun':True})
save('derivation.json',{'schema':'nu-peak-fps-derivation/v1','sourceOnly':True,'parentReady':rec(P/'ready.json'),'exactCopies':[{'borrowed':rec(P/name),'owned':rec(W/name),'byteIdentical':True} for name in ['survey.mjs','native-owned.mjs','passive-guard.mjs','public-assets.json']], 'sourceDiffs':[rec(W/(name+'.diff')) for name in ['authority.mjs','strict.mjs','build-only.mjs','bind-launch.py','checks-driver.py','pair.mjs']],'singleRuntimeTransform':spec,'inheritedInternalEnvironmentKeys':['FULL_WRITER_FPS_LAUNCHER_REPORT','FULL_WRITER_FPS_EXPECTED_WORKER','FULL_WRITER_FPS_EXPECTED_SOLO_ONE_STEP']})
print(json.dumps({'sourcePreparationOnly':True,'runtimeDifference':spec,'ownedFilesSoFar':len(list(W.iterdir()))},indent=2))
