# Bounded next gates — not executed/authorized by this file

## Source pins / first proposed CPU operation

Reference accepted runtime e3e630bc45339e0f7564e59cfdd556275c06de92; current production remains untouched. Work directory: `/private/tmp/surf-aeration-empty-neighborhood-20261004`. Exactly three candidate runtime files differ. Source/readiness manifest pins literal dependency closure plus one WebGPU ambient type declaration, prepared test/config/proposal bytes, and read-only-use links. It does not claim a new Big trajectory or native visual proof.

Proposed commands, STRICT FIRST then26 portable cases, sequential, stop the first terminal failure; preserve source before/after and separate UTC/argv/PID/stdout/stderr/exit logs:

```
node node_modules/typescript/bin/tsc --project tsconfig.qa.json --noEmit
node node_modules/vitest/vitest.mjs run tests/parity.test.ts --config=vitest.config.ts --maxWorkers=1
```

26 written focused cases; 5s per-case existing default bound, one worker. Vite cacheDir is explicitly scratch/.cache/vite, never shared node_modules/.vite. The prepared checks-driver.py grants120s total command budget, stop-first-failure, then bounded owned-child cleanup and source-after verification. Invocation after parent review: AERATION_EMPTY_READY_SHA256=<new ready SHA> python3 checks-driver-v2.py --run=true. No other suite. No automatic fix/retry or numerical cost run follows merely because checks pass. All source is unexecuted preparation at freeze.

## One prospective complete-chain CPU cost gate

Prepare exact harness/compiled authority for parent review after parity, before execution. Borrow existing retained F32 post-state SET1 source: `docs/research/performance-2026-10-03/render-scale/baseline-held-source.json.gz` (gzip95f3937160eff73a9c751fcbdc2246a811978b49be7dbbda0e56ed9dea69e584; JSON8e73b4d10d268081891d0bf89b93c6706b37617a6bea5543af443d6963443587; rawSET138b63fbe297eeb143c6449902855be39802455d4f14d540a07d152ead7ec32e0). Reuse the corrected decoder design, `new Uint8Array(raw)` followed by independent DataView raw-offset/word checks; never pass Node Buffer.slice as owning codec bytes. These are inherited expected pins, not a new decoded material scan in this source-only preparation.

The same supplied actual config (seed8761/Hs3.8/T18/dir0/spread150/C64/dx2/fine1) gives116000 physical cells and original spacing2 render grid. Both arms construct their own real Simulation/classes, import the exact state, and run unchanged BreakingModel.update(0). No ProfileLibrary/front/crash/water replay or spin-up. This is a **controlled subsequent update from captured F32 post-state into current e3**, not the historical pre-degas state, a live late-Big trajectory, or an actual recorded gated-strength fixture. TKE is not serialized; normal import clears it. Unexported SweptCrash-gated whitewater remains unavailable: unchanged breaking strength is the explicitly declared source proxy. This fixture limitation prevents claiming a representative steady Big FPS saving.

Whole timer: original/candidate actual Foam.update → unchanged actual private aerateBores callbacks → generic/owner Air.update → fused writeUniformSnapshot to reused buffers. Include all source-call native/owner guards, mark writes, any window processing or reseed, interpolation, all three array copies, final tags, unchanged finish/degas, and snapshot work. Do not report reduced reads or interpolation-only time as a complete improvement. No h/q/time advance, body/contact/particles/page/GPU included; label exactly CPU material+snapshot chain.

One bounded operation,20s total including intake/setup/checks,12 matched warmup pairs then24 measured adjacent AB/BA pairs (balanced12 each). Evolve both material fields by the same dt1/60 each pair rather than restoring hidden tags outside timing. Both start with import-invalidated tags; retain first-call restore/reseed timing and counters as a labeled setup row in the same operation. No per-pair large exported state allocations. Source event order and all source checks are timed. Use preallocated output buffers and native exact-byte comparison with failure-only messages after each pair. No success-message flood inside sampling.

A small explicit dense-TKE counterfactual can be included as a *separately labeled second fixture* in this same predeclared20s operation: apply the same TKE positive value to both actors using a declared import-equivalent QA write plus invalidation, with its first reseed inside the timed call.12 warmup+24 balanced pairs again. This tests whether the tag/guard cost makes dense behavior slower. Count total measurement rows48, warm pairs24, initial labeled reseed pairs2 (148 chain calls). If parent wants only one fixture, settle that count before harness freeze; no dynamic expansion after results.

Exact gates after every pair: all air/depth/TKE and private next/stirred arrays; foam dense/residual/source/dissipation/source/breaking index *capacity and tails* plus counts; source strengths; consumed stencil data/descriptors/identity and single-use readiness; held solver h/bed/qx/qz/centers/dz bytes, clocks and array identities; source caches/window; all reused surface/flow/aeration snapshot bytes. Include identical aggregate air/plume/TKE checks for interpretation, while byte parity remains the acceptance test. Assert no water steps occurred and report actual dt/phase/cell/grid values.

Report wet/skipped destinations, final active-tag occupancy, source calls, actual guard invocations, injection marks, window shifts and reseeds, alongside complete chain paired median/mean, positive pair count and AB-versus-BA rows. **Every prepareMutation guard stays in the timer.** A negative or negligible complete result ends this candidate; no larger cache/owner framework, further repetitions or FPS/GPU trial is implied.

Portable import/window/callback ownership cases are covered by the proposed focused tests, not manufactured steady results. All historical rejected foam fusion/coarsening/zero shortcuts and exp-cache evidence stays unchanged.

## Reviewed fixture-only correction before a separate retry

The first strict check stopped at FreshFoam(water) missing its required decay argument; Vitest did not run. The initial-substituted-Math import case now supplies the same {dense:3,residual:20} used by the other actors. All assertions, runtime/eligibility and test count are unchanged. First inputs and logs remain under checks/, including first-inputs/. The separate prepared checks-driver-v2.py writes fresh checks-v2/ and retains the original bounds/order; no retry has been executed at this source freeze.
