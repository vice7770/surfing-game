import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { gunzipSync, inflateSync } from "node:zlib";
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/dispersion.ts
/** Linear (Airy) water-wave dispersion, ω² = g k tanh(kh), in SI units. */
const GRAVITY$1 = 9.81;
/**
* Explicit wavenumber from Guo (2002), exact in both limits and within 0.8 %
* of the dispersion root at every depth. Cheap enough for per-cell use.
* `depth` is still-water depth in metres; Infinity means deep water.
*/
function waveNumber(omega, depth, g = GRAVITY$1) {
	if (!(depth > 0)) throw new RangeError(`Water depth must be positive, got ${depth}`);
	const deep = omega * omega / g;
	if (!Number.isFinite(depth)) return deep;
	const x = deep * depth;
	const y = omega * Math.sqrt(depth / g);
	return x * Math.pow(1 - Math.exp(-Math.pow(y, 2.5)), -.4) / depth;
}
/** Exact dispersion root by Newton iteration from the Guo estimate, for setup-time use. */
function exactWaveNumber(omega, depth, g = GRAVITY$1) {
	let k = waveNumber(omega, depth, g);
	if (!Number.isFinite(depth)) return k;
	for (let iteration = 0; iteration < 20; iteration += 1) {
		const tanh = Math.tanh(k * depth);
		const residual = g * k * tanh - omega * omega;
		const slope = g * tanh + g * k * depth * (1 - tanh * tanh);
		const next = k - residual / slope;
		if (Math.abs(next - k) <= 1e-15 * k) return next;
		k = next;
	}
	return k;
}
function waveKinematics(period, depth, g = GRAVITY$1) {
	const omega = 2 * Math.PI / period;
	const k = exactWaveNumber(omega, depth, g);
	const kh = k * depth;
	const n = Number.isFinite(kh) ? .5 * (1 + 2 * kh / Math.sinh(2 * kh)) : .5;
	const phaseSpeed = omega / k;
	return {
		k,
		wavelength: 2 * Math.PI / k,
		phaseSpeed,
		groupSpeed: n * phaseSpeed,
		kh
	};
}
/** Passyworld/Sandwell classes: deep above L/2, shallow below L/20. */
function depthClass(depth, wavelength) {
	const ratio = depth / wavelength;
	if (ratio > .5) return "deep";
	if (ratio < 1 / 20) return "shallow";
	return "transitional";
}
/** Non-dispersive shallow-water wavenumber k = ω/√(gh), consistent with the stage 1 solver. */
function shallowWaterWaveNumber(omega, depth, g = GRAVITY$1) {
	if (!(depth > 0) || !Number.isFinite(depth)) throw new RangeError(`Shallow-water waves need a finite positive depth, got ${depth}`);
	return omega / Math.sqrt(g * depth);
}
/** Linear shoaling from deep water to depth h at period T: K_s = √(c_g∞ / c_g(h)), c_g∞ = gT/4π (the wave-sizes spec). */
function shoalingCoefficient(period, depth, g = GRAVITY$1) {
	return Math.sqrt(g * period / (4 * Math.PI) / waveKinematics(period, depth, g).groupSpeed);
}
/** Group speed dω/dk for any dispersion, by central difference in ω, m/s. */
function groupSpeed(waveNumberAt, omega, depth) {
	const step = omega * 1e-4;
	return 2 * step / (waveNumberAt(omega + step, depth) - waveNumberAt(omega - step, depth));
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/random.ts
/** Deterministic mulberry32 stream; `salt` separates independent streams drawn from one seed. */
function seededRandom(seed, salt = 0) {
	let value = (seed ^ salt) >>> 0;
	return () => {
		value = value + 1831565813 >>> 0;
		let t = value;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/SeaState.ts
const JONSWAP_GAMMA = 3.3;
/** JONSWAP spectral shape without the α g² scale, which fromSpectrum normalizes to Hs. */
function jonswapShape(omega, peakOmega, gamma = JONSWAP_GAMMA) {
	if (!(omega > 0)) return 0;
	const sigma = omega <= peakOmega ? .07 : .09;
	const r = Math.exp(-((omega - peakOmega) ** 2) / (2 * sigma * sigma * peakOmega * peakOmega));
	return Math.pow(omega, -5) * Math.exp(-1.25 * Math.pow(peakOmega / omega, 4)) * Math.pow(gamma, r);
}
/** Gaussian dispersion window exp(−(ω/ω_p − 1)² / 2w²); 1 everywhere for a non-finite width. */
function bandwidthWindow(omega, peakOmega, bandwidth = Infinity) {
	if (!Number.isFinite(bandwidth)) return 1;
	const offset = omega / peakOmega - 1;
	return Math.exp(-(offset * offset) / (2 * bandwidth * bandwidth));
}
/** Frequency range the spectrum is sampled over, as multiples of ω_p. */
const SPECTRUM_RANGE = {
	low: .5,
	high: 4
};
/** Draws of a direction that points offshore before one is clamped to shoreward travel (never reached at the game's spreads). */
const MAX_REDRAWS = 64;
/** The most oblique shoreward direction a clamped draw takes, rad. */
const SHOREWARD_LIMIT = Math.PI / 2 - .001;
function clamp$2(value, low, high) {
	return Math.min(high, Math.max(low, value));
}
/** Tabulated inverse CDF of `density` on [lo, hi] (trapezoid rule, linear inversion). */
function inverseCdf(lo, hi, samples, density) {
	const xs = new Float64Array(samples);
	const cdf = new Float64Array(samples);
	const dx = (hi - lo) / (samples - 1);
	xs[0] = lo;
	let previous = density(lo);
	for (let index = 1; index < samples; index += 1) {
		xs[index] = lo + index * dx;
		const value = density(xs[index]);
		cdf[index] = cdf[index - 1] + .5 * (value + previous) * dx;
		previous = value;
	}
	const total = cdf[samples - 1];
	return (u) => {
		const target = Math.min(1, Math.max(0, u)) * total;
		let low = 0;
		let high = samples - 1;
		while (high - low > 1) {
			const middle = low + high >> 1;
			if (cdf[middle] < target) low = middle;
			else high = middle;
		}
		const span = cdf[high] - cdf[low];
		const t = span > 0 ? (target - cdf[low]) / span : 0;
		return xs[low] + t * (xs[high] - xs[low]);
	};
}
/** A linear sea: a fixed set of seeded Airy components over a reference depth. */
var SeaState = class SeaState {
	depth;
	waveNumberAt;
	components;
	constructor(components, depth, waveNumberAt = exactWaveNumber) {
		this.depth = depth;
		this.waveNumberAt = waveNumberAt;
		this.components = components.map((component) => {
			const k = waveNumberAt(component.omega, depth);
			return {
				...component,
				k,
				kx: k * Math.sin(component.direction),
				kz: k * Math.cos(component.direction)
			};
		});
	}
	/**
	* Split a JONSWAP spectrum into equal-energy frequency bins and draw each bin's
	* frequency, direction (cos-2s, clipped to shoreward travel), and phase from the
	* seed. Equal energy per component makes the realized Hs exact.
	*/
	static fromSpectrum(params, seed, waveNumberAt = exactWaveNumber) {
		const count = Math.max(1, Math.floor(params.componentCount));
		const peakOmega = 2 * Math.PI / params.peakPeriod;
		const frequencyAt = inverseCdf(SPECTRUM_RANGE.low * peakOmega, SPECTRUM_RANGE.high * peakOmega, 2048, (omega) => jonswapShape(omega, peakOmega) * bandwidthWindow(omega, peakOmega, params.bandwidth));
		const halfWidth = Math.PI / 2;
		const s = Math.max(0, params.spreading);
		const directionAt = inverseCdf(-halfWidth, halfWidth, 721, (theta) => Math.pow(Math.cos(theta / 2), 2 * s));
		const amplitude = params.significantHeight / Math.sqrt(8 * count);
		const random = seededRandom(seed, 1588221863);
		const components = [];
		for (let index = 0; index < count; index += 1) {
			const omega = frequencyAt((index + .25 + .5 * random()) / count);
			let direction = params.direction + directionAt(random());
			for (let redraw = 0; redraw < MAX_REDRAWS && !(Math.abs(direction) < halfWidth); redraw += 1) direction = params.direction + directionAt(random());
			if (!(Math.abs(direction) < halfWidth)) direction = clamp$2(direction, -SHOREWARD_LIMIT, SHOREWARD_LIMIT);
			components.push({
				amplitude,
				omega,
				direction,
				phase: 2 * Math.PI * random()
			});
		}
		return new SeaState(components, params.depth, waveNumberAt);
	}
	/** Linear surface elevation η(x, z, t) = Σ a cos(k·x − ωt + φ), m. */
	elevation(x, z, t) {
		let eta = 0;
		for (const component of this.components) eta += component.amplitude * Math.cos(component.kx * x + component.kz * z - component.omega * t + component.phase);
		return eta;
	}
	/** Depth-averaged horizontal flow from linear continuity, ū = η ω / (k h) along each component, m/s. */
	depthAveragedVelocity(x, z, t) {
		const flow = {
			x: 0,
			z: 0
		};
		if (!Number.isFinite(this.depth)) return flow;
		for (const component of this.components) {
			const speed = component.amplitude * component.omega / (component.k * this.depth) * Math.cos(component.kx * x + component.kz * z - component.omega * t + component.phase);
			flow.x += speed * Math.sin(component.direction);
			flow.z += speed * Math.cos(component.direction);
		}
		return flow;
	}
	/** Wave-group envelope |Σ a e^{iψ}|; its slow beats are the sets, m. */
	envelope(x, z, t) {
		let real = 0;
		let imaginary = 0;
		for (const component of this.components) {
			const psi = component.kx * x + component.kz * z - component.omega * t + component.phase;
			real += component.amplitude * Math.cos(psi);
			imaginary += component.amplitude * Math.sin(psi);
		}
		return Math.hypot(real, imaginary);
	}
	/** First set peak after `fromTime`: an envelope maximum within 90 % of the horizon's largest, s. */
	nextSetPeak(x, z, fromTime, horizon = 600, step = .25) {
		const count = Math.max(3, Math.ceil(horizon / step) + 1);
		const values = new Float64Array(count);
		let largest = 0;
		let largestIndex = 0;
		for (let index = 0; index < count; index += 1) {
			values[index] = this.envelope(x, z, fromTime + index * step);
			if (values[index] > largest) {
				largest = values[index];
				largestIndex = index;
			}
		}
		for (let index = 1; index < count - 1; index += 1) {
			const value = values[index];
			if (value < .9 * largest || value < values[index - 1] || value < values[index + 1]) continue;
			const curvature = values[index - 1] - 2 * value + values[index + 1];
			const offset = curvature < 0 ? .5 * (values[index - 1] - values[index + 1]) / curvature : 0;
			return fromTime + (index + offset) * step;
		}
		return fromTime + largestIndex * step;
	}
	get significantHeight() {
		let m0 = 0;
		for (const component of this.components) m0 += .5 * component.amplitude * component.amplitude;
		return 4 * Math.sqrt(m0);
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/pool.ts
/**
* The Wave Pool (the movement-flow spec): a training pool whose machine sends the same wave every POOL.period
* seconds onto an A-frame reef, a finger that breaks first at its tip and peels both ways, a right and a left each
* wave, for faces of 1.0, 1.25 and 1.5 m. The same solver rides it as every spot. The layout is the water-physics
* advisor's (2026-10-01 consult, docs/research/water-physics/consult-log.md), provisional until the sweep:
* - the machine's floor `feedDepth` deep under the relaxation zone, where a regular wave of the pool's height is
*   near linear (Ursell about 8; at 4.5 m it was 41 and a linear input would shed free harmonics);
* - a ramp square to the crests (so it turns nothing) at `rampSlope`, at least half a wavelength long so it
*   reflects little, up to a terrace `terraceDepth` deep: shallow, so little depth is left to refract over (at
*   2.5 m still 1.7 times the biggest breaking depth, so nothing breaks on it);
* - the reef on the terrace: a finger pointing seaward, its tip at z = `apexZ` (x = 0, on the grid's symmetry
*   line), its two arms at `armAngle` to the incoming crests, rounded over a half-width `tipRounding` at the tip (a
*   hyperbola: the width over which the focus spreads, 0.5–1 wavelength on the terrace), easing to
*   `outerArmAngle` past |x| = `bendX` over `bendWidth` m (a curve, not a kink, which would refract like a small
*   tip), so the arms' longer outer run stays in the tank with its peel still about 46°. Refraction turns the
*   crests toward the arms, so arms at 71° break at a peel angle of about 47–50° along them (measured): Scarfe's
*   46–55° for intermediates' standard manoeuvres, about 6–6.5 m/s at 1.1–1.25 m faces;
* - seaward of the terrace's edge the finger's faces run on at their gradient instead of stopping at the terrace:
*   in front of the finger (|x| under about 90 m) two ridges aligned with the approach, their crests dipping seaward
*   at about 1:43 along the path and their sides at 1:18 normal, down to 4–8 m at the zone's inner edge, where the
*   tank blends them into the feed over 10 m (a step reflecting at most about 3 % of the energy into the zone). This
*   is Mead's "focus" (Mead 2000, table 3.3: contour-normal gradients 1:10–1:80, alignments 40–90°), which gathers the
*   waves onto the finger and eases the take-off. Found after the sweep and kept on the advisor's ruling
*   (2026-10-01): every measurement was made on it. If the zone or the feed ever moves, recheck the step; if a size
*   ever breaks on the arms before the tip, look at the axis first (deeper than the ridges, so it draws less);
* - its face climbs at `gradient` square to the crest line, about 1:18: Mead & Black's orthogonal gradient of about
*   1:28 along the ray at breaking, which crosses the arms at about 50° (their intensity about 2.6–2.8, a face that
*   throws without a tube; set along +z it made the arms about 1:9 and tubed), to its crest: `crestDepth` deep at
*   the tip, shallowing along each arm to `crestEndDepth` at its end (a ramped reef: a deeper tip focuses less, so
*   it breaks over a small peak rather than closing out across the finger and starving the flanks, and the
*   shallowing crest keeps the arms' refracted waves breaking in order; the advisor, 2026-10-01);
* - behind the crest a reef top `flatWidth` wide, then the lagoon inside the finger, `lagoonDepth` deep;
* - past |x| = `armLength` each arm tapers over `taperWidth` into the terrace, its crest deepening to the terrace's,
*   so the break fades into a shoulder to kick out on, and the lagoon's return flow leaves through the channels
*   beside it, level across the window's open side edges;
* - a beach face at `shoreSlope` up to the waterline at z = 0, and on up to the deck, `deck` m above the water.
* Mutable for the probes.
*/
const POOL = {
	period: 10,
	feedDepth: 9,
	rampSlope: 1 / 9,
	terraceDepth: 2.5,
	apexZ: -210,
	armAngle: 71,
	outerArmAngle: 65,
	bendX: 40,
	bendWidth: 14,
	tipRounding: 15,
	gradient: 1 / 18,
	crestDepth: 1,
	crestEndDepth: .5,
	flatWidth: 6,
	lagoonDepth: 1.8,
	armLength: 82,
	taperWidth: 25,
	/**
	* Where riders wait, x, m: on the right arm just past the tip's fast section, where the break line settles to its
	* steady peel (about 6 m/s along the arm from |x| 27 out; the break-line probe, 2026-10-01).
	*/
	takeOffX: 27,
	/** How far seaward of the tip's face the terrace reaches before the ramp, m: short, so the ramp's free harmonics don't reorder the crest. */
	terraceLead: 20,
	shoreSlope: 1 / 8,
	deck: .6,
	alongShore: 280
};
/** Where the terrace begins, z, m: seaward of the tip's face by `terraceLead`. */
function poolTerraceZ() {
	const p = POOL;
	return p.apexZ - (p.terraceDepth - p.crestDepth) / p.gradient - p.terraceLead;
}
/** Where the ramp rises from the machine's floor, z, m. */
function poolRampFootZ() {
	return poolTerraceZ() - (POOL.feedDepth - POOL.terraceDepth) / POOL.rampSlope;
}
/**
* Where the machine's wave starts breaking at the take-off, m deep for a wave H m high at the feed: the size probe's
* first breaks at x 27 (2026-10-01) were 1.73, 1.85 and 2.20 m deep for H 0.85, 1.05 and 1.3, about 0.84 + 1.04 H.
* At 1.5 H (the break-line probe's contour) riders waited 13–23 m inside the break, in its whitewater.
*/
const POOL_BREAK_DEPTH = {
	base: .84,
	perMetre: 1.04
};
/** How deep the pool's wave of height H at the feed first breaks at the take-off, m. */
function poolBreakDepth(height) {
	return POOL_BREAK_DEPTH.base + POOL_BREAK_DEPTH.perMetre * height;
}
/** A regular wave's Hs, 4√m0, for its height H: m0 = a²/2 = H²/8, so Hs = √2 H. */
/** smoothstep, kept here so this module and Bathymetry's import only each other's types. */
function ease(edge0, edge1, value) {
	const t = Math.min(1, Math.max(0, (value - edge0) / (edge1 - edge0)));
	return t * t * (3 - 2 * t);
}
/** The crest line's slope dz/d|x| at along-shore position x: the hyperbola's at the tip, its arms easing from armAngle to outerArmAngle. */
function crestSlope(u) {
	const p = POOL;
	const bend = ease(p.bendX - p.bendWidth / 2, p.bendX + p.bendWidth / 2, u);
	const angle = p.armAngle + (p.outerArmAngle - p.armAngle) * bend;
	return Math.tan(angle * Math.PI / 180) * (u / Math.hypot(u, p.tipRounding));
}
/** The crest line's z at |x| on a 0.25 m table, integrated from its slope; rebuilt when POOL changes (the probes set it). */
const CREST_STEP = .25;
let crestTable;
function crestTableFor() {
	const key = JSON.stringify(POOL);
	if (crestTable?.key === key) return crestTable.z;
	const count = Math.ceil(POOL.alongShore / CREST_STEP) + 2;
	const z = new Float64Array(count);
	for (let i = 1; i < count; i += 1) z[i] = z[i - 1] + CREST_STEP * (crestSlope((i - 1) * CREST_STEP) + crestSlope(i * CREST_STEP)) / 2;
	crestTable = {
		key,
		z
	};
	return z;
}
/** Where the crest line (the top of the reef's arms) crosses along-shore position x: rounded at the tip, bent outward. */
function poolCrestZ(x) {
	const table = crestTableFor();
	const at = Math.min(table.length - 1.001, Math.abs(x) / CREST_STEP);
	const i = Math.floor(at);
	return POOL.apexZ + table[i] + (table[i + 1] - table[i]) * (at - i);
}
/** The share of a step along +z that lies square to the crest line at along-shore position x: the cosine of the line's angle there. */
function poolNormalShare(x) {
	return 1 / Math.hypot(1, crestSlope(Math.abs(x)));
}
/** The arm the pool's peel is measured on: the right one (riders wait there), out to where its taper ends. */
function poolRiddenAt(x) {
	return x >= 0 && x <= POOL.armLength + POOL.taperWidth;
}
/** How far each arm has tapered into the terrace at along-shore position x: 0 on the reef, 1 past its end. */
function poolTaper(x) {
	return ease(POOL.armLength, POOL.armLength + POOL.taperWidth, Math.abs(x));
}
/** The pool's still depth below datum at (x, z), m; negative on the deck. */
function poolDepth(x, z) {
	const p = POOL;
	const ramp = Math.min(p.feedDepth, p.terraceDepth + Math.max(0, poolTerraceZ() - z) * p.rampSlope);
	const taper = poolTaper(x);
	const crestLine = poolCrestZ(x);
	const ramped = p.crestDepth + (p.crestEndDepth - p.crestDepth) * Math.min(1, Math.abs(x) / p.armLength);
	const crest = ramped + (p.terraceDepth - ramped) * taper;
	const lagoon = p.lagoonDepth + (p.terraceDepth - p.lagoonDepth) * taper;
	const normal = poolNormalShare(x);
	const face = crest + Math.max(0, crestLine - z) * normal * p.gradient;
	const inside = Math.max(0, z - crestLine - p.flatWidth) * normal;
	const reef = z <= crestLine ? face : Math.min(lagoon, crest + inside * p.gradient);
	const bed = Math.min(ramp, reef);
	const beach = Math.max(-p.deck, -z * p.shoreSlope);
	return Math.min(bed, beach);
}
function poolSpot() {
	return {
		name: "pool",
		depthAt: poolDepth
	};
}
/**
* The machine's sea: one regular wave square to the tank, of height H = Hs/√2 at the edge, every POOL.period s.
* Every wave is the same one, so the pool needs no seed.
*/
function poolSea(significantHeight, depth, waveNumberAt) {
	return new SeaState([{
		amplitude: significantHeight / Math.SQRT2 / 2,
		omega: 2 * Math.PI / POOL.period,
		direction: 0,
		phase: 0
	}], depth, waveNumberAt);
}
/** The machine's relaxation zone is this many wavelengths at its floor long: 1.5–2 absorb a 10 s wave (the advisor). */
const POOL_ZONE_WAVELENGTHS = 1.75;
/**
* The pool's tank across shore, m (a TankLayout without its edge depth): the relaxation zone over the machine's
* floor ending just seaward of the ramp, the fine grid from just seaward of the terrace to the shore.
*/
function poolTankLayout(shore) {
	const zoneInner = poolRampFootZ() - 10;
	return {
		offshore: zoneInner - POOL_ZONE_WAVELENGTHS * waveKinematics(POOL.period, POOL.feedDepth).wavelength,
		zoneInner,
		blendEnd: zoneInner + 10,
		fineFrom: poolTerraceZ() - 10,
		shore
	};
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/Bathymetry.ts
function smoothstep$1(edge0, edge1, value) {
	const t = Math.min(1, Math.max(0, (value - edge0) / (edge1 - edge0)));
	return t * t * (3 - 2 * t);
}
/** Dean (1991) equilibrium profile h = A s^(2/3) at offshore distance s, capped, with a planar foreshore on land. */
function deanDepth(offshore, a = .12, maxDepth = 12, landSlope = .06) {
	if (offshore <= 0) return offshore * landSlope;
	return Math.min(maxDepth, a * Math.pow(offshore, 2 / 3));
}
const BEACH_BAR = {
	offshore: 90,
	height: .9,
	width: 18,
	ripSpacing: 110,
	ripWidth: 22,
	ripJitter: 25
};
const POINT_HEADLAND = {
	center: 0,
	halfWidth: 150,
	protrusion: 120,
	slope: .04,
	maxDepth: 12
};
/**
* The Beach's outer bar and shelf (the wave-sizes spec; docs/research/outer-profiles.md): a Gaussian bar 2 m
* high 450 m out (crest 5 m deep, inside Duck's 300–600 m and 3–8 m), 80 m long so its tail leaves the inner
* bed alone, on Dean's profile continued to 30 m.
*/
const BEACH_OUTER = {
	barOffshore: 450,
	barHeight: 2,
	barWidth: 80,
	maxDepth: 30
};
/** The Point's shelf past its 12 m: a gentler 1:67 slope to 30 m (an assumption; see the research doc). */
const POINT_OUTER = {
	slope: .015,
	maxDepth: 30
};
/**
* The Teahupo'o Reef (the Teahupo'o Reef spec): a left slab. The tank's deep water rises up a
* 1:2.29 forereef (Rodríguez-Burguette et al. 2025, a model of Teahupo'o's reef) to a shelf
* about 10 m deep (Shand 2024), where the wave stands up before the reef rises again to its
* crest, about 1.5 m under the surface (WSL). The ledge rises from the shelf, its foot meeting
* the shelf's edge at the peak (x = crestX), and runs at `angle` degrees to the shoreline,
* furthest out toward −x, so each wave breaks there first and peels toward +x (a left) at the
* shelf's celerity over the sine of the crest's angle to it (`ledgePeel`). A pass runs along the
* window's +x open edge, level across it like the Canyon's axis, where the left ends. A planar
* beach face caps it all. Sources and provisional values: docs/research/teahupoo-reef-sources.md.
* Mutable for the design sweep (`scripts/reefShape.ts`).
*/
const REEF = {
	deep: 30,
	foreSlope: 1 / 2.29,
	shelfEdge: -150,
	shelfDepth: 10,
	ledgeSlope: 1 / 2.29,
	crestDepth: 1.5,
	crestX: -80,
	crestZ: -120,
	angle: 45,
	passX: 80,
	passHalfWidth: 25,
	passDepth: 12,
	takeOffX: -50,
	flatWidth: 20,
	lagoonDepth: 2.5,
	inlandSlope: 1 / 9.64
};
/** Where the Reef's crest line (the top of its ledge) crosses along-shore position x. */
function reefCrestZ(x) {
	return REEF.crestZ + (x - REEF.crestX) * Math.tan(REEF.angle * Math.PI / 180);
}
/**
* Whether the Reef's ledge is ridden at along-shore position x: out of the pass (beyond two of its
* half-widths from its axis) and where the crest still lies seaward of the inland slope's crest depth.
* Past it, waves break on the beach face in the pass and the lagoon: not the Reef's wave.
*/
function reefLedgeAt(x) {
	return x < REEF.passX - 2 * REEF.passHalfWidth && reefCrestZ(x) < -REEF.crestDepth / REEF.inlandSlope;
}
/** Distance seaward of the Reef's crest line, m, measured across it (negative shoreward of it). */
function reefSeaward(x, z) {
	return (reefCrestZ(x) - z) * Math.cos(REEF.angle * Math.PI / 180);
}
/**
* Padang Padang (the Padang Padang spec): a left over a coral reef on the west coast of Bali's Bukit, built from Mead's
* components for it (ramp, focus, wedge, pinnacle; no platform: Mead 2000, table 4.1), as Mead & Black's idealised
* Bingin beds (1999; Mead 2000, ch. 5). The swell arrives square to the tank in water `deep` deep (the tank's edge,
* where its linear sea is near-linear; the Bukit's terrace has already wrapped it), climbs a shore-parallel forereef
* at `foreSlope` to a knee `kneeDepth` deep, then Mead's ramp at `rampSlope`, level along shore. From the ramp rises
* the wedge to a reef flat `crestDepth` deep that nearly dries at the lowest spring tides. The wave climbs it at Mead &
* Black's orthogonal gradient along its own path, inferred from the measured vortex ratios of its tubes (about 1:19;
* Mead & Black 2001), so `wedgeSlope`, measured across the crest line, is steeper by the path's angle to it (the
* owner's decision, 2026-09-29: docs/research/water-physics/basilisk-profiles.md). The wedge's top
* edge (the crest line) runs at `angle` degrees to the ramp's contours from the peak (x = peakX, where the wedge's base
* is `baseDepth` deep), so each wave breaks there first and peels toward +x (a left) at the celerity over the wedge's
* base over the sine of that angle (phase matching). A spur on the swell's line through the peak (Mead's focus) draws
* the waves' energy onto it, so it breaks first. Upcoast of the peak the wedge fades out over `endWidth` m, so the
* bed is the bare ramp, level along shore, at the window's −x open edge (an open edge copies its neighbours: a bed
* sloping across it ran the Reef's Big swell to NaN); a channel runs along the +x open edge, level across its axis,
* where the left ends, `kneeDepth` deep shoreward of `channelFrom`. A planar beach face caps it all. The window is
* `alongShore` m wide, so the peak stands clear of the −x side feed. Sources and provisional values: docs/research/padang-padang-sources.md.
* Mutable for the design sweep (`scripts/padangShape.ts`).
*/
const PADANG = {
	deep: 25,
	foreSlope: 1 / 20,
	foreRounding: 10,
	kneeDepth: 12,
	rampSlope: 1 / 80,
	/**
	* The wedge's slope across its crest line: 1:19 along the swell's path, which crosses the 40° line obliquely (1:14.6
	* as the swell arrives square, about 1:15.8 once refraction turns it toward the wedge's normal). At 1:19 across the line
	* the swell climbed 1:24.8: in Basilisk (level 11) the peak's face went vertical 16 m before the flat and threw a tube
	* of 0.125 H²; at 1:19 along the path, 3.6 m before it, the lip landing on the flat and the tube 0.208 H², 1.7 × larger.
	*/
	wedgeSlope: 1 / 15,
	baseDepth: 7,
	crestDepth: 1.25,
	peakX: -60,
	peakZ: -170,
	angle: 40,
	endWidth: 20,
	alongShore: 320,
	channelX: 160,
	channelHalfWidth: 45,
	shoreSlope: .2,
	takeOffX: -50,
	/** How far the channel is deepened from the ramp toward the knee's depth: its crests ran ahead over it and tilted the reef's down-reef crests (the design sweep's). */
	channelDeepening: 1,
	/**
	* How far seaward the channel is deepened, z (−Infinity: from the knee). Held at the knee's depth all the way out, its
	* crests ran ahead and tilted the down-reef crests about 11° before the wedge (the advisor, 2026-09-29), a peel of
	* 15.9 m/s against 10.7 without it. Deepened only shoreward of where the ramp is about 5 m deep (the wedge base's depth
	* at the ride's end), the crests offshore of it cross the bare ramp as they do along the reef: 22 clean waves at 11.3
	* m/s, the two halves of each alike (docs/research/padang-padang-report.md). The line is the sweep's, provisional.
	*/
	channelFrom: -138,
	/**
	* Mead's focus: a spur along the incoming swell through the peak, `focusRelief` m above the bed where it meets the
	* wedge's base, tapering (cos²) to nothing `focusLength` m seaward and `focusInset` m up the wedge, `focusHalfWidth` m
	* to either side of the peak. The advisor's ruling (2026-09-29, from Mead 2000, figs 5.1–5.2): about a wavelength
	* across (a narrower shoal diffracts rather than focuses), its crest deepening seaward at 1:20–1:40 inside Mead's
	* focus gradients (1:10–1:80). All provisional.
	*/
	focusRelief: 2,
	focusLength: 150,
	focusInset: 80,
	focusHalfWidth: 70
};
/** Where Padang Padang's wedge rises from the ramp at its peak: `baseDepth` deep, (baseDepth − crestDepth) / wedgeSlope across the crest line. */
function padangBaseZ() {
	const { peakZ, baseDepth, crestDepth, wedgeSlope, angle } = PADANG;
	return peakZ - (baseDepth - crestDepth) / wedgeSlope / Math.cos(angle * Math.PI / 180);
}
/** Where Padang Padang's forereef meets its ramp (the knee's centre): the ramp climbs from kneeDepth there to baseDepth at the peak's base. */
function padangKneeZ() {
	return padangBaseZ() - (PADANG.kneeDepth - PADANG.baseDepth) / PADANG.rampSlope;
}
/** Where Padang Padang's forereef rises from deep water (its foot's centre). */
function padangForeFootZ() {
	return padangKneeZ() - (PADANG.deep - PADANG.kneeDepth) / PADANG.foreSlope;
}
/** Where Padang Padang's crest line (the top of its wedge) crosses along-shore position x. */
function padangCrestZ(x) {
	return PADANG.peakZ + (x - PADANG.peakX) * Math.tan(PADANG.angle * Math.PI / 180);
}
/** Distance seaward of Padang Padang's crest line, m, measured across it (negative shoreward of it). */
function padangSeaward(x, z) {
	return (padangCrestZ(x) - z) * Math.cos(PADANG.angle * Math.PI / 180);
}
/** max(0, d), rounded quadratically (C¹) over ±r: a ramp's knee without a slope break. */
function rounded(d, r) {
	if (d <= -r) return 0;
	if (d >= r) return d;
	return (d + r) * (d + r) / (4 * r);
}
/** Whether Padang Padang's reef is ridden at along-shore position x: from its peak to where the channel begins (two half-widths from its axis). */
function padangReefAt(x) {
	return x >= PADANG.peakX && x < PADANG.channelX - 2 * PADANG.channelHalfWidth;
}
/**
* A canyon cut through the shelf. It bends the swell off its axis, leaving a
* shadow over it, and gathers it on its flank: 60–130 m from the axis at the
* break line, by the swell's direction and period. The axis runs along the
* window's open edge (x = 80, half the 160 m window), so the window holds the
* focusing flank and the bed is level across the boundary. On the centreline
* the focus fell on the open edges and the break line was all shadow; with a
* canyon wall crossing an edge, the edge cells ran unstable until the
* dispersive terms carried the surface's curvature across open edges.
*/
const CANYON = {
	axisX: 80,
	halfWidth: 30,
	depth: 14,
	head: 60,
	fullAt: 160,
	fadeStart: 200,
	fadeEnd: 250
};
function beach(seed) {
	const random = seededRandom(seed, 780996);
	const rips = [];
	for (let k = -8; k <= 8; k += 1) rips.push(k * BEACH_BAR.ripSpacing + (random() * 2 - 1) * BEACH_BAR.ripJitter);
	return {
		name: "beach",
		depthAt(x, z) {
			const offshore = -z;
			let gap = 0;
			for (const rip of rips) gap = Math.max(gap, Math.exp(-(((x - rip) / BEACH_BAR.ripWidth) ** 2)));
			const bar = BEACH_BAR.height * Math.exp(-(((offshore - BEACH_BAR.offshore) / BEACH_BAR.width) ** 2)) * (1 - gap);
			const outerBar = BEACH_OUTER.barHeight * Math.exp(-(((offshore - BEACH_OUTER.barOffshore) / BEACH_OUTER.barWidth) ** 2));
			return deanDepth(offshore, .12, BEACH_OUTER.maxDepth) - bar - outerBar;
		}
	};
}
function point() {
	const { center, halfWidth, protrusion, slope, maxDepth } = POINT_HEADLAND;
	return {
		name: "point",
		depthAt(x, z) {
			const offshore = -protrusion * smoothstep$1(center + halfWidth, center - halfWidth, x) - z;
			if (offshore <= 0) return offshore * .06;
			const shelf = maxDepth / slope;
			return offshore <= shelf ? slope * offshore : Math.min(POINT_OUTER.maxDepth, maxDepth + POINT_OUTER.slope * (offshore - shelf));
		}
	};
}
/** The Reef's bed in its parts: the pass's weight, the reef's own depth, how far inside its crest, and the shore's. */
function reefTerms(x, z) {
	const r = REEF;
	const fore = z >= r.shelfEdge ? r.shelfDepth : Math.min(r.deep, r.shelfDepth + (r.shelfEdge - z) * r.foreSlope);
	const seaward = reefSeaward(x, z);
	const ledge = r.crestDepth + Math.max(0, seaward) * r.ledgeSlope;
	const inside = Math.max(0, -seaward);
	const lagoon = Math.min(r.lagoonDepth, r.crestDepth + Math.max(0, inside - r.flatWidth) * r.ledgeSlope);
	const onReef = z >= r.shelfEdge ? Math.min(r.shelfDepth, seaward >= 0 ? ledge : lagoon) : fore;
	return {
		pass: Math.exp(-(((x - r.passX) / r.passHalfWidth) ** 2)),
		onReef,
		fore,
		inside,
		beachFace: z >= 0 ? -z * .06 : z >= r.shelfEdge ? -z * r.inlandSlope : Infinity
	};
}
function reef() {
	return {
		name: "reef",
		depthAt(x, z) {
			const { pass, onReef, fore, beachFace } = reefTerms(x, z);
			const depth = onReef + (Math.max(fore, REEF.passDepth) - onReef) * pass;
			return Math.min(depth, beachFace);
		},
		materialAt(x, z) {
			const r = REEF;
			const { pass, onReef, inside, beachFace } = reefTerms(x, z);
			const reefWall = r.flatWidth + (r.lagoonDepth - r.crestDepth) / r.ledgeSlope;
			return pass < .5 && onReef < beachFace && inside < reefWall ? "reef" : "sand";
		}
	};
}
/** cos²(π/2 · d/reach) inside ±reach, 0 beyond: a bump's profile, C¹ at its centre and its edge. */
function bump(d, reach) {
	return Math.abs(d) >= reach ? 0 : Math.cos(Math.PI / 2 * (d / reach)) ** 2;
}
/** Padang Padang's focus, 0–1: 1 on the swell's line through the peak where it crosses the wedge's base. */
function padangFocusShape(x, z) {
	const p = PADANG;
	const seaward = padangBaseZ() - z;
	return bump(x - p.peakX, p.focusHalfWidth) * bump(seaward, seaward >= 0 ? p.focusLength : p.focusInset);
}
/** Padang Padang's bed in its parts: the channel's weight, the depth beneath the beach face, and the beach face's. */
function padangTerms(x, z) {
	const p = PADANG;
	const knee = padangKneeZ();
	const r = p.foreRounding;
	const fore = p.kneeDepth + (rounded(knee - z, r) - rounded(padangForeFootZ() - z, r)) * p.foreSlope;
	const ramp = fore - rounded(z - knee, r) * p.rampSlope;
	const wedge = p.crestDepth + Math.max(0, padangSeaward(x, z)) * p.wedgeSlope;
	const reef = ramp - Math.max(0, ramp - wedge) * smoothstep$1(p.peakX - p.endWidth, p.peakX, x) - p.focusRelief * padangFocusShape(x, z);
	const channel = Math.exp(-(((x - p.channelX) / p.channelHalfWidth) ** 2));
	const inshore = p.channelFrom === -Infinity ? 1 : smoothstep$1(p.channelFrom - 2 * r, p.channelFrom + 2 * r, z);
	return {
		channel,
		depth: reef + (ramp + (fore - ramp) * p.channelDeepening * inshore - reef) * channel,
		beachFace: z < 0 ? -z * p.shoreSlope : -z * .06
	};
}
function padang() {
	return {
		name: "padang",
		depthAt(x, z) {
			const { depth, beachFace } = padangTerms(x, z);
			return Math.min(depth, beachFace);
		},
		materialAt(x, z) {
			const { channel, depth, beachFace } = padangTerms(x, z);
			return channel < .5 && depth < beachFace ? "reef" : "sand";
		}
	};
}
function canyon() {
	return {
		name: "canyon",
		depthAt(x, z) {
			const offshore = -z;
			const along = smoothstep$1(CANYON.head, CANYON.fullAt, offshore) * (1 - smoothstep$1(CANYON.fadeStart, CANYON.fadeEnd, offshore));
			return deanDepth(offshore) + CANYON.depth * Math.exp(-(((x - CANYON.axisX) / CANYON.halfWidth) ** 2)) * along;
		}
	};
}
function createSpot(name, seed) {
	switch (name) {
		case "beach": return beach(seed);
		case "point": return point();
		case "reef": return reef();
		case "canyon": return canyon();
		case "padang": return padang();
		case "pool": return poolSpot();
	}
}
/**
* The breaking age a cell brings into this step: its own when it is breaking, else (or if older) that of its oldest
* breaking parent behind its front face, the surface sloping up at (slopeX, slopeZ).
*/
function inheritedAge(i, ix, iz, nx, nz, slopeX, slopeZ, strength, age) {
	let inherited = strength[i] > 0 ? age[i] : 0;
	if (slopeX * slopeX + slopeZ * slopeZ <= 1e-8) return inherited;
	if (Math.abs(slopeX) >= Math.abs(slopeZ)) {
		const bx = ix + Math.sign(slopeX);
		if (bx < 0 || bx >= nx) return inherited;
		const j = iz * nx + bx;
		if (strength[j] > 0) inherited = Math.max(inherited, age[j]);
		if (iz > 0 && strength[j - nx] > 0) inherited = Math.max(inherited, age[j - nx]);
		if (iz < nz - 1 && strength[j + nx] > 0) inherited = Math.max(inherited, age[j + nx]);
		return inherited;
	}
	const bz = iz + Math.sign(slopeZ);
	if (bz < 0 || bz >= nz) return inherited;
	const j = bz * nx + ix;
	if (strength[j] > 0) inherited = Math.max(inherited, age[j]);
	if (ix > 0 && strength[j - 1] > 0) inherited = Math.max(inherited, age[j - 1]);
	if (ix < nx - 1 && strength[j + 1] > 0) inherited = Math.max(inherited, age[j + 1]);
	return inherited;
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/ShallowWaterSolver.ts
/** Jacobsen et al. (2012) ramp: 0 at the zone's inner edge, 1 at its outer boundary. */
function relaxationRamp(s) {
	return (Math.exp(Math.pow(Math.min(1, Math.max(0, s)), 3.5)) - 1) / (Math.E - 1);
}
/**
* Cross-shore edges from `offshore` to `shore`: uniform cells of about `fine`
* shoreward of `fineFrom`, growing by at most `growth` per cell to `coarse`
* toward `offshore`. The offshore cells are scaled together to fit exactly.
*/
function stretchedEdges(offshore, shore, fineFrom, fine, coarse, growth = 1.08) {
	const fineCount = Math.max(1, Math.round((shore - fineFrom) / fine));
	const fineSpacing = (shore - fineFrom) / fineCount;
	const span = fineFrom - offshore;
	const spacings = [];
	let covered = 0;
	let spacing = fineSpacing;
	while (covered < span) {
		spacing = Math.min(coarse, spacing * growth);
		spacings.push(spacing);
		covered += spacing;
	}
	const scale = spacings.length > 0 ? span / covered : 1;
	const edges = new Float64Array(spacings.length + fineCount + 1);
	edges[0] = offshore;
	let z = offshore;
	for (let k = spacings.length - 1; k >= 0; k -= 1) {
		z += spacings[k] * scale;
		edges[spacings.length - k] = z;
	}
	edges[spacings.length] = fineFrom;
	for (let k = 1; k <= fineCount; k += 1) edges[spacings.length + k] = fineFrom + k * fineSpacing;
	edges[edges.length - 1] = shore;
	return edges;
}
/** A stable step this short, s (about a thousandth of the surf zone's usual), means the water has diverged. */
const COLLAPSED_STEP = 1e-5;
/**
* Equal substeps for `dt` at the CFL limit `stable`, on the CPU or the GPU.
* Diverged water asks for trillions of them: say so instead of stepping without end.
*/
function cflSubsteps(dt, stable) {
	if (stable < COLLAPSED_STEP) throw new Error(`The water blew up: its stable step is ${stable.toExponential(1)} s`);
	return Math.max(1, Math.ceil(dt / stable));
}
/** Monotonized-central limited slope from backward and forward differences. */
function limited(back, forward) {
	if (back * forward <= 0) return 0;
	const magnitude = Math.min(Math.abs(.5 * (back + forward)), 2 * Math.abs(back), 2 * Math.abs(forward));
	return back > 0 ? magnitude : -magnitude;
}
/**
* HLL flux with the hydrostatic reconstruction of Audusse et al. (2004): both
* sides are lowered onto the higher bed, and the pressure lost in doing so is
* returned to each cell as a correction. This keeps a lake at rest exactly at
* rest over any bed, and dry cells positive.
*/
function interfaceFlux(hL, etaL, uL, vL, hR, etaR, uR, vR, g, out) {
	const bedStar = Math.max(etaL - hL, etaR - hR);
	const hLs = Math.max(0, etaL - bedStar);
	const hRs = Math.max(0, etaR - bedStar);
	out.leftCorrection = .5 * g * (hL * hL - hLs * hLs);
	out.rightCorrection = .5 * g * (hR * hR - hRs * hRs);
	if (hLs <= 0 && hRs <= 0) {
		out.mass = 0;
		out.normal = 0;
		out.tangent = 0;
		return;
	}
	const cL = Math.sqrt(g * hLs);
	const cR = Math.sqrt(g * hRs);
	let sL;
	let sR;
	if (hLs <= 0) {
		sL = uR - 2 * cR;
		sR = uR + cR;
	} else if (hRs <= 0) {
		sL = uL - cL;
		sR = uL + 2 * cL;
	} else {
		sL = Math.min(uL - cL, uR - cR);
		sR = Math.max(uL + cL, uR + cR);
	}
	const massL = hLs * uL;
	const massR = hRs * uR;
	const normalL = massL * uL + .5 * g * hLs * hLs;
	const normalR = massR * uR + .5 * g * hRs * hRs;
	const tangentL = massL * vL;
	const tangentR = massR * vR;
	if (sL >= 0) {
		out.mass = massL;
		out.normal = normalL;
		out.tangent = tangentL;
		return;
	}
	if (sR <= 0) {
		out.mass = massR;
		out.normal = normalR;
		out.tangent = tangentR;
		return;
	}
	const inverse = 1 / (sR - sL);
	out.mass = (sR * massL - sL * massR + sL * sR * (hRs - hLs)) * inverse;
	out.normal = (sR * normalL - sL * normalR + sL * sR * (massR - massL)) * inverse;
	out.tangent = (sR * tangentL - sL * tangentR + sL * sR * (hRs * vR - hLs * vL)) * inverse;
}
/**
* Stage 1 surf-zone solver: nonlinear shallow-water equations on a grid that is
* uniform along shore (x) and may stretch across shore (z). Breaking waves
* become shock-captured bores; there is no dispersion (see plan §1.7).
*/
var ShallowWaterSolver = class {
	nx;
	nz;
	dx;
	xCenters;
	zCenters;
	dz;
	/** Bed elevation b = −depth, m. */
	bed;
	/** Total water depth, m. */
	h;
	/** Depth-integrated flow along x and z, m²/s. */
	qx;
	qz;
	time = 0;
	gravity;
	dryDepth;
	restLevel;
	depthAt;
	manning;
	courant;
	xBoundary;
	zEdges;
	zGaps;
	u;
	w;
	eta;
	rateH;
	rateQx;
	rateQz;
	flux = {
		mass: 0,
		normal: 0,
		tangent: 0,
		leftCorrection: 0,
		rightCorrection: 0
	};
	/** MUSCL face states per cell: x faces (west/east) and z faces (south/north). */
	xhW;
	xhE;
	xetaW;
	xetaE;
	xuW;
	xuE;
	xwW;
	xwE;
	zhS;
	zhN;
	zetaS;
	zetaN;
	zwS;
	zwN;
	zuS;
	zuN;
	zones = [];
	/**
	* Accelerations of qx and qz beyond the shallow-water terms (a dispersive
	* solver's), added to the Hancock predictor's half step of the cells
	* `predictorMask` has on this step; absent in stage 1.
	*/
	predictorX;
	predictorZ;
	predictorMask;
	target = {
		eta: 0,
		qx: 0,
		qz: 0
	};
	constructor(grid, depthAt, options = {}) {
		this.nx = grid.nx;
		this.nz = grid.zEdges.length - 1;
		this.dx = grid.dx;
		this.xBoundary = grid.xBoundary === "periodic" ? 1 : grid.xBoundary === "open" ? 2 : 0;
		this.depthAt = depthAt;
		this.gravity = options.gravity ?? 9.81;
		this.manning = options.manning ?? .02;
		this.dryDepth = options.dryDepth ?? 1e-4;
		this.courant = options.courant ?? .45;
		this.restLevel = options.waterLevel ?? 0;
		this.zEdges = Float64Array.from(grid.zEdges);
		this.xCenters = new Float64Array(this.nx);
		for (let ix = 0; ix < this.nx; ix += 1) this.xCenters[ix] = grid.xMin + (ix + .5) * grid.dx;
		this.zCenters = new Float64Array(this.nz);
		this.dz = new Float64Array(this.nz);
		for (let iz = 0; iz < this.nz; iz += 1) {
			this.zCenters[iz] = .5 * (this.zEdges[iz] + this.zEdges[iz + 1]);
			this.dz[iz] = this.zEdges[iz + 1] - this.zEdges[iz];
		}
		this.zGaps = new Float64Array(this.nz);
		for (let iz = 0; iz < this.nz; iz += 1) this.zGaps[iz] = iz < this.nz - 1 ? this.zCenters[iz + 1] - this.zCenters[iz] : this.dz[iz];
		const size = this.nx * this.nz;
		const make = () => new Float64Array(size);
		this.bed = make();
		this.h = make();
		this.qx = make();
		this.qz = make();
		this.u = make();
		this.w = make();
		this.eta = make();
		this.rateH = make();
		this.rateQx = make();
		this.rateQz = make();
		this.xhW = make();
		this.xhE = make();
		this.xetaW = make();
		this.xetaE = make();
		this.xuW = make();
		this.xuE = make();
		this.xwW = make();
		this.xwE = make();
		this.zhS = make();
		this.zhN = make();
		this.zetaS = make();
		this.zetaN = make();
		this.zwS = make();
		this.zwN = make();
		this.zuS = make();
		this.zuN = make();
		for (let iz = 0; iz < this.nz; iz += 1) for (let ix = 0; ix < this.nx; ix += 1) {
			const i = iz * this.nx + ix;
			this.bed[i] = -depthAt(this.xCenters[ix], this.zCenters[iz]);
			this.h[i] = Math.max(0, this.restLevel - this.bed[i]);
		}
		this.levelOpenEdges(true);
	}
	surfaceAt(index) {
		return this.h[index] + this.bed[index];
	}
	/** Index of the cell containing (x, z), clamped to the grid. */
	cellIndex(x, z) {
		const ix = Math.min(this.nx - 1, Math.max(0, Math.floor((x - this.xCenters[0]) / this.dx + .5)));
		let low = 0;
		let high = this.nz;
		while (high - low > 1) {
			const middle = low + high >> 1;
			if (this.zEdges[middle] <= z) low = middle;
			else high = middle;
		}
		return low * this.nx + ix;
	}
	/** Bilinear sample of a cell-centred field at (x, z), clamped to the outermost centres. */
	sampleCentered(values, x, z) {
		const gx = Math.min(this.nx - 1, Math.max(0, (x - this.xCenters[0]) / this.dx));
		const ix = Math.min(this.nx - 2, Math.floor(gx));
		const tx = gx - ix;
		const iz = this.rowBelow(z);
		const tz = Math.min(1, Math.max(0, (z - this.zCenters[iz]) / (this.zCenters[iz + 1] - this.zCenters[iz])));
		const i = iz * this.nx + ix;
		return (values[i] * (1 - tx) + values[i + 1] * tx) * (1 - tz) + (values[i + this.nx] * (1 - tx) + values[i + this.nx + 1] * tx) * tz;
	}
	/** Largest row whose centre is at or below z, clamped to [0, nz − 2]. */
	rowBelow(z) {
		let low = 0;
		let high = this.nz - 1;
		while (high - low > 1) {
			const middle = low + high >> 1;
			if (this.zCenters[middle] <= z) low = middle;
			else high = middle;
		}
		return Math.min(low, this.nz - 2);
	}
	/** Largest time step the CFL condition allows for the current state, s. */
	maxStableStep() {
		let rate = 0;
		for (let iz = 0; iz < this.nz; iz += 1) {
			const inverseDz = 1 / this.dz[iz];
			for (let ix = 0; ix < this.nx; ix += 1) {
				const i = iz * this.nx + ix;
				const depth = this.h[i];
				if (depth <= this.dryDepth) continue;
				const c = Math.sqrt(this.gravity * depth);
				rate = Math.max(rate, (Math.abs(this.qx[i] / depth) + c) / this.dx, (Math.abs(this.qz[i] / depth) + c) * inverseDz);
			}
		}
		return rate > 0 ? this.courant / rate : Infinity;
	}
	/** Advance by dt seconds, sub-stepping as the CFL condition requires. */
	step(dt) {
		if (!(dt > 0) || !Number.isFinite(dt)) return;
		const substeps = cflSubsteps(dt, this.maxStableStep());
		const sub = dt / substeps;
		for (let s = 0; s < substeps; s += 1) {
			this.advance(sub);
			this.time += sub;
			this.relax();
		}
	}
	totalVolume() {
		let volume = 0;
		for (let iz = 0; iz < this.nz; iz += 1) for (let ix = 0; ix < this.nx; ix += 1) volume += this.h[iz * this.nx + ix] * this.dx * this.dz[iz];
		return volume;
	}
	/** Kinetic plus potential energy relative to datum, per unit density, m⁵/s². */
	totalEnergy() {
		let energy = 0;
		for (let iz = 0; iz < this.nz; iz += 1) for (let ix = 0; ix < this.nx; ix += 1) {
			const i = iz * this.nx + ix;
			const depth = this.h[i];
			const surface = depth + this.bed[i];
			const kinetic = depth > this.dryDepth ? .5 * (this.qx[i] ** 2 + this.qz[i] ** 2) / depth : 0;
			energy += (kinetic + .5 * this.gravity * (surface * surface - this.bed[i] * this.bed[i])) * this.dx * this.dz[iz];
		}
		return energy;
	}
	/** How fast the surface rises in each cell over the latest step, η_t = −∇·q, m/s. */
	get surfaceRiseRate() {
		return this.rateH;
	}
	/** Whether the along-shore edges wrap onto each other. */
	get periodicAlongShore() {
		return this.xBoundary === 1;
	}
	/** Whether the along-shore edges are open: water leaves the window through them. */
	get openAlongShore() {
		return this.xBoundary === 2;
	}
	/**
	* Whether along-shore position x lies past an open edge: what comes down there has left the window, and nothing
	* of it belongs in the edge column the grid's lookups clamp it to.
	*/
	beyondOpenEdge(x) {
		return this.openAlongShore && (x < this.xCenters[0] - this.dx / 2 || x > this.xCenters[this.nx - 1] + this.dx / 2);
	}
	/** The relaxation zones, in the order they blend. */
	get relaxationZones() {
		return this.zones.map((entry) => entry.zone);
	}
	addRelaxationZone(zone) {
		let firstRow = this.nz;
		let lastRow = -1;
		for (let iz = 0; iz < this.nz; iz += 1) for (let ix = 0; ix < this.nx; ix += 1) {
			if (zone.weights[iz * this.nx + ix] <= 0) continue;
			firstRow = Math.min(firstRow, iz);
			lastRow = Math.max(lastRow, iz);
		}
		this.zones.push({
			zone,
			firstRow,
			lastRow
		});
	}
	/** Weights for a zone spanning z from `inner` (weight 0) to `outer` (weight 1). */
	zoneWeightsAlongZ(inner, outer) {
		const weights = new Float64Array(this.nx * this.nz);
		for (let iz = 0; iz < this.nz; iz += 1) {
			const s = (this.zCenters[iz] - inner) / (outer - inner);
			if (s <= 0) continue;
			weights.fill(relaxationRamp(s), iz * this.nx, (iz + 1) * this.nx);
		}
		return weights;
	}
	/**
	* Move the window `columns` cells along shore (+x when positive) over the
	* fixed spot seabed. Overlapping water is kept exactly. New columns sample the
	* seabed and extend the old edge's surface and velocity, or rest at the still
	* level where the edge was dry. Relaxation weights move with their cells.
	*/
	shiftAlongShore(columns) {
		const shift = Math.trunc(columns);
		if (shift === 0) return;
		const { nx, nz } = this;
		if (Math.abs(shift) >= nx) throw new RangeError(`Cannot shift ${shift} columns in a ${nx}-column window`);
		this.levelOpenEdges(false);
		for (let ix = 0; ix < nx; ix += 1) this.xCenters[ix] += shift * this.dx;
		const arrays = [
			this.bed,
			this.h,
			this.qx,
			this.qz,
			...this.zones.map((entry) => entry.zone.weights)
		];
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			const oldEdge = shift > 0 ? row + nx - 1 : row;
			const edgeWet = this.h[oldEdge] > this.dryDepth;
			const edgeSurface = edgeWet ? this.h[oldEdge] + this.bed[oldEdge] : this.restLevel;
			const edgeU = edgeWet ? this.qx[oldEdge] / this.h[oldEdge] : 0;
			const edgeW = edgeWet ? this.qz[oldEdge] / this.h[oldEdge] : 0;
			for (const values of arrays) if (shift > 0) values.copyWithin(row, row + shift, row + nx);
			else values.copyWithin(row - shift, row, row + nx + shift);
			const keptEdge = shift > 0 ? row + nx - 1 - shift : row - shift;
			const start = shift > 0 ? nx - shift : 0;
			const end = shift > 0 ? nx : -shift;
			for (let ix = start; ix < end; ix += 1) {
				const i = row + ix;
				this.bed[i] = -this.depthAt(this.xCenters[ix], this.zCenters[iz]);
				const depth = Math.max(0, edgeSurface - this.bed[i]);
				const wet = depth > this.dryDepth;
				this.h[i] = depth;
				this.qx[i] = wet ? depth * edgeU : 0;
				this.qz[i] = wet ? depth * edgeW : 0;
				for (const entry of this.zones) entry.zone.weights[i] = entry.zone.weights[keptEdge];
			}
		}
		this.levelOpenEdges(true);
		for (const entry of this.zones) entry.zone.afterShift?.();
	}
	/**
	* An open edge copies its neighbours, so over a bed sloping across it the copy stands on the wrong bed: the
	* Reef's Big swell ran away where the window's edge cut its ledge (Part B), as the Canyon's once did across
	* its wall. Levelling only the columns the stencils reach left a kink where the slope resumed, and the Reef's
	* biggest seas drained that corner until a thin cell ran away there. So in a window wide enough (the game's) the
	* bed eases over `OPEN_EDGE_RAMP` metres (smootherstep, continuous in slope and curvature) from the spot's own to
	* its profile that far in, uniform along shore where the stencils copy the edge (`level`); a smaller window levels
	* just the copied columns. Not `level`, it takes the spot's again. The surface stays where it was, at the still
	* level where dry.
	*/
	levelOpenEdges(level) {
		const { nx, nz, bed, h, qx, qz } = this;
		if (this.xBoundary !== 2 || nx <= 4) return;
		const columns = Math.round(20 / this.dx);
		const ramp = columns > 2 && 8 * columns <= nx ? columns : 2;
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			const z = this.zCenters[iz];
			for (let k = 0; k < ramp; k += 1) {
				const s = ramp > 2 ? Math.min(1, Math.max(0, (k - 2) / (ramp - 2))) : 0;
				const own = s * s * s * (s * (6 * s - 15) + 10);
				for (const [ix, inner] of [[k, ramp], [nx - 1 - k, nx - 1 - ramp]]) {
					const i = row + ix;
					const wet = h[i] > this.dryDepth;
					const surface = wet ? h[i] + bed[i] : this.restLevel;
					const spot = -this.depthAt(this.xCenters[ix], z);
					bed[i] = level ? own * spot + (1 - own) * -this.depthAt(this.xCenters[inner], z) : spot;
					const depth = Math.max(0, surface - bed[i]);
					const scale = wet ? depth / h[i] : 0;
					h[i] = depth;
					qx[i] *= scale;
					qz[i] *= scale;
				}
			}
		}
	}
	/** Blend relaxation zones toward their prescribed water after each sub-step. */
	relax() {
		for (const { zone, firstRow, lastRow } of this.zones) for (let iz = firstRow; iz <= lastRow; iz += 1) for (let ix = 0; ix < this.nx; ix += 1) {
			const i = iz * this.nx + ix;
			const weight = zone.weights[i];
			if (weight <= 0) continue;
			zone.target(this.xCenters[ix], this.zCenters[iz], this.time, this.target, i);
			const targetDepth = Math.max(0, this.target.eta - this.bed[i]);
			this.h[i] += weight * (targetDepth - this.h[i]);
			const wet = this.h[i] > this.dryDepth;
			this.qx[i] = wet ? this.qx[i] + weight * (this.target.qx - this.qx[i]) : 0;
			this.qz[i] = wet ? this.qz[i] + weight * (this.target.qz - this.qz[i]) : 0;
		}
	}
	/**
	* MUSCL-Hancock step: reconstruct faces once, advance them half a step with
	* each cell's own face fluxes (the Hancock predictor), then take one full
	* conservative step with Riemann fluxes of the predicted faces. One flux
	* evaluation per step instead of SSP-RK2's two.
	*/
	advance(dt) {
		const { h, qx, qz, rateH, rateQx, rateQz } = this;
		this.computeRates(dt);
		for (let i = 0; i < h.length; i += 1) {
			h[i] = Math.max(0, h[i] + dt * rateH[i]);
			const wet = h[i] > this.dryDepth;
			qx[i] = wet ? qx[i] + dt * rateQx[i] : 0;
			qz[i] = wet ? qz[i] + dt * rateQz[i] : 0;
		}
		this.applyFriction(dt);
	}
	/** The Hancock predictor's faces, then the conservative rates of h, qx and qz over a step of `dt`. */
	computeRates(dt) {
		this.predictFaces(.5 * dt);
		this.rateH.fill(0);
		this.rateQx.fill(0);
		this.rateQz.fill(0);
		this.fluxAlongX();
		this.fluxAlongZ();
	}
	/** Semi-implicit Manning bottom friction over `dt`. */
	applyFriction(dt) {
		const { h, qx, qz } = this;
		if (this.manning > 0) {
			const factor = dt * this.gravity * this.manning * this.manning;
			for (let i = 0; i < h.length; i += 1) {
				const depth = h[i];
				if (depth <= this.dryDepth) continue;
				const damping = 1 + factor * (Math.sqrt(qx[i] * qx[i] + qz[i] * qz[i]) / depth) / (depth * Math.cbrt(depth));
				qx[i] /= damping;
				qz[i] /= damping;
			}
		}
	}
	/**
	* MC-limited faces of every cell along x and z (walls mirror, open edges extend
	* the cell), advanced half a step by the Hancock predictor in the same pass:
	* each cell's own face fluxes and the corrector's bed-slope source, so a lake
	* at rest predicts no change.
	*/
	predictFaces(half) {
		const { nx, nz, h, qx, qz, bed, u, w, eta, dz, zGaps, dryDepth, gravity: g, predictorX, predictorZ, predictorMask } = this;
		const { xhW, xhE, xetaW, xetaE, xuW, xuE, xwW, xwE, zhS, zhN, zetaS, zetaN, zwS, zwN, zuS, zuN } = this;
		for (let i = 0; i < h.length; i += 1) {
			const wet = h[i] > dryDepth;
			u[i] = wet ? qx[i] / h[i] : 0;
			w[i] = wet ? qz[i] / h[i] : 0;
			eta[i] = h[i] + bed[i];
		}
		const periodic = this.xBoundary === 1;
		const wallX = this.xBoundary === 0;
		const invDx = 1 / this.dx;
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			const hasBelow = iz > 0;
			const hasAbove = iz < nz - 1;
			const backScale = hasBelow ? dz[iz] / zGaps[iz - 1] : 1;
			const forwardScale = hasAbove ? dz[iz] / zGaps[iz] : 1;
			const invDz = 1 / dz[iz];
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const hasLeft = ix > 0 || periodic;
				const hasRight = ix < nx - 1 || periodic;
				const left = ix > 0 ? i - 1 : row + nx - 1;
				const right = ix < nx - 1 ? i + 1 : row;
				const below = i - nx;
				const above = i + nx;
				const hi = h[i];
				const hL = hasLeft ? h[left] : hi;
				const hR = hasRight ? h[right] : hi;
				const hB = hasBelow ? h[below] : hi;
				const hA = hasAbove ? h[above] : hi;
				const ei = eta[i];
				if (hi <= 0 && hL <= 0 && hR <= 0 && hB <= 0 && hA <= 0) {
					xhW[i] = 0;
					xhE[i] = 0;
					xetaW[i] = ei;
					xetaE[i] = ei;
					xuW[i] = 0;
					xuE[i] = 0;
					xwW[i] = 0;
					xwE[i] = 0;
					zhS[i] = 0;
					zhN[i] = 0;
					zetaS[i] = ei;
					zetaN[i] = ei;
					zwS[i] = 0;
					zwN[i] = 0;
					zuS[i] = 0;
					zuN[i] = 0;
					continue;
				}
				const ui = u[i];
				const wi = w[i];
				const shx = .5 * limited(hi - hL, hR - hi);
				const sex = .5 * limited(ei - (hasLeft ? eta[left] : ei), (hasRight ? eta[right] : ei) - ei);
				const sux = .5 * limited(ui - (hasLeft ? u[left] : wallX ? -ui : ui), (hasRight ? u[right] : wallX ? -ui : ui) - ui);
				const swx = .5 * limited(wi - (hasLeft ? w[left] : wi), (hasRight ? w[right] : wi) - wi);
				const shz = .5 * limited((hi - hB) * backScale, (hA - hi) * forwardScale);
				const sez = .5 * limited((ei - (hasBelow ? eta[below] : ei)) * backScale, ((hasAbove ? eta[above] : ei) - ei) * forwardScale);
				const swz = .5 * limited((wi - (hasBelow ? w[below] : -wi)) * backScale, ((hasAbove ? w[above] : -wi) - wi) * forwardScale);
				const suz = .5 * limited((ui - (hasBelow ? u[below] : ui)) * backScale, ((hasAbove ? u[above] : ui) - ui) * forwardScale);
				const westRaw = hi - shx;
				const eastRaw = hi + shx;
				const southRaw = hi - shz;
				const northRaw = hi + shz;
				const hW = westRaw > 0 ? westRaw : 0;
				const hE = eastRaw > 0 ? eastRaw : 0;
				const hS = southRaw > 0 ? southRaw : 0;
				const hN = northRaw > 0 ? northRaw : 0;
				const uW = ui - sux;
				const uE = ui + sux;
				const vW = wi - swx;
				const vE = wi + swx;
				const wS = wi - swz;
				const wN = wi + swz;
				const tS = ui - suz;
				const tN = ui + suz;
				const etaW = ei - sex;
				const etaE = ei + sex;
				const etaS = ei - sez;
				const etaN = ei + sez;
				const massX = hE * uE - hW * uW;
				const massZ = hN * wN - hS * wS;
				const pressureX = hE * uE * uE + .5 * g * hE * hE - hW * uW * uW - .5 * g * hW * hW - g * .5 * (hW + hE) * (etaW - hW - (etaE - hE));
				const pressureZ = hN * wN * wN + .5 * g * hN * hN - hS * wS * wS - .5 * g * hS * hS - g * .5 * (hS + hN) * (etaS - hS - (etaN - hN));
				const shearX = hE * uE * vE - hW * uW * vW;
				const shearZ = hN * wN * tN - hS * wS * tS;
				const dH = -half * (massX * invDx + massZ * invDz);
				let dQx = -half * (pressureX * invDx + shearZ * invDz);
				let dQz = -half * (shearX * invDx + pressureZ * invDz);
				if (predictorX && predictorZ && predictorMask && predictorMask[i] > 0) {
					dQx += half * predictorX[i];
					dQz += half * predictorZ[i];
				}
				let depth = hW + dH;
				if (depth > dryDepth) {
					const inverse = 1 / depth;
					xuW[i] = (hW * uW + dQx) * inverse;
					xwW[i] = (hW * vW + dQz) * inverse;
				} else {
					depth = depth > 0 ? depth : 0;
					xuW[i] = 0;
					xwW[i] = 0;
				}
				xetaW[i] = etaW + depth - hW;
				xhW[i] = depth;
				depth = hE + dH;
				if (depth > dryDepth) {
					const inverse = 1 / depth;
					xuE[i] = (hE * uE + dQx) * inverse;
					xwE[i] = (hE * vE + dQz) * inverse;
				} else {
					depth = depth > 0 ? depth : 0;
					xuE[i] = 0;
					xwE[i] = 0;
				}
				xetaE[i] = etaE + depth - hE;
				xhE[i] = depth;
				depth = hS + dH;
				if (depth > dryDepth) {
					const inverse = 1 / depth;
					zwS[i] = (hS * wS + dQz) * inverse;
					zuS[i] = (hS * tS + dQx) * inverse;
				} else {
					depth = depth > 0 ? depth : 0;
					zwS[i] = 0;
					zuS[i] = 0;
				}
				zetaS[i] = etaS + depth - hS;
				zhS[i] = depth;
				depth = hN + dH;
				if (depth > dryDepth) {
					const inverse = 1 / depth;
					zwN[i] = (hN * wN + dQz) * inverse;
					zuN[i] = (hN * tN + dQx) * inverse;
				} else {
					depth = depth > 0 ? depth : 0;
					zwN[i] = 0;
					zuN[i] = 0;
				}
				zetaN[i] = etaN + depth - hN;
				zhN[i] = depth;
			}
		}
	}
	/** Riemann fluxes and well-balanced sources across x faces, row by row. */
	fluxAlongX() {
		const { nx, nz, rateH, rateQx, rateQz, flux, gravity: g } = this;
		const { xhW, xhE, xetaW, xetaE, xuW, xuE, xwW, xwE } = this;
		const periodic = this.xBoundary === 1;
		const wall = this.xBoundary === 0;
		const invDx = 1 / this.dx;
		const interfaces = periodic ? nx : nx - 1;
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			for (let ix = 0; ix < interfaces; ix += 1) {
				const left = row + ix;
				const right = ix + 1 < nx ? left + 1 : row;
				if (xhE[left] <= 0 && xhW[right] <= 0) continue;
				interfaceFlux(xhE[left], xetaE[left], xuE[left], xwE[left], xhW[right], xetaW[right], xuW[right], xwW[right], g, flux);
				rateH[left] -= flux.mass * invDx;
				rateQx[left] -= (flux.normal + flux.leftCorrection) * invDx;
				rateQz[left] -= flux.tangent * invDx;
				rateH[right] += flux.mass * invDx;
				rateQx[right] += (flux.normal + flux.rightCorrection) * invDx;
				rateQz[right] += flux.tangent * invDx;
			}
			if (!periodic) {
				const first = row;
				if (xhW[first] > 0) {
					interfaceFlux(xhW[first], xetaW[first], wall ? -xuW[first] : xuW[first], xwW[first], xhW[first], xetaW[first], xuW[first], xwW[first], g, flux);
					rateH[first] += flux.mass * invDx;
					rateQx[first] += (flux.normal + flux.rightCorrection) * invDx;
					rateQz[first] += flux.tangent * invDx;
				}
				const last = row + nx - 1;
				if (xhE[last] > 0) {
					interfaceFlux(xhE[last], xetaE[last], xuE[last], xwE[last], xhE[last], xetaE[last], wall ? -xuE[last] : xuE[last], xwE[last], g, flux);
					rateH[last] -= flux.mass * invDx;
					rateQx[last] -= (flux.normal + flux.leftCorrection) * invDx;
					rateQz[last] -= flux.tangent * invDx;
				}
			}
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const depthSum = xhW[i] + xhE[i];
				if (depthSum <= 0) continue;
				rateQx[i] += g * .5 * depthSum * (xetaW[i] - xhW[i] - (xetaE[i] - xhE[i])) * invDx;
			}
		}
	}
	/** Riemann fluxes and well-balanced sources across z faces, with walls at both cross-shore ends. */
	fluxAlongZ() {
		const { nx, nz, dz, rateH, rateQx, rateQz, flux, gravity: g } = this;
		const { zhS, zhN, zetaS, zetaN, zwS, zwN, zuS, zuN } = this;
		for (let iz = 0; iz < nz - 1; iz += 1) {
			const invLower = 1 / dz[iz];
			const invUpper = 1 / dz[iz + 1];
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const lower = row + ix;
				const upper = lower + nx;
				if (zhN[lower] <= 0 && zhS[upper] <= 0) continue;
				interfaceFlux(zhN[lower], zetaN[lower], zwN[lower], zuN[lower], zhS[upper], zetaS[upper], zwS[upper], zuS[upper], g, flux);
				rateH[lower] -= flux.mass * invLower;
				rateQz[lower] -= (flux.normal + flux.leftCorrection) * invLower;
				rateQx[lower] -= flux.tangent * invLower;
				rateH[upper] += flux.mass * invUpper;
				rateQz[upper] += (flux.normal + flux.rightCorrection) * invUpper;
				rateQx[upper] += flux.tangent * invUpper;
			}
		}
		const invFirst = 1 / dz[0];
		const invLast = 1 / dz[nz - 1];
		const lastRow = (nz - 1) * nx;
		for (let ix = 0; ix < nx; ix += 1) {
			const south = ix;
			if (zhS[south] > 0) {
				interfaceFlux(zhS[south], zetaS[south], -zwS[south], zuS[south], zhS[south], zetaS[south], zwS[south], zuS[south], g, flux);
				rateH[south] += flux.mass * invFirst;
				rateQz[south] += (flux.normal + flux.rightCorrection) * invFirst;
				rateQx[south] += flux.tangent * invFirst;
			}
			const north = lastRow + ix;
			if (zhN[north] > 0) {
				interfaceFlux(zhN[north], zetaN[north], zwN[north], zuN[north], zhN[north], zetaN[north], -zwN[north], zuN[north], g, flux);
				rateH[north] -= flux.mass * invLast;
				rateQz[north] -= (flux.normal + flux.leftCorrection) * invLast;
				rateQx[north] -= flux.tangent * invLast;
			}
		}
		for (let iz = 0; iz < nz; iz += 1) {
			const inverse = 1 / dz[iz];
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const depthSum = zhS[i] + zhN[i];
				if (depthSum <= 0) continue;
				rateQz[i] += g * .5 * depthSum * (zetaS[i] - zhS[i] - (zetaN[i] - zhN[i])) * inverse;
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/BoussinesqSolver.ts
/** Madsen & Sørensen (1992) dispersion coefficient: the [2,2] Padé fit to Airy. */
const MADSEN_SORENSEN_B = 1 / 15;
const ALPHA = .39999999999999997;
/** A cell disperses only where it and its neighbours hold at least this much water, over this much still depth, m. */
const DISPERSIVE_DEPTH = .05;
/** Tonelli & Petti (2009), FUNWAVE-TVD's default: shallow water where the surface stands this high over the still depth (or a trough this deep below it). */
const SWITCH_RATIO = .8;
/**
* The plunge zone: where a jet lands, the water is an impact, a plume and a splash-up, not the weakly nonlinear
* wave the dispersive terms assume (on the Teahupo'o Reef a landing piled 0.4 m of water to 1.5 m, and the terms
* drained it at 23.5 m/s). A landing holds shallow water over the young roller, about 2 H long (L tan θ ≈ H,
* Martins et al. 2018): from `behind` of the breaking wave's height H behind where it lands (the jet's thickness
* and the splash thrown back) to `ahead` of H beyond (the impact's rise, to about 2.5 depths: Chanson, Aoki &
* Maruyama 2002), one cell either side of its travel, for Kennedy's T* = `hold` √(d/g) after it lands. It never
* reaches back past where the jet left the crest: the void's face keeps its dispersion, since it breaks only when
* the void collapses. A fixed impact zone ends on a time cap; a zone following a bore would end where its Froude
* number falls below 1.3 (Tissier et al. 2012). Advice from the water-physics advisor (the wave-shape-advisor note).
*/
const PLUNGE = {
	behind: .5,
	ahead: 1.5,
	hold: 5
};
/**
* FUNWAVE-TVD's Froude cap (`capFroude`): the largest Froude number a wet cell keeps, the depth under which it is
* left alone (FUNWAVE's wet depth, MinDepth), and the depth above which a capped cell counts as water, m.
*/
const FROUDE_CAP = {
	froude: 10,
	wetDepth: .01,
	countDepth: .05
};
/** Phase speed ω/k the Madsen–Sørensen equations give at depth d: ω² = g d k² (1 + B(kd)²)/(1 + α(kd)²). */
function madsenSorensenCelerity(omega, depth, g = GRAVITY$1) {
	const B = MADSEN_SORENSEN_B;
	let k = omega / Math.sqrt(g * depth);
	for (let i = 0; i < 60; i += 1) {
		const s = (k * depth) ** 2;
		const ratio = (1 + B * s) / (1 + ALPHA * s);
		const f = g * depth * k * k * ratio - omega * omega;
		const dRatio = -.6666666666666666 * k * depth * depth / (1 + ALPHA * s) ** 2;
		const df = g * depth * (2 * k * ratio + k * k * dRatio);
		const next = k - f / df;
		if (Math.abs(next - k) < 1e-14 * k) return omega / next;
		k = next;
	}
	return omega / k;
}
/** The wave number ω/c the Madsen–Sørensen equations give at depth d, 1/m (a deep tank's boundary sea, the wave-sizes spec). */
function madsenSorensenWaveNumber(omega, depth, g = GRAVITY$1) {
	return omega / madsenSorensenCelerity(omega, depth, g);
}
/** Thinner water does not break, m. */
const BREAKING_DEPTH = .05;
/** The eddy viscosity never exceeds this share of H √(gH): a mixing length of the depth at the long-wave speed. */
const MAX_EDDY = .3;
/** Solve a tridiagonal system in place (Thomas): lower a, diagonal b, upper c, right side r → solution in r. */
function thomas(a, b, c, r, scratch, n) {
	let denominator = b[0];
	scratch[0] = c[0] / denominator;
	r[0] /= denominator;
	for (let i = 1; i < n; i += 1) {
		denominator = b[i] - a[i] * scratch[i - 1];
		scratch[i] = c[i] / denominator;
		r[i] = (r[i] - a[i] * r[i - 1]) / denominator;
	}
	for (let i = n - 2; i >= 0; i -= 1) r[i] -= scratch[i] * r[i + 1];
}
/**
* Stage 2 surf-zone solver (plan §1.8): the shallow-water fluxes of stage 1 plus
* the Madsen & Sørensen (1992) dispersive terms in modified-flux form,
*
*   P̄ = P − α d²(P_xx + Q_xy) − d d_x(P_x/3 + Q_y/6) − d d_y Q_x/6,
*   P̄_t + (shallow-water terms) = B g d³(η_xxx + η_xyy) + B g d² d_x(2η_xx + η_yy) + B g d² d_y η_xy,
*
* and the same along y (here z) with x and y exchanged: d is the still depth
* and α = B + 1/3. A step advances P̄ and Q̄ with the Hancock step's rates and
* the dispersive sources at the half step, then recovers P by one tridiagonal
* solve per row and Q by one per column; the cross terms use the latest other
* flux (the hybrid FV/FD structure of Celeris and FUNWAVE-TVD). Where the
* water is thin or the surface stands above 0.8 of the still depth (Tonelli
* and Petti 2009), or a jet has just landed (`holdPlunge`), a cell reverts to
* shallow water, so bores stay shock-captured.
*/
var BoussinesqSolver = class extends ShallowWaterSolver {
	dispersive;
	/** Breaking strength B in [0, 1], seconds since the bore over each cell began breaking, surface rise rate η_t (m/s) and eddy viscosity (m²/s). */
	breakingStrength;
	breakingAge;
	riseRate;
	viscosity;
	/** Multiplies the breaking onset; the local wind shifts it (plan Q23). */
	onsetScale = 1;
	kennedy;
	/** Whether waves break inside the step (Kennedy eddy viscosity). */
	get breaks() {
		return this.kennedy !== void 0;
	}
	nextStrength;
	nextAge;
	viscousX;
	viscousZ;
	viscosityPeak = 0;
	/** The still depth and its slopes follow the bed; recomputed when the window shifts. */
	depthDirty = true;
	layoutVersion = 0;
	/** Column solves, all columns at once row by row: the eliminated upper band and right side. */
	columnUpper;
	columnRight;
	finest;
	/** Still depth, m, and whether each cell disperses this step (1) or is shallow water (0). */
	still;
	mask;
	/** Seconds each cell stays shallow water because a jet landed on it (`holdPlunge`); 0 elsewhere. */
	plungeHold;
	/** Changes whenever a cell enters or leaves the plunge zone: a device uploads the zone again. */
	plungeVersion = 0;
	/** Cells the Froude cap has slowed so far, and those among them deeper than 5 cm (a health metric). */
	froudeCaps = 0;
	froudeCapsInWater = 0;
	pBar;
	qBar;
	sourceX;
	sourceZ;
	halfEta;
	dX;
	dZ;
	/** Derivative scratch. */
	f1;
	f2;
	f3;
	f4;
	f5;
	f6;
	/** Distance to the neighbour centre below and above each row (ghosts beyond the walls), m. */
	below;
	above;
	lowerBand;
	diagonal;
	upperBand;
	right;
	scratch;
	spare;
	/** P and Q as the step began, to measure the acceleration beyond shallow water for the next predictor. */
	startP;
	startQ;
	constructor(grid, depthAt, options = {}) {
		super(grid, depthAt, options);
		this.dispersive = options.dispersion ?? true;
		if (options.breaking) this.kennedy = {
			end: .15,
			transition: 5,
			delta: 1.2,
			...options.breaking
		};
		const size = this.nx * this.nz;
		const make = () => new Float64Array(size);
		this.breakingStrength = make();
		this.breakingAge = make();
		this.riseRate = make();
		this.viscosity = make();
		this.nextStrength = make();
		this.nextAge = make();
		this.viscousX = make();
		this.viscousZ = make();
		this.columnUpper = make();
		this.columnRight = make();
		this.finest = Math.min(this.dx, ...this.dz);
		this.still = make();
		this.mask = make();
		this.plungeHold = make();
		this.pBar = make();
		this.qBar = make();
		this.sourceX = make();
		this.sourceZ = make();
		this.halfEta = make();
		this.dX = make();
		this.dZ = make();
		this.f1 = make();
		this.f2 = make();
		this.f3 = make();
		this.f4 = make();
		this.f5 = make();
		this.f6 = make();
		this.below = new Float64Array(this.nz);
		this.above = new Float64Array(this.nz);
		for (let iz = 0; iz < this.nz; iz += 1) {
			this.below[iz] = iz > 0 ? this.zGaps[iz - 1] : this.dz[0];
			this.above[iz] = iz < this.nz - 1 ? this.zGaps[iz] : this.dz[this.nz - 1];
		}
		const longest = Math.max(this.nx, this.nz);
		this.lowerBand = new Float64Array(longest);
		this.diagonal = new Float64Array(longest);
		this.upperBand = new Float64Array(longest);
		this.right = new Float64Array(longest);
		this.scratch = new Float64Array(longest);
		this.spare = new Float64Array(longest);
		this.startP = make();
		this.startQ = make();
		if (this.dispersive) {
			this.predictorX = make();
			this.predictorZ = make();
			this.predictorMask = this.mask;
		}
	}
	/** Advance by `dt` seconds; the plunge zone ages once the water has moved (a device step ages it in `adoptDeviceStep`). */
	step(dt) {
		super.step(dt);
		this.agePlunge(dt);
	}
	/**
	* A jet from a breaking wave `height` m high landed at (x, z), travelling along (dirX, dirZ), `flown` m on from
	* where it left the crest: hold its impact zone in shallow water (`PLUNGE`). A cell already held keeps the longer
	* of its two holds.
	*/
	holdPlunge(x, z, dirX, dirZ, height, flown = Infinity) {
		const { nx, nz, dx, xCenters, zCenters, still, plungeHold, gravity: g } = this;
		this.refreshStillDepth();
		const travel = Math.hypot(dirX, dirZ);
		const ux = travel > 0 ? dirX / travel : 0;
		const uz = travel > 0 ? dirZ / travel : 0;
		const drop = Math.max(0, height);
		const behind = Math.min(PLUNGE.behind * drop, Math.max(0, flown));
		const ahead = PLUNGE.ahead * drop;
		const reach = Math.max(behind, ahead) + dx;
		const first = Math.max(0, Math.ceil((x - reach - xCenters[0]) / dx));
		const last = Math.min(nx - 1, Math.floor((x + reach - xCenters[0]) / dx));
		for (let iz = 0; iz < nz; iz += 1) {
			const across = zCenters[iz] - z;
			if (Math.abs(across) > reach) continue;
			for (let ix = first; ix <= last; ix += 1) {
				const along = xCenters[ix] - x;
				const s = Math.min(ahead, Math.max(-behind, along * ux + across * uz));
				if (Math.hypot(along - s * ux, across - s * uz) > dx + 1e-9) continue;
				const i = iz * nx + ix;
				const hold = PLUNGE.hold * Math.sqrt(Math.max(DISPERSIVE_DEPTH, still[i]) / g);
				if (!(plungeHold[i] > 0)) this.plungeVersion += 1;
				if (hold > plungeHold[i]) plungeHold[i] = hold;
			}
		}
	}
	/** The plunge zone `dt` seconds on: cells whose hold has run out disperse again. */
	agePlunge(dt) {
		if (!(dt > 0)) return;
		const { plungeHold } = this;
		for (let i = 0; i < plungeHold.length; i += 1) {
			if (!(plungeHold[i] > 0)) continue;
			plungeHold[i] = Math.max(0, plungeHold[i] - dt);
			if (plungeHold[i] === 0) this.plungeVersion += 1;
		}
	}
	advance(dt) {
		if (!this.dispersive && !this.kennedy) {
			super.advance(dt);
			return;
		}
		const { h, qx, qz, rateH, rateQx, rateQz, pBar, qBar, sourceX, sourceZ, dryDepth } = this;
		this.startP.set(qx);
		this.startQ.set(qz);
		this.updateMask();
		this.modifiedFluxes();
		this.computeRates(dt);
		this.halfStepSurface();
		this.dispersiveSources();
		this.breakingTerms(dt);
		const { viscousX, viscousZ } = this;
		for (let i = 0; i < h.length; i += 1) {
			h[i] = Math.max(0, h[i] + dt * rateH[i]);
			const wet = h[i] > dryDepth;
			pBar[i] = wet ? pBar[i] + dt * (rateQx[i] + sourceX[i] + viscousX[i]) : 0;
			qBar[i] = wet ? qBar[i] + dt * (rateQz[i] + sourceZ[i] + viscousZ[i]) : 0;
		}
		this.recoverRows();
		this.recoverColumns();
		const { startP, startQ, predictorX, predictorZ } = this;
		for (let i = 0; i < h.length; i += 1) {
			if (h[i] > dryDepth) {
				if (predictorX && predictorZ) {
					predictorX[i] = (qx[i] - startP[i]) / dt - rateQx[i];
					predictorZ[i] = (qz[i] - startQ[i]) / dt - rateQz[i];
				}
				continue;
			}
			qx[i] = 0;
			qz[i] = 0;
			if (predictorX && predictorZ) {
				predictorX[i] = 0;
				predictorZ[i] = 0;
			}
		}
		this.applyFriction(dt);
		this.capFroude();
	}
	/**
	* FUNWAVE-TVD's Froude cap (FroudeCap, 5–10; Shi et al. 2011, CACR-11-04): a wet cell's speed stays under ten
	* times its shallow-water wave speed. The P/Q recovery can pin a thin dispersing cell's flux to its held
	* neighbours', and u = P/h then runs away (the Reef's biggest seas). `SWITCH_FROUDE` takes such water out of the
	* dispersion first; this is the net under it, counted so a report shows if it ever holds real water. Water under
	* FUNWAVE's 1 cm wet depth is left to friction. A capped cell's predictor is dropped: its step was not the
	* dispersive terms'.
	*/
	capFroude() {
		const { h, qx, qz, predictorX, predictorZ, gravity: g } = this;
		for (let i = 0; i < h.length; i += 1) {
			const depth = h[i];
			if (!(depth >= FROUDE_CAP.wetDepth)) continue;
			const speed = Math.hypot(qx[i], qz[i]) / depth;
			const limit = FROUDE_CAP.froude * Math.sqrt(g * depth);
			if (!(speed > limit)) continue;
			const scale = limit / speed;
			qx[i] *= scale;
			qz[i] *= scale;
			if (predictorX && predictorZ) {
				predictorX[i] = 0;
				predictorZ[i] = 0;
			}
			this.froudeCaps += 1;
			if (depth > FROUDE_CAP.countDepth) this.froudeCapsInWater += 1;
		}
	}
	/** The dispersive acceleration the next Hancock predictor adds, per cell; absent without dispersion. */
	get predictor() {
		return this.predictorX && this.predictorZ ? {
			x: this.predictorX,
			z: this.predictorZ
		} : void 0;
	}
	/** The constants, still depth and zones a device step needs (refreshed first). */
	deviceLayout() {
		this.refreshStillDepth();
		const kennedy = this.kennedy;
		return {
			gravity: this.gravity,
			dryDepth: this.dryDepth,
			manning: this.manning,
			xBoundary: this.xBoundary,
			dispersive: this.dispersive,
			breaking: kennedy && {
				onset: kennedy.onset * this.onsetScale,
				end: kennedy.end,
				transition: kennedy.transition,
				mixing: kennedy.delta * kennedy.delta
			},
			still: this.still,
			slopeX: this.dX,
			slopeZ: this.dZ,
			below: this.below,
			above: this.above,
			gaps: this.zGaps,
			version: this.layoutVersion,
			zones: this.relaxationZones
		};
	}
	/**
	* Book a step of `elapsed` seconds that a device took and wrote back into h,
	* qx, qz and the breaking and predictor fields: the clock, the eddy
	* viscosity's step limit from the viscosity it read back, and the plunge zone.
	*/
	adoptDeviceStep(elapsed) {
		this.time += elapsed;
		let peak = 0;
		for (const nu of this.viscosity) if (nu > peak) peak = nu;
		this.viscosityPeak = peak;
		this.agePlunge(elapsed);
	}
	/** The CFL step, and for breaking water the explicit eddy viscosity's limit. */
	maxStableStep() {
		const step = super.maxStableStep();
		return this.viscosityPeak > 0 ? Math.min(step, .2 * this.finest * this.finest / this.viscosityPeak) : step;
	}
	/**
	* Kennedy breaking from this step's surface rise rate (the continuity rate),
	* and the eddy-viscosity terms R_x = ∂x(ν P_x) + ½∂y(ν(P_y + Q_x)),
	* R_y = ½∂x(ν(P_y + Q_x)) + ∂y(ν Q_y).
	*/
	breakingTerms(dt) {
		const { viscousX, viscousZ } = this;
		const kennedy = this.kennedy;
		if (!kennedy) {
			viscousX.fill(0);
			viscousZ.fill(0);
			return;
		}
		const { nx, nz, h, rateH, breakingStrength: strength, breakingAge: age, nextStrength, nextAge, riseRate, viscosity: nu, gravity: g } = this;
		const onset = kennedy.onset * this.onsetScale;
		const mixing = kennedy.delta * kennedy.delta;
		const { halfEta, f1: slopeX, f2: slopeZ } = this;
		this.derivativeX(halfEta, slopeX, false);
		this.derivativeZ(halfEta, slopeZ, false);
		let peak = 0;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const depth = h[i];
			const rise = rateH[i];
			riseRate[i] = rise;
			if (depth <= BREAKING_DEPTH) {
				nextStrength[i] = 0;
				nextAge[i] = 0;
				nu[i] = 0;
				continue;
			}
			const inherited = inheritedAge(i, ix, iz, nx, nz, slopeX[i], slopeZ[i], strength, age);
			const still = Math.max(BREAKING_DEPTH, this.still[i]);
			const ramp = Math.min(1, inherited / (kennedy.transition * Math.sqrt(still / g)));
			const threshold = Math.sqrt(g * still) * (onset + (kennedy.end - onset) * ramp);
			const breaking = Math.min(1, Math.max(0, rise / threshold - 1));
			nextStrength[i] = breaking;
			nextAge[i] = breaking > 0 ? inherited + dt : 0;
			nu[i] = breaking > 0 ? Math.min(MAX_EDDY * depth * Math.sqrt(g * depth), breaking * mixing * depth * rise) : 0;
			if (nu[i] > peak) peak = nu[i];
		}
		strength.set(nextStrength);
		age.set(nextAge);
		this.viscosityPeak = peak;
		if (!(peak > 0)) {
			viscousX.fill(0);
			viscousZ.fill(0);
			return;
		}
		const { qx: P, qz: Q, below, above, f1, f2, f3 } = this;
		const periodic = this.xBoundary === 1;
		const pEdge = this.xBoundary === 0 ? -1 : 1;
		const inverse = 1 / (this.dx * this.dx);
		for (let iz = 0; iz < nz; iz += 1) {
			const minus = below[iz];
			const plus = above[iz];
			const across = 2 / (minus + plus);
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const left = ix > 0 ? i - 1 : periodic ? row + nx - 1 : -1;
				const right = ix < nx - 1 ? i + 1 : periodic ? row : -1;
				const nuL = left >= 0 ? .5 * (nu[i] + nu[left]) : nu[i];
				const nuR = right >= 0 ? .5 * (nu[i] + nu[right]) : nu[i];
				const pL = left >= 0 ? P[left] : pEdge * P[i];
				viscousX[i] = (nuR * ((right >= 0 ? P[right] : pEdge * P[i]) - P[i]) - nuL * (P[i] - pL)) * inverse;
				const down = iz > 0 ? i - nx : -1;
				const up = iz < nz - 1 ? i + nx : -1;
				const nuD = down >= 0 ? .5 * (nu[i] + nu[down]) : nu[i];
				const nuU = up >= 0 ? .5 * (nu[i] + nu[up]) : nu[i];
				const qD = down >= 0 ? Q[down] : -Q[i];
				viscousZ[i] = (nuU * ((up >= 0 ? Q[up] : -Q[i]) - Q[i]) / plus - nuD * (Q[i] - qD) / minus) * across;
			}
		}
		this.derivativeZ(P, f1, false);
		this.derivativeX(Q, f2, false);
		for (let i = 0; i < f1.length; i += 1) f3[i] = nu[i] * (f1[i] + f2[i]);
		this.derivativeZ(f3, f1, true);
		this.derivativeX(f3, f2, true);
		for (let i = 0; i < f1.length; i += 1) {
			viscousX[i] += .5 * f1[i];
			viscousZ[i] += .5 * f2[i];
		}
	}
	/**
	* Still depth and the dispersive mask. A cell disperses when every cell its
	* stencils reach (two along each axis, one diagonally) holds water over still
	* depth, and its surface stands within the Tonelli–Petti ratio of still water:
	* no higher at a crest, and no deeper in a trough, and its water runs no
	* faster than `SWITCH_FROUDE` long-wave speeds. The weakly nonlinear terms
	* fail as badly in a trough that has drained a reef ledge as at a breaking
	* crest (the Teahupo'o Reef's backwash ran away at 0.07 m over 4 m). Nor does
	* a cell disperse inside a jet's plunge zone (`holdPlunge`).
	*/
	updateMask() {
		const { h, qx, qz, still, mask, plungeHold, gravity, f1: wet, f2: alongX, f3: box, f4: work } = this;
		this.refreshStillDepth();
		for (let i = 0; i < h.length; i += 1) wet[i] = h[i] > DISPERSIVE_DEPTH && still[i] > DISPERSIVE_DEPTH ? 1 : 0;
		this.erodeX(wet, alongX, 2);
		this.erodeX(wet, work, 1);
		this.erodeZ(work, box, 1);
		this.erodeZ(wet, work, 2);
		const on = this.dispersive ? 1 : 0;
		for (let i = 0; i < h.length; i += 1) {
			const flux = qx[i] * qx[i] + qz[i] * qz[i];
			const weak = !(plungeHold[i] > 0) && Math.abs(h[i] - still[i]) <= SWITCH_RATIO * still[i] && flux <= 4 * gravity * h[i] * h[i] * h[i];
			mask[i] = wet[i] > 0 && alongX[i] > 0 && work[i] > 0 && box[i] > 0 && weak ? on : 0;
		}
	}
	refreshStillDepth() {
		if (!this.depthDirty) return;
		const { bed, restLevel, still } = this;
		for (let i = 0; i < still.length; i += 1) still[i] = Math.max(0, restLevel - bed[i]);
		this.derivativeX(still, this.dX, false);
		this.derivativeZ(still, this.dZ, false);
		this.depthDirty = false;
	}
	/** The smallest of `f` within `reach` cells along x (clamped at edges, wrapped when periodic). */
	erodeX(f, out, reach) {
		const { nx, nz } = this;
		const periodic = this.xBoundary === 1;
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				let least = f[row + ix];
				for (let k = -reach; k <= reach && least > 0; k += 1) {
					let j = ix + k;
					if (j < 0) j = periodic ? j + nx : 0;
					else if (j >= nx) j = periodic ? j - nx : nx - 1;
					least = Math.min(least, f[row + j]);
				}
				out[row + ix] = least;
			}
		}
	}
	/** The smallest of `f` within `reach` rows along z (clamped at the ends). */
	erodeZ(f, out, reach) {
		const { nx, nz } = this;
		for (let iz = 0; iz < nz; iz += 1) {
			const low = Math.max(0, iz - reach);
			const high = Math.min(nz - 1, iz + reach);
			for (let ix = 0; ix < nx; ix += 1) {
				let least = f[iz * nx + ix];
				for (let k = low; k <= high && least > 0; k += 1) least = Math.min(least, f[k * nx + ix]);
				out[iz * nx + ix] = least;
			}
		}
	}
	/**
	* The carried breaking and predictor state changed outside a step (a sea taken
	* over, or restored for a lesson, spec L2): a device uploads it again before
	* its next step, as after a window shift.
	*/
	invalidateDeviceLayout() {
		this.layoutVersion += 1;
	}
	shiftAlongShore(columns) {
		super.shiftAlongShore(columns);
		this.depthDirty = true;
		this.layoutVersion += 1;
		const shift = Math.trunc(columns);
		if (shift === 0) return;
		const { nx, nz } = this;
		const carried = [
			this.breakingStrength,
			this.breakingAge,
			this.viscosity,
			this.plungeHold,
			...this.predictorX && this.predictorZ ? [this.predictorX, this.predictorZ] : []
		];
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			for (const values of carried) if (shift > 0) {
				values.copyWithin(row, row + shift, row + nx);
				values.fill(0, row + nx - shift, row + nx);
			} else {
				values.copyWithin(row - shift, row, row + nx + shift);
				values.fill(0, row, row - shift);
			}
		}
	}
	/** P̄ and Q̄ from P and Q. */
	modifiedFluxes() {
		const { qx: P, qz: Q, pBar, qBar, still: d, dX, dZ, mask, f1, f2, f3, f4, f5, f6 } = this;
		this.secondX(P, f1, true);
		this.derivativeX(P, f2, true);
		this.derivativeZ(Q, f3, true);
		this.derivativeX(f3, f4, false);
		this.derivativeX(Q, f5, false);
		for (let i = 0; i < P.length; i += 1) pBar[i] = mask[i] > 0 ? P[i] - ALPHA * d[i] * d[i] * (f1[i] + f4[i]) - d[i] * dX[i] * (f2[i] / 3 + f3[i] / 6) - d[i] * dZ[i] * f5[i] / 6 : P[i];
		this.secondZ(Q, f1, true);
		this.derivativeZ(f2, f4, false);
		this.derivativeZ(P, f6, false);
		for (let i = 0; i < Q.length; i += 1) qBar[i] = mask[i] > 0 ? Q[i] - ALPHA * d[i] * d[i] * (f1[i] + f4[i]) - d[i] * dZ[i] * (f3[i] / 3 + f2[i] / 6) - d[i] * dX[i] * f6[i] / 6 : Q[i];
	}
	/** The surface at the half step, from the Hancock predictor's four faces of each cell. */
	halfStepSurface() {
		const { halfEta, xetaW, xetaE, zetaS, zetaN } = this;
		for (let i = 0; i < halfEta.length; i += 1) halfEta[i] = .25 * (xetaW[i] + xetaE[i] + zetaS[i] + zetaN[i]);
	}
	/** Bg d³(η_xxx + η_xyy) + Bg d² d_x(2η_xx + η_yy) + Bg d² d_y η_xy, and its y twin. */
	dispersiveSources() {
		const { halfEta: eta, still: d, dX, dZ, mask, sourceX, sourceZ, f1, f2, f3, f4, f5, f6, gravity: g } = this;
		this.secondX(eta, f1, false);
		this.carryCurvatureAcrossOpenEdges(f1);
		this.secondZ(eta, f2, false);
		this.derivativeZ(eta, f5, false);
		this.derivativeX(f5, f3, false);
		this.derivativeX(f1, f4, false);
		this.derivativeX(f2, f5, false);
		for (let i = 0; i < eta.length; i += 1) {
			if (!(mask[i] > 0)) {
				sourceX[i] = 0;
				continue;
			}
			const scale = MADSEN_SORENSEN_B * g * d[i] * d[i];
			sourceX[i] = scale * (d[i] * (f4[i] + f5[i]) + dX[i] * (2 * f1[i] + f2[i]) + dZ[i] * f3[i]);
		}
		this.derivativeZ(f2, f4, false);
		this.derivativeZ(f1, f6, false);
		for (let i = 0; i < eta.length; i += 1) {
			if (!(mask[i] > 0)) {
				sourceZ[i] = 0;
				continue;
			}
			const scale = MADSEN_SORENSEN_B * g * d[i] * d[i];
			sourceZ[i] = scale * (d[i] * (f4[i] + f6[i]) + dZ[i] * (2 * f2[i] + f1[i]) + dX[i] * f3[i]);
		}
	}
	/**
	* η_xx at each open edge column from its inner neighbour: the curvature
	* carries across the edge, as if η were extrapolated quadratically. The
	* extended ghost that serves the shallow-water fluxes would give −η_x/dx
	* there instead, not a curvature at all, and B g d³ η_xxx a surface-slope
	* force (B d²/2dx²) times the hydrostatic one: 2.7 times in 9 m of water on
	* a 1 m grid. Over a bed sloping across the edge, where any along-shore
	* outflow draws the surface down toward the shallower side, that force
	* pushes on the drawdown and runs away.
	*/
	carryCurvatureAcrossOpenEdges(curvature) {
		const { nx, nz } = this;
		if (this.xBoundary !== 2 || nx < 2) return;
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			const west = curvature[row + 1];
			const east = curvature[row + nx - 2];
			curvature[row] = west;
			curvature[row + nx - 1] = east;
		}
	}
	/**
	* P from P̄, row by row: P − α d² P_xx − (d d_x/3) P_x = P̄ + α d² Q_xy + d d_x Q_y/6 + d d_y Q_x/6,
	* the cross terms from the current Q.
	*/
	recoverRows() {
		const { nx, nz, qx: P, qz: Q, pBar, still: d, dX, dZ, mask, f3, f4, f5 } = this;
		const { lowerBand: a, diagonal: b, upperBand: c, right: r, scratch } = this;
		this.derivativeZ(Q, f3, true);
		this.derivativeX(f3, f4, false);
		this.derivativeX(Q, f5, false);
		const periodic = this.xBoundary === 1;
		const edge = this.xBoundary === 0 ? -1 : 1;
		const inverse = 1 / (this.dx * this.dx);
		const half = 1 / (2 * this.dx);
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			let any = false;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				if (mask[i] > 0) {
					any = true;
					const A = ALPHA * d[i] * d[i] * inverse;
					const E = d[i] * dX[i] / 3 * half;
					a[ix] = -(A - E);
					b[ix] = 1 + 2 * A;
					c[ix] = -(A + E);
					r[ix] = pBar[i] + ALPHA * d[i] * d[i] * f4[i] + d[i] * dX[i] * f3[i] / 6 + d[i] * dZ[i] * f5[i] / 6;
				} else {
					a[ix] = 0;
					b[ix] = 1;
					c[ix] = 0;
					r[ix] = pBar[i];
				}
			}
			if (!any) {
				for (let ix = 0; ix < nx; ix += 1) P[row + ix] = pBar[row + ix];
				continue;
			}
			if (periodic) this.cyclic(nx);
			else {
				b[0] += edge * a[0];
				a[0] = 0;
				b[nx - 1] += edge * c[nx - 1];
				c[nx - 1] = 0;
				thomas(a, b, c, r, scratch, nx);
			}
			for (let ix = 0; ix < nx; ix += 1) P[row + ix] = r[ix];
		}
	}
	/**
	* Q from Q̄, column by column: Q − α d² Q_yy − (d d_y/3) Q_y = Q̄ + α d² P_xy + d d_y P_x/6 + d d_x P_y/6,
	* with walls (Q odd) at both cross-shore ends.
	*/
	recoverColumns() {
		const { nx, nz, qx: P, qz: Q, qBar, still: d, dX, dZ, mask, below, above, f2, f4, f6, columnUpper: upper, columnRight: right } = this;
		this.derivativeX(P, f2, true);
		this.derivativeZ(f2, f4, false);
		this.derivativeZ(P, f6, false);
		for (let iz = 0; iz < nz; iz += 1) {
			const minus = below[iz];
			const plus = above[iz];
			const sum = minus + plus;
			const secondLow = 2 / (minus * sum);
			const secondHigh = 2 / (plus * sum);
			const secondMid = -2 / (minus * plus);
			const firstLow = -plus / (minus * sum);
			const firstHigh = minus / (plus * sum);
			const firstMid = (plus - minus) / (plus * minus);
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				let a = 0;
				let b = 1;
				let c = 0;
				let r = qBar[i];
				if (mask[i] > 0) {
					const A = ALPHA * d[i] * d[i];
					const E = d[i] * dZ[i] / 3;
					a = -(A * secondLow + E * firstLow);
					b = 1 - (A * secondMid + E * firstMid);
					c = -(A * secondHigh + E * firstHigh);
					r += A * f4[i] + d[i] * dZ[i] * f2[i] / 6 + d[i] * dX[i] * f6[i] / 6;
					if (iz === 0) {
						b -= a;
						a = 0;
					}
					if (iz === nz - 1) {
						b -= c;
						c = 0;
					}
				}
				if (iz === 0) {
					upper[i] = c / b;
					right[i] = r / b;
				} else {
					const denominator = b - a * upper[i - nx];
					upper[i] = c / denominator;
					right[i] = (r - a * right[i - nx]) / denominator;
				}
			}
		}
		const last = (nz - 1) * nx;
		for (let ix = 0; ix < nx; ix += 1) Q[last + ix] = right[last + ix];
		for (let iz = nz - 2; iz >= 0; iz -= 1) {
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) Q[row + ix] = right[row + ix] - upper[row + ix] * Q[row + ix + nx];
		}
	}
	/**
	* Cyclic tridiagonal solve (Sherman–Morrison) of the bands in place: row 0's
	* lower coefficient and the last row's upper one wrap around.
	*/
	cyclic(n) {
		const { lowerBand: a, diagonal: b, upperBand: c, right: r, scratch, spare: u } = this;
		const beta = a[0];
		const alpha = c[n - 1];
		const gamma = -b[0];
		b[0] -= gamma;
		b[n - 1] -= alpha * beta / gamma;
		a[0] = 0;
		c[n - 1] = 0;
		u.fill(0, 0, n);
		u[0] = gamma;
		u[n - 1] = alpha;
		thomas(a, b, c, r, scratch, n);
		thomas(a, b, c, u, scratch, n);
		const factor = (r[0] + beta * r[n - 1] / gamma) / (1 + u[0] + beta * u[n - 1] / gamma);
		for (let i = 0; i < n; i += 1) r[i] -= factor * u[i];
	}
	/** ∂x of a cell field: central differences; ghosts mirror at walls (negated when `odd`), extend at open edges, wrap when periodic. */
	derivativeX(f, out, odd) {
		const { nx, nz } = this;
		const periodic = this.xBoundary === 1;
		const sign = this.xBoundary === 0 && odd ? -1 : 1;
		const half = 1 / (2 * this.dx);
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const left = ix > 0 ? f[i - 1] : periodic ? f[row + nx - 1] : sign * f[i];
				out[i] = ((ix < nx - 1 ? f[i + 1] : periodic ? f[row] : sign * f[i]) - left) * half;
			}
		}
	}
	secondX(f, out, odd) {
		const { nx, nz } = this;
		const periodic = this.xBoundary === 1;
		const sign = this.xBoundary === 0 && odd ? -1 : 1;
		const inverse = 1 / (this.dx * this.dx);
		for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const left = ix > 0 ? f[i - 1] : periodic ? f[row + nx - 1] : sign * f[i];
				out[i] = ((ix < nx - 1 ? f[i + 1] : periodic ? f[row] : sign * f[i]) - 2 * f[i] + left) * inverse;
			}
		}
	}
	/** ∂z on the stretched rows (second order); walls at both ends mirror, negated when `odd`. */
	derivativeZ(f, out, odd) {
		const { nx, nz, below, above } = this;
		const sign = odd ? -1 : 1;
		for (let iz = 0; iz < nz; iz += 1) {
			const minus = below[iz];
			const plus = above[iz];
			const sum = minus + plus;
			const wPlus = minus / (plus * sum);
			const wMinus = -plus / (minus * sum);
			const wCentre = (plus - minus) / (plus * minus);
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const down = iz > 0 ? f[i - nx] : sign * f[i];
				out[i] = wPlus * (iz < nz - 1 ? f[i + nx] : sign * f[i]) + wMinus * down + wCentre * f[i];
			}
		}
	}
	secondZ(f, out, odd) {
		const { nx, nz, below, above } = this;
		const sign = odd ? -1 : 1;
		for (let iz = 0; iz < nz; iz += 1) {
			const minus = below[iz];
			const plus = above[iz];
			const sum = minus + plus;
			const wPlus = 2 / (plus * sum);
			const wMinus = 2 / (minus * sum);
			const row = iz * nx;
			for (let ix = 0; ix < nx; ix += 1) {
				const i = row + ix;
				const down = iz > 0 ? f[i - nx] : sign * f[i];
				out[i] = wPlus * (iz < nz - 1 ? f[i + nx] : sign * f[i]) + wMinus * down - (wPlus + wMinus) * f[i];
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/SwellReadout.ts
/** McCowan depth-limited breaker index H_b/h_b; Sandwell's d_b = 1.28 H_b is 1/0.78. */
const BREAKER_INDEX = .78;
function describeSwell({ height, period, depth, bedSlope, submergedCrest = false }) {
	const kinematics = waveKinematics(period, depth);
	const deepWavelength = GRAVITY$1 * period * period / (2 * Math.PI);
	const breakerDepth = height / BREAKER_INDEX;
	const slope = Math.max(0, bedSlope);
	const iribarren = slope > 0 && height > 0 ? slope / Math.sqrt(height / deepWavelength) : 0;
	const breakerType = iribarren <= 0 ? "none" : iribarren < .4 ? "spilling" : iribarren <= 2 || submergedCrest ? "plunging" : "surging";
	return {
		deepWavelength,
		wavelength: kinematics.wavelength,
		phaseSpeed: kinematics.phaseSpeed,
		groupSpeed: kinematics.groupSpeed,
		depthRatio: depth / kinematics.wavelength,
		depthClass: depthClass(depth, kinematics.wavelength),
		breakerDepth,
		breakerSpeed: Math.sqrt(GRAVITY$1 * breakerDepth),
		iribarren,
		breakerType
	};
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/Breaking.ts
const MIN_DEPTH$5 = .05;
function ramp(value, from, to) {
	return Math.min(1, Math.max(0, (value - from) / (to - from)));
}
/**
* Stage 1 bore criterion. The shallow-water solver smears a bore over 2–3 cells,
* so the Kennedy rise rate depends on resolution: the peak measured on the reef
* was 0.33 √(gh) with 2 m cells and 0.70 √(gh) with 1 m cells, against a 0.65
* onset. A rising front counts as breaking when it is both steep (slope 0.10 →
* 0.25) and depth-limited (η/h 0.15 → 0.30, scaled by the wind). The second
* condition keeps the solver's non-dispersive steepening offshore from reading as
* surf.
*/
function boreStrength(slope, relativeHeight, scale = 1) {
	return ramp(slope, .1, .25) * ramp(relativeHeight, .15 * scale, .3 * scale);
}
/**
* Breaking indicator on the stage 1 solver (plan §1.8, Q27): the larger of the
* Kennedy et al. (2000) rise-rate test and the stage 1 bore criterion
* (`boreStrength`). A cell breaks when its surface rises faster than η_t*; η_t* starts at
* the onset fraction of √(gh) and ramps to the end fraction over T* = 5√(h/g).
* A cell inherits the breaking age from behind its front face (`inheritedAge`),
* so a travelling bore keeps its age. In stage 1 this is an indicator for rendering, readouts
* and the lip only; the shock-capturing solver already dissipates the bore.
*/
var BreakingModel = class {
	solver;
	options;
	/** Breaking strength B in [0, 1] per cell. */
	strength;
	/** Seconds since breaking began for the bore that covers each cell. */
	age;
	scale = 1;
	previousSurface;
	nextStrength;
	nextAge;
	primed = false;
	/**
	* On the stage 2 solver breaking is part of the step (Kennedy eddy
	* viscosity): the model only mirrors the solver's strength and age, so lip,
	* foam, readouts and the board read the same signal in both stages.
	*/
	source;
	constructor(solver, options) {
		this.solver = solver;
		this.options = options;
		if (solver instanceof BoussinesqSolver && solver.breaks) this.source = solver;
		const size = solver.nx * solver.nz;
		this.strength = new Float64Array(size);
		this.age = new Float64Array(size);
		this.previousSurface = new Float64Array(size);
		this.nextStrength = new Float64Array(size);
		this.nextAge = new Float64Array(size);
	}
	/** Multiplies the onset threshold; the local wind shifts it (plan Q23). */
	get onsetScale() {
		return this.source ? this.source.onsetScale : this.scale;
	}
	set onsetScale(value) {
		this.scale = value;
		if (this.source) this.source.onsetScale = value;
	}
	update(dt) {
		if (this.source) {
			this.strength.set(this.source.breakingStrength);
			this.age.set(this.source.breakingAge);
			return;
		}
		const { nx, nz, h, bed, dx, zCenters, restLevel } = this.solver;
		if (!this.primed || !(dt > 0)) {
			for (let i = 0; i < h.length; i += 1) this.previousSurface[i] = h[i] + bed[i];
			this.primed = true;
			return;
		}
		const periodic = this.solver.periodicAlongShore;
		const onset = this.options.onset * this.onsetScale;
		const end = this.options.end ?? .15;
		const transition = this.options.transition ?? 5;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const surface = h[i] + bed[i];
			const rise = (surface - this.previousSurface[i]) / dt;
			this.previousSurface[i] = surface;
			const depth = h[i];
			if (depth <= MIN_DEPTH$5) {
				this.nextStrength[i] = 0;
				this.nextAge[i] = 0;
				continue;
			}
			const interior = ix > 0 && ix < nx - 1 && iz > 0 && iz < nz - 1;
			const row = iz * nx;
			const left = ix > 0 ? i - 1 : periodic ? row + nx - 1 : i;
			const right = ix < nx - 1 ? i + 1 : periodic ? row : i;
			const down = iz > 0 ? i - nx : i;
			const up = iz < nz - 1 ? i + nx : i;
			const spanX = (right === i || left === i ? 1 : 2) * dx;
			const spanZ = zCenters[up === i ? iz : iz + 1] - zCenters[down === i ? iz : iz - 1];
			const slopeX = right === left ? 0 : (h[right] + bed[right] - h[left] - bed[left]) / spanX;
			const slopeZ = up === down ? 0 : (h[up] + bed[up] - h[down] - bed[down]) / spanZ;
			const inherited = inheritedAge(i, ix, iz, nx, nz, slopeX, slopeZ, this.strength, this.age);
			const ramp = Math.min(1, inherited / (transition * Math.sqrt(depth / GRAVITY$1)));
			const threshold = Math.sqrt(GRAVITY$1 * depth) * (onset + (end - onset) * ramp);
			let breaking = Math.min(1, Math.max(0, rise / threshold - 1));
			const stillDepth = restLevel - bed[i];
			if (rise > 0 && stillDepth > .1 && interior) breaking = Math.max(breaking, boreStrength(Math.hypot(slopeX, slopeZ), (surface - restLevel) / stillDepth, this.onsetScale));
			this.nextStrength[i] = breaking;
			this.nextAge[i] = breaking > 0 ? inherited + dt : 0;
		}
		this.strength.set(this.nextStrength);
		this.age.set(this.nextAge);
	}
};
/** Depth where Green's-law shoaling from the tank depth first reaches H = γh: h_b = (Hs·D^¼/γ)^⅘, m. */
function breakerDepthFor(significantHeight, tankDepth, gamma = BREAKER_INDEX) {
	return Math.pow(significantHeight * Math.pow(tankDepth, .25) / gamma, .8);
}
/**
* Measures peel from when and where each along-shore column starts breaking.
* The onsets' times and cross-shore positions are fitted against x; the break
* point runs along the fitted break line at V = √(1 + (dz/dx)²) / |dt_onset/dx|,
* and sin α = c_b / V (Walker 1974; Hutt et al. 2001), so a close-out that
* breaks everywhere at once gives α ≈ 0. A break line along the shore reads
* V = 1 / |dt/dx|; an oblique one (a reef ledge) is measured along itself.
*/
var PeelTracker = class {
	xs;
	window;
	quiet;
	include;
	lastBreaking;
	onset;
	onsetZ;
	constructor(xs, window, quiet = .8, include = () => true) {
		this.xs = xs;
		this.window = window;
		this.quiet = quiet;
		this.include = include;
		this.lastBreaking = new Float64Array(xs.length).fill(-Infinity);
		this.onset = new Float64Array(xs.length).fill(NaN);
		this.onsetZ = new Float64Array(xs.length);
	}
	/** Note which columns are breaking at `time`; a column restarting after `quiet` seconds starts a new onset at `zOf(column)`. */
	record(time, isBreaking, zOf) {
		for (let column = 0; column < this.xs.length; column += 1) {
			if (!isBreaking(column)) continue;
			if (time - this.lastBreaking[column] > this.quiet) this.markOnset(column, time, zOf?.(column) ?? 0);
			this.lastBreaking[column] = time;
		}
	}
	/** Record that a new wave started breaking in `column` at `time`, `z` across shore (on the break line). */
	markOnset(column, time, z = 0) {
		this.onset[column] = time;
		this.onsetZ[column] = z;
	}
	/** Whether this column's breaks count toward the peel (a spot may measure only where its wave is ridden). */
	measures(column) {
		return this.include(column);
	}
	/**
	* The recent wave's front: the longest run of neighbouring measured columns whose onsets
	* follow each other within a tenth of the window. A long peel takes about a period, so the
	* window can also hold the next wave starting at the peak; a gap in time splits the two.
	*/
	front(time, first, last) {
		const recent = (column) => this.include(column) && this.onset[column] >= time - this.window && this.onset[column] <= time;
		const gap = .1 * this.window;
		let best;
		let start = -1;
		for (let column = first; column <= last; column += 1) {
			const joins = column < last && recent(column) && (start >= 0 ? Math.abs(this.onset[column] - this.onset[column - 1]) <= gap : true);
			if (joins && start < 0) start = column;
			if (joins) continue;
			if (start >= 0 && (!best || column - start > best.end - best.start)) best = {
				start,
				end: column
			};
			start = column < last && recent(column) ? column : -1;
		}
		return best;
	}
	/** Fit onset time and position against x over the recent wave's front, leaving out `margin` of the columns at each open edge. */
	estimate(time, celerity, margin = .1) {
		const edge = Math.floor(this.xs.length * margin);
		const front = this.front(time, edge, this.xs.length - edge);
		if (!front) return void 0;
		const first = front.start;
		const last = front.end;
		let count = 0;
		let sumX = 0;
		let sumT = 0;
		let sumZ = 0;
		for (let column = first; column < last; column += 1) {
			const onset = this.onset[column];
			if (!(onset >= time - this.window && onset <= time)) continue;
			count += 1;
			sumX += this.xs[column];
			sumT += onset;
			sumZ += this.onsetZ[column];
		}
		if (count < 8) return void 0;
		const meanX = sumX / count;
		const meanT = sumT / count;
		const meanZ = sumZ / count;
		let sxx = 0;
		let sxt = 0;
		let stt = 0;
		let sxz = 0;
		for (let column = first; column < last; column += 1) {
			const onset = this.onset[column];
			if (!(onset >= time - this.window && onset <= time)) continue;
			const dx = this.xs[column] - meanX;
			const dt = onset - meanT;
			sxx += dx * dx;
			sxt += dx * dt;
			stt += dt * dt;
			sxz += dx * (this.onsetZ[column] - meanZ);
		}
		const slope = sxx > 0 ? sxt / sxx : 0;
		const lineSlope = sxx > 0 ? sxz / sxx : 0;
		const stretch = Math.hypot(1, lineSlope);
		const sine = Math.min(1, celerity * Math.abs(slope) / stretch);
		return {
			angleDegrees: Math.asin(sine) * 180 / Math.PI,
			direction: slope > 1e-9 ? 1 : slope < -1e-9 ? -1 : 0,
			peelSpeed: Math.abs(slope) > 0 ? stretch / Math.abs(slope) : Infinity,
			lineSlope,
			columns: count,
			fit: sxx > 0 && stt > 0 ? sxt * sxt / (sxx * stt) : 0
		};
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/surfForecast.ts
/** H1/10 over H1/3 in a Rayleigh sea (docs/research/surf-size-sources.md). */
const SETS_OVER_TYPICAL = 1.27;
/** Komar & Gaughan's breaker height from a deep-water height and period, m: H_b = 0.39 g^0.2 (T H0²)^0.4. */
function komarGaughan(significantHeight, period) {
	return .39 * GRAVITY$1 ** .2 * (period * significantHeight ** 2) ** .4;
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/AerationField.ts
/**
* The air breaking drives into the water (G9), from `docs/research/whitewater-sources.md`:
* - `share` (β): share of the dissipated energy spent entraining air against buoyancy, 4–14 % in
*   surf-zone breakers (Blenkinsopp & Chaplin 2007);
* - `plungeDepth` (κ_p) and `boreDepth` (κ_s): plume depth per breaker or bore height (provisional);
* - `riseSpeed` (w_b): bubbles of radius above 0.5 mm rise at 0.2–0.3 m/s (Deane & Stokes 2002);
* - `peak` (α_max): the most air a surf-zone plume holds, about 20 % under plunging breakers
*   (Blenkinsopp & Chaplin 2007). Air driven in beyond it vents at once.
*/
const AERATION$2 = {
	share: .1,
	plungeDepth: .8,
	boreDepth: .3,
	riseSpeed: .25,
	peak: .2
};
/**
* The plume's turbulence (the wipeout spec, Part B), provisional:
* - under breaking of strength B in water h deep, the turbulent kinetic energy k
*   relaxes over `rise` s toward (ratio · √(g h))² · B: Ting & Kirby (1995,
*   1996) measured √k / √(g h) of about 0.1–0.2 under broken waves;
* - once the breaking has passed it fades with an e-folding time of
*   `decayShare` of the peak period, so it is all but gone within one period
*   (plunging breakers dissipate their turbulence within about one wave period);
* - it is carried by the current like the air.
*/
const TURBULENCE$2 = {
	ratio: .15,
	rise: .5,
	decayShare: 1 / 3
};
const DENSITY$2 = 1025;
const WET$7 = .01;
const TRACE$4 = 1e-7;
/** A plume spreads to the rows either side of where it lands. */
const ACROSS$2 = [-1, 1];
/** Plumes thinner than this still degas at this depth's rate, m (a numerical floor). */
const MIN_DEPTH$4 = .05;
/**
* Entrained air on the solver grid (G9): per cell, the air it holds per unit
* area (m³/m², its depth if it were one layer) and the plume's depth. Air
* enters where lip water lands (a share of the impact's energy spent against
* buoyancy, carried down to half the plunge's depth on average), where bores
* dissipate, and where trapped tubes break into bubbles. A plunge's or a
* tube's bubbles fill a plume as wide as it is deep (provisional). It is carried by the
* current semi-Lagrangian, like the foam, and degasses as its bubbles rise
* out of the plume. It never feeds back into the water.
*/
var AerationField$2 = class {
	solver;
	air;
	depth;
	/** The turbulent kinetic energy in each cell's water, m²/s² (`TURBULENCE`). */
	turbulence;
	nextAir;
	nextDepth;
	nextTurbulence;
	/** Cells breaking stirred since the latest update: they hold their turbulence rather than fade. */
	stirred;
	windowX;
	period;
	stirDt = NaN;
	stirGain = 0;
	/** `period`: the swell's peak period, s, which sets how fast the turbulence fades. */
	constructor(solver, options = {}) {
		this.solver = solver;
		const size = solver.h.length;
		this.air = new Float64Array(size);
		this.depth = new Float64Array(size);
		this.turbulence = new Float64Array(size);
		this.nextAir = new Float64Array(size);
		this.nextDepth = new Float64Array(size);
		this.nextTurbulence = new Float64Array(size);
		this.stirred = new Uint8Array(size);
		this.windowX = solver.xCenters[0];
		this.period = options.period ?? 10;
	}
	/** Breaking of strength `strength` (0–1) in `cell` for `dt` s stirs its water toward Ting & Kirby's intensity. */
	stir(cell, strength, dt) {
		this.followWindow();
		const depth = this.solver.h[cell];
		if (!(depth > WET$7) || !(strength > 0)) return;
		this.stirred[cell] = 1;
		const target = (TURBULENCE$2.ratio * Math.sqrt(GRAVITY$1 * depth)) ** 2 * Math.min(1, strength);
		if (target > this.turbulence[cell]) {
			if (dt !== this.stirDt) {
				this.stirDt = dt;
				this.stirGain = 1 - Math.exp(-dt / TURBULENCE$2.rise);
			}
			this.turbulence[cell] += (target - this.turbulence[cell]) * this.stirGain;
		}
	}
	/** A plunge that dissipated `energy` J at (x, z), driving its bubbles `penetration` m down. */
	addPlunge(x, z, energy, penetration) {
		this.followWindow();
		const cell = this.solver.cellIndex(x, z);
		const reach = this.reach(cell, penetration);
		if (!(reach > 0) || !(energy > 0)) return;
		this.spread(x, z, AERATION$2.share * energy / (DENSITY$2 * GRAVITY$1 * (reach / 2)), reach);
	}
	/**
	* A bore dissipating `dissipation` (energy per unit crest length over ρ,
	* m⁴/s³, `boreDissipation`) for `dt` s in `cell`, `height` m high: β of the
	* energy its cell's width of crest loses, as air held against buoyancy at
	* half the plume's depth (the cell holds it, where the bore dissipates).
	*/
	addBore(cell, dissipation, height, dt) {
		this.followWindow();
		const reach = this.reach(cell, AERATION$2.boreDepth * height);
		if (!(reach > 0) || !(dissipation > 0)) return;
		this.addTo(cell, AERATION$2.share * dissipation * dt * this.solver.dx / (GRAVITY$1 * (reach / 2)), reach);
	}
	/** Trapped air of `volume` m³ broken into bubbles at (x, z), `penetration` m down. */
	addAir(x, z, volume, penetration) {
		this.followWindow();
		const cell = this.solver.cellIndex(x, z);
		const reach = this.reach(cell, penetration);
		if (!(reach > 0) || !(volume > 0)) return;
		this.spread(x, z, volume, reach);
	}
	/** The void fraction the plume holds: its air over its depth, 0 … 1. */
	voidFraction(cell) {
		const depth = this.depth[cell];
		return depth > 0 ? Math.min(1, this.air[cell] / depth) : 0;
	}
	/** Advance by `dt` s: carry with the current, and degas as the bubbles rise out of the plume. */
	update(dt, stencil) {
		if (!(dt > 0)) return;
		this.followWindow();
		this.advect(dt, stencil?.take(this.solver, dt));
		const { h } = this.solver;
		const fade = Math.exp(-dt / (TURBULENCE$2.decayShare * this.period));
		for (let i = 0; i < h.length; i += 1) {
			this.turbulence[i] = h[i] <= WET$7 || this.turbulence[i] < TRACE$4 ? 0 : this.turbulence[i] * (this.stirred[i] ? 1 : fade);
			this.stirred[i] = 0;
			if (h[i] <= WET$7 || this.air[i] === 0) {
				this.air[i] = 0;
				this.depth[i] = 0;
				continue;
			}
			const depth = Math.min(this.depth[i], h[i]);
			const air = this.air[i] * Math.exp(-AERATION$2.riseSpeed * dt / Math.max(MIN_DEPTH$4, depth));
			this.air[i] = air < TRACE$4 ? 0 : Math.min(air, AERATION$2.peak * depth);
			this.depth[i] = this.air[i] > 0 ? depth : 0;
		}
	}
	reach(cell, penetration) {
		return Math.min(penetration, this.solver.h[cell]);
	}
	/**
	* `volume` m³ of air over the wet cells whose centres lie within `radius` of
	* (x, z) (always the cell it lands in), evenly per square metre, each down to
	* `radius` or its water's depth. None from past an open edge: the plunge was
	* outside the window, and its cell would be the edge column's.
	*/
	spread(x, z, volume, radius) {
		if (this.solver.beyondOpenEdge(x)) return;
		const { nx, nz, xCenters, zCenters, dx, dz, h } = this.solver;
		const centre = this.solver.cellIndex(x, z);
		const column = centre % nx;
		const row = Math.floor(centre / nx);
		const span = Math.ceil(radius / dx);
		const cells = this.plume;
		cells.length = 0;
		let area = 0;
		for (const step of ACROSS$2) for (let iz = step < 0 ? row : row + 1; iz >= 0 && iz < nz; iz += step) {
			const across = zCenters[iz] - z;
			if (iz !== row && Math.abs(across) > radius) break;
			for (let ix = Math.max(0, column - span); ix <= Math.min(nx - 1, column + span); ix += 1) {
				const i = iz * nx + ix;
				if (!(i === centre || Math.hypot(xCenters[ix] - x, across) <= radius) || h[i] <= WET$7) continue;
				cells.push(i);
				area += dx * dz[iz];
			}
		}
		for (const i of cells) this.addTo(i, volume * dx * dz[Math.floor(i / nx)] / area, this.reach(i, radius));
	}
	plume = [];
	addTo(cell, volume, reach) {
		const { dx, dz, nx } = this.solver;
		const area = dx * dz[Math.floor(cell / nx)];
		this.depth[cell] = Math.max(this.depth[cell], reach);
		this.air[cell] = Math.min(AERATION$2.peak * this.depth[cell], this.air[cell] + volume / area);
	}
	/** Semi-Lagrangian step: each cell takes the air (and plume depth, and turbulence) found upstream at x − u·dt. */
	advect(dt, stencil) {
		if (stencil) {
			this.advectStencil(stencil);
			return;
		}
		const { nx, nz, h, qx, qz, xCenters, zCenters, dx } = this.solver;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const water = h[i];
			if (water <= WET$7) {
				this.nextAir[i] = 0;
				this.nextDepth[i] = 0;
				this.nextTurbulence[i] = 0;
				continue;
			}
			const x = xCenters[ix] - qx[i] / water * dt;
			const z = zCenters[iz] - qz[i] / water * dt;
			const gx = Math.min(nx - 1, Math.max(0, (x - xCenters[0]) / dx));
			const column = Math.min(nx - 2, Math.floor(gx));
			const tx = gx - column;
			let row = Math.min(iz, nz - 2);
			while (row > 0 && zCenters[row] > z) row -= 1;
			while (row < nz - 2 && zCenters[row + 1] <= z) row += 1;
			const tz = Math.min(1, Math.max(0, (z - zCenters[row]) / (zCenters[row + 1] - zCenters[row])));
			const k = row * nx + column;
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			this.nextAir[i] = this.air[k] * w00 + this.air[k + 1] * w10 + this.air[k + nx] * w01 + this.air[k + nx + 1] * w11;
			this.nextTurbulence[i] = this.turbulence[k] * w00 + this.turbulence[k + 1] * w10 + this.turbulence[k + nx] * w01 + this.turbulence[k + nx + 1] * w11;
			this.nextDepth[i] = Math.max(this.depth[k] * (w00 > 0 ? 1 : 0), this.depth[k + 1] * (w10 > 0 ? 1 : 0), this.depth[k + nx] * (w01 > 0 ? 1 : 0), this.depth[k + nx + 1] * (w11 > 0 ? 1 : 0));
		}
		this.air.set(this.nextAir);
		this.depth.set(this.nextDepth);
		this.turbulence.set(this.nextTurbulence);
	}
	/** Same interpolation as `advect`; foam has already found the departures on this step's water. */
	advectStencil(stencil) {
		const { h, nx } = this.solver;
		const { indices, values } = stencil;
		for (let i = 0; i < h.length; i += 1) {
			if (h[i] <= WET$7) {
				this.nextAir[i] = 0;
				this.nextDepth[i] = 0;
				this.nextTurbulence[i] = 0;
				continue;
			}
			const k = indices[i];
			const tx = values[i * 2];
			const tz = values[i * 2 + 1];
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			this.nextAir[i] = this.air[k] * w00 + this.air[k + 1] * w10 + this.air[k + nx] * w01 + this.air[k + nx + 1] * w11;
			this.nextTurbulence[i] = this.turbulence[k] * w00 + this.turbulence[k + 1] * w10 + this.turbulence[k + nx] * w01 + this.turbulence[k + nx + 1] * w11;
			this.nextDepth[i] = Math.max(this.depth[k] * (w00 > 0 ? 1 : 0), this.depth[k + 1] * (w10 > 0 ? 1 : 0), this.depth[k + nx] * (w01 > 0 ? 1 : 0), this.depth[k + nx + 1] * (w11 > 0 ? 1 : 0));
		}
		this.air.set(this.nextAir);
		this.depth.set(this.nextDepth);
		this.turbulence.set(this.nextTurbulence);
	}
	/**
	* Shift with the solver when its window slides, so air stays on the same
	* water; new columns start clear. Every add follows first, so air added in
	* the window it arrives in is not shifted again.
	*/
	followWindow() {
		const { nx, nz, dx, xCenters } = this.solver;
		const shift = Math.round((xCenters[0] - this.windowX) / dx);
		this.windowX = xCenters[0];
		if (shift === 0) return;
		for (const values of [
			this.air,
			this.depth,
			this.turbulence
		]) for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			if (Math.abs(shift) >= nx) values.fill(0, row, row + nx);
			else if (shift > 0) {
				values.copyWithin(row, row + shift, row + nx);
				values.fill(0, row + nx - shift, row + nx);
			} else {
				values.copyWithin(row - shift, row, row + nx + shift);
				values.fill(0, row, row - shift);
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/AdvectionStencil.ts
/** A same-step departure lookup shared by fields carried on unchanged water. */
var AdvectionStencil$1 = class {
	indices = /* @__PURE__ */ new Uint32Array(0);
	/** The original tx/tz fractions, in double precision. */
	values = /* @__PURE__ */ new Float64Array(0);
	solver;
	xCenters;
	zCenters;
	dt = NaN;
	time = NaN;
	xMin = NaN;
	zMin = NaN;
	dx = NaN;
	nx = 0;
	nz = 0;
	ready = false;
	/** Foam records a fresh lookup every update: h/q are mutable, even without a clock or window change. */
	begin(solver, dt) {
		this.ready = false;
		const size = solver.h.length;
		if (this.indices.length !== size) {
			this.indices = new Uint32Array(size);
			this.values = new Float64Array(size * 2);
		}
		this.solver = solver;
		this.xCenters = solver.xCenters;
		this.zCenters = solver.zCenters;
		this.dt = dt;
		this.time = solver.time;
		this.xMin = solver.xCenters[0];
		this.zMin = solver.zCenters[0];
		this.dx = solver.dx;
		this.nx = solver.nx;
		this.nz = solver.nz;
	}
	/** The whole lookup has been written; dry cells need no entry because both fields clear them. */
	commit() {
		this.ready = true;
	}
	/** Discard it when a caller changes h/q between the two field updates. */
	invalidate() {
		this.ready = false;
	}
	/**
	* Aeration may reuse it once, immediately after foam, while h/q stay unchanged.
	* A changed dt, grid, window or clock falls back to computing departures itself.
	* Consuming it prevents an unrelated later call at the same solver time from reusing mutable-water state.
	*/
	take(solver, dt) {
		const matches = this.ready && this.solver === solver && this.dt === dt && this.time === solver.time && this.xCenters === solver.xCenters && this.zCenters === solver.zCenters && this.xMin === solver.xCenters[0] && this.zMin === solver.zCenters[0] && this.dx === solver.dx && this.nx === solver.nx && this.nz === solver.nz;
		this.ready = false;
		return matches ? this : void 0;
	}
};
/** A modest surf bore: 0.25 m running onto 1 m of still water. */
const REFERENCE_BORE$1 = {
	stillDepth: 1,
	depth: 1.25
};
/** Share of the dense foam that decays into residual lace instead of vanishing (a game value). */
const LACE_SHARE$1 = .3;
/** Depth of landed lip water that covers a cell with foam, m. */
const SPLASH_DEPTH$1 = .05;
const WET$6 = .01;
const TRACE$3 = 1e-6;
/**
* Energy a bore dissipates per unit crest length, divided by ρ, m³/s³: g q ΔH,
* with the hydraulic-jump head loss ΔH = (h₂ − h₁)³/(4 h₁ h₂), the bore speed
* c = √(g h₂ (h₁ + h₂)/(2 h₁)) and the discharge through it q = c h₁ (e.g. Chow 1959).
* The still depth ahead is h₁ and the local depth behind the front h₂.
*/
function boreDissipation$1(stillDepth, depth) {
	if (!(stillDepth > 0) || !(depth > stillDepth)) return 0;
	const headLoss = (depth - stillDepth) ** 3 / (4 * stillDepth * depth);
	const speed = Math.sqrt(GRAVITY$1 * depth * (stillDepth + depth) / (2 * stillDepth));
	return GRAVITY$1 * speed * stillDepth * headLoss;
}
const REFERENCE_DISSIPATION$1 = boreDissipation$1(REFERENCE_BORE$1.stillDepth, REFERENCE_BORE$1.depth);
/**
* Foam carried by the flow on the solver grid (plan §2.4, G4): ∂F/∂t + u·∇F = S − F/τ.
* F is the fraction of the surface covered by foam, split into dense whitewater
* and the residual lace it decays into, which lasts longer (the two regimes of
* Callaghan et al. 2013). Each update advects both semi-Lagrangian with the
* solver's depth-averaged velocity, decays them exactly, and adds the breaking
* strength times the bore's dissipation. Lip splashes add foam where they land.
* The foam never feeds back into the water.
*/
var FoamField$1 = class {
	solver;
	decay;
	dense;
	residual;
	/** Dense foam bores made per second in each cell at the last update (it also drives the bubbles). */
	source;
	/** Positive bore sources, sorted by cell: the visual clouds skip the rest of the grid. */
	sourceCells;
	sourceCount = 0;
	/** Wet breaking cells and their dissipated power: aeration reads the same bore measurement. */
	breakingCells;
	dissipation;
	breakingCount = 0;
	nextDense;
	nextResidual;
	windowX;
	constructor(solver, decay) {
		this.solver = solver;
		this.decay = decay;
		const size = solver.nx * solver.nz;
		this.dense = new Float64Array(size);
		this.residual = new Float64Array(size);
		this.source = new Float64Array(size);
		this.sourceCells = new Uint32Array(size);
		this.breakingCells = new Uint32Array(size);
		this.dissipation = new Float64Array(size);
		this.nextDense = new Float64Array(size);
		this.nextResidual = new Float64Array(size);
		this.windowX = solver.xCenters[0];
	}
	totalAt(index) {
		return this.dense[index] + this.residual[index];
	}
	/** Cover the cell a lip parcel of `volume` m³ lands in; none past an open edge, where it has left the window. */
	addSplash(x, z, volume) {
		const { solver } = this;
		if (solver.beyondOpenEdge(x)) return;
		const cell = solver.cellIndex(x, z);
		const area = solver.dx * solver.dz[Math.floor(cell / solver.nx)];
		this.dense[cell] = Math.min(1, this.dense[cell] + volume / (area * SPLASH_DEPTH$1));
		this.residual[cell] = Math.min(this.residual[cell], 1 - this.dense[cell]);
	}
	/** Advance by `dt` seconds with the breaking strength B per cell. */
	update(dt, breaking, stencil) {
		if (!(dt > 0)) return;
		this.followWindow();
		this.advect(dt, stencil);
		const { h, bed, restLevel } = this.solver;
		const keepDense = Math.exp(-dt / this.decay.dense);
		const keepLace = Math.exp(-dt / this.decay.residual);
		this.sourceCount = 0;
		this.breakingCount = 0;
		for (let i = 0; i < h.length; i += 1) {
			if (h[i] <= WET$6) {
				this.dense[i] = 0;
				this.residual[i] = 0;
				this.source[i] = 0;
				continue;
			}
			const previous = this.dense[i];
			let dense = previous * keepDense;
			const lace = this.residual[i] * keepLace + LACE_SHARE$1 * (previous - dense);
			const strength = breaking[i];
			let bore = 0;
			if (strength > 0) {
				bore = boreDissipation$1(restLevel - bed[i], h[i]);
				this.breakingCells[this.breakingCount++] = i;
				this.dissipation[i] = strength * bore;
			}
			const rate = strength > 0 ? strength * 4 * bore / REFERENCE_DISSIPATION$1 : 0;
			this.source[i] = rate;
			if (rate > 0) this.sourceCells[this.sourceCount++] = i;
			dense += rate * dt;
			this.dense[i] = dense < TRACE$3 ? 0 : Math.min(1, dense);
			this.residual[i] = lace < TRACE$3 ? 0 : Math.min(lace, 1 - this.dense[i]);
		}
	}
	/** Rebuild the derived index after a tool or test directly edits `source`; normal updates build it as they go. */
	reindexSources() {
		this.sourceCount = 0;
		for (let i = 0; i < this.source.length; i += 1) if (this.source[i] > 0) this.sourceCells[this.sourceCount++] = i;
	}
	/** Semi-Lagrangian step: each cell takes the foam found upstream at x − u·dt. */
	advect(dt, stencil) {
		const { nx, nz, h, qx, qz, xCenters, zCenters, dx } = this.solver;
		stencil?.begin(this.solver, dt);
		const indices = stencil?.indices;
		const values = stencil?.values;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const depth = h[i];
			if (depth <= WET$6) {
				this.nextDense[i] = 0;
				this.nextResidual[i] = 0;
				continue;
			}
			const x = xCenters[ix] - qx[i] / depth * dt;
			const z = zCenters[iz] - qz[i] / depth * dt;
			const gx = Math.min(nx - 1, Math.max(0, (x - xCenters[0]) / dx));
			const column = Math.min(nx - 2, Math.floor(gx));
			const tx = gx - column;
			let row = Math.min(iz, nz - 2);
			while (row > 0 && zCenters[row] > z) row -= 1;
			while (row < nz - 2 && zCenters[row + 1] <= z) row += 1;
			const tz = Math.min(1, Math.max(0, (z - zCenters[row]) / (zCenters[row + 1] - zCenters[row])));
			const k = row * nx + column;
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			if (indices && values) {
				indices[i] = k;
				values[i * 2] = tx;
				values[i * 2 + 1] = tz;
			}
			this.nextDense[i] = this.dense[k] * w00 + this.dense[k + 1] * w10 + this.dense[k + nx] * w01 + this.dense[k + nx + 1] * w11;
			this.nextResidual[i] = this.residual[k] * w00 + this.residual[k + 1] * w10 + this.residual[k + nx] * w01 + this.residual[k + nx + 1] * w11;
		}
		this.dense.set(this.nextDense);
		this.residual.set(this.nextResidual);
		stencil?.commit();
	}
	/** Shift with the solver when its window slides, so foam stays on the same water; new columns start clean. */
	followWindow() {
		const { nx, nz, dx, xCenters } = this.solver;
		const shift = Math.round((xCenters[0] - this.windowX) / dx);
		this.windowX = xCenters[0];
		if (shift === 0) return;
		for (const values of [this.dense, this.residual]) for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			if (Math.abs(shift) >= nx) values.fill(0, row, row + nx);
			else if (shift > 0) {
				values.copyWithin(row, row + shift, row + nx);
				values.fill(0, row + nx - shift, row + nx);
			} else {
				values.copyWithin(row - shift, row, row + nx + shift);
				values.fill(0, row, row - shift);
			}
		}
	}
};
/**
* @license
* Copyright 2010-2026 Three.js Authors
* SPDX-License-Identifier: MIT
*/
/**
* The texture will simply repeat to infinity.
*
* @type {number}
* @constant
*/
const RepeatWrapping = 1e3;
/**
* The last pixel of the texture stretches to the edge of the mesh.
*
* @type {number}
* @constant
*/
const ClampToEdgeWrapping = 1001;
/**
* The texture will repeats to infinity, mirroring on each repeat.
*
* @type {number}
* @constant
*/
const MirroredRepeatWrapping = 1002;
/**
* Returns the weighted average of the four texture elements that are closest to the specified
* texture coordinates, and can include items wrapped or repeated from other parts of a texture,
* depending on the values of `wrapS` and `wrapT`, and on the exact mapping.
*
* @type {number}
* @constant
*/
const LinearFilter = 1006;
/**
* Chooses the two mipmaps that most closely match the size of the pixel being textured and uses
* the `LinearFilter` criterion to produce a texture value from each mipmap. The final texture value
* is a weighted average of those two values.
*
* @type {number}
* @constant
*/
const LinearMipmapLinearFilter = 1008;
/**
* An unsigned byte data type for textures.
*
* @type {number}
* @constant
*/
const UnsignedByteType = 1009;
/**
* Reads the red, green, blue and alpha components.
*
* @type {number}
* @constant
*/
const RGBAFormat = 1023;
/**
* Discrete interpolation mode for keyframe tracks.
*
* @type {number}
* @constant
*/
const InterpolateDiscrete = 2300;
/**
* Linear interpolation mode for keyframe tracks.
*
* @type {number}
* @constant
*/
const InterpolateLinear = 2301;
/**
* Smooth interpolation mode for keyframe tracks.
*
* @type {number}
* @constant
*/
const InterpolateSmooth = 2302;
/**
* Bezier interpolation mode for keyframe tracks.
*
* Uses cubic Bezier curves with explicit 2D control points.
* Requires tangent data to be set on the track.
*
* @type {number}
* @constant
*/
const InterpolateBezier = 2303;
/**
* Zero curvature ending for animations.
*
* @type {number}
* @constant
*/
const ZeroCurvatureEnding = 2400;
/**
* Zero slope ending for animations.
*
* @type {number}
* @constant
*/
const ZeroSlopeEnding = 2401;
/**
* Wrap around ending for animations.
*
* @type {number}
* @constant
*/
const WrapAroundEnding = 2402;
/**
* sRGB color space.
*
* @type {string}
* @constant
*/
const SRGBColorSpace = "srgb";
/**
* sRGB-linear color space.
*
* @type {string}
* @constant
*/
const LinearSRGBColorSpace = "srgb-linear";
/**
* Linear transfer function.
*
* @type {string}
* @constant
*/
const LinearTransfer = "linear";
/**
* sRGB transfer function.
*
* @type {string}
* @constant
*/
const SRGBTransfer = "srgb";
/**
* WebGL coordinate system.
*
* @type {number}
* @constant
*/
const WebGLCoordinateSystem = 2e3;
/**
* Returns `true` if the given object is a typed array.
*
* @param {any} array - The object to check.
* @return {boolean} Whether the given object is a typed array.
*/
function isTypedArray(array) {
	return ArrayBuffer.isView(array) && !(array instanceof DataView);
}
/**
* Creates an XHTML element with the specified tag name.
*
* This function uses the XHTML namespace to create DOM elements,
* ensuring proper element creation in XML-based contexts.
*
* @private
* @param {string} name - The tag name of the element to create (e.g., 'canvas', 'div').
* @return {HTMLElement} The created XHTML element.
*/
function createElementNS(name) {
	return document.createElementNS("http://www.w3.org/1999/xhtml", name);
}
/**
* Internal cache for tracking warning messages to prevent duplicate warnings.
*
* @private
* @type {Object<string, boolean>}
*/
const _cache = {};
/**
* Enhances log/warn/error messages related to TSL.
*
* @param {Array<any>} params - The original message parameters.
* @returns {Array<any>} The filtered and enhanced message parameters.
*/
function enhanceLogMessage(params) {
	const message = params[0];
	if (typeof message === "string" && message.startsWith("TSL:")) {
		const stackTrace = params[1];
		if (stackTrace && stackTrace.isStackTrace) params[0] += " " + stackTrace.getLocation();
		else params[1] = "Stack trace not available. Enable \"THREE.Node.captureStackTrace\" to capture stack traces.";
	}
	return params;
}
/**
* Logs a warning message with the 'THREE.' prefix.
*
* If a custom console function is set via setConsoleFunction(), it will be used
* instead of the native console.warn. The first parameter is treated as the
* method name and is automatically prefixed with 'THREE.'.
*
* @param {...any} params - The message components. The first param is used as
*                          the method name and prefixed with 'THREE.'.
*/
function warn(...params) {
	params = enhanceLogMessage(params);
	const message = "THREE." + params.shift();
	{
		const stackTrace = params[0];
		if (stackTrace && stackTrace.isStackTrace) console.warn(stackTrace.getError(message));
		else console.warn(message, ...params);
	}
}
/**
* Logs an error message with the 'THREE.' prefix.
*
* If a custom console function is set via setConsoleFunction(), it will be used
* instead of the native console.error. The first parameter is treated as the
* method name and is automatically prefixed with 'THREE.'.
*
* @param {...any} params - The message components. The first param is used as
*                          the method name and prefixed with 'THREE.'.
*/
function error(...params) {
	params = enhanceLogMessage(params);
	const message = "THREE." + params.shift();
	{
		const stackTrace = params[0];
		if (stackTrace && stackTrace.isStackTrace) console.error(stackTrace.getError(message));
		else console.error(message, ...params);
	}
}
/**
* Logs a warning message only once, preventing duplicate warnings.
*
* This function maintains an internal cache of warning messages and will only
* output each unique warning message once. Useful for warnings that may be
* triggered repeatedly but should only be shown to the user once.
*
* @param {...any} params - The warning message components.
*/
function warnOnce(...params) {
	const message = params.join(" ");
	if (message in _cache) return;
	_cache[message] = true;
	warn(...params);
}
/**
* This modules allows to dispatch event objects on custom JavaScript objects.
*
* Main repository: [eventdispatcher.js](https://github.com/mrdoob/eventdispatcher.js/)
*
* Code Example:
* ```js
* class Car extends EventDispatcher {
* 	start() {
*		this.dispatchEvent( { type: 'start', message: 'vroom vroom!' } );
*	}
*};
*
* // Using events with the custom object
* const car = new Car();
* car.addEventListener( 'start', function ( event ) {
* 	alert( event.message );
* } );
*
* car.start();
* ```
*/
var EventDispatcher = class {
	/**
	* Adds the given event listener to the given event type.
	*
	* @param {string} type - The type of event to listen to.
	* @param {Function} listener - The function that gets called when the event is fired.
	*/
	addEventListener(type, listener) {
		if (this._listeners === void 0) this._listeners = {};
		const listeners = this._listeners;
		if (listeners[type] === void 0) listeners[type] = [];
		if (listeners[type].indexOf(listener) === -1) listeners[type].push(listener);
	}
	/**
	* Returns `true` if the given event listener has been added to the given event type.
	*
	* @param {string} type - The type of event.
	* @param {Function} listener - The listener to check.
	* @return {boolean} Whether the given event listener has been added to the given event type.
	*/
	hasEventListener(type, listener) {
		const listeners = this._listeners;
		if (listeners === void 0) return false;
		return listeners[type] !== void 0 && listeners[type].indexOf(listener) !== -1;
	}
	/**
	* Removes the given event listener from the given event type.
	*
	* @param {string} type - The type of event.
	* @param {Function} listener - The listener to remove.
	*/
	removeEventListener(type, listener) {
		const listeners = this._listeners;
		if (listeners === void 0) return;
		const listenerArray = listeners[type];
		if (listenerArray !== void 0) {
			const index = listenerArray.indexOf(listener);
			if (index !== -1) listenerArray.splice(index, 1);
		}
	}
	/**
	* Dispatches an event object.
	*
	* @param {Object} event - The event that gets fired.
	*/
	dispatchEvent(event) {
		const listeners = this._listeners;
		if (listeners === void 0) return;
		const listenerArray = listeners[event.type];
		if (listenerArray !== void 0) {
			event.target = this;
			const array = listenerArray.slice(0);
			for (let i = 0, l = array.length; i < l; i++) array[i].call(this, event);
			event.target = null;
		}
	}
};
const _lut = [
	"00",
	"01",
	"02",
	"03",
	"04",
	"05",
	"06",
	"07",
	"08",
	"09",
	"0a",
	"0b",
	"0c",
	"0d",
	"0e",
	"0f",
	"10",
	"11",
	"12",
	"13",
	"14",
	"15",
	"16",
	"17",
	"18",
	"19",
	"1a",
	"1b",
	"1c",
	"1d",
	"1e",
	"1f",
	"20",
	"21",
	"22",
	"23",
	"24",
	"25",
	"26",
	"27",
	"28",
	"29",
	"2a",
	"2b",
	"2c",
	"2d",
	"2e",
	"2f",
	"30",
	"31",
	"32",
	"33",
	"34",
	"35",
	"36",
	"37",
	"38",
	"39",
	"3a",
	"3b",
	"3c",
	"3d",
	"3e",
	"3f",
	"40",
	"41",
	"42",
	"43",
	"44",
	"45",
	"46",
	"47",
	"48",
	"49",
	"4a",
	"4b",
	"4c",
	"4d",
	"4e",
	"4f",
	"50",
	"51",
	"52",
	"53",
	"54",
	"55",
	"56",
	"57",
	"58",
	"59",
	"5a",
	"5b",
	"5c",
	"5d",
	"5e",
	"5f",
	"60",
	"61",
	"62",
	"63",
	"64",
	"65",
	"66",
	"67",
	"68",
	"69",
	"6a",
	"6b",
	"6c",
	"6d",
	"6e",
	"6f",
	"70",
	"71",
	"72",
	"73",
	"74",
	"75",
	"76",
	"77",
	"78",
	"79",
	"7a",
	"7b",
	"7c",
	"7d",
	"7e",
	"7f",
	"80",
	"81",
	"82",
	"83",
	"84",
	"85",
	"86",
	"87",
	"88",
	"89",
	"8a",
	"8b",
	"8c",
	"8d",
	"8e",
	"8f",
	"90",
	"91",
	"92",
	"93",
	"94",
	"95",
	"96",
	"97",
	"98",
	"99",
	"9a",
	"9b",
	"9c",
	"9d",
	"9e",
	"9f",
	"a0",
	"a1",
	"a2",
	"a3",
	"a4",
	"a5",
	"a6",
	"a7",
	"a8",
	"a9",
	"aa",
	"ab",
	"ac",
	"ad",
	"ae",
	"af",
	"b0",
	"b1",
	"b2",
	"b3",
	"b4",
	"b5",
	"b6",
	"b7",
	"b8",
	"b9",
	"ba",
	"bb",
	"bc",
	"bd",
	"be",
	"bf",
	"c0",
	"c1",
	"c2",
	"c3",
	"c4",
	"c5",
	"c6",
	"c7",
	"c8",
	"c9",
	"ca",
	"cb",
	"cc",
	"cd",
	"ce",
	"cf",
	"d0",
	"d1",
	"d2",
	"d3",
	"d4",
	"d5",
	"d6",
	"d7",
	"d8",
	"d9",
	"da",
	"db",
	"dc",
	"dd",
	"de",
	"df",
	"e0",
	"e1",
	"e2",
	"e3",
	"e4",
	"e5",
	"e6",
	"e7",
	"e8",
	"e9",
	"ea",
	"eb",
	"ec",
	"ed",
	"ee",
	"ef",
	"f0",
	"f1",
	"f2",
	"f3",
	"f4",
	"f5",
	"f6",
	"f7",
	"f8",
	"f9",
	"fa",
	"fb",
	"fc",
	"fd",
	"fe",
	"ff"
];
/**
* Generate a [UUID](https://en.wikipedia.org/wiki/Universally_unique_identifier)
* (universally unique identifier).
*
* @return {string} The UUID.
*/
function generateUUID() {
	const d0 = Math.random() * 4294967295 | 0;
	const d1 = Math.random() * 4294967295 | 0;
	const d2 = Math.random() * 4294967295 | 0;
	const d3 = Math.random() * 4294967295 | 0;
	return (_lut[d0 & 255] + _lut[d0 >> 8 & 255] + _lut[d0 >> 16 & 255] + _lut[d0 >> 24 & 255] + "-" + _lut[d1 & 255] + _lut[d1 >> 8 & 255] + "-" + _lut[d1 >> 16 & 15 | 64] + _lut[d1 >> 24 & 255] + "-" + _lut[d2 & 63 | 128] + _lut[d2 >> 8 & 255] + "-" + _lut[d2 >> 16 & 255] + _lut[d2 >> 24 & 255] + _lut[d3 & 255] + _lut[d3 >> 8 & 255] + _lut[d3 >> 16 & 255] + _lut[d3 >> 24 & 255]).toLowerCase();
}
/**
* Clamps the given value between min and max.
*
* @param {number} value - The value to clamp.
* @param {number} min - The min value.
* @param {number} max - The max value.
* @return {number} The clamped value.
*/
function clamp$1(value, min, max) {
	return Math.max(min, Math.min(max, value));
}
/**
* Computes the Euclidean modulo of the given parameters that
* is `( ( n % m ) + m ) % m`.
*
* @param {number} n - The first parameter.
* @param {number} m - The second parameter.
* @return {number} The Euclidean modulo.
*/
function euclideanModulo(n, m) {
	return (n % m + m) % m;
}
/**
* Returns a value linearly interpolated from two known points based on the given interval -
* `t = 0` will return `x` and `t = 1` will return `y`.
*
* @param {number} x - The start point
* @param {number} y - The end point.
* @param {number} t - The interpolation factor in the closed interval `[0, 1]`.
* @return {number} The interpolated value.
*/
function lerp(x, y, t) {
	return (1 - t) * x + t * y;
}
/**
* Class representing a 2D vector. A 2D vector is an ordered pair of numbers
* (labeled x and y), which can be used to represent a number of things, such as:
*
* - A point in 2D space (i.e. a position on a plane).
* - A direction and length across a plane. In three.js the length will
* always be the Euclidean distance(straight-line distance) from `(0, 0)` to `(x, y)`
* and the direction is also measured from `(0, 0)` towards `(x, y)`.
* - Any arbitrary ordered pair of numbers.
*
* There are other things a 2D vector can be used to represent, such as
* momentum vectors, complex numbers and so on, however these are the most
* common uses in three.js.
*
* Iterating through a vector instance will yield its components `(x, y)` in
* the corresponding order.
* ```js
* const a = new THREE.Vector2( 0, 1 );
*
* //no arguments; will be initialised to (0, 0)
* const b = new THREE.Vector2( );
*
* const d = a.distanceTo( b );
* ```
*/
var Vector2 = class Vector2 {
	static {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		Vector2.prototype.isVector2 = true;
	}
	/**
	* Constructs a new 2D vector.
	*
	* @param {number} [x=0] - The x value of this vector.
	* @param {number} [y=0] - The y value of this vector.
	*/
	constructor(x = 0, y = 0) {
		/**
		* The x value of this vector.
		*
		* @type {number}
		*/
		this.x = x;
		/**
		* The y value of this vector.
		*
		* @type {number}
		*/
		this.y = y;
	}
	/**
	* Alias for {@link Vector2#x}.
	*
	* @type {number}
	*/
	get width() {
		return this.x;
	}
	set width(value) {
		this.x = value;
	}
	/**
	* Alias for {@link Vector2#y}.
	*
	* @type {number}
	*/
	get height() {
		return this.y;
	}
	set height(value) {
		this.y = value;
	}
	/**
	* Sets the vector components.
	*
	* @param {number} x - The value of the x component.
	* @param {number} y - The value of the y component.
	* @return {Vector2} A reference to this vector.
	*/
	set(x, y) {
		this.x = x;
		this.y = y;
		return this;
	}
	/**
	* Sets the vector components to the same value.
	*
	* @param {number} scalar - The value to set for all vector components.
	* @return {Vector2} A reference to this vector.
	*/
	setScalar(scalar) {
		this.x = scalar;
		this.y = scalar;
		return this;
	}
	/**
	* Sets the vector's x component to the given value
	*
	* @param {number} x - The value to set.
	* @return {Vector2} A reference to this vector.
	*/
	setX(x) {
		this.x = x;
		return this;
	}
	/**
	* Sets the vector's y component to the given value
	*
	* @param {number} y - The value to set.
	* @return {Vector2} A reference to this vector.
	*/
	setY(y) {
		this.y = y;
		return this;
	}
	/**
	* Allows to set a vector component with an index.
	*
	* @param {number} index - The component index. `0` equals to x, `1` equals to y.
	* @param {number} value - The value to set.
	* @return {Vector2} A reference to this vector.
	*/
	setComponent(index, value) {
		switch (index) {
			case 0:
				this.x = value;
				break;
			case 1:
				this.y = value;
				break;
			default: throw new Error("THREE.Vector2: index is out of range: " + index);
		}
		return this;
	}
	/**
	* Returns the value of the vector component which matches the given index.
	*
	* @param {number} index - The component index. `0` equals to x, `1` equals to y.
	* @return {number} A vector component value.
	*/
	getComponent(index) {
		switch (index) {
			case 0: return this.x;
			case 1: return this.y;
			default: throw new Error("THREE.Vector2: index is out of range: " + index);
		}
	}
	/**
	* Returns a new vector with copied values from this instance.
	*
	* @return {Vector2} A clone of this instance.
	*/
	clone() {
		return new this.constructor(this.x, this.y);
	}
	/**
	* Copies the values of the given vector to this instance.
	*
	* @param {Vector2} v - The vector to copy.
	* @return {Vector2} A reference to this vector.
	*/
	copy(v) {
		this.x = v.x;
		this.y = v.y;
		return this;
	}
	/**
	* Adds the given vector to this instance.
	*
	* @param {Vector2} v - The vector to add.
	* @return {Vector2} A reference to this vector.
	*/
	add(v) {
		this.x += v.x;
		this.y += v.y;
		return this;
	}
	/**
	* Adds the given scalar value to all components of this instance.
	*
	* @param {number} s - The scalar to add.
	* @return {Vector2} A reference to this vector.
	*/
	addScalar(s) {
		this.x += s;
		this.y += s;
		return this;
	}
	/**
	* Adds the given vectors and stores the result in this instance.
	*
	* @param {Vector2} a - The first vector.
	* @param {Vector2} b - The second vector.
	* @return {Vector2} A reference to this vector.
	*/
	addVectors(a, b) {
		this.x = a.x + b.x;
		this.y = a.y + b.y;
		return this;
	}
	/**
	* Adds the given vector scaled by the given factor to this instance.
	*
	* @param {Vector2} v - The vector.
	* @param {number} s - The factor that scales `v`.
	* @return {Vector2} A reference to this vector.
	*/
	addScaledVector(v, s) {
		this.x += v.x * s;
		this.y += v.y * s;
		return this;
	}
	/**
	* Subtracts the given vector from this instance.
	*
	* @param {Vector2} v - The vector to subtract.
	* @return {Vector2} A reference to this vector.
	*/
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		return this;
	}
	/**
	* Subtracts the given scalar value from all components of this instance.
	*
	* @param {number} s - The scalar to subtract.
	* @return {Vector2} A reference to this vector.
	*/
	subScalar(s) {
		this.x -= s;
		this.y -= s;
		return this;
	}
	/**
	* Subtracts the given vectors and stores the result in this instance.
	*
	* @param {Vector2} a - The first vector.
	* @param {Vector2} b - The second vector.
	* @return {Vector2} A reference to this vector.
	*/
	subVectors(a, b) {
		this.x = a.x - b.x;
		this.y = a.y - b.y;
		return this;
	}
	/**
	* Multiplies the given vector with this instance.
	*
	* @param {Vector2} v - The vector to multiply.
	* @return {Vector2} A reference to this vector.
	*/
	multiply(v) {
		this.x *= v.x;
		this.y *= v.y;
		return this;
	}
	/**
	* Multiplies the given scalar value with all components of this instance.
	*
	* @param {number} scalar - The scalar to multiply.
	* @return {Vector2} A reference to this vector.
	*/
	multiplyScalar(scalar) {
		this.x *= scalar;
		this.y *= scalar;
		return this;
	}
	/**
	* Divides this instance by the given vector.
	*
	* @param {Vector2} v - The vector to divide.
	* @return {Vector2} A reference to this vector.
	*/
	divide(v) {
		this.x /= v.x;
		this.y /= v.y;
		return this;
	}
	/**
	* Divides this vector by the given scalar.
	*
	* @param {number} scalar - The scalar to divide.
	* @return {Vector2} A reference to this vector.
	*/
	divideScalar(scalar) {
		return this.multiplyScalar(1 / scalar);
	}
	/**
	* Multiplies this vector (with an implicit 1 as the 3rd component) by
	* the given 3x3 matrix.
	*
	* @param {Matrix3} m - The matrix to apply.
	* @return {Vector2} A reference to this vector.
	*/
	applyMatrix3(m) {
		const x = this.x, y = this.y;
		const e = m.elements;
		this.x = e[0] * x + e[3] * y + e[6];
		this.y = e[1] * x + e[4] * y + e[7];
		return this;
	}
	/**
	* If this vector's x or y value is greater than the given vector's x or y
	* value, replace that value with the corresponding min value.
	*
	* @param {Vector2} v - The vector.
	* @return {Vector2} A reference to this vector.
	*/
	min(v) {
		this.x = Math.min(this.x, v.x);
		this.y = Math.min(this.y, v.y);
		return this;
	}
	/**
	* If this vector's x or y value is less than the given vector's x or y
	* value, replace that value with the corresponding max value.
	*
	* @param {Vector2} v - The vector.
	* @return {Vector2} A reference to this vector.
	*/
	max(v) {
		this.x = Math.max(this.x, v.x);
		this.y = Math.max(this.y, v.y);
		return this;
	}
	/**
	* If this vector's x or y value is greater than the max vector's x or y
	* value, it is replaced by the corresponding value.
	* If this vector's x or y value is less than the min vector's x or y value,
	* it is replaced by the corresponding value.
	*
	* @param {Vector2} min - The minimum x and y values.
	* @param {Vector2} max - The maximum x and y values in the desired range.
	* @return {Vector2} A reference to this vector.
	*/
	clamp(min, max) {
		this.x = clamp$1(this.x, min.x, max.x);
		this.y = clamp$1(this.y, min.y, max.y);
		return this;
	}
	/**
	* If this vector's x or y values are greater than the max value, they are
	* replaced by the max value.
	* If this vector's x or y values are less than the min value, they are
	* replaced by the min value.
	*
	* @param {number} minVal - The minimum value the components will be clamped to.
	* @param {number} maxVal - The maximum value the components will be clamped to.
	* @return {Vector2} A reference to this vector.
	*/
	clampScalar(minVal, maxVal) {
		this.x = clamp$1(this.x, minVal, maxVal);
		this.y = clamp$1(this.y, minVal, maxVal);
		return this;
	}
	/**
	* If this vector's length is greater than the max value, it is replaced by
	* the max value.
	* If this vector's length is less than the min value, it is replaced by the
	* min value.
	*
	* @param {number} min - The minimum value the vector length will be clamped to.
	* @param {number} max - The maximum value the vector length will be clamped to.
	* @return {Vector2} A reference to this vector.
	*/
	clampLength(min, max) {
		const length = this.length();
		return this.divideScalar(length || 1).multiplyScalar(clamp$1(length, min, max));
	}
	/**
	* The components of this vector are rounded down to the nearest integer value.
	*
	* @return {Vector2} A reference to this vector.
	*/
	floor() {
		this.x = Math.floor(this.x);
		this.y = Math.floor(this.y);
		return this;
	}
	/**
	* The components of this vector are rounded up to the nearest integer value.
	*
	* @return {Vector2} A reference to this vector.
	*/
	ceil() {
		this.x = Math.ceil(this.x);
		this.y = Math.ceil(this.y);
		return this;
	}
	/**
	* The components of this vector are rounded to the nearest integer value
	*
	* @return {Vector2} A reference to this vector.
	*/
	round() {
		this.x = Math.round(this.x);
		this.y = Math.round(this.y);
		return this;
	}
	/**
	* The components of this vector are rounded towards zero (up if negative,
	* down if positive) to an integer value.
	*
	* @return {Vector2} A reference to this vector.
	*/
	roundToZero() {
		this.x = Math.trunc(this.x);
		this.y = Math.trunc(this.y);
		return this;
	}
	/**
	* Inverts this vector - i.e. sets x = -x and y = -y.
	*
	* @return {Vector2} A reference to this vector.
	*/
	negate() {
		this.x = -this.x;
		this.y = -this.y;
		return this;
	}
	/**
	* Calculates the dot product of the given vector with this instance.
	*
	* @param {Vector2} v - The vector to compute the dot product with.
	* @return {number} The result of the dot product.
	*/
	dot(v) {
		return this.x * v.x + this.y * v.y;
	}
	/**
	* Calculates the cross product of the given vector with this instance.
	*
	* @param {Vector2} v - The vector to compute the cross product with.
	* @return {number} The result of the cross product.
	*/
	cross(v) {
		return this.x * v.y - this.y * v.x;
	}
	/**
	* Computes the square of the Euclidean length (straight-line length) from
	* (0, 0) to (x, y). If you are comparing the lengths of vectors, you should
	* compare the length squared instead as it is slightly more efficient to calculate.
	*
	* @return {number} The square length of this vector.
	*/
	lengthSq() {
		return this.x * this.x + this.y * this.y;
	}
	/**
	* Computes the  Euclidean length (straight-line length) from (0, 0) to (x, y).
	*
	* @return {number} The length of this vector.
	*/
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y);
	}
	/**
	* Computes the Manhattan length of this vector.
	*
	* @return {number} The length of this vector.
	*/
	manhattanLength() {
		return Math.abs(this.x) + Math.abs(this.y);
	}
	/**
	* Converts this vector to a unit vector - that is, sets it equal to a vector
	* with the same direction as this one, but with a vector length of `1`.
	*
	* @return {Vector2} A reference to this vector.
	*/
	normalize() {
		return this.divideScalar(this.length() || 1);
	}
	/**
	* Computes the angle in radians of this vector with respect to the positive x-axis.
	*
	* @return {number} The angle in radians.
	*/
	angle() {
		return Math.atan2(-this.y, -this.x) + Math.PI;
	}
	/**
	* Returns the angle between the given vector and this instance in radians.
	*
	* @param {Vector2} v - The vector to compute the angle with.
	* @return {number} The angle in radians.
	*/
	angleTo(v) {
		const denominator = Math.sqrt(this.lengthSq() * v.lengthSq());
		if (denominator === 0) return Math.PI / 2;
		const theta = this.dot(v) / denominator;
		return Math.acos(clamp$1(theta, -1, 1));
	}
	/**
	* Computes the distance from the given vector to this instance.
	*
	* @param {Vector2} v - The vector to compute the distance to.
	* @return {number} The distance.
	*/
	distanceTo(v) {
		return Math.sqrt(this.distanceToSquared(v));
	}
	/**
	* Computes the squared distance from the given vector to this instance.
	* If you are just comparing the distance with another distance, you should compare
	* the distance squared instead as it is slightly more efficient to calculate.
	*
	* @param {Vector2} v - The vector to compute the squared distance to.
	* @return {number} The squared distance.
	*/
	distanceToSquared(v) {
		const dx = this.x - v.x, dy = this.y - v.y;
		return dx * dx + dy * dy;
	}
	/**
	* Computes the Manhattan distance from the given vector to this instance.
	*
	* @param {Vector2} v - The vector to compute the Manhattan distance to.
	* @return {number} The Manhattan distance.
	*/
	manhattanDistanceTo(v) {
		return Math.abs(this.x - v.x) + Math.abs(this.y - v.y);
	}
	/**
	* Sets this vector to a vector with the same direction as this one, but
	* with the specified length.
	*
	* @param {number} length - The new length of this vector.
	* @return {Vector2} A reference to this vector.
	*/
	setLength(length) {
		return this.normalize().multiplyScalar(length);
	}
	/**
	* Linearly interpolates between the given vector and this instance, where
	* alpha is the percent distance along the line - alpha = 0 will be this
	* vector, and alpha = 1 will be the given one.
	*
	* @param {Vector2} v - The vector to interpolate towards.
	* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
	* @return {Vector2} A reference to this vector.
	*/
	lerp(v, alpha) {
		this.x += (v.x - this.x) * alpha;
		this.y += (v.y - this.y) * alpha;
		return this;
	}
	/**
	* Linearly interpolates between the given vectors, where alpha is the percent
	* distance along the line - alpha = 0 will be first vector, and alpha = 1 will
	* be the second one. The result is stored in this instance.
	*
	* @param {Vector2} v1 - The first vector.
	* @param {Vector2} v2 - The second vector.
	* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
	* @return {Vector2} A reference to this vector.
	*/
	lerpVectors(v1, v2, alpha) {
		this.x = v1.x + (v2.x - v1.x) * alpha;
		this.y = v1.y + (v2.y - v1.y) * alpha;
		return this;
	}
	/**
	* Returns `true` if this vector is equal with the given one.
	*
	* @param {Vector2} v - The vector to test for equality.
	* @return {boolean} Whether this vector is equal with the given one.
	*/
	equals(v) {
		return v.x === this.x && v.y === this.y;
	}
	/**
	* Sets this vector's x value to be `array[ offset ]` and y
	* value to be `array[ offset + 1 ]`.
	*
	* @param {Array<number>} array - An array holding the vector component values.
	* @param {number} [offset=0] - The offset into the array.
	* @return {Vector2} A reference to this vector.
	*/
	fromArray(array, offset = 0) {
		this.x = array[offset];
		this.y = array[offset + 1];
		return this;
	}
	/**
	* Writes the components of this vector to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the vector components.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The vector components.
	*/
	toArray(array = [], offset = 0) {
		array[offset] = this.x;
		array[offset + 1] = this.y;
		return array;
	}
	/**
	* Sets the components of this vector from the given buffer attribute.
	*
	* @param {BufferAttribute} attribute - The buffer attribute holding vector data.
	* @param {number} index - The index into the attribute.
	* @return {Vector2} A reference to this vector.
	*/
	fromBufferAttribute(attribute, index) {
		this.x = attribute.getX(index);
		this.y = attribute.getY(index);
		return this;
	}
	/**
	* Rotates this vector around the given center by the given angle.
	*
	* @param {Vector2} center - The point around which to rotate.
	* @param {number} angle - The angle to rotate, in radians.
	* @return {Vector2} A reference to this vector.
	*/
	rotateAround(center, angle) {
		const c = Math.cos(angle), s = Math.sin(angle);
		const x = this.x - center.x;
		const y = this.y - center.y;
		this.x = x * c - y * s + center.x;
		this.y = x * s + y * c + center.y;
		return this;
	}
	/**
	* Sets each component of this vector to a pseudo-random value between `0` and
	* `1`, excluding `1`.
	*
	* @return {Vector2} A reference to this vector.
	*/
	random() {
		this.x = Math.random();
		this.y = Math.random();
		return this;
	}
	*[Symbol.iterator]() {
		yield this.x;
		yield this.y;
	}
};
/**
* Class for representing a Quaternion. Quaternions are used in three.js to represent rotations.
*
* Iterating through a vector instance will yield its components `(x, y, z, w)` in
* the corresponding order.
*
* Note that three.js expects Quaternions to be normalized.
* ```js
* const quaternion = new THREE.Quaternion();
* quaternion.setFromAxisAngle( new THREE.Vector3( 0, 1, 0 ), Math.PI / 2 );
*
* const vector = new THREE.Vector3( 1, 0, 0 );
* vector.applyQuaternion( quaternion );
* ```
*/
var Quaternion = class {
	/**
	* Constructs a new quaternion.
	*
	* @param {number} [x=0] - The x value of this quaternion.
	* @param {number} [y=0] - The y value of this quaternion.
	* @param {number} [z=0] - The z value of this quaternion.
	* @param {number} [w=1] - The w value of this quaternion.
	*/
	constructor(x = 0, y = 0, z = 0, w = 1) {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		this.isQuaternion = true;
		this._x = x;
		this._y = y;
		this._z = z;
		this._w = w;
	}
	/**
	* Interpolates between two quaternions via SLERP. This implementation assumes the
	* quaternion data are managed in flat arrays.
	*
	* @param {Array<number>} dst - The destination array.
	* @param {number} dstOffset - An offset into the destination array.
	* @param {Array<number>} src0 - The source array of the first quaternion.
	* @param {number} srcOffset0 - An offset into the first source array.
	* @param {Array<number>} src1 -  The source array of the second quaternion.
	* @param {number} srcOffset1 - An offset into the second source array.
	* @param {number} t - The interpolation factor. A value in the range `[0,1]` will interpolate. A value outside the range `[0,1]` will extrapolate.
	* @see {@link Quaternion#slerp}
	*/
	static slerpFlat(dst, dstOffset, src0, srcOffset0, src1, srcOffset1, t) {
		let x0 = src0[srcOffset0 + 0], y0 = src0[srcOffset0 + 1], z0 = src0[srcOffset0 + 2], w0 = src0[srcOffset0 + 3];
		let x1 = src1[srcOffset1 + 0], y1 = src1[srcOffset1 + 1], z1 = src1[srcOffset1 + 2], w1 = src1[srcOffset1 + 3];
		if (w0 !== w1 || x0 !== x1 || y0 !== y1 || z0 !== z1) {
			let dot = x0 * x1 + y0 * y1 + z0 * z1 + w0 * w1;
			if (dot < 0) {
				x1 = -x1;
				y1 = -y1;
				z1 = -z1;
				w1 = -w1;
				dot = -dot;
			}
			let s = 1 - t;
			if (dot < .9995) {
				const theta = Math.acos(dot);
				const sin = Math.sin(theta);
				s = Math.sin(s * theta) / sin;
				t = Math.sin(t * theta) / sin;
				x0 = x0 * s + x1 * t;
				y0 = y0 * s + y1 * t;
				z0 = z0 * s + z1 * t;
				w0 = w0 * s + w1 * t;
			} else {
				x0 = x0 * s + x1 * t;
				y0 = y0 * s + y1 * t;
				z0 = z0 * s + z1 * t;
				w0 = w0 * s + w1 * t;
				const f = 1 / Math.sqrt(x0 * x0 + y0 * y0 + z0 * z0 + w0 * w0);
				x0 *= f;
				y0 *= f;
				z0 *= f;
				w0 *= f;
			}
		}
		dst[dstOffset] = x0;
		dst[dstOffset + 1] = y0;
		dst[dstOffset + 2] = z0;
		dst[dstOffset + 3] = w0;
	}
	/**
	* Multiplies two quaternions. This implementation assumes the quaternion data are managed
	* in flat arrays.
	*
	* @param {Array<number>} dst - The destination array.
	* @param {number} dstOffset - An offset into the destination array.
	* @param {Array<number>} src0 - The source array of the first quaternion.
	* @param {number} srcOffset0 - An offset into the first source array.
	* @param {Array<number>} src1 -  The source array of the second quaternion.
	* @param {number} srcOffset1 - An offset into the second source array.
	* @return {Array<number>} The destination array.
	* @see {@link Quaternion#multiplyQuaternions}.
	*/
	static multiplyQuaternionsFlat(dst, dstOffset, src0, srcOffset0, src1, srcOffset1) {
		const x0 = src0[srcOffset0];
		const y0 = src0[srcOffset0 + 1];
		const z0 = src0[srcOffset0 + 2];
		const w0 = src0[srcOffset0 + 3];
		const x1 = src1[srcOffset1];
		const y1 = src1[srcOffset1 + 1];
		const z1 = src1[srcOffset1 + 2];
		const w1 = src1[srcOffset1 + 3];
		dst[dstOffset] = x0 * w1 + w0 * x1 + y0 * z1 - z0 * y1;
		dst[dstOffset + 1] = y0 * w1 + w0 * y1 + z0 * x1 - x0 * z1;
		dst[dstOffset + 2] = z0 * w1 + w0 * z1 + x0 * y1 - y0 * x1;
		dst[dstOffset + 3] = w0 * w1 - x0 * x1 - y0 * y1 - z0 * z1;
		return dst;
	}
	/**
	* The x value of this quaternion.
	*
	* @type {number}
	* @default 0
	*/
	get x() {
		return this._x;
	}
	set x(value) {
		this._x = value;
		this._onChangeCallback();
	}
	/**
	* The y value of this quaternion.
	*
	* @type {number}
	* @default 0
	*/
	get y() {
		return this._y;
	}
	set y(value) {
		this._y = value;
		this._onChangeCallback();
	}
	/**
	* The z value of this quaternion.
	*
	* @type {number}
	* @default 0
	*/
	get z() {
		return this._z;
	}
	set z(value) {
		this._z = value;
		this._onChangeCallback();
	}
	/**
	* The w value of this quaternion.
	*
	* @type {number}
	* @default 1
	*/
	get w() {
		return this._w;
	}
	set w(value) {
		this._w = value;
		this._onChangeCallback();
	}
	/**
	* Sets the quaternion components.
	*
	* @param {number} x - The x value of this quaternion.
	* @param {number} y - The y value of this quaternion.
	* @param {number} z - The z value of this quaternion.
	* @param {number} w - The w value of this quaternion.
	* @return {Quaternion} A reference to this quaternion.
	*/
	set(x, y, z, w) {
		this._x = x;
		this._y = y;
		this._z = z;
		this._w = w;
		this._onChangeCallback();
		return this;
	}
	/**
	* Returns a new quaternion with copied values from this instance.
	*
	* @return {Quaternion} A clone of this instance.
	*/
	clone() {
		return new this.constructor(this._x, this._y, this._z, this._w);
	}
	/**
	* Copies the values of the given quaternion to this instance.
	*
	* @param {Quaternion} quaternion - The quaternion to copy.
	* @return {Quaternion} A reference to this quaternion.
	*/
	copy(quaternion) {
		this._x = quaternion.x;
		this._y = quaternion.y;
		this._z = quaternion.z;
		this._w = quaternion.w;
		this._onChangeCallback();
		return this;
	}
	/**
	* Sets this quaternion from the rotation specified by the given
	* Euler angles.
	*
	* @param {Euler} euler - The Euler angles.
	* @param {boolean} [update=true] - Whether the internal `onChange` callback should be executed or not.
	* @return {Quaternion} A reference to this quaternion.
	*/
	setFromEuler(euler, update = true) {
		const x = euler._x, y = euler._y, z = euler._z, order = euler._order;
		const cos = Math.cos;
		const sin = Math.sin;
		const c1 = cos(x / 2);
		const c2 = cos(y / 2);
		const c3 = cos(z / 2);
		const s1 = sin(x / 2);
		const s2 = sin(y / 2);
		const s3 = sin(z / 2);
		switch (order) {
			case "XYZ":
				this._x = s1 * c2 * c3 + c1 * s2 * s3;
				this._y = c1 * s2 * c3 - s1 * c2 * s3;
				this._z = c1 * c2 * s3 + s1 * s2 * c3;
				this._w = c1 * c2 * c3 - s1 * s2 * s3;
				break;
			case "YXZ":
				this._x = s1 * c2 * c3 + c1 * s2 * s3;
				this._y = c1 * s2 * c3 - s1 * c2 * s3;
				this._z = c1 * c2 * s3 - s1 * s2 * c3;
				this._w = c1 * c2 * c3 + s1 * s2 * s3;
				break;
			case "ZXY":
				this._x = s1 * c2 * c3 - c1 * s2 * s3;
				this._y = c1 * s2 * c3 + s1 * c2 * s3;
				this._z = c1 * c2 * s3 + s1 * s2 * c3;
				this._w = c1 * c2 * c3 - s1 * s2 * s3;
				break;
			case "ZYX":
				this._x = s1 * c2 * c3 - c1 * s2 * s3;
				this._y = c1 * s2 * c3 + s1 * c2 * s3;
				this._z = c1 * c2 * s3 - s1 * s2 * c3;
				this._w = c1 * c2 * c3 + s1 * s2 * s3;
				break;
			case "YZX":
				this._x = s1 * c2 * c3 + c1 * s2 * s3;
				this._y = c1 * s2 * c3 + s1 * c2 * s3;
				this._z = c1 * c2 * s3 - s1 * s2 * c3;
				this._w = c1 * c2 * c3 - s1 * s2 * s3;
				break;
			case "XZY":
				this._x = s1 * c2 * c3 - c1 * s2 * s3;
				this._y = c1 * s2 * c3 - s1 * c2 * s3;
				this._z = c1 * c2 * s3 + s1 * s2 * c3;
				this._w = c1 * c2 * c3 + s1 * s2 * s3;
				break;
			default: warn("Quaternion: .setFromEuler() encountered an unknown order: " + order);
		}
		if (update === true) this._onChangeCallback();
		return this;
	}
	/**
	* Sets this quaternion from the given axis and angle.
	*
	* @param {Vector3} axis - The normalized axis.
	* @param {number} angle - The angle in radians.
	* @return {Quaternion} A reference to this quaternion.
	*/
	setFromAxisAngle(axis, angle) {
		const halfAngle = angle / 2, s = Math.sin(halfAngle);
		this._x = axis.x * s;
		this._y = axis.y * s;
		this._z = axis.z * s;
		this._w = Math.cos(halfAngle);
		this._onChangeCallback();
		return this;
	}
	/**
	* Sets this quaternion from the given rotation matrix.
	*
	* @param {Matrix4} m - A 4x4 matrix of which the upper 3x3 of matrix is a pure rotation matrix (i.e. unscaled).
	* @return {Quaternion} A reference to this quaternion.
	*/
	setFromRotationMatrix(m) {
		const te = m.elements, m11 = te[0], m12 = te[4], m13 = te[8], m21 = te[1], m22 = te[5], m23 = te[9], m31 = te[2], m32 = te[6], m33 = te[10], trace = m11 + m22 + m33;
		if (trace > 0) {
			const s = .5 / Math.sqrt(trace + 1);
			this._w = .25 / s;
			this._x = (m32 - m23) * s;
			this._y = (m13 - m31) * s;
			this._z = (m21 - m12) * s;
		} else if (m11 > m22 && m11 > m33) {
			const s = 2 * Math.sqrt(1 + m11 - m22 - m33);
			this._w = (m32 - m23) / s;
			this._x = .25 * s;
			this._y = (m12 + m21) / s;
			this._z = (m13 + m31) / s;
		} else if (m22 > m33) {
			const s = 2 * Math.sqrt(1 + m22 - m11 - m33);
			this._w = (m13 - m31) / s;
			this._x = (m12 + m21) / s;
			this._y = .25 * s;
			this._z = (m23 + m32) / s;
		} else {
			const s = 2 * Math.sqrt(1 + m33 - m11 - m22);
			this._w = (m21 - m12) / s;
			this._x = (m13 + m31) / s;
			this._y = (m23 + m32) / s;
			this._z = .25 * s;
		}
		this._onChangeCallback();
		return this;
	}
	/**
	* Sets this quaternion to the rotation required to rotate the direction vector
	* `vFrom` to the direction vector `vTo`.
	*
	* @param {Vector3} vFrom - The first (normalized) direction vector.
	* @param {Vector3} vTo - The second (normalized) direction vector.
	* @return {Quaternion} A reference to this quaternion.
	*/
	setFromUnitVectors(vFrom, vTo) {
		let r = vFrom.dot(vTo) + 1;
		if (r < 1e-8) {
			r = 0;
			if (Math.abs(vFrom.x) > Math.abs(vFrom.z)) {
				this._x = -vFrom.y;
				this._y = vFrom.x;
				this._z = 0;
				this._w = r;
			} else {
				this._x = 0;
				this._y = -vFrom.z;
				this._z = vFrom.y;
				this._w = r;
			}
		} else {
			this._x = vFrom.y * vTo.z - vFrom.z * vTo.y;
			this._y = vFrom.z * vTo.x - vFrom.x * vTo.z;
			this._z = vFrom.x * vTo.y - vFrom.y * vTo.x;
			this._w = r;
		}
		return this.normalize();
	}
	/**
	* Returns the angle between this quaternion and the given one in radians.
	*
	* @param {Quaternion} q - The quaternion to compute the angle with.
	* @return {number} The angle in radians.
	*/
	angleTo(q) {
		return 2 * Math.acos(Math.abs(clamp$1(this.dot(q), -1, 1)));
	}
	/**
	* Rotates this quaternion by a given angular step to the given quaternion.
	* The method ensures that the final quaternion will not overshoot `q`.
	*
	* @param {Quaternion} q - The target quaternion.
	* @param {number} step - The angular step in radians.
	* @return {Quaternion} A reference to this quaternion.
	*/
	rotateTowards(q, step) {
		const angle = this.angleTo(q);
		if (angle === 0) return this;
		const t = Math.min(1, step / angle);
		this.slerp(q, t);
		return this;
	}
	/**
	* Sets this quaternion to the identity quaternion; that is, to the
	* quaternion that represents "no rotation".
	*
	* @return {Quaternion} A reference to this quaternion.
	*/
	identity() {
		return this.set(0, 0, 0, 1);
	}
	/**
	* Inverts this quaternion via {@link Quaternion#conjugate}. The
	* quaternion is assumed to have unit length.
	*
	* @return {Quaternion} A reference to this quaternion.
	*/
	invert() {
		return this.conjugate();
	}
	/**
	* Returns the rotational conjugate of this quaternion. The conjugate of a
	* quaternion represents the same rotation in the opposite direction about
	* the rotational axis.
	*
	* @return {Quaternion} A reference to this quaternion.
	*/
	conjugate() {
		this._x *= -1;
		this._y *= -1;
		this._z *= -1;
		this._onChangeCallback();
		return this;
	}
	/**
	* Calculates the dot product of this quaternion and the given one.
	*
	* @param {Quaternion} v - The quaternion to compute the dot product with.
	* @return {number} The result of the dot product.
	*/
	dot(v) {
		return this._x * v._x + this._y * v._y + this._z * v._z + this._w * v._w;
	}
	/**
	* Computes the squared Euclidean length (straight-line length) of this quaternion,
	* considered as a 4 dimensional vector. This can be useful if you are comparing the
	* lengths of two quaternions, as this is a slightly more efficient calculation than
	* {@link Quaternion#length}.
	*
	* @return {number} The squared Euclidean length.
	*/
	lengthSq() {
		return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
	}
	/**
	* Computes the Euclidean length (straight-line length) of this quaternion,
	* considered as a 4 dimensional vector.
	*
	* @return {number} The Euclidean length.
	*/
	length() {
		return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
	}
	/**
	* Normalizes this quaternion - that is, calculated the quaternion that performs
	* the same rotation as this one, but has a length equal to `1`.
	*
	* @return {Quaternion} A reference to this quaternion.
	*/
	normalize() {
		let l = this.length();
		if (l === 0) {
			this._x = 0;
			this._y = 0;
			this._z = 0;
			this._w = 1;
		} else {
			l = 1 / l;
			this._x = this._x * l;
			this._y = this._y * l;
			this._z = this._z * l;
			this._w = this._w * l;
		}
		this._onChangeCallback();
		return this;
	}
	/**
	* Multiplies this quaternion by the given one.
	*
	* @param {Quaternion} q - The quaternion.
	* @return {Quaternion} A reference to this quaternion.
	*/
	multiply(q) {
		return this.multiplyQuaternions(this, q);
	}
	/**
	* Pre-multiplies this quaternion by the given one.
	*
	* @param {Quaternion} q - The quaternion.
	* @return {Quaternion} A reference to this quaternion.
	*/
	premultiply(q) {
		return this.multiplyQuaternions(q, this);
	}
	/**
	* Multiplies the given quaternions and stores the result in this instance.
	*
	* @param {Quaternion} a - The first quaternion.
	* @param {Quaternion} b - The second quaternion.
	* @return {Quaternion} A reference to this quaternion.
	*/
	multiplyQuaternions(a, b) {
		const qax = a._x, qay = a._y, qaz = a._z, qaw = a._w;
		const qbx = b._x, qby = b._y, qbz = b._z, qbw = b._w;
		this._x = qax * qbw + qaw * qbx + qay * qbz - qaz * qby;
		this._y = qay * qbw + qaw * qby + qaz * qbx - qax * qbz;
		this._z = qaz * qbw + qaw * qbz + qax * qby - qay * qbx;
		this._w = qaw * qbw - qax * qbx - qay * qby - qaz * qbz;
		this._onChangeCallback();
		return this;
	}
	/**
	* Performs a spherical linear interpolation between this quaternion and the target quaternion.
	*
	* @param {Quaternion} qb - The target quaternion.
	* @param {number} t - The interpolation factor. A value in the range `[0,1]` will interpolate. A value outside the range `[0,1]` will extrapolate.
	* @return {Quaternion} A reference to this quaternion.
	*/
	slerp(qb, t) {
		let x = qb._x, y = qb._y, z = qb._z, w = qb._w;
		let dot = this.dot(qb);
		if (dot < 0) {
			x = -x;
			y = -y;
			z = -z;
			w = -w;
			dot = -dot;
		}
		let s = 1 - t;
		if (dot < .9995) {
			const theta = Math.acos(dot);
			const sin = Math.sin(theta);
			s = Math.sin(s * theta) / sin;
			t = Math.sin(t * theta) / sin;
			this._x = this._x * s + x * t;
			this._y = this._y * s + y * t;
			this._z = this._z * s + z * t;
			this._w = this._w * s + w * t;
			this._onChangeCallback();
		} else {
			this._x = this._x * s + x * t;
			this._y = this._y * s + y * t;
			this._z = this._z * s + z * t;
			this._w = this._w * s + w * t;
			this.normalize();
		}
		return this;
	}
	/**
	* Performs a spherical linear interpolation between the given quaternions
	* and stores the result in this quaternion.
	*
	* @param {Quaternion} qa - The source quaternion.
	* @param {Quaternion} qb - The target quaternion.
	* @param {number} t - The interpolation factor in the closed interval `[0, 1]`.
	* @return {Quaternion} A reference to this quaternion.
	*/
	slerpQuaternions(qa, qb, t) {
		return this.copy(qa).slerp(qb, t);
	}
	/**
	* Sets this quaternion to a uniformly random, normalized quaternion.
	*
	* @return {Quaternion} A reference to this quaternion.
	*/
	random() {
		const theta1 = 2 * Math.PI * Math.random();
		const theta2 = 2 * Math.PI * Math.random();
		const x0 = Math.random();
		const r1 = Math.sqrt(1 - x0);
		const r2 = Math.sqrt(x0);
		return this.set(r1 * Math.sin(theta1), r1 * Math.cos(theta1), r2 * Math.sin(theta2), r2 * Math.cos(theta2));
	}
	/**
	* Returns `true` if this quaternion is equal with the given one.
	*
	* @param {Quaternion} quaternion - The quaternion to test for equality.
	* @return {boolean} Whether this quaternion is equal with the given one.
	*/
	equals(quaternion) {
		return quaternion._x === this._x && quaternion._y === this._y && quaternion._z === this._z && quaternion._w === this._w;
	}
	/**
	* Sets this quaternion's components from the given array.
	*
	* @param {Array<number>} array - An array holding the quaternion component values.
	* @param {number} [offset=0] - The offset into the array.
	* @return {Quaternion} A reference to this quaternion.
	*/
	fromArray(array, offset = 0) {
		this._x = array[offset];
		this._y = array[offset + 1];
		this._z = array[offset + 2];
		this._w = array[offset + 3];
		this._onChangeCallback();
		return this;
	}
	/**
	* Writes the components of this quaternion to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the quaternion components.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The quaternion components.
	*/
	toArray(array = [], offset = 0) {
		array[offset] = this._x;
		array[offset + 1] = this._y;
		array[offset + 2] = this._z;
		array[offset + 3] = this._w;
		return array;
	}
	/**
	* Sets the components of this quaternion from the given buffer attribute.
	*
	* @param {BufferAttribute} attribute - The buffer attribute holding quaternion data.
	* @param {number} index - The index into the attribute.
	* @return {Quaternion} A reference to this quaternion.
	*/
	fromBufferAttribute(attribute, index) {
		this._x = attribute.getX(index);
		this._y = attribute.getY(index);
		this._z = attribute.getZ(index);
		this._w = attribute.getW(index);
		this._onChangeCallback();
		return this;
	}
	/**
	* This methods defines the serialization result of this class. Returns the
	* numerical elements of this quaternion in an array of format `[x, y, z, w]`.
	*
	* @return {Array<number>} The serialized quaternion.
	*/
	toJSON() {
		return this.toArray();
	}
	_onChange(callback) {
		this._onChangeCallback = callback;
		return this;
	}
	_onChangeCallback() {}
	*[Symbol.iterator]() {
		yield this._x;
		yield this._y;
		yield this._z;
		yield this._w;
	}
};
/**
* Class representing a 3D vector. A 3D vector is an ordered triplet of numbers
* (labeled x, y and z), which can be used to represent a number of things, such as:
*
* - A point in 3D space.
* - A direction and length in 3D space. In three.js the length will
* always be the Euclidean distance(straight-line distance) from `(0, 0, 0)` to `(x, y, z)`
* and the direction is also measured from `(0, 0, 0)` towards `(x, y, z)`.
* - Any arbitrary ordered triplet of numbers.
*
* There are other things a 3D vector can be used to represent, such as
* momentum vectors and so on, however these are the most
* common uses in three.js.
*
* Iterating through a vector instance will yield its components `(x, y, z)` in
* the corresponding order.
* ```js
* const a = new THREE.Vector3( 0, 1, 0 );
*
* //no arguments; will be initialised to (0, 0, 0)
* const b = new THREE.Vector3( );
*
* const d = a.distanceTo( b );
* ```
*/
var Vector3 = class Vector3 {
	static {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		Vector3.prototype.isVector3 = true;
	}
	/**
	* Constructs a new 3D vector.
	*
	* @param {number} [x=0] - The x value of this vector.
	* @param {number} [y=0] - The y value of this vector.
	* @param {number} [z=0] - The z value of this vector.
	*/
	constructor(x = 0, y = 0, z = 0) {
		/**
		* The x value of this vector.
		*
		* @type {number}
		*/
		this.x = x;
		/**
		* The y value of this vector.
		*
		* @type {number}
		*/
		this.y = y;
		/**
		* The z value of this vector.
		*
		* @type {number}
		*/
		this.z = z;
	}
	/**
	* Sets the vector components.
	*
	* @param {number} x - The value of the x component.
	* @param {number} y - The value of the y component.
	* @param {number} z - The value of the z component.
	* @return {Vector3} A reference to this vector.
	*/
	set(x, y, z) {
		if (z === void 0) z = this.z;
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	/**
	* Sets the vector components to the same value.
	*
	* @param {number} scalar - The value to set for all vector components.
	* @return {Vector3} A reference to this vector.
	*/
	setScalar(scalar) {
		this.x = scalar;
		this.y = scalar;
		this.z = scalar;
		return this;
	}
	/**
	* Sets the vector's x component to the given value.
	*
	* @param {number} x - The value to set.
	* @return {Vector3} A reference to this vector.
	*/
	setX(x) {
		this.x = x;
		return this;
	}
	/**
	* Sets the vector's y component to the given value.
	*
	* @param {number} y - The value to set.
	* @return {Vector3} A reference to this vector.
	*/
	setY(y) {
		this.y = y;
		return this;
	}
	/**
	* Sets the vector's z component to the given value.
	*
	* @param {number} z - The value to set.
	* @return {Vector3} A reference to this vector.
	*/
	setZ(z) {
		this.z = z;
		return this;
	}
	/**
	* Allows to set a vector component with an index.
	*
	* @param {number} index - The component index. `0` equals to x, `1` equals to y, `2` equals to z.
	* @param {number} value - The value to set.
	* @return {Vector3} A reference to this vector.
	*/
	setComponent(index, value) {
		switch (index) {
			case 0:
				this.x = value;
				break;
			case 1:
				this.y = value;
				break;
			case 2:
				this.z = value;
				break;
			default: throw new Error("THREE.Vector3: index is out of range: " + index);
		}
		return this;
	}
	/**
	* Returns the value of the vector component which matches the given index.
	*
	* @param {number} index - The component index. `0` equals to x, `1` equals to y, `2` equals to z.
	* @return {number} A vector component value.
	*/
	getComponent(index) {
		switch (index) {
			case 0: return this.x;
			case 1: return this.y;
			case 2: return this.z;
			default: throw new Error("THREE.Vector3: index is out of range: " + index);
		}
	}
	/**
	* Returns a new vector with copied values from this instance.
	*
	* @return {Vector3} A clone of this instance.
	*/
	clone() {
		return new this.constructor(this.x, this.y, this.z);
	}
	/**
	* Copies the values of the given vector to this instance.
	*
	* @param {Vector3} v - The vector to copy.
	* @return {Vector3} A reference to this vector.
	*/
	copy(v) {
		this.x = v.x;
		this.y = v.y;
		this.z = v.z;
		return this;
	}
	/**
	* Adds the given vector to this instance.
	*
	* @param {Vector3} v - The vector to add.
	* @return {Vector3} A reference to this vector.
	*/
	add(v) {
		this.x += v.x;
		this.y += v.y;
		this.z += v.z;
		return this;
	}
	/**
	* Adds the given scalar value to all components of this instance.
	*
	* @param {number} s - The scalar to add.
	* @return {Vector3} A reference to this vector.
	*/
	addScalar(s) {
		this.x += s;
		this.y += s;
		this.z += s;
		return this;
	}
	/**
	* Adds the given vectors and stores the result in this instance.
	*
	* @param {Vector3} a - The first vector.
	* @param {Vector3} b - The second vector.
	* @return {Vector3} A reference to this vector.
	*/
	addVectors(a, b) {
		this.x = a.x + b.x;
		this.y = a.y + b.y;
		this.z = a.z + b.z;
		return this;
	}
	/**
	* Adds the given vector scaled by the given factor to this instance.
	*
	* @param {Vector3|Vector4} v - The vector.
	* @param {number} s - The factor that scales `v`.
	* @return {Vector3} A reference to this vector.
	*/
	addScaledVector(v, s) {
		this.x += v.x * s;
		this.y += v.y * s;
		this.z += v.z * s;
		return this;
	}
	/**
	* Subtracts the given vector from this instance.
	*
	* @param {Vector3} v - The vector to subtract.
	* @return {Vector3} A reference to this vector.
	*/
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		this.z -= v.z;
		return this;
	}
	/**
	* Subtracts the given scalar value from all components of this instance.
	*
	* @param {number} s - The scalar to subtract.
	* @return {Vector3} A reference to this vector.
	*/
	subScalar(s) {
		this.x -= s;
		this.y -= s;
		this.z -= s;
		return this;
	}
	/**
	* Subtracts the given vectors and stores the result in this instance.
	*
	* @param {Vector3} a - The first vector.
	* @param {Vector3} b - The second vector.
	* @return {Vector3} A reference to this vector.
	*/
	subVectors(a, b) {
		this.x = a.x - b.x;
		this.y = a.y - b.y;
		this.z = a.z - b.z;
		return this;
	}
	/**
	* Multiplies the given vector with this instance.
	*
	* @param {Vector3} v - The vector to multiply.
	* @return {Vector3} A reference to this vector.
	*/
	multiply(v) {
		this.x *= v.x;
		this.y *= v.y;
		this.z *= v.z;
		return this;
	}
	/**
	* Multiplies the given scalar value with all components of this instance.
	*
	* @param {number} scalar - The scalar to multiply.
	* @return {Vector3} A reference to this vector.
	*/
	multiplyScalar(scalar) {
		this.x *= scalar;
		this.y *= scalar;
		this.z *= scalar;
		return this;
	}
	/**
	* Multiplies the given vectors and stores the result in this instance.
	*
	* @param {Vector3} a - The first vector.
	* @param {Vector3} b - The second vector.
	* @return {Vector3} A reference to this vector.
	*/
	multiplyVectors(a, b) {
		this.x = a.x * b.x;
		this.y = a.y * b.y;
		this.z = a.z * b.z;
		return this;
	}
	/**
	* Applies the given Euler rotation to this vector.
	*
	* @param {Euler} euler - The Euler angles.
	* @return {Vector3} A reference to this vector.
	*/
	applyEuler(euler) {
		return this.applyQuaternion(_quaternion$5.setFromEuler(euler));
	}
	/**
	* Applies a rotation specified by an axis and an angle to this vector.
	*
	* @param {Vector3} axis - A normalized vector representing the rotation axis.
	* @param {number} angle - The angle in radians.
	* @return {Vector3} A reference to this vector.
	*/
	applyAxisAngle(axis, angle) {
		return this.applyQuaternion(_quaternion$5.setFromAxisAngle(axis, angle));
	}
	/**
	* Multiplies this vector with the given 3x3 matrix.
	*
	* @param {Matrix3} m - The 3x3 matrix.
	* @return {Vector3} A reference to this vector.
	*/
	applyMatrix3(m) {
		const x = this.x, y = this.y, z = this.z;
		const e = m.elements;
		this.x = e[0] * x + e[3] * y + e[6] * z;
		this.y = e[1] * x + e[4] * y + e[7] * z;
		this.z = e[2] * x + e[5] * y + e[8] * z;
		return this;
	}
	/**
	* Multiplies this vector by the given normal matrix and normalizes
	* the result.
	*
	* @param {Matrix3} m - The normal matrix.
	* @return {Vector3} A reference to this vector.
	*/
	applyNormalMatrix(m) {
		return this.applyMatrix3(m).normalize();
	}
	/**
	* Multiplies this vector (with an implicit 1 in the 4th dimension) by m, and
	* divides by perspective.
	*
	* @param {Matrix4} m - The matrix to apply.
	* @return {Vector3} A reference to this vector.
	*/
	applyMatrix4(m) {
		const x = this.x, y = this.y, z = this.z;
		const e = m.elements;
		const w = 1 / (e[3] * x + e[7] * y + e[11] * z + e[15]);
		this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) * w;
		this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) * w;
		this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) * w;
		return this;
	}
	/**
	* Applies the given Quaternion to this vector.
	*
	* @param {Quaternion} q - The Quaternion.
	* @return {Vector3} A reference to this vector.
	*/
	applyQuaternion(q) {
		const vx = this.x, vy = this.y, vz = this.z;
		const qx = q.x, qy = q.y, qz = q.z, qw = q.w;
		const tx = 2 * (qy * vz - qz * vy);
		const ty = 2 * (qz * vx - qx * vz);
		const tz = 2 * (qx * vy - qy * vx);
		this.x = vx + qw * tx + qy * tz - qz * ty;
		this.y = vy + qw * ty + qz * tx - qx * tz;
		this.z = vz + qw * tz + qx * ty - qy * tx;
		return this;
	}
	/**
	* Projects this vector from world space into the camera's normalized
	* device coordinate (NDC) space.
	*
	* @param {Camera} camera - The camera.
	* @return {Vector3} A reference to this vector.
	*/
	project(camera) {
		return this.applyMatrix4(camera.matrixWorldInverse).applyMatrix4(camera.projectionMatrix);
	}
	/**
	* Unprojects this vector from the camera's normalized device coordinate (NDC)
	* space into world space.
	*
	* @param {Camera} camera - The camera.
	* @return {Vector3} A reference to this vector.
	*/
	unproject(camera) {
		return this.applyMatrix4(camera.projectionMatrixInverse).applyMatrix4(camera.matrixWorld);
	}
	/**
	* Transforms this vector by the upper left 3x3 sub-matrix of the given 4x4 matrix,
	* and normalizes the result.
	*
	* @param {Matrix4} m - The matrix.
	* @return {Vector3} A reference to this vector.
	*/
	transformDirection(m) {
		const x = this.x, y = this.y, z = this.z;
		const e = m.elements;
		this.x = e[0] * x + e[4] * y + e[8] * z;
		this.y = e[1] * x + e[5] * y + e[9] * z;
		this.z = e[2] * x + e[6] * y + e[10] * z;
		return this.normalize();
	}
	/**
	* Divides this instance by the given vector.
	*
	* @param {Vector3} v - The vector to divide.
	* @return {Vector3} A reference to this vector.
	*/
	divide(v) {
		this.x /= v.x;
		this.y /= v.y;
		this.z /= v.z;
		return this;
	}
	/**
	* Divides this vector by the given scalar.
	*
	* @param {number} scalar - The scalar to divide.
	* @return {Vector3} A reference to this vector.
	*/
	divideScalar(scalar) {
		return this.multiplyScalar(1 / scalar);
	}
	/**
	* If this vector's x, y or z value is greater than the given vector's x, y or z
	* value, replace that value with the corresponding min value.
	*
	* @param {Vector3} v - The vector.
	* @return {Vector3} A reference to this vector.
	*/
	min(v) {
		this.x = Math.min(this.x, v.x);
		this.y = Math.min(this.y, v.y);
		this.z = Math.min(this.z, v.z);
		return this;
	}
	/**
	* If this vector's x, y or z value is less than the given vector's x, y or z
	* value, replace that value with the corresponding max value.
	*
	* @param {Vector3} v - The vector.
	* @return {Vector3} A reference to this vector.
	*/
	max(v) {
		this.x = Math.max(this.x, v.x);
		this.y = Math.max(this.y, v.y);
		this.z = Math.max(this.z, v.z);
		return this;
	}
	/**
	* If this vector's x, y or z value is greater than the max vector's x, y or z
	* value, it is replaced by the corresponding value.
	* If this vector's x, y or z value is less than the min vector's x, y or z value,
	* it is replaced by the corresponding value.
	*
	* @param {Vector3} min - The minimum x, y and z values.
	* @param {Vector3} max - The maximum x, y and z values in the desired range.
	* @return {Vector3} A reference to this vector.
	*/
	clamp(min, max) {
		this.x = clamp$1(this.x, min.x, max.x);
		this.y = clamp$1(this.y, min.y, max.y);
		this.z = clamp$1(this.z, min.z, max.z);
		return this;
	}
	/**
	* If this vector's x, y or z values are greater than the max value, they are
	* replaced by the max value.
	* If this vector's x, y or z values are less than the min value, they are
	* replaced by the min value.
	*
	* @param {number} minVal - The minimum value the components will be clamped to.
	* @param {number} maxVal - The maximum value the components will be clamped to.
	* @return {Vector3} A reference to this vector.
	*/
	clampScalar(minVal, maxVal) {
		this.x = clamp$1(this.x, minVal, maxVal);
		this.y = clamp$1(this.y, minVal, maxVal);
		this.z = clamp$1(this.z, minVal, maxVal);
		return this;
	}
	/**
	* If this vector's length is greater than the max value, it is replaced by
	* the max value.
	* If this vector's length is less than the min value, it is replaced by the
	* min value.
	*
	* @param {number} min - The minimum value the vector length will be clamped to.
	* @param {number} max - The maximum value the vector length will be clamped to.
	* @return {Vector3} A reference to this vector.
	*/
	clampLength(min, max) {
		const length = this.length();
		return this.divideScalar(length || 1).multiplyScalar(clamp$1(length, min, max));
	}
	/**
	* The components of this vector are rounded down to the nearest integer value.
	*
	* @return {Vector3} A reference to this vector.
	*/
	floor() {
		this.x = Math.floor(this.x);
		this.y = Math.floor(this.y);
		this.z = Math.floor(this.z);
		return this;
	}
	/**
	* The components of this vector are rounded up to the nearest integer value.
	*
	* @return {Vector3} A reference to this vector.
	*/
	ceil() {
		this.x = Math.ceil(this.x);
		this.y = Math.ceil(this.y);
		this.z = Math.ceil(this.z);
		return this;
	}
	/**
	* The components of this vector are rounded to the nearest integer value
	*
	* @return {Vector3} A reference to this vector.
	*/
	round() {
		this.x = Math.round(this.x);
		this.y = Math.round(this.y);
		this.z = Math.round(this.z);
		return this;
	}
	/**
	* The components of this vector are rounded towards zero (up if negative,
	* down if positive) to an integer value.
	*
	* @return {Vector3} A reference to this vector.
	*/
	roundToZero() {
		this.x = Math.trunc(this.x);
		this.y = Math.trunc(this.y);
		this.z = Math.trunc(this.z);
		return this;
	}
	/**
	* Inverts this vector - i.e. sets x = -x, y = -y and z = -z.
	*
	* @return {Vector3} A reference to this vector.
	*/
	negate() {
		this.x = -this.x;
		this.y = -this.y;
		this.z = -this.z;
		return this;
	}
	/**
	* Calculates the dot product of the given vector with this instance.
	*
	* @param {Vector3} v - The vector to compute the dot product with.
	* @return {number} The result of the dot product.
	*/
	dot(v) {
		return this.x * v.x + this.y * v.y + this.z * v.z;
	}
	/**
	* Computes the square of the Euclidean length (straight-line length) from
	* (0, 0, 0) to (x, y, z). If you are comparing the lengths of vectors, you should
	* compare the length squared instead as it is slightly more efficient to calculate.
	*
	* @return {number} The square length of this vector.
	*/
	lengthSq() {
		return this.x * this.x + this.y * this.y + this.z * this.z;
	}
	/**
	* Computes the  Euclidean length (straight-line length) from (0, 0, 0) to (x, y, z).
	*
	* @return {number} The length of this vector.
	*/
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	}
	/**
	* Computes the Manhattan length of this vector.
	*
	* @return {number} The length of this vector.
	*/
	manhattanLength() {
		return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
	}
	/**
	* Converts this vector to a unit vector - that is, sets it equal to a vector
	* with the same direction as this one, but with a vector length of `1`.
	*
	* @return {Vector3} A reference to this vector.
	*/
	normalize() {
		return this.divideScalar(this.length() || 1);
	}
	/**
	* Sets this vector to a vector with the same direction as this one, but
	* with the specified length.
	*
	* @param {number} length - The new length of this vector.
	* @return {Vector3} A reference to this vector.
	*/
	setLength(length) {
		return this.normalize().multiplyScalar(length);
	}
	/**
	* Linearly interpolates between the given vector and this instance, where
	* alpha is the percent distance along the line - alpha = 0 will be this
	* vector, and alpha = 1 will be the given one.
	*
	* @param {Vector3} v - The vector to interpolate towards.
	* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
	* @return {Vector3} A reference to this vector.
	*/
	lerp(v, alpha) {
		this.x += (v.x - this.x) * alpha;
		this.y += (v.y - this.y) * alpha;
		this.z += (v.z - this.z) * alpha;
		return this;
	}
	/**
	* Linearly interpolates between the given vectors, where alpha is the percent
	* distance along the line - alpha = 0 will be first vector, and alpha = 1 will
	* be the second one. The result is stored in this instance.
	*
	* @param {Vector3} v1 - The first vector.
	* @param {Vector3} v2 - The second vector.
	* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
	* @return {Vector3} A reference to this vector.
	*/
	lerpVectors(v1, v2, alpha) {
		this.x = v1.x + (v2.x - v1.x) * alpha;
		this.y = v1.y + (v2.y - v1.y) * alpha;
		this.z = v1.z + (v2.z - v1.z) * alpha;
		return this;
	}
	/**
	* Calculates the cross product of the given vector with this instance.
	*
	* @param {Vector3} v - The vector to compute the cross product with.
	* @return {Vector3} The result of the cross product.
	*/
	cross(v) {
		return this.crossVectors(this, v);
	}
	/**
	* Calculates the cross product of the given vectors and stores the result
	* in this instance.
	*
	* @param {Vector3} a - The first vector.
	* @param {Vector3} b - The second vector.
	* @return {Vector3} A reference to this vector.
	*/
	crossVectors(a, b) {
		const ax = a.x, ay = a.y, az = a.z;
		const bx = b.x, by = b.y, bz = b.z;
		this.x = ay * bz - az * by;
		this.y = az * bx - ax * bz;
		this.z = ax * by - ay * bx;
		return this;
	}
	/**
	* Projects this vector onto the given one.
	*
	* @param {Vector3} v - The vector to project to.
	* @return {Vector3} A reference to this vector.
	*/
	projectOnVector(v) {
		const denominator = v.lengthSq();
		if (denominator === 0) return this.set(0, 0, 0);
		const scalar = v.dot(this) / denominator;
		return this.copy(v).multiplyScalar(scalar);
	}
	/**
	* Projects this vector onto a plane by subtracting this
	* vector projected onto the plane's normal from this vector.
	*
	* @param {Vector3} planeNormal - The plane normal.
	* @return {Vector3} A reference to this vector.
	*/
	projectOnPlane(planeNormal) {
		_vector$c.copy(this).projectOnVector(planeNormal);
		return this.sub(_vector$c);
	}
	/**
	* Reflects this vector off a plane orthogonal to the given normal vector.
	*
	* @param {Vector3} normal - The (normalized) normal vector.
	* @return {Vector3} A reference to this vector.
	*/
	reflect(normal) {
		return this.sub(_vector$c.copy(normal).multiplyScalar(2 * this.dot(normal)));
	}
	/**
	* Returns the angle between the given vector and this instance in radians.
	*
	* @param {Vector3} v - The vector to compute the angle with.
	* @return {number} The angle in radians.
	*/
	angleTo(v) {
		const denominator = Math.sqrt(this.lengthSq() * v.lengthSq());
		if (denominator === 0) return Math.PI / 2;
		const theta = this.dot(v) / denominator;
		return Math.acos(clamp$1(theta, -1, 1));
	}
	/**
	* Computes the distance from the given vector to this instance.
	*
	* @param {Vector3} v - The vector to compute the distance to.
	* @return {number} The distance.
	*/
	distanceTo(v) {
		return Math.sqrt(this.distanceToSquared(v));
	}
	/**
	* Computes the squared distance from the given vector to this instance.
	* If you are just comparing the distance with another distance, you should compare
	* the distance squared instead as it is slightly more efficient to calculate.
	*
	* @param {Vector3} v - The vector to compute the squared distance to.
	* @return {number} The squared distance.
	*/
	distanceToSquared(v) {
		const dx = this.x - v.x, dy = this.y - v.y, dz = this.z - v.z;
		return dx * dx + dy * dy + dz * dz;
	}
	/**
	* Computes the Manhattan distance from the given vector to this instance.
	*
	* @param {Vector3} v - The vector to compute the Manhattan distance to.
	* @return {number} The Manhattan distance.
	*/
	manhattanDistanceTo(v) {
		return Math.abs(this.x - v.x) + Math.abs(this.y - v.y) + Math.abs(this.z - v.z);
	}
	/**
	* Sets the vector components from the given spherical coordinates.
	*
	* @param {Spherical} s - The spherical coordinates.
	* @return {Vector3} A reference to this vector.
	*/
	setFromSpherical(s) {
		return this.setFromSphericalCoords(s.radius, s.phi, s.theta);
	}
	/**
	* Sets the vector components from the given spherical coordinates.
	*
	* @param {number} radius - The radius.
	* @param {number} phi - The phi angle in radians.
	* @param {number} theta - The theta angle in radians.
	* @return {Vector3} A reference to this vector.
	*/
	setFromSphericalCoords(radius, phi, theta) {
		const sinPhiRadius = Math.sin(phi) * radius;
		this.x = sinPhiRadius * Math.sin(theta);
		this.y = Math.cos(phi) * radius;
		this.z = sinPhiRadius * Math.cos(theta);
		return this;
	}
	/**
	* Sets the vector components from the given cylindrical coordinates.
	*
	* @param {Cylindrical} c - The cylindrical coordinates.
	* @return {Vector3} A reference to this vector.
	*/
	setFromCylindrical(c) {
		return this.setFromCylindricalCoords(c.radius, c.theta, c.y);
	}
	/**
	* Sets the vector components from the given cylindrical coordinates.
	*
	* @param {number} radius - The radius.
	* @param {number} theta - The theta angle in radians.
	* @param {number} y - The y value.
	* @return {Vector3} A reference to this vector.
	*/
	setFromCylindricalCoords(radius, theta, y) {
		this.x = radius * Math.sin(theta);
		this.y = y;
		this.z = radius * Math.cos(theta);
		return this;
	}
	/**
	* Sets the vector components to the position elements of the
	* given transformation matrix.
	*
	* @param {Matrix4} m - The 4x4 matrix.
	* @return {Vector3} A reference to this vector.
	*/
	setFromMatrixPosition(m) {
		const e = m.elements;
		this.x = e[12];
		this.y = e[13];
		this.z = e[14];
		return this;
	}
	/**
	* Sets the vector components to the scale elements of the
	* given transformation matrix.
	*
	* @param {Matrix4} m - The 4x4 matrix.
	* @return {Vector3} A reference to this vector.
	*/
	setFromMatrixScale(m) {
		const sx = this.setFromMatrixColumn(m, 0).length();
		const sy = this.setFromMatrixColumn(m, 1).length();
		const sz = this.setFromMatrixColumn(m, 2).length();
		this.x = sx;
		this.y = sy;
		this.z = sz;
		return this;
	}
	/**
	* Sets the vector components from the specified matrix column.
	*
	* @param {Matrix4} m - The 4x4 matrix.
	* @param {number} index - The column index.
	* @return {Vector3} A reference to this vector.
	*/
	setFromMatrixColumn(m, index) {
		return this.fromArray(m.elements, index * 4);
	}
	/**
	* Sets the vector components from the specified matrix column.
	*
	* @param {Matrix3} m - The 3x3 matrix.
	* @param {number} index - The column index.
	* @return {Vector3} A reference to this vector.
	*/
	setFromMatrix3Column(m, index) {
		return this.fromArray(m.elements, index * 3);
	}
	/**
	* Sets the vector components from the given Euler angles.
	*
	* @param {Euler} e - The Euler angles to set.
	* @return {Vector3} A reference to this vector.
	*/
	setFromEuler(e) {
		this.x = e._x;
		this.y = e._y;
		this.z = e._z;
		return this;
	}
	/**
	* Sets the vector components from the RGB components of the
	* given color.
	*
	* @param {Color} c - The color to set.
	* @return {Vector3} A reference to this vector.
	*/
	setFromColor(c) {
		this.x = c.r;
		this.y = c.g;
		this.z = c.b;
		return this;
	}
	/**
	* Returns `true` if this vector is equal with the given one.
	*
	* @param {Vector3} v - The vector to test for equality.
	* @return {boolean} Whether this vector is equal with the given one.
	*/
	equals(v) {
		return v.x === this.x && v.y === this.y && v.z === this.z;
	}
	/**
	* Sets this vector's x value to be `array[ offset ]`, y value to be `array[ offset + 1 ]`
	* and z value to be `array[ offset + 2 ]`.
	*
	* @param {Array<number>} array - An array holding the vector component values.
	* @param {number} [offset=0] - The offset into the array.
	* @return {Vector3} A reference to this vector.
	*/
	fromArray(array, offset = 0) {
		this.x = array[offset];
		this.y = array[offset + 1];
		this.z = array[offset + 2];
		return this;
	}
	/**
	* Writes the components of this vector to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the vector components.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The vector components.
	*/
	toArray(array = [], offset = 0) {
		array[offset] = this.x;
		array[offset + 1] = this.y;
		array[offset + 2] = this.z;
		return array;
	}
	/**
	* Sets the components of this vector from the given buffer attribute.
	*
	* @param {BufferAttribute} attribute - The buffer attribute holding vector data.
	* @param {number} index - The index into the attribute.
	* @return {Vector3} A reference to this vector.
	*/
	fromBufferAttribute(attribute, index) {
		this.x = attribute.getX(index);
		this.y = attribute.getY(index);
		this.z = attribute.getZ(index);
		return this;
	}
	/**
	* Sets each component of this vector to a pseudo-random value between `0` and
	* `1`, excluding `1`.
	*
	* @return {Vector3} A reference to this vector.
	*/
	random() {
		this.x = Math.random();
		this.y = Math.random();
		this.z = Math.random();
		return this;
	}
	/**
	* Sets this vector to a uniformly random point on a unit sphere.
	*
	* @return {Vector3} A reference to this vector.
	*/
	randomDirection() {
		const theta = Math.random() * Math.PI * 2;
		const u = Math.random() * 2 - 1;
		const c = Math.sqrt(1 - u * u);
		this.x = c * Math.cos(theta);
		this.y = u;
		this.z = c * Math.sin(theta);
		return this;
	}
	*[Symbol.iterator]() {
		yield this.x;
		yield this.y;
		yield this.z;
	}
};
const _vector$c = /*@__PURE__*/ new Vector3();
const _quaternion$5 = /*@__PURE__*/ new Quaternion();
/**
* Represents a 3x3 matrix.
*
* A Note on Row-Major and Column-Major Ordering:
*
* The constructor and {@link Matrix3#set} method take arguments in
* [row-major](https://en.wikipedia.org/wiki/Row-_and_column-major_order#Column-major_order)
* order, while internally they are stored in the {@link Matrix3#elements} array in column-major order.
* This means that calling:
* ```js
* const m = new THREE.Matrix();
* m.set( 11, 12, 13,
*        21, 22, 23,
*        31, 32, 33 );
* ```
* will result in the elements array containing:
* ```js
* m.elements = [ 11, 21, 31,
*                12, 22, 32,
*                13, 23, 33 ];
* ```
* and internally all calculations are performed using column-major ordering.
* However, as the actual ordering makes no difference mathematically and
* most people are used to thinking about matrices in row-major order, the
* three.js documentation shows matrices in row-major order. Just bear in
* mind that if you are reading the source code, you'll have to take the
* transpose of any matrices outlined here to make sense of the calculations.
*/
var Matrix3 = class Matrix3 {
	static {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		Matrix3.prototype.isMatrix3 = true;
	}
	/**
	* Constructs a new 3x3 matrix. The arguments are supposed to be
	* in row-major order. If no arguments are provided, the constructor
	* initializes the matrix as an identity matrix.
	*
	* @param {number} [n11] - 1-1 matrix element.
	* @param {number} [n12] - 1-2 matrix element.
	* @param {number} [n13] - 1-3 matrix element.
	* @param {number} [n21] - 2-1 matrix element.
	* @param {number} [n22] - 2-2 matrix element.
	* @param {number} [n23] - 2-3 matrix element.
	* @param {number} [n31] - 3-1 matrix element.
	* @param {number} [n32] - 3-2 matrix element.
	* @param {number} [n33] - 3-3 matrix element.
	*/
	constructor(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
		/**
		* A column-major list of matrix values.
		*
		* @type {Array<number>}
		*/
		this.elements = [
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		];
		if (n11 !== void 0) this.set(n11, n12, n13, n21, n22, n23, n31, n32, n33);
	}
	/**
	* Sets the elements of the matrix.The arguments are supposed to be
	* in row-major order.
	*
	* @param {number} [n11] - 1-1 matrix element.
	* @param {number} [n12] - 1-2 matrix element.
	* @param {number} [n13] - 1-3 matrix element.
	* @param {number} [n21] - 2-1 matrix element.
	* @param {number} [n22] - 2-2 matrix element.
	* @param {number} [n23] - 2-3 matrix element.
	* @param {number} [n31] - 3-1 matrix element.
	* @param {number} [n32] - 3-2 matrix element.
	* @param {number} [n33] - 3-3 matrix element.
	* @return {Matrix3} A reference to this matrix.
	*/
	set(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
		const te = this.elements;
		te[0] = n11;
		te[1] = n21;
		te[2] = n31;
		te[3] = n12;
		te[4] = n22;
		te[5] = n32;
		te[6] = n13;
		te[7] = n23;
		te[8] = n33;
		return this;
	}
	/**
	* Sets this matrix to the 3x3 identity matrix.
	*
	* @return {Matrix3} A reference to this matrix.
	*/
	identity() {
		this.set(1, 0, 0, 0, 1, 0, 0, 0, 1);
		return this;
	}
	/**
	* Copies the values of the given matrix to this instance.
	*
	* @param {Matrix3} m - The matrix to copy.
	* @return {Matrix3} A reference to this matrix.
	*/
	copy(m) {
		const te = this.elements;
		const me = m.elements;
		te[0] = me[0];
		te[1] = me[1];
		te[2] = me[2];
		te[3] = me[3];
		te[4] = me[4];
		te[5] = me[5];
		te[6] = me[6];
		te[7] = me[7];
		te[8] = me[8];
		return this;
	}
	/**
	* Extracts the basis of this matrix into the three axis vectors provided.
	*
	* @param {Vector3} xAxis - The basis's x axis.
	* @param {Vector3} yAxis - The basis's y axis.
	* @param {Vector3} zAxis - The basis's z axis.
	* @return {Matrix3} A reference to this matrix.
	*/
	extractBasis(xAxis, yAxis, zAxis) {
		xAxis.setFromMatrix3Column(this, 0);
		yAxis.setFromMatrix3Column(this, 1);
		zAxis.setFromMatrix3Column(this, 2);
		return this;
	}
	/**
	* Set this matrix to the upper 3x3 matrix of the given 4x4 matrix.
	*
	* @param {Matrix4} m - The 4x4 matrix.
	* @return {Matrix3} A reference to this matrix.
	*/
	setFromMatrix4(m) {
		const me = m.elements;
		this.set(me[0], me[4], me[8], me[1], me[5], me[9], me[2], me[6], me[10]);
		return this;
	}
	/**
	* Post-multiplies this matrix by the given 3x3 matrix.
	*
	* @param {Matrix3} m - The matrix to multiply with.
	* @return {Matrix3} A reference to this matrix.
	*/
	multiply(m) {
		return this.multiplyMatrices(this, m);
	}
	/**
	* Pre-multiplies this matrix by the given 3x3 matrix.
	*
	* @param {Matrix3} m - The matrix to multiply with.
	* @return {Matrix3} A reference to this matrix.
	*/
	premultiply(m) {
		return this.multiplyMatrices(m, this);
	}
	/**
	* Multiples the given 3x3 matrices and stores the result
	* in this matrix.
	*
	* @param {Matrix3} a - The first matrix.
	* @param {Matrix3} b - The second matrix.
	* @return {Matrix3} A reference to this matrix.
	*/
	multiplyMatrices(a, b) {
		const ae = a.elements;
		const be = b.elements;
		const te = this.elements;
		const a11 = ae[0], a12 = ae[3], a13 = ae[6];
		const a21 = ae[1], a22 = ae[4], a23 = ae[7];
		const a31 = ae[2], a32 = ae[5], a33 = ae[8];
		const b11 = be[0], b12 = be[3], b13 = be[6];
		const b21 = be[1], b22 = be[4], b23 = be[7];
		const b31 = be[2], b32 = be[5], b33 = be[8];
		te[0] = a11 * b11 + a12 * b21 + a13 * b31;
		te[3] = a11 * b12 + a12 * b22 + a13 * b32;
		te[6] = a11 * b13 + a12 * b23 + a13 * b33;
		te[1] = a21 * b11 + a22 * b21 + a23 * b31;
		te[4] = a21 * b12 + a22 * b22 + a23 * b32;
		te[7] = a21 * b13 + a22 * b23 + a23 * b33;
		te[2] = a31 * b11 + a32 * b21 + a33 * b31;
		te[5] = a31 * b12 + a32 * b22 + a33 * b32;
		te[8] = a31 * b13 + a32 * b23 + a33 * b33;
		return this;
	}
	/**
	* Multiplies every component of the matrix by the given scalar.
	*
	* @param {number} s - The scalar.
	* @return {Matrix3} A reference to this matrix.
	*/
	multiplyScalar(s) {
		const te = this.elements;
		te[0] *= s;
		te[3] *= s;
		te[6] *= s;
		te[1] *= s;
		te[4] *= s;
		te[7] *= s;
		te[2] *= s;
		te[5] *= s;
		te[8] *= s;
		return this;
	}
	/**
	* Computes and returns the determinant of this matrix.
	*
	* @return {number} The determinant.
	*/
	determinant() {
		const te = this.elements;
		const a = te[0], b = te[1], c = te[2], d = te[3], e = te[4], f = te[5], g = te[6], h = te[7], i = te[8];
		return a * e * i - a * f * h - b * d * i + b * f * g + c * d * h - c * e * g;
	}
	/**
	* Inverts this matrix, using the [analytic method](https://en.wikipedia.org/wiki/Invertible_matrix#Analytic_solution).
	* You can not invert with a determinant of zero. If you attempt this, the method produces
	* a zero matrix instead.
	*
	* @return {Matrix3} A reference to this matrix.
	*/
	invert() {
		const te = this.elements, n11 = te[0], n21 = te[1], n31 = te[2], n12 = te[3], n22 = te[4], n32 = te[5], n13 = te[6], n23 = te[7], n33 = te[8], t11 = n33 * n22 - n32 * n23, t12 = n32 * n13 - n33 * n12, t13 = n23 * n12 - n22 * n13, det = n11 * t11 + n21 * t12 + n31 * t13;
		if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
		const detInv = 1 / det;
		te[0] = t11 * detInv;
		te[1] = (n31 * n23 - n33 * n21) * detInv;
		te[2] = (n32 * n21 - n31 * n22) * detInv;
		te[3] = t12 * detInv;
		te[4] = (n33 * n11 - n31 * n13) * detInv;
		te[5] = (n31 * n12 - n32 * n11) * detInv;
		te[6] = t13 * detInv;
		te[7] = (n21 * n13 - n23 * n11) * detInv;
		te[8] = (n22 * n11 - n21 * n12) * detInv;
		return this;
	}
	/**
	* Transposes this matrix in place.
	*
	* @return {Matrix3} A reference to this matrix.
	*/
	transpose() {
		let tmp;
		const m = this.elements;
		tmp = m[1];
		m[1] = m[3];
		m[3] = tmp;
		tmp = m[2];
		m[2] = m[6];
		m[6] = tmp;
		tmp = m[5];
		m[5] = m[7];
		m[7] = tmp;
		return this;
	}
	/**
	* Computes the normal matrix which is the inverse transpose of the upper
	* left 3x3 portion of the given 4x4 matrix.
	*
	* @param {Matrix4} matrix4 - The 4x4 matrix.
	* @return {Matrix3} A reference to this matrix.
	*/
	getNormalMatrix(matrix4) {
		return this.setFromMatrix4(matrix4).invert().transpose();
	}
	/**
	* Transposes this matrix into the supplied array, and returns itself unchanged.
	*
	* @param {Array<number>} r - An array to store the transposed matrix elements.
	* @return {Matrix3} A reference to this matrix.
	*/
	transposeIntoArray(r) {
		const m = this.elements;
		r[0] = m[0];
		r[1] = m[3];
		r[2] = m[6];
		r[3] = m[1];
		r[4] = m[4];
		r[5] = m[7];
		r[6] = m[2];
		r[7] = m[5];
		r[8] = m[8];
		return this;
	}
	/**
	* Sets the UV transform matrix from offset, repeat, rotation, and center.
	*
	* @param {number} tx - Offset x.
	* @param {number} ty - Offset y.
	* @param {number} sx - Repeat x.
	* @param {number} sy - Repeat y.
	* @param {number} rotation - Rotation, in radians. Positive values rotate counterclockwise.
	* @param {number} cx - Center x of rotation.
	* @param {number} cy - Center y of rotation
	* @return {Matrix3} A reference to this matrix.
	*/
	setUvTransform(tx, ty, sx, sy, rotation, cx, cy) {
		const c = Math.cos(rotation);
		const s = Math.sin(rotation);
		this.set(sx * c, sx * s, -sx * (c * cx + s * cy) + cx + tx, -sy * s, sy * c, -sy * (-s * cx + c * cy) + cy + ty, 0, 0, 1);
		return this;
	}
	/**
	* Scales this matrix with the given scalar values.
	*
	* @deprecated
	* @param {number} sx - The amount to scale in the X axis.
	* @param {number} sy - The amount to scale in the Y axis.
	* @return {Matrix3} A reference to this matrix.
	*/
	scale(sx, sy) {
		warnOnce("Matrix3: .scale() is deprecated. Use .makeScale() instead.");
		this.premultiply(_m3.makeScale(sx, sy));
		return this;
	}
	/**
	* Rotates this matrix by the given angle.
	*
	* @deprecated
	* @param {number} theta - The rotation in radians.
	* @return {Matrix3} A reference to this matrix.
	*/
	rotate(theta) {
		warnOnce("Matrix3: .rotate() is deprecated. Use .makeRotation() instead.");
		this.premultiply(_m3.makeRotation(-theta));
		return this;
	}
	/**
	* Translates this matrix by the given scalar values.
	*
	* @deprecated
	* @param {number} tx - The amount to translate in the X axis.
	* @param {number} ty - The amount to translate in the Y axis.
	* @return {Matrix3} A reference to this matrix.
	*/
	translate(tx, ty) {
		warnOnce("Matrix3: .translate() is deprecated. Use .makeTranslation() instead.");
		this.premultiply(_m3.makeTranslation(tx, ty));
		return this;
	}
	/**
	* Sets this matrix as a 2D translation transform.
	*
	* @param {number|Vector2} x - The amount to translate in the X axis or alternatively a translation vector.
	* @param {number} y - The amount to translate in the Y axis.
	* @return {Matrix3} A reference to this matrix.
	*/
	makeTranslation(x, y) {
		if (x.isVector2) this.set(1, 0, x.x, 0, 1, x.y, 0, 0, 1);
		else this.set(1, 0, x, 0, 1, y, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a 2D rotational transformation.
	*
	* @param {number} theta - The rotation in radians.
	* @return {Matrix3} A reference to this matrix.
	*/
	makeRotation(theta) {
		const c = Math.cos(theta);
		const s = Math.sin(theta);
		this.set(c, -s, 0, s, c, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a 2D scale transform.
	*
	* @param {number} x - The amount to scale in the X axis.
	* @param {number} y - The amount to scale in the Y axis.
	* @return {Matrix3} A reference to this matrix.
	*/
	makeScale(x, y) {
		this.set(x, 0, 0, 0, y, 0, 0, 0, 1);
		return this;
	}
	/**
	* Returns `true` if this matrix is equal with the given one.
	*
	* @param {Matrix3} matrix - The matrix to test for equality.
	* @return {boolean} Whether this matrix is equal with the given one.
	*/
	equals(matrix) {
		const te = this.elements;
		const me = matrix.elements;
		for (let i = 0; i < 9; i++) if (te[i] !== me[i]) return false;
		return true;
	}
	/**
	* Sets the elements of the matrix from the given array.
	*
	* @param {Array<number>} array - The matrix elements in column-major order.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Matrix3} A reference to this matrix.
	*/
	fromArray(array, offset = 0) {
		for (let i = 0; i < 9; i++) this.elements[i] = array[i + offset];
		return this;
	}
	/**
	* Writes the elements of this matrix to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the matrix elements in column-major order.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The matrix elements in column-major order.
	*/
	toArray(array = [], offset = 0) {
		const te = this.elements;
		array[offset] = te[0];
		array[offset + 1] = te[1];
		array[offset + 2] = te[2];
		array[offset + 3] = te[3];
		array[offset + 4] = te[4];
		array[offset + 5] = te[5];
		array[offset + 6] = te[6];
		array[offset + 7] = te[7];
		array[offset + 8] = te[8];
		return array;
	}
	/**
	* Returns a matrix with copied values from this instance.
	*
	* @return {Matrix3} A clone of this instance.
	*/
	clone() {
		return new this.constructor().fromArray(this.elements);
	}
};
const _m3 = /*@__PURE__*/ new Matrix3();
const LINEAR_REC709_TO_XYZ = /*@__PURE__*/ new Matrix3().set(.4123908, .3575843, .1804808, .212639, .7151687, .0721923, .0193308, .1191948, .9505322);
const XYZ_TO_LINEAR_REC709 = /*@__PURE__*/ new Matrix3().set(3.2409699, -1.5373832, -.4986108, -.9692436, 1.8759675, .0415551, .0556301, -.203977, 1.0569715);
function createColorManagement() {
	const ColorManagement = {
		enabled: true,
		workingColorSpace: LinearSRGBColorSpace,
		/**
		* Implementations of supported color spaces.
		*
		* Required:
		*	- primaries: chromaticity coordinates [ rx ry gx gy bx by ]
		*	- whitePoint: reference white [ x y ]
		*	- transfer: transfer function (pre-defined)
		*	- toXYZ: Matrix3 RGB to XYZ transform
		*	- fromXYZ: Matrix3 XYZ to RGB transform
		*	- luminanceCoefficients: RGB luminance coefficients
		*
		* Optional:
		*  - outputColorSpaceConfig: { drawingBufferColorSpace: ColorSpace, toneMappingMode: 'extended' | 'standard' }
		*  - workingColorSpaceConfig: { unpackColorSpace: ColorSpace }
		*
		* Reference:
		* - https://www.russellcottrell.com/photo/matrixCalculator.htm
		*/
		spaces: {},
		convert: function(color, sourceColorSpace, targetColorSpace) {
			if (this.enabled === false || sourceColorSpace === targetColorSpace || !sourceColorSpace || !targetColorSpace) return color;
			if (this.spaces[sourceColorSpace].transfer === "srgb") {
				color.r = SRGBToLinear(color.r);
				color.g = SRGBToLinear(color.g);
				color.b = SRGBToLinear(color.b);
			}
			if (this.spaces[sourceColorSpace].primaries !== this.spaces[targetColorSpace].primaries) {
				color.applyMatrix3(this.spaces[sourceColorSpace].toXYZ);
				color.applyMatrix3(this.spaces[targetColorSpace].fromXYZ);
			}
			if (this.spaces[targetColorSpace].transfer === "srgb") {
				color.r = LinearToSRGB(color.r);
				color.g = LinearToSRGB(color.g);
				color.b = LinearToSRGB(color.b);
			}
			return color;
		},
		workingToColorSpace: function(color, targetColorSpace) {
			return this.convert(color, this.workingColorSpace, targetColorSpace);
		},
		colorSpaceToWorking: function(color, sourceColorSpace) {
			return this.convert(color, sourceColorSpace, this.workingColorSpace);
		},
		getPrimaries: function(colorSpace) {
			return this.spaces[colorSpace].primaries;
		},
		getTransfer: function(colorSpace) {
			if (colorSpace === "") return LinearTransfer;
			return this.spaces[colorSpace].transfer;
		},
		getToneMappingMode: function(colorSpace) {
			return this.spaces[colorSpace].outputColorSpaceConfig.toneMappingMode || "standard";
		},
		getLuminanceCoefficients: function(target, colorSpace = this.workingColorSpace) {
			return target.fromArray(this.spaces[colorSpace].luminanceCoefficients);
		},
		define: function(colorSpaces) {
			Object.assign(this.spaces, colorSpaces);
		},
		_getMatrix: function(targetMatrix, sourceColorSpace, targetColorSpace) {
			return targetMatrix.copy(this.spaces[sourceColorSpace].toXYZ).multiply(this.spaces[targetColorSpace].fromXYZ);
		},
		_getDrawingBufferColorSpace: function(colorSpace) {
			return this.spaces[colorSpace].outputColorSpaceConfig.drawingBufferColorSpace;
		},
		_getUnpackColorSpace: function(colorSpace = this.workingColorSpace) {
			return this.spaces[colorSpace].workingColorSpaceConfig.unpackColorSpace;
		},
		fromWorkingColorSpace: function(color, targetColorSpace) {
			warnOnce("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().");
			return ColorManagement.workingToColorSpace(color, targetColorSpace);
		},
		toWorkingColorSpace: function(color, sourceColorSpace) {
			warnOnce("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().");
			return ColorManagement.colorSpaceToWorking(color, sourceColorSpace);
		}
	};
	/******************************************************************************
	* sRGB definitions
	*/
	const REC709_PRIMARIES = [
		.64,
		.33,
		.3,
		.6,
		.15,
		.06
	];
	const REC709_LUMINANCE_COEFFICIENTS = [
		.2126,
		.7152,
		.0722
	];
	const D65 = [.3127, .329];
	ColorManagement.define({
		[LinearSRGBColorSpace]: {
			primaries: REC709_PRIMARIES,
			whitePoint: D65,
			transfer: LinearTransfer,
			toXYZ: LINEAR_REC709_TO_XYZ,
			fromXYZ: XYZ_TO_LINEAR_REC709,
			luminanceCoefficients: REC709_LUMINANCE_COEFFICIENTS,
			workingColorSpaceConfig: { unpackColorSpace: SRGBColorSpace },
			outputColorSpaceConfig: { drawingBufferColorSpace: SRGBColorSpace }
		},
		[SRGBColorSpace]: {
			primaries: REC709_PRIMARIES,
			whitePoint: D65,
			transfer: SRGBTransfer,
			toXYZ: LINEAR_REC709_TO_XYZ,
			fromXYZ: XYZ_TO_LINEAR_REC709,
			luminanceCoefficients: REC709_LUMINANCE_COEFFICIENTS,
			outputColorSpaceConfig: { drawingBufferColorSpace: SRGBColorSpace }
		}
	});
	return ColorManagement;
}
const ColorManagement = /*@__PURE__*/ createColorManagement();
function SRGBToLinear(c) {
	return c < .04045 ? c * .0773993808 : Math.pow(c * .9478672986 + .0521327014, 2.4);
}
function LinearToSRGB(c) {
	return c < .0031308 ? c * 12.92 : 1.055 * Math.pow(c, .41666) - .055;
}
let _canvas;
/**
* A class containing utility functions for images.
*
* @hideconstructor
*/
var ImageUtils = class {
	/**
	* Returns a data URI containing a representation of the given image.
	*
	* @param {(HTMLImageElement|HTMLCanvasElement)} image - The image object.
	* @param {string} [type='image/png'] - Indicates the image format.
	* @return {string} The data URI.
	*/
	static getDataURL(image, type = "image/png") {
		if (/^data:/i.test(image.src)) return image.src;
		if (typeof HTMLCanvasElement === "undefined") return image.src;
		let canvas;
		if (image instanceof HTMLCanvasElement) canvas = image;
		else {
			if (_canvas === void 0) _canvas = createElementNS("canvas");
			_canvas.width = image.width;
			_canvas.height = image.height;
			const context = _canvas.getContext("2d");
			if (image instanceof ImageData) context.putImageData(image, 0, 0);
			else context.drawImage(image, 0, 0, image.width, image.height);
			canvas = _canvas;
		}
		return canvas.toDataURL(type);
	}
	/**
	* Converts the given sRGB image data to linear color space.
	*
	* @param {(HTMLImageElement|HTMLCanvasElement|ImageBitmap|Object)} image - The image object.
	* @return {HTMLCanvasElement|Object} The converted image.
	*/
	static sRGBToLinear(image) {
		if (typeof HTMLImageElement !== "undefined" && image instanceof HTMLImageElement || typeof HTMLCanvasElement !== "undefined" && image instanceof HTMLCanvasElement || typeof ImageBitmap !== "undefined" && image instanceof ImageBitmap) {
			const canvas = createElementNS("canvas");
			canvas.width = image.width;
			canvas.height = image.height;
			const context = canvas.getContext("2d");
			context.drawImage(image, 0, 0, image.width, image.height);
			const imageData = context.getImageData(0, 0, image.width, image.height);
			const data = imageData.data;
			for (let i = 0; i < data.length; i++) data[i] = SRGBToLinear(data[i] / 255) * 255;
			context.putImageData(imageData, 0, 0);
			return canvas;
		} else if (image.data) {
			const data = image.data.slice(0);
			for (let i = 0; i < data.length; i++) if (data instanceof Uint8Array || data instanceof Uint8ClampedArray) data[i] = Math.floor(SRGBToLinear(data[i] / 255) * 255);
			else data[i] = SRGBToLinear(data[i]);
			return {
				data,
				width: image.width,
				height: image.height
			};
		} else {
			warn("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.");
			return image;
		}
	}
};
let _sourceId = 0;
/**
* Represents the data source of a texture.
*
* The main purpose of this class is to decouple the data definition from the texture
* definition so the same data can be used with multiple texture instances.
*/
var TextureSource = class {
	/**
	* Constructs a new texture source.
	*
	* @param {any} [data=null] - The data definition of a texture.
	*/
	constructor(data = null) {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		this.isTextureSource = true;
		/**
		* The ID of the source.
		*
		* @name TextureSource#id
		* @type {number}
		* @readonly
		*/
		Object.defineProperty(this, "id", { value: _sourceId++ });
		/**
		* The UUID of the source.
		*
		* @type {string}
		* @readonly
		*/
		this.uuid = generateUUID();
		/**
		* The data definition of a texture.
		*
		* @type {any}
		*/
		this.data = data;
		/**
		* This property is only relevant when {@link TextureSource#needsUpdate} is set to `true` and
		* provides more control on how texture data should be processed. When `dataReady` is set
		* to `false`, the engine performs the memory allocation (if necessary) but does not transfer
		* the data into the GPU memory.
		*
		* @type {boolean}
		* @default true
		*/
		this.dataReady = true;
		/**
		* This starts at `0` and counts how many times {@link TextureSource#needsUpdate} is set to `true`.
		*
		* @type {number}
		* @readonly
		* @default 0
		*/
		this.version = 0;
	}
	/**
	* Returns the dimensions of the source into the given target vector.
	*
	* @param {(Vector2|Vector3)} target - The target object the result is written into.
	* @return {(Vector2|Vector3)} The dimensions of the source.
	*/
	getSize(target) {
		const data = this.data;
		if (typeof HTMLVideoElement !== "undefined" && data instanceof HTMLVideoElement) target.set(data.videoWidth, data.videoHeight, 0);
		else if (typeof VideoFrame !== "undefined" && data instanceof VideoFrame) target.set(data.displayWidth, data.displayHeight, 0);
		else if (data !== null) target.set(data.width, data.height, data.depth || 0);
		else target.set(0, 0, 0);
		return target;
	}
	/**
	* When the property is set to `true`, the engine allocates the memory
	* for the texture (if necessary) and triggers the actual texture upload
	* to the GPU next time the source is used.
	*
	* @type {boolean}
	* @default false
	* @param {boolean} value
	*/
	set needsUpdate(value) {
		if (value === true) this.version++;
	}
	/**
	* Serializes the source into JSON.
	*
	* @param {?(Object|string)} meta - An optional value holding meta information about the serialization.
	* @return {Object} A JSON object representing the serialized source.
	* @see {@link ObjectLoader#parse}
	*/
	toJSON(meta) {
		const isRootObject = meta === void 0 || typeof meta === "string";
		if (!isRootObject && meta.images[this.uuid] !== void 0) return meta.images[this.uuid];
		const output = {
			uuid: this.uuid,
			url: ""
		};
		const data = this.data;
		if (data !== null) {
			let url;
			if (Array.isArray(data)) {
				url = [];
				for (let i = 0, l = data.length; i < l; i++) if (data[i].isDataTexture) url.push(serializeImage(data[i].image));
				else url.push(serializeImage(data[i]));
			} else url = serializeImage(data);
			output.url = url;
		}
		if (!isRootObject) meta.images[this.uuid] = output;
		return output;
	}
};
function serializeImage(image) {
	if (typeof HTMLImageElement !== "undefined" && image instanceof HTMLImageElement || typeof HTMLCanvasElement !== "undefined" && image instanceof HTMLCanvasElement || typeof ImageBitmap !== "undefined" && image instanceof ImageBitmap) return ImageUtils.getDataURL(image);
	else if (image.data) return {
		data: Array.from(image.data),
		width: image.width,
		height: image.height,
		type: image.data.constructor.name
	};
	else {
		warn("Texture: Unable to serialize Texture.");
		return {};
	}
}
let _textureId = 0;
const _tempVec3 = /*@__PURE__*/ new Vector3();
/**
* Base class for all textures.
*
* Note: After the initial use of a texture, its dimensions, format, and type
* cannot be changed. Instead, call {@link Texture#dispose} on the texture and instantiate a new one.
*
* @augments EventDispatcher
*/
var Texture = class Texture extends EventDispatcher {
	/**
	* Constructs a new texture.
	*
	* @param {?Object} [image=Texture.DEFAULT_IMAGE] - The image holding the texture data.
	* @param {number} [mapping=Texture.DEFAULT_MAPPING] - The texture mapping.
	* @param {number} [wrapS=ClampToEdgeWrapping] - The wrapS value.
	* @param {number} [wrapT=ClampToEdgeWrapping] - The wrapT value.
	* @param {number} [magFilter=LinearFilter] - The mag filter value.
	* @param {number} [minFilter=LinearMipmapLinearFilter] - The min filter value.
	* @param {number} [format=RGBAFormat] - The texture format.
	* @param {number} [type=UnsignedByteType] - The texture type.
	* @param {number} [anisotropy=Texture.DEFAULT_ANISOTROPY] - The anisotropy value.
	* @param {string} [colorSpace=NoColorSpace] - The color space.
	*/
	constructor(image = Texture.DEFAULT_IMAGE, mapping = Texture.DEFAULT_MAPPING, wrapS = ClampToEdgeWrapping, wrapT = ClampToEdgeWrapping, magFilter = LinearFilter, minFilter = LinearMipmapLinearFilter, format = RGBAFormat, type = UnsignedByteType, anisotropy = Texture.DEFAULT_ANISOTROPY, colorSpace = "") {
		super();
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		this.isTexture = true;
		/**
		* The ID of the texture.
		*
		* @name Texture#id
		* @type {number}
		* @readonly
		*/
		Object.defineProperty(this, "id", { value: _textureId++ });
		/**
		* The UUID of the texture.
		*
		* @type {string}
		* @readonly
		*/
		this.uuid = generateUUID();
		/**
		* The name of the texture.
		*
		* @type {string}
		*/
		this.name = "";
		/**
		* The data definition of a texture. A reference to the data source can be
		* shared across textures. This is often useful in context of spritesheets
		* where multiple textures render the same data but with different texture
		* transformations.
		*
		* @type {TextureSource}
		*/
		this.source = new TextureSource(image);
		/**
		* An array holding user-defined mipmaps.
		*
		* @type {Array<Object>}
		*/
		this.mipmaps = [];
		/**
		* How the texture is applied to the object. The value `UVMapping`
		* is the default, where texture or uv coordinates are used to apply the map.
		*
		* @type {(UVMapping|CubeReflectionMapping|CubeRefractionMapping|EquirectangularReflectionMapping|EquirectangularRefractionMapping|CubeUVReflectionMapping)}
		* @default UVMapping
		*/
		this.mapping = mapping;
		/**
		* Lets you select the uv attribute to map the texture to. `0` for `uv`,
		* `1` for `uv1`, `2` for `uv2` and `3` for `uv3`.
		*
		* @type {number}
		* @default 0
		*/
		this.channel = 0;
		/**
		* This defines how the texture is wrapped horizontally and corresponds to
		* *U* in UV mapping.
		*
		* @type {(RepeatWrapping|ClampToEdgeWrapping|MirroredRepeatWrapping)}
		* @default ClampToEdgeWrapping
		*/
		this.wrapS = wrapS;
		/**
		* This defines how the texture is wrapped horizontally and corresponds to
		* *V* in UV mapping.
		*
		* @type {(RepeatWrapping|ClampToEdgeWrapping|MirroredRepeatWrapping)}
		* @default ClampToEdgeWrapping
		*/
		this.wrapT = wrapT;
		/**
		* How the texture is sampled when a texel covers more than one pixel.
		*
		* @type {(NearestFilter|NearestMipmapNearestFilter|NearestMipmapLinearFilter|LinearFilter|LinearMipmapNearestFilter|LinearMipmapLinearFilter)}
		* @default LinearFilter
		*/
		this.magFilter = magFilter;
		/**
		* How the texture is sampled when a texel covers less than one pixel.
		*
		* @type {(NearestFilter|NearestMipmapNearestFilter|NearestMipmapLinearFilter|LinearFilter|LinearMipmapNearestFilter|LinearMipmapLinearFilter)}
		* @default LinearMipmapLinearFilter
		*/
		this.minFilter = minFilter;
		/**
		* The number of samples taken along the axis through the pixel that has the
		* highest density of texels. By default, this value is `1`. A higher value
		* gives a less blurry result than a basic mipmap, at the cost of more
		* texture samples being used.
		*
		* @type {number}
		* @default Texture.DEFAULT_ANISOTROPY
		*/
		this.anisotropy = anisotropy;
		/**
		* The format of the texture.
		*
		* @type {number}
		* @default RGBAFormat
		*/
		this.format = format;
		/**
		* The default internal format is derived from {@link Texture#format} and {@link Texture#type} and
		* defines how the texture data is going to be stored on the GPU.
		*
		* This property allows to overwrite the default format.
		*
		* @type {?string}
		* @default null
		*/
		this.internalFormat = null;
		/**
		* The data type of the texture.
		*
		* @type {number}
		* @default UnsignedByteType
		*/
		this.type = type;
		/**
		* How much a single repetition of the texture is offset from the beginning,
		* in each direction U and V. Typical range is `0.0` to `1.0`.
		*
		* @type {Vector2}
		* @default (0,0)
		*/
		this.offset = new Vector2(0, 0);
		/**
		* How many times the texture is repeated across the surface, in each
		* direction U and V. If repeat is set greater than `1` in either direction,
		* the corresponding wrap parameter should also be set to `RepeatWrapping`
		* or `MirroredRepeatWrapping` to achieve the desired tiling effect.
		*
		* @type {Vector2}
		* @default (1,1)
		*/
		this.repeat = new Vector2(1, 1);
		/**
		* The point around which rotation occurs. A value of `(0.5, 0.5)` corresponds
		* to the center of the texture. Default is `(0, 0)`, the lower left.
		*
		* @type {Vector2}
		* @default (0,0)
		*/
		this.center = new Vector2(0, 0);
		/**
		* How much the texture is rotated around the center point, in radians.
		* Positive values are counter-clockwise.
		*
		* @type {number}
		* @default 0
		*/
		this.rotation = 0;
		/**
		* Whether to update the texture's uv-transformation {@link Texture#matrix}
		* from the properties {@link Texture#offset}, {@link Texture#repeat},
		* {@link Texture#rotation}, and {@link Texture#center}.
		*
		* Set this to `false` if you are specifying the uv-transform matrix directly.
		*
		* @type {boolean}
		* @default true
		*/
		this.matrixAutoUpdate = true;
		/**
		* The uv-transformation matrix of the texture.
		*
		* @type {Matrix3}
		*/
		this.matrix = new Matrix3();
		/**
		* Whether to generate mipmaps (if possible) for a texture.
		*
		* Set this to `false` if you are creating mipmaps manually.
		*
		* @type {boolean}
		* @default true
		*/
		this.generateMipmaps = true;
		/**
		* If set to `true`, the alpha channel, if present, is multiplied into the
		* color channels when the texture is uploaded to the GPU.
		*
		* Note that this property has no effect when using `ImageBitmap`. You need to
		* configure premultiply alpha on bitmap creation instead.
		*
		* @type {boolean}
		* @default false
		*/
		this.premultiplyAlpha = false;
		/**
		* If set to `true`, the texture is flipped along the vertical axis when
		* uploaded to the GPU.
		*
		* Note that this property has no effect when using `ImageBitmap`. You need to
		* configure the flip on bitmap creation instead.
		*
		* @type {boolean}
		* @default true
		*/
		this.flipY = true;
		/**
		* Specifies the alignment requirements for the start of each pixel row in memory.
		* The allowable values are `1` (byte-alignment), `2` (rows aligned to even-numbered bytes),
		* `4` (word-alignment), and `8` (rows start on double-word boundaries).
		*
		* @type {number}
		* @default 4
		*/
		this.unpackAlignment = 4;
		/**
		* Textures containing color data should be annotated with `SRGBColorSpace` or `LinearSRGBColorSpace`.
		*
		* @type {string}
		* @default NoColorSpace
		*/
		this.colorSpace = colorSpace;
		/**
		* An object that can be used to store custom data about the texture. It
		* should not hold references to functions as these will not be cloned.
		*
		* @type {Object}
		*/
		this.userData = {};
		/**
		* This can be used to only update a subregion or specific rows of the texture (for example, just the
		* first 3 rows). Use the `addUpdateRange()` function to add ranges to this array.
		*
		* @type {Array<Object>}
		*/
		this.updateRanges = [];
		/**
		* This starts at `0` and counts how many times {@link Texture#needsUpdate} is set to `true`.
		*
		* @type {number}
		* @readonly
		* @default 0
		*/
		this.version = 0;
		/**
		* A callback function, called when the texture is updated (e.g., when
		* {@link Texture#needsUpdate} has been set to true and then the texture is used).
		*
		* @type {?Function}
		* @default null
		*/
		this.onUpdate = null;
		/**
		* An optional back reference to the textures render target.
		*
		* @type {?(RenderTarget|WebGLRenderTarget)}
		* @default null
		*/
		this.renderTarget = null;
		/**
		* Indicates whether a texture belongs to a render target or not.
		*
		* @type {boolean}
		* @readonly
		* @default false
		*/
		this.isRenderTargetTexture = false;
		/**
		* Indicates if a texture should be handled like a texture array.
		*
		* @type {boolean}
		* @readonly
		* @default false
		*/
		this.isArrayTexture = image && image.depth && image.depth > 1 ? true : false;
		/**
		* Indicates whether this texture should be processed by `PMREMGenerator` or not
		* (only relevant for render target textures).
		*
		* @type {number}
		* @readonly
		* @default 0
		*/
		this.pmremVersion = 0;
		/**
		* Whether the texture should use one of the 16 bit integer formats which are normalized
		* to [0, 1] or [-1, 1] (depending on signed/unsigned) when sampled.
		*
		* @type {boolean}
		* @default false
		*/
		this.normalized = false;
	}
	/**
	* The width of the texture in pixels.
	*/
	get width() {
		return this.source.getSize(_tempVec3).x;
	}
	/**
	* The height of the texture in pixels.
	*/
	get height() {
		return this.source.getSize(_tempVec3).y;
	}
	/**
	* The depth of the texture in pixels.
	*/
	get depth() {
		return this.source.getSize(_tempVec3).z;
	}
	/**
	* The image object holding the texture data.
	*
	* @type {?Object}
	*/
	get image() {
		return this.source.data;
	}
	set image(value) {
		this.source.data = value;
	}
	/**
	* Updates the texture transformation matrix from the properties {@link Texture#offset},
	* {@link Texture#repeat}, {@link Texture#rotation}, and {@link Texture#center}.
	*/
	updateMatrix() {
		this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y);
	}
	/**
	* Adds a range of data in the data texture to be updated on the GPU.
	*
	* @param {number} start - Position at which to start update.
	* @param {number} count - The number of components to update.
	*/
	addUpdateRange(start, count) {
		this.updateRanges.push({
			start,
			count
		});
	}
	/**
	* Clears the update ranges.
	*/
	clearUpdateRanges() {
		this.updateRanges.length = 0;
	}
	/**
	* Returns a new texture with copied values from this instance.
	*
	* @return {Texture} A clone of this instance.
	*/
	clone() {
		return new this.constructor().copy(this);
	}
	/**
	* Copies the values of the given texture to this instance.
	*
	* @param {Texture} source - The texture to copy.
	* @return {Texture} A reference to this instance.
	*/
	copy(source) {
		this.name = source.name;
		this.source = source.source;
		this.mipmaps = source.mipmaps.slice(0);
		this.mapping = source.mapping;
		this.channel = source.channel;
		this.wrapS = source.wrapS;
		this.wrapT = source.wrapT;
		this.magFilter = source.magFilter;
		this.minFilter = source.minFilter;
		this.anisotropy = source.anisotropy;
		this.format = source.format;
		this.internalFormat = source.internalFormat;
		this.type = source.type;
		this.normalized = source.normalized;
		this.offset.copy(source.offset);
		this.repeat.copy(source.repeat);
		this.center.copy(source.center);
		this.rotation = source.rotation;
		this.matrixAutoUpdate = source.matrixAutoUpdate;
		this.matrix.copy(source.matrix);
		this.generateMipmaps = source.generateMipmaps;
		this.premultiplyAlpha = source.premultiplyAlpha;
		this.flipY = source.flipY;
		this.unpackAlignment = source.unpackAlignment;
		this.colorSpace = source.colorSpace;
		this.renderTarget = source.renderTarget;
		this.isRenderTargetTexture = source.isRenderTargetTexture;
		this.isArrayTexture = source.isArrayTexture;
		this.userData = JSON.parse(JSON.stringify(source.userData));
		this.needsUpdate = true;
		return this;
	}
	/**
	* Sets this texture's properties based on `values`.
	* @param {Object} values - A container with texture parameters.
	*/
	setValues(values) {
		for (const key in values) {
			const newValue = values[key];
			if (newValue === void 0) {
				warn(`Texture.setValues(): parameter '${key}' has value of undefined.`);
				continue;
			}
			const currentValue = this[key];
			if (currentValue === void 0) {
				warn(`Texture.setValues(): property '${key}' does not exist.`);
				continue;
			}
			if (currentValue && newValue && currentValue.isVector2 && newValue.isVector2) currentValue.copy(newValue);
			else if (currentValue && newValue && currentValue.isVector3 && newValue.isVector3) currentValue.copy(newValue);
			else if (currentValue && newValue && currentValue.isMatrix3 && newValue.isMatrix3) currentValue.copy(newValue);
			else this[key] = newValue;
		}
	}
	/**
	* Serializes the texture into JSON.
	*
	* @param {?(Object|string)} meta - An optional value holding meta information about the serialization.
	* @return {Object} A JSON object representing the serialized texture.
	* @see {@link ObjectLoader#parse}
	*/
	toJSON(meta) {
		const isRootObject = meta === void 0 || typeof meta === "string";
		if (!isRootObject && meta.textures[this.uuid] !== void 0) return meta.textures[this.uuid];
		const output = {
			metadata: {
				version: 4.7,
				type: "Texture",
				generator: "Texture.toJSON"
			},
			uuid: this.uuid,
			name: this.name,
			image: this.source.toJSON(meta).uuid,
			mapping: this.mapping,
			channel: this.channel,
			repeat: [this.repeat.x, this.repeat.y],
			offset: [this.offset.x, this.offset.y],
			center: [this.center.x, this.center.y],
			rotation: this.rotation,
			wrap: [this.wrapS, this.wrapT],
			format: this.format,
			internalFormat: this.internalFormat,
			type: this.type,
			normalized: this.normalized,
			colorSpace: this.colorSpace,
			minFilter: this.minFilter,
			magFilter: this.magFilter,
			anisotropy: this.anisotropy,
			flipY: this.flipY,
			generateMipmaps: this.generateMipmaps,
			premultiplyAlpha: this.premultiplyAlpha,
			unpackAlignment: this.unpackAlignment
		};
		if (Object.keys(this.userData).length > 0) output.userData = this.userData;
		if (!isRootObject) meta.textures[this.uuid] = output;
		return output;
	}
	/**
	* Frees the GPU-related resources allocated by this instance. Call this
	* method whenever this instance is no longer used in your app.
	*
	* @fires Texture#dispose
	*/
	dispose() {
		/**
		* Fires when the texture has been disposed of.
		*
		* @event Texture#dispose
		* @type {Object}
		*/
		this.dispatchEvent({ type: "dispose" });
	}
	/**
	* Transforms the given uv vector with the textures uv transformation matrix.
	*
	* @param {Vector2} uv - The uv vector.
	* @return {Vector2} The transformed uv vector.
	*/
	transformUv(uv) {
		if (this.mapping !== 300) return uv;
		uv.applyMatrix3(this.matrix);
		if (uv.x < 0 || uv.x > 1) switch (this.wrapS) {
			case RepeatWrapping:
				uv.x = uv.x - Math.floor(uv.x);
				break;
			case ClampToEdgeWrapping:
				uv.x = uv.x < 0 ? 0 : 1;
				break;
			case MirroredRepeatWrapping: if (Math.abs(Math.floor(uv.x) % 2) === 1) uv.x = Math.ceil(uv.x) - uv.x;
			else uv.x = uv.x - Math.floor(uv.x);
		}
		if (uv.y < 0 || uv.y > 1) switch (this.wrapT) {
			case RepeatWrapping:
				uv.y = uv.y - Math.floor(uv.y);
				break;
			case ClampToEdgeWrapping:
				uv.y = uv.y < 0 ? 0 : 1;
				break;
			case MirroredRepeatWrapping: if (Math.abs(Math.floor(uv.y) % 2) === 1) uv.y = Math.ceil(uv.y) - uv.y;
			else uv.y = uv.y - Math.floor(uv.y);
		}
		if (this.flipY) uv.y = 1 - uv.y;
		return uv;
	}
	/**
	* Setting this property to `true` indicates the engine the texture
	* must be updated in the next render. This triggers a texture upload
	* to the GPU and ensures correct texture parameter configuration.
	*
	* @type {boolean}
	* @default false
	* @param {boolean} value
	*/
	set needsUpdate(value) {
		if (value === true) {
			this.version++;
			this.source.needsUpdate = true;
		}
	}
	/**
	* Setting this property to `true` indicates the engine the PMREM
	* must be regenerated.
	*
	* @type {boolean}
	* @default false
	* @param {boolean} value
	*/
	set needsPMREMUpdate(value) {
		if (value === true) this.pmremVersion++;
	}
};
/**
* The default image for all textures.
*
* @static
* @type {?Image}
* @default null
*/
Texture.DEFAULT_IMAGE = null;
/**
* The default mapping for all textures.
*
* @static
* @type {number}
* @default UVMapping
*/
Texture.DEFAULT_MAPPING = 300;
/**
* The default anisotropy value for all textures.
*
* @static
* @type {number}
* @default 1
*/
Texture.DEFAULT_ANISOTROPY = 1;
(class Vector4 {
	static {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		Vector4.prototype.isVector4 = true;
	}
	/**
	* Constructs a new 4D vector.
	*
	* @param {number} [x=0] - The x value of this vector.
	* @param {number} [y=0] - The y value of this vector.
	* @param {number} [z=0] - The z value of this vector.
	* @param {number} [w=1] - The w value of this vector.
	*/
	constructor(x = 0, y = 0, z = 0, w = 1) {
		/**
		* The x value of this vector.
		*
		* @type {number}
		*/
		this.x = x;
		/**
		* The y value of this vector.
		*
		* @type {number}
		*/
		this.y = y;
		/**
		* The z value of this vector.
		*
		* @type {number}
		*/
		this.z = z;
		/**
		* The w value of this vector.
		*
		* @type {number}
		*/
		this.w = w;
	}
	/**
	* Alias for {@link Vector4#z}.
	*
	* @type {number}
	*/
	get width() {
		return this.z;
	}
	set width(value) {
		this.z = value;
	}
	/**
	* Alias for {@link Vector4#w}.
	*
	* @type {number}
	*/
	get height() {
		return this.w;
	}
	set height(value) {
		this.w = value;
	}
	/**
	* Sets the vector components.
	*
	* @param {number} x - The value of the x component.
	* @param {number} y - The value of the y component.
	* @param {number} z - The value of the z component.
	* @param {number} w - The value of the w component.
	* @return {Vector4} A reference to this vector.
	*/
	set(x, y, z, w) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
		return this;
	}
	/**
	* Sets the vector components to the same value.
	*
	* @param {number} scalar - The value to set for all vector components.
	* @return {Vector4} A reference to this vector.
	*/
	setScalar(scalar) {
		this.x = scalar;
		this.y = scalar;
		this.z = scalar;
		this.w = scalar;
		return this;
	}
	/**
	* Sets the vector's x component to the given value
	*
	* @param {number} x - The value to set.
	* @return {Vector4} A reference to this vector.
	*/
	setX(x) {
		this.x = x;
		return this;
	}
	/**
	* Sets the vector's y component to the given value
	*
	* @param {number} y - The value to set.
	* @return {Vector4} A reference to this vector.
	*/
	setY(y) {
		this.y = y;
		return this;
	}
	/**
	* Sets the vector's z component to the given value
	*
	* @param {number} z - The value to set.
	* @return {Vector4} A reference to this vector.
	*/
	setZ(z) {
		this.z = z;
		return this;
	}
	/**
	* Sets the vector's w component to the given value
	*
	* @param {number} w - The value to set.
	* @return {Vector4} A reference to this vector.
	*/
	setW(w) {
		this.w = w;
		return this;
	}
	/**
	* Allows to set a vector component with an index.
	*
	* @param {number} index - The component index. `0` equals to x, `1` equals to y,
	* `2` equals to z, `3` equals to w.
	* @param {number} value - The value to set.
	* @return {Vector4} A reference to this vector.
	*/
	setComponent(index, value) {
		switch (index) {
			case 0:
				this.x = value;
				break;
			case 1:
				this.y = value;
				break;
			case 2:
				this.z = value;
				break;
			case 3:
				this.w = value;
				break;
			default: throw new Error("THREE.Vector4: index is out of range: " + index);
		}
		return this;
	}
	/**
	* Returns the value of the vector component which matches the given index.
	*
	* @param {number} index - The component index. `0` equals to x, `1` equals to y,
	* `2` equals to z, `3` equals to w.
	* @return {number} A vector component value.
	*/
	getComponent(index) {
		switch (index) {
			case 0: return this.x;
			case 1: return this.y;
			case 2: return this.z;
			case 3: return this.w;
			default: throw new Error("THREE.Vector4: index is out of range: " + index);
		}
	}
	/**
	* Returns a new vector with copied values from this instance.
	*
	* @return {Vector4} A clone of this instance.
	*/
	clone() {
		return new this.constructor(this.x, this.y, this.z, this.w);
	}
	/**
	* Copies the values of the given vector to this instance.
	*
	* @param {Vector3|Vector4} v - The vector to copy.
	* @return {Vector4} A reference to this vector.
	*/
	copy(v) {
		this.x = v.x;
		this.y = v.y;
		this.z = v.z;
		this.w = v.w !== void 0 ? v.w : 1;
		return this;
	}
	/**
	* Adds the given vector to this instance.
	*
	* @param {Vector4} v - The vector to add.
	* @return {Vector4} A reference to this vector.
	*/
	add(v) {
		this.x += v.x;
		this.y += v.y;
		this.z += v.z;
		this.w += v.w;
		return this;
	}
	/**
	* Adds the given scalar value to all components of this instance.
	*
	* @param {number} s - The scalar to add.
	* @return {Vector4} A reference to this vector.
	*/
	addScalar(s) {
		this.x += s;
		this.y += s;
		this.z += s;
		this.w += s;
		return this;
	}
	/**
	* Adds the given vectors and stores the result in this instance.
	*
	* @param {Vector4} a - The first vector.
	* @param {Vector4} b - The second vector.
	* @return {Vector4} A reference to this vector.
	*/
	addVectors(a, b) {
		this.x = a.x + b.x;
		this.y = a.y + b.y;
		this.z = a.z + b.z;
		this.w = a.w + b.w;
		return this;
	}
	/**
	* Adds the given vector scaled by the given factor to this instance.
	*
	* @param {Vector4} v - The vector.
	* @param {number} s - The factor that scales `v`.
	* @return {Vector4} A reference to this vector.
	*/
	addScaledVector(v, s) {
		this.x += v.x * s;
		this.y += v.y * s;
		this.z += v.z * s;
		this.w += v.w * s;
		return this;
	}
	/**
	* Subtracts the given vector from this instance.
	*
	* @param {Vector4} v - The vector to subtract.
	* @return {Vector4} A reference to this vector.
	*/
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		this.z -= v.z;
		this.w -= v.w;
		return this;
	}
	/**
	* Subtracts the given scalar value from all components of this instance.
	*
	* @param {number} s - The scalar to subtract.
	* @return {Vector4} A reference to this vector.
	*/
	subScalar(s) {
		this.x -= s;
		this.y -= s;
		this.z -= s;
		this.w -= s;
		return this;
	}
	/**
	* Subtracts the given vectors and stores the result in this instance.
	*
	* @param {Vector4} a - The first vector.
	* @param {Vector4} b - The second vector.
	* @return {Vector4} A reference to this vector.
	*/
	subVectors(a, b) {
		this.x = a.x - b.x;
		this.y = a.y - b.y;
		this.z = a.z - b.z;
		this.w = a.w - b.w;
		return this;
	}
	/**
	* Multiplies the given vector with this instance.
	*
	* @param {Vector4} v - The vector to multiply.
	* @return {Vector4} A reference to this vector.
	*/
	multiply(v) {
		this.x *= v.x;
		this.y *= v.y;
		this.z *= v.z;
		this.w *= v.w;
		return this;
	}
	/**
	* Multiplies the given scalar value with all components of this instance.
	*
	* @param {number} scalar - The scalar to multiply.
	* @return {Vector4} A reference to this vector.
	*/
	multiplyScalar(scalar) {
		this.x *= scalar;
		this.y *= scalar;
		this.z *= scalar;
		this.w *= scalar;
		return this;
	}
	/**
	* Multiplies this vector with the given 4x4 matrix.
	*
	* @param {Matrix4} m - The 4x4 matrix.
	* @return {Vector4} A reference to this vector.
	*/
	applyMatrix4(m) {
		const x = this.x, y = this.y, z = this.z, w = this.w;
		const e = m.elements;
		this.x = e[0] * x + e[4] * y + e[8] * z + e[12] * w;
		this.y = e[1] * x + e[5] * y + e[9] * z + e[13] * w;
		this.z = e[2] * x + e[6] * y + e[10] * z + e[14] * w;
		this.w = e[3] * x + e[7] * y + e[11] * z + e[15] * w;
		return this;
	}
	/**
	* Divides this instance by the given vector.
	*
	* @param {Vector4} v - The vector to divide.
	* @return {Vector4} A reference to this vector.
	*/
	divide(v) {
		this.x /= v.x;
		this.y /= v.y;
		this.z /= v.z;
		this.w /= v.w;
		return this;
	}
	/**
	* Divides this vector by the given scalar.
	*
	* @param {number} scalar - The scalar to divide.
	* @return {Vector4} A reference to this vector.
	*/
	divideScalar(scalar) {
		return this.multiplyScalar(1 / scalar);
	}
	/**
	* Sets the x, y and z components of this
	* vector to the quaternion's axis and w to the angle.
	*
	* @param {Quaternion} q - The Quaternion to set.
	* @return {Vector4} A reference to this vector.
	*/
	setAxisAngleFromQuaternion(q) {
		this.w = 2 * Math.acos(q.w);
		const s = Math.sqrt(1 - q.w * q.w);
		if (s < 1e-4) {
			this.x = 1;
			this.y = 0;
			this.z = 0;
		} else {
			this.x = q.x / s;
			this.y = q.y / s;
			this.z = q.z / s;
		}
		return this;
	}
	/**
	* Sets the x, y and z components of this
	* vector to the axis of rotation and w to the angle.
	*
	* @param {Matrix4} m - A 4x4 matrix of which the upper left 3x3 matrix is a pure rotation matrix.
	* @return {Vector4} A reference to this vector.
	*/
	setAxisAngleFromRotationMatrix(m) {
		let angle, x, y, z;
		const epsilon = .01, epsilon2 = .1, te = m.elements, m11 = te[0], m12 = te[4], m13 = te[8], m21 = te[1], m22 = te[5], m23 = te[9], m31 = te[2], m32 = te[6], m33 = te[10];
		if (Math.abs(m12 - m21) < epsilon && Math.abs(m13 - m31) < epsilon && Math.abs(m23 - m32) < epsilon) {
			if (Math.abs(m12 + m21) < epsilon2 && Math.abs(m13 + m31) < epsilon2 && Math.abs(m23 + m32) < epsilon2 && Math.abs(m11 + m22 + m33 - 3) < epsilon2) {
				this.set(1, 0, 0, 0);
				return this;
			}
			angle = Math.PI;
			const xx = (m11 + 1) / 2;
			const yy = (m22 + 1) / 2;
			const zz = (m33 + 1) / 2;
			const xy = (m12 + m21) / 4;
			const xz = (m13 + m31) / 4;
			const yz = (m23 + m32) / 4;
			if (xx > yy && xx > zz) {
				if (xx < epsilon) {
					x = 0;
					y = .707106781;
					z = .707106781;
				} else {
					x = Math.sqrt(xx);
					y = xy / x;
					z = xz / x;
				}
			} else if (yy > zz) {
				if (yy < epsilon) {
					x = .707106781;
					y = 0;
					z = .707106781;
				} else {
					y = Math.sqrt(yy);
					x = xy / y;
					z = yz / y;
				}
			} else if (zz < epsilon) {
				x = .707106781;
				y = .707106781;
				z = 0;
			} else {
				z = Math.sqrt(zz);
				x = xz / z;
				y = yz / z;
			}
			this.set(x, y, z, angle);
			return this;
		}
		let s = Math.sqrt((m32 - m23) * (m32 - m23) + (m13 - m31) * (m13 - m31) + (m21 - m12) * (m21 - m12));
		if (Math.abs(s) < .001) s = 1;
		this.x = (m32 - m23) / s;
		this.y = (m13 - m31) / s;
		this.z = (m21 - m12) / s;
		this.w = Math.acos((m11 + m22 + m33 - 1) / 2);
		return this;
	}
	/**
	* Sets the vector components to the position elements of the
	* given transformation matrix.
	*
	* @param {Matrix4} m - The 4x4 matrix.
	* @return {Vector4} A reference to this vector.
	*/
	setFromMatrixPosition(m) {
		const e = m.elements;
		this.x = e[12];
		this.y = e[13];
		this.z = e[14];
		this.w = e[15];
		return this;
	}
	/**
	* If this vector's x, y, z or w value is greater than the given vector's x, y, z or w
	* value, replace that value with the corresponding min value.
	*
	* @param {Vector4} v - The vector.
	* @return {Vector4} A reference to this vector.
	*/
	min(v) {
		this.x = Math.min(this.x, v.x);
		this.y = Math.min(this.y, v.y);
		this.z = Math.min(this.z, v.z);
		this.w = Math.min(this.w, v.w);
		return this;
	}
	/**
	* If this vector's x, y, z or w value is less than the given vector's x, y, z or w
	* value, replace that value with the corresponding max value.
	*
	* @param {Vector4} v - The vector.
	* @return {Vector4} A reference to this vector.
	*/
	max(v) {
		this.x = Math.max(this.x, v.x);
		this.y = Math.max(this.y, v.y);
		this.z = Math.max(this.z, v.z);
		this.w = Math.max(this.w, v.w);
		return this;
	}
	/**
	* If this vector's x, y, z or w value is greater than the max vector's x, y, z or w
	* value, it is replaced by the corresponding value.
	* If this vector's x, y, z or w value is less than the min vector's x, y, z or w value,
	* it is replaced by the corresponding value.
	*
	* @param {Vector4} min - The minimum x, y and z values.
	* @param {Vector4} max - The maximum x, y and z values in the desired range.
	* @return {Vector4} A reference to this vector.
	*/
	clamp(min, max) {
		this.x = clamp$1(this.x, min.x, max.x);
		this.y = clamp$1(this.y, min.y, max.y);
		this.z = clamp$1(this.z, min.z, max.z);
		this.w = clamp$1(this.w, min.w, max.w);
		return this;
	}
	/**
	* If this vector's x, y, z or w values are greater than the max value, they are
	* replaced by the max value.
	* If this vector's x, y, z or w values are less than the min value, they are
	* replaced by the min value.
	*
	* @param {number} minVal - The minimum value the components will be clamped to.
	* @param {number} maxVal - The maximum value the components will be clamped to.
	* @return {Vector4} A reference to this vector.
	*/
	clampScalar(minVal, maxVal) {
		this.x = clamp$1(this.x, minVal, maxVal);
		this.y = clamp$1(this.y, minVal, maxVal);
		this.z = clamp$1(this.z, minVal, maxVal);
		this.w = clamp$1(this.w, minVal, maxVal);
		return this;
	}
	/**
	* If this vector's length is greater than the max value, it is replaced by
	* the max value.
	* If this vector's length is less than the min value, it is replaced by the
	* min value.
	*
	* @param {number} min - The minimum value the vector length will be clamped to.
	* @param {number} max - The maximum value the vector length will be clamped to.
	* @return {Vector4} A reference to this vector.
	*/
	clampLength(min, max) {
		const length = this.length();
		return this.divideScalar(length || 1).multiplyScalar(clamp$1(length, min, max));
	}
	/**
	* The components of this vector are rounded down to the nearest integer value.
	*
	* @return {Vector4} A reference to this vector.
	*/
	floor() {
		this.x = Math.floor(this.x);
		this.y = Math.floor(this.y);
		this.z = Math.floor(this.z);
		this.w = Math.floor(this.w);
		return this;
	}
	/**
	* The components of this vector are rounded up to the nearest integer value.
	*
	* @return {Vector4} A reference to this vector.
	*/
	ceil() {
		this.x = Math.ceil(this.x);
		this.y = Math.ceil(this.y);
		this.z = Math.ceil(this.z);
		this.w = Math.ceil(this.w);
		return this;
	}
	/**
	* The components of this vector are rounded to the nearest integer value
	*
	* @return {Vector4} A reference to this vector.
	*/
	round() {
		this.x = Math.round(this.x);
		this.y = Math.round(this.y);
		this.z = Math.round(this.z);
		this.w = Math.round(this.w);
		return this;
	}
	/**
	* The components of this vector are rounded towards zero (up if negative,
	* down if positive) to an integer value.
	*
	* @return {Vector4} A reference to this vector.
	*/
	roundToZero() {
		this.x = Math.trunc(this.x);
		this.y = Math.trunc(this.y);
		this.z = Math.trunc(this.z);
		this.w = Math.trunc(this.w);
		return this;
	}
	/**
	* Inverts this vector - i.e. sets x = -x, y = -y, z = -z, w = -w.
	*
	* @return {Vector4} A reference to this vector.
	*/
	negate() {
		this.x = -this.x;
		this.y = -this.y;
		this.z = -this.z;
		this.w = -this.w;
		return this;
	}
	/**
	* Calculates the dot product of the given vector with this instance.
	*
	* @param {Vector4} v - The vector to compute the dot product with.
	* @return {number} The result of the dot product.
	*/
	dot(v) {
		return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w;
	}
	/**
	* Computes the square of the Euclidean length (straight-line length) from
	* (0, 0, 0, 0) to (x, y, z, w). If you are comparing the lengths of vectors, you should
	* compare the length squared instead as it is slightly more efficient to calculate.
	*
	* @return {number} The square length of this vector.
	*/
	lengthSq() {
		return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
	}
	/**
	* Computes the  Euclidean length (straight-line length) from (0, 0, 0, 0) to (x, y, z, w).
	*
	* @return {number} The length of this vector.
	*/
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
	}
	/**
	* Computes the Manhattan length of this vector.
	*
	* @return {number} The length of this vector.
	*/
	manhattanLength() {
		return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
	}
	/**
	* Converts this vector to a unit vector - that is, sets it equal to a vector
	* with the same direction as this one, but with a vector length of `1`.
	*
	* @return {Vector4} A reference to this vector.
	*/
	normalize() {
		return this.divideScalar(this.length() || 1);
	}
	/**
	* Sets this vector to a vector with the same direction as this one, but
	* with the specified length.
	*
	* @param {number} length - The new length of this vector.
	* @return {Vector4} A reference to this vector.
	*/
	setLength(length) {
		return this.normalize().multiplyScalar(length);
	}
	/**
	* Linearly interpolates between the given vector and this instance, where
	* alpha is the percent distance along the line - alpha = 0 will be this
	* vector, and alpha = 1 will be the given one.
	*
	* @param {Vector4} v - The vector to interpolate towards.
	* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
	* @return {Vector4} A reference to this vector.
	*/
	lerp(v, alpha) {
		this.x += (v.x - this.x) * alpha;
		this.y += (v.y - this.y) * alpha;
		this.z += (v.z - this.z) * alpha;
		this.w += (v.w - this.w) * alpha;
		return this;
	}
	/**
	* Linearly interpolates between the given vectors, where alpha is the percent
	* distance along the line - alpha = 0 will be first vector, and alpha = 1 will
	* be the second one. The result is stored in this instance.
	*
	* @param {Vector4} v1 - The first vector.
	* @param {Vector4} v2 - The second vector.
	* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
	* @return {Vector4} A reference to this vector.
	*/
	lerpVectors(v1, v2, alpha) {
		this.x = v1.x + (v2.x - v1.x) * alpha;
		this.y = v1.y + (v2.y - v1.y) * alpha;
		this.z = v1.z + (v2.z - v1.z) * alpha;
		this.w = v1.w + (v2.w - v1.w) * alpha;
		return this;
	}
	/**
	* Returns `true` if this vector is equal with the given one.
	*
	* @param {Vector4} v - The vector to test for equality.
	* @return {boolean} Whether this vector is equal with the given one.
	*/
	equals(v) {
		return v.x === this.x && v.y === this.y && v.z === this.z && v.w === this.w;
	}
	/**
	* Sets this vector's x value to be `array[ offset ]`, y value to be `array[ offset + 1 ]`,
	* z value to be `array[ offset + 2 ]`, w value to be `array[ offset + 3 ]`.
	*
	* @param {Array<number>} array - An array holding the vector component values.
	* @param {number} [offset=0] - The offset into the array.
	* @return {Vector4} A reference to this vector.
	*/
	fromArray(array, offset = 0) {
		this.x = array[offset];
		this.y = array[offset + 1];
		this.z = array[offset + 2];
		this.w = array[offset + 3];
		return this;
	}
	/**
	* Writes the components of this vector to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the vector components.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The vector components.
	*/
	toArray(array = [], offset = 0) {
		array[offset] = this.x;
		array[offset + 1] = this.y;
		array[offset + 2] = this.z;
		array[offset + 3] = this.w;
		return array;
	}
	/**
	* Sets the components of this vector from the given buffer attribute.
	*
	* @param {BufferAttribute} attribute - The buffer attribute holding vector data.
	* @param {number} index - The index into the attribute.
	* @return {Vector4} A reference to this vector.
	*/
	fromBufferAttribute(attribute, index) {
		this.x = attribute.getX(index);
		this.y = attribute.getY(index);
		this.z = attribute.getZ(index);
		this.w = attribute.getW(index);
		return this;
	}
	/**
	* Sets each component of this vector to a pseudo-random value between `0` and
	* `1`, excluding `1`.
	*
	* @return {Vector4} A reference to this vector.
	*/
	random() {
		this.x = Math.random();
		this.y = Math.random();
		this.z = Math.random();
		this.w = Math.random();
		return this;
	}
	*[Symbol.iterator]() {
		yield this.x;
		yield this.y;
		yield this.z;
		yield this.w;
	}
});
/**
* Represents a 4x4 matrix.
*
* The most common use of a 4x4 matrix in 3D computer graphics is as a transformation matrix.
* For an introduction to transformation matrices as used in WebGL, check out [this tutorial](https://www.opengl-tutorial.org/beginners-tutorials/tutorial-3-matrices)
*
* This allows a 3D vector representing a point in 3D space to undergo
* transformations such as translation, rotation, shear, scale, reflection,
* orthogonal or perspective projection and so on, by being multiplied by the
* matrix. This is known as `applying` the matrix to the vector.
*
* A Note on Row-Major and Column-Major Ordering:
*
* The constructor and {@link Matrix3#set} method take arguments in
* [row-major](https://en.wikipedia.org/wiki/Row-_and_column-major_order#Column-major_order)
* order, while internally they are stored in the {@link Matrix3#elements} array in column-major order.
* This means that calling:
* ```js
* const m = new THREE.Matrix4();
* m.set( 11, 12, 13, 14,
*        21, 22, 23, 24,
*        31, 32, 33, 34,
*        41, 42, 43, 44 );
* ```
* will result in the elements array containing:
* ```js
* m.elements = [ 11, 21, 31, 41,
*                12, 22, 32, 42,
*                13, 23, 33, 43,
*                14, 24, 34, 44 ];
* ```
* and internally all calculations are performed using column-major ordering.
* However, as the actual ordering makes no difference mathematically and
* most people are used to thinking about matrices in row-major order, the
* three.js documentation shows matrices in row-major order. Just bear in
* mind that if you are reading the source code, you'll have to take the
* transpose of any matrices outlined here to make sense of the calculations.
*/
var Matrix4 = class Matrix4 {
	static {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		Matrix4.prototype.isMatrix4 = true;
	}
	/**
	* Constructs a new 4x4 matrix. The arguments are supposed to be
	* in row-major order. If no arguments are provided, the constructor
	* initializes the matrix as an identity matrix.
	*
	* @param {number} [n11] - 1-1 matrix element.
	* @param {number} [n12] - 1-2 matrix element.
	* @param {number} [n13] - 1-3 matrix element.
	* @param {number} [n14] - 1-4 matrix element.
	* @param {number} [n21] - 2-1 matrix element.
	* @param {number} [n22] - 2-2 matrix element.
	* @param {number} [n23] - 2-3 matrix element.
	* @param {number} [n24] - 2-4 matrix element.
	* @param {number} [n31] - 3-1 matrix element.
	* @param {number} [n32] - 3-2 matrix element.
	* @param {number} [n33] - 3-3 matrix element.
	* @param {number} [n34] - 3-4 matrix element.
	* @param {number} [n41] - 4-1 matrix element.
	* @param {number} [n42] - 4-2 matrix element.
	* @param {number} [n43] - 4-3 matrix element.
	* @param {number} [n44] - 4-4 matrix element.
	*/
	constructor(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
		/**
		* A column-major list of matrix values.
		*
		* @type {Array<number>}
		*/
		this.elements = [
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1
		];
		if (n11 !== void 0) this.set(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44);
	}
	/**
	* Sets the elements of the matrix.The arguments are supposed to be
	* in row-major order.
	*
	* @param {number} [n11] - 1-1 matrix element.
	* @param {number} [n12] - 1-2 matrix element.
	* @param {number} [n13] - 1-3 matrix element.
	* @param {number} [n14] - 1-4 matrix element.
	* @param {number} [n21] - 2-1 matrix element.
	* @param {number} [n22] - 2-2 matrix element.
	* @param {number} [n23] - 2-3 matrix element.
	* @param {number} [n24] - 2-4 matrix element.
	* @param {number} [n31] - 3-1 matrix element.
	* @param {number} [n32] - 3-2 matrix element.
	* @param {number} [n33] - 3-3 matrix element.
	* @param {number} [n34] - 3-4 matrix element.
	* @param {number} [n41] - 4-1 matrix element.
	* @param {number} [n42] - 4-2 matrix element.
	* @param {number} [n43] - 4-3 matrix element.
	* @param {number} [n44] - 4-4 matrix element.
	* @return {Matrix4} A reference to this matrix.
	*/
	set(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
		const te = this.elements;
		te[0] = n11;
		te[4] = n12;
		te[8] = n13;
		te[12] = n14;
		te[1] = n21;
		te[5] = n22;
		te[9] = n23;
		te[13] = n24;
		te[2] = n31;
		te[6] = n32;
		te[10] = n33;
		te[14] = n34;
		te[3] = n41;
		te[7] = n42;
		te[11] = n43;
		te[15] = n44;
		return this;
	}
	/**
	* Sets this matrix to the 4x4 identity matrix.
	*
	* @return {Matrix4} A reference to this matrix.
	*/
	identity() {
		this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Returns a matrix with copied values from this instance.
	*
	* @return {Matrix4} A clone of this instance.
	*/
	clone() {
		return new Matrix4().fromArray(this.elements);
	}
	/**
	* Copies the values of the given matrix to this instance.
	*
	* @param {Matrix4} m - The matrix to copy.
	* @return {Matrix4} A reference to this matrix.
	*/
	copy(m) {
		const te = this.elements;
		const me = m.elements;
		te[0] = me[0];
		te[1] = me[1];
		te[2] = me[2];
		te[3] = me[3];
		te[4] = me[4];
		te[5] = me[5];
		te[6] = me[6];
		te[7] = me[7];
		te[8] = me[8];
		te[9] = me[9];
		te[10] = me[10];
		te[11] = me[11];
		te[12] = me[12];
		te[13] = me[13];
		te[14] = me[14];
		te[15] = me[15];
		return this;
	}
	/**
	* Copies the translation component of the given matrix
	* into this matrix's translation component.
	*
	* @param {Matrix4} m - The matrix to copy the translation component.
	* @return {Matrix4} A reference to this matrix.
	*/
	copyPosition(m) {
		const te = this.elements, me = m.elements;
		te[12] = me[12];
		te[13] = me[13];
		te[14] = me[14];
		return this;
	}
	/**
	* Set the upper 3x3 elements of this matrix to the values of given 3x3 matrix.
	*
	* @param {Matrix3} m - The 3x3 matrix.
	* @return {Matrix4} A reference to this matrix.
	*/
	setFromMatrix3(m) {
		const me = m.elements;
		this.set(me[0], me[3], me[6], 0, me[1], me[4], me[7], 0, me[2], me[5], me[8], 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Extracts the basis vectors of this matrix into the three vectors provided.
	*
	* @param {Vector3} xAxis - The basis's x axis.
	* @param {Vector3} yAxis - The basis's y axis.
	* @param {Vector3} zAxis - The basis's z axis.
	* @return {Matrix4} A reference to this matrix.
	*/
	extractBasis(xAxis, yAxis, zAxis) {
		if (this.determinantAffine() === 0) {
			xAxis.set(1, 0, 0);
			yAxis.set(0, 1, 0);
			zAxis.set(0, 0, 1);
			return this;
		}
		xAxis.setFromMatrixColumn(this, 0);
		yAxis.setFromMatrixColumn(this, 1);
		zAxis.setFromMatrixColumn(this, 2);
		return this;
	}
	/**
	* Sets the given basis vectors to this matrix.
	*
	* @param {Vector3} xAxis - The basis's x axis.
	* @param {Vector3} yAxis - The basis's y axis.
	* @param {Vector3} zAxis - The basis's z axis.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeBasis(xAxis, yAxis, zAxis) {
		this.set(xAxis.x, yAxis.x, zAxis.x, 0, xAxis.y, yAxis.y, zAxis.y, 0, xAxis.z, yAxis.z, zAxis.z, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Extracts the rotation component of the given matrix
	* into this matrix's rotation component.
	*
	* Note: This method does not support reflection matrices.
	*
	* @param {Matrix4} m - The matrix.
	* @return {Matrix4} A reference to this matrix.
	*/
	extractRotation(m) {
		if (m.determinantAffine() === 0) return this.identity();
		const te = this.elements;
		const me = m.elements;
		const scaleX = 1 / _v1$7.setFromMatrixColumn(m, 0).length();
		const scaleY = 1 / _v1$7.setFromMatrixColumn(m, 1).length();
		const scaleZ = 1 / _v1$7.setFromMatrixColumn(m, 2).length();
		te[0] = me[0] * scaleX;
		te[1] = me[1] * scaleX;
		te[2] = me[2] * scaleX;
		te[3] = 0;
		te[4] = me[4] * scaleY;
		te[5] = me[5] * scaleY;
		te[6] = me[6] * scaleY;
		te[7] = 0;
		te[8] = me[8] * scaleZ;
		te[9] = me[9] * scaleZ;
		te[10] = me[10] * scaleZ;
		te[11] = 0;
		te[12] = 0;
		te[13] = 0;
		te[14] = 0;
		te[15] = 1;
		return this;
	}
	/**
	* Sets the rotation component (the upper left 3x3 matrix) of this matrix to
	* the rotation specified by the given Euler angles. The rest of
	* the matrix is set to the identity. Depending on the {@link Euler#order},
	* there are six possible outcomes. See [this page](https://en.wikipedia.org/wiki/Euler_angles#Rotation_matrix)
	* for a complete list.
	*
	* @param {Euler} euler - The Euler angles.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeRotationFromEuler(euler) {
		const te = this.elements;
		const x = euler.x, y = euler.y, z = euler.z;
		const a = Math.cos(x), b = Math.sin(x);
		const c = Math.cos(y), d = Math.sin(y);
		const e = Math.cos(z), f = Math.sin(z);
		if (euler.order === "XYZ") {
			const ae = a * e, af = a * f, be = b * e, bf = b * f;
			te[0] = c * e;
			te[4] = -c * f;
			te[8] = d;
			te[1] = af + be * d;
			te[5] = ae - bf * d;
			te[9] = -b * c;
			te[2] = bf - ae * d;
			te[6] = be + af * d;
			te[10] = a * c;
		} else if (euler.order === "YXZ") {
			const ce = c * e, cf = c * f, de = d * e, df = d * f;
			te[0] = ce + df * b;
			te[4] = de * b - cf;
			te[8] = a * d;
			te[1] = a * f;
			te[5] = a * e;
			te[9] = -b;
			te[2] = cf * b - de;
			te[6] = df + ce * b;
			te[10] = a * c;
		} else if (euler.order === "ZXY") {
			const ce = c * e, cf = c * f, de = d * e, df = d * f;
			te[0] = ce - df * b;
			te[4] = -a * f;
			te[8] = de + cf * b;
			te[1] = cf + de * b;
			te[5] = a * e;
			te[9] = df - ce * b;
			te[2] = -a * d;
			te[6] = b;
			te[10] = a * c;
		} else if (euler.order === "ZYX") {
			const ae = a * e, af = a * f, be = b * e, bf = b * f;
			te[0] = c * e;
			te[4] = be * d - af;
			te[8] = ae * d + bf;
			te[1] = c * f;
			te[5] = bf * d + ae;
			te[9] = af * d - be;
			te[2] = -d;
			te[6] = b * c;
			te[10] = a * c;
		} else if (euler.order === "YZX") {
			const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
			te[0] = c * e;
			te[4] = bd - ac * f;
			te[8] = bc * f + ad;
			te[1] = f;
			te[5] = a * e;
			te[9] = -b * e;
			te[2] = -d * e;
			te[6] = ad * f + bc;
			te[10] = ac - bd * f;
		} else if (euler.order === "XZY") {
			const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
			te[0] = c * e;
			te[4] = -f;
			te[8] = d * e;
			te[1] = ac * f + bd;
			te[5] = a * e;
			te[9] = ad * f - bc;
			te[2] = bc * f - ad;
			te[6] = b * e;
			te[10] = bd * f + ac;
		}
		te[3] = 0;
		te[7] = 0;
		te[11] = 0;
		te[12] = 0;
		te[13] = 0;
		te[14] = 0;
		te[15] = 1;
		return this;
	}
	/**
	* Sets the rotation component of this matrix to the rotation specified by
	* the given Quaternion as outlined [here](https://en.wikipedia.org/wiki/Rotation_matrix#Quaternion)
	* The rest of the matrix is set to the identity.
	*
	* @param {Quaternion} q - The Quaternion.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeRotationFromQuaternion(q) {
		return this.compose(_zero, q, _one);
	}
	/**
	* Sets the rotation component of the transformation matrix, looking from `eye` towards
	* `target`, and oriented by the up-direction.
	*
	* @param {Vector3} eye - The eye vector.
	* @param {Vector3} target - The target vector.
	* @param {Vector3} up - The up vector.
	* @return {Matrix4} A reference to this matrix.
	*/
	lookAt(eye, target, up) {
		const te = this.elements;
		_z.subVectors(eye, target);
		if (_z.lengthSq() === 0) _z.z = 1;
		_z.normalize();
		_x.crossVectors(up, _z);
		if (_x.lengthSq() === 0) {
			if (Math.abs(up.z) === 1) _z.x += 1e-4;
			else _z.z += 1e-4;
			_z.normalize();
			_x.crossVectors(up, _z);
		}
		_x.normalize();
		_y.crossVectors(_z, _x);
		te[0] = _x.x;
		te[4] = _y.x;
		te[8] = _z.x;
		te[1] = _x.y;
		te[5] = _y.y;
		te[9] = _z.y;
		te[2] = _x.z;
		te[6] = _y.z;
		te[10] = _z.z;
		return this;
	}
	/**
	* Post-multiplies this matrix by the given 4x4 matrix.
	*
	* @param {Matrix4} m - The matrix to multiply with.
	* @return {Matrix4} A reference to this matrix.
	*/
	multiply(m) {
		return this.multiplyMatrices(this, m);
	}
	/**
	* Pre-multiplies this matrix by the given 4x4 matrix.
	*
	* @param {Matrix4} m - The matrix to multiply with.
	* @return {Matrix4} A reference to this matrix.
	*/
	premultiply(m) {
		return this.multiplyMatrices(m, this);
	}
	/**
	* Multiples the given 4x4 matrices and stores the result
	* in this matrix.
	*
	* @param {Matrix4} a - The first matrix.
	* @param {Matrix4} b - The second matrix.
	* @return {Matrix4} A reference to this matrix.
	*/
	multiplyMatrices(a, b) {
		const ae = a.elements;
		const be = b.elements;
		const te = this.elements;
		const a11 = ae[0], a12 = ae[4], a13 = ae[8], a14 = ae[12];
		const a21 = ae[1], a22 = ae[5], a23 = ae[9], a24 = ae[13];
		const a31 = ae[2], a32 = ae[6], a33 = ae[10], a34 = ae[14];
		const a41 = ae[3], a42 = ae[7], a43 = ae[11], a44 = ae[15];
		const b11 = be[0], b12 = be[4], b13 = be[8], b14 = be[12];
		const b21 = be[1], b22 = be[5], b23 = be[9], b24 = be[13];
		const b31 = be[2], b32 = be[6], b33 = be[10], b34 = be[14];
		const b41 = be[3], b42 = be[7], b43 = be[11], b44 = be[15];
		te[0] = a11 * b11 + a12 * b21 + a13 * b31 + a14 * b41;
		te[4] = a11 * b12 + a12 * b22 + a13 * b32 + a14 * b42;
		te[8] = a11 * b13 + a12 * b23 + a13 * b33 + a14 * b43;
		te[12] = a11 * b14 + a12 * b24 + a13 * b34 + a14 * b44;
		te[1] = a21 * b11 + a22 * b21 + a23 * b31 + a24 * b41;
		te[5] = a21 * b12 + a22 * b22 + a23 * b32 + a24 * b42;
		te[9] = a21 * b13 + a22 * b23 + a23 * b33 + a24 * b43;
		te[13] = a21 * b14 + a22 * b24 + a23 * b34 + a24 * b44;
		te[2] = a31 * b11 + a32 * b21 + a33 * b31 + a34 * b41;
		te[6] = a31 * b12 + a32 * b22 + a33 * b32 + a34 * b42;
		te[10] = a31 * b13 + a32 * b23 + a33 * b33 + a34 * b43;
		te[14] = a31 * b14 + a32 * b24 + a33 * b34 + a34 * b44;
		te[3] = a41 * b11 + a42 * b21 + a43 * b31 + a44 * b41;
		te[7] = a41 * b12 + a42 * b22 + a43 * b32 + a44 * b42;
		te[11] = a41 * b13 + a42 * b23 + a43 * b33 + a44 * b43;
		te[15] = a41 * b14 + a42 * b24 + a43 * b34 + a44 * b44;
		return this;
	}
	/**
	* Multiplies every component of the matrix by the given scalar.
	*
	* @param {number} s - The scalar.
	* @return {Matrix4} A reference to this matrix.
	*/
	multiplyScalar(s) {
		const te = this.elements;
		te[0] *= s;
		te[4] *= s;
		te[8] *= s;
		te[12] *= s;
		te[1] *= s;
		te[5] *= s;
		te[9] *= s;
		te[13] *= s;
		te[2] *= s;
		te[6] *= s;
		te[10] *= s;
		te[14] *= s;
		te[3] *= s;
		te[7] *= s;
		te[11] *= s;
		te[15] *= s;
		return this;
	}
	/**
	* Computes and returns the determinant of this matrix.
	*
	* @return {number} The determinant.
	*/
	determinant() {
		const te = this.elements;
		const n11 = te[0], n12 = te[4], n13 = te[8], n14 = te[12];
		const n21 = te[1], n22 = te[5], n23 = te[9], n24 = te[13];
		const n31 = te[2], n32 = te[6], n33 = te[10], n34 = te[14];
		const n41 = te[3], n42 = te[7], n43 = te[11], n44 = te[15];
		const t11 = n23 * n34 - n24 * n33;
		const t12 = n22 * n34 - n24 * n32;
		const t13 = n22 * n33 - n23 * n32;
		const t21 = n21 * n34 - n24 * n31;
		const t22 = n21 * n33 - n23 * n31;
		const t23 = n21 * n32 - n22 * n31;
		return n11 * (n42 * t11 - n43 * t12 + n44 * t13) - n12 * (n41 * t11 - n43 * t21 + n44 * t22) + n13 * (n41 * t12 - n42 * t21 + n44 * t23) - n14 * (n41 * t13 - n42 * t22 + n43 * t23);
	}
	/**
	* Computes and returns the determinant of the 4x4 matrix, but assumes the
	* matrix is affine, saving some computations.
	*
	* For affine matrices (like an object's world matrix), this value equals the
	* full 4x4 {@link Matrix4#determinant} but is cheaper to compute.
	*
	* Assumes the bottom row is [0, 0, 0, 1].
	*
	* @return {number} The determinant of the matrix.
	*/
	determinantAffine() {
		const te = this.elements;
		const n11 = te[0], n12 = te[4], n13 = te[8];
		const n21 = te[1], n22 = te[5], n23 = te[9];
		const n31 = te[2], n32 = te[6], n33 = te[10];
		return n11 * (n22 * n33 - n23 * n32) - n12 * (n21 * n33 - n23 * n31) + n13 * (n21 * n32 - n22 * n31);
	}
	/**
	* Transposes this matrix in place.
	*
	* @return {Matrix4} A reference to this matrix.
	*/
	transpose() {
		const te = this.elements;
		let tmp;
		tmp = te[1];
		te[1] = te[4];
		te[4] = tmp;
		tmp = te[2];
		te[2] = te[8];
		te[8] = tmp;
		tmp = te[6];
		te[6] = te[9];
		te[9] = tmp;
		tmp = te[3];
		te[3] = te[12];
		te[12] = tmp;
		tmp = te[7];
		te[7] = te[13];
		te[13] = tmp;
		tmp = te[11];
		te[11] = te[14];
		te[14] = tmp;
		return this;
	}
	/**
	* Sets the position component for this matrix from the given vector,
	* without affecting the rest of the matrix.
	*
	* @param {number|Vector3} x - The x component of the vector or alternatively the vector object.
	* @param {number} y - The y component of the vector.
	* @param {number} z - The z component of the vector.
	* @return {Matrix4} A reference to this matrix.
	*/
	setPosition(x, y, z) {
		const te = this.elements;
		if (x.isVector3) {
			te[12] = x.x;
			te[13] = x.y;
			te[14] = x.z;
		} else {
			te[12] = x;
			te[13] = y;
			te[14] = z;
		}
		return this;
	}
	/**
	* Inverts this matrix, using the [analytic method](https://en.wikipedia.org/wiki/Invertible_matrix#Analytic_solution).
	* You can not invert with a determinant of zero. If you attempt this, the method produces
	* a zero matrix instead.
	*
	* @return {Matrix4} A reference to this matrix.
	*/
	invert() {
		const te = this.elements, n11 = te[0], n21 = te[1], n31 = te[2], n41 = te[3], n12 = te[4], n22 = te[5], n32 = te[6], n42 = te[7], n13 = te[8], n23 = te[9], n33 = te[10], n43 = te[11], n14 = te[12], n24 = te[13], n34 = te[14], n44 = te[15], t1 = n11 * n22 - n21 * n12, t2 = n11 * n32 - n31 * n12, t3 = n11 * n42 - n41 * n12, t4 = n21 * n32 - n31 * n22, t5 = n21 * n42 - n41 * n22, t6 = n31 * n42 - n41 * n32, t7 = n13 * n24 - n23 * n14, t8 = n13 * n34 - n33 * n14, t9 = n13 * n44 - n43 * n14, t10 = n23 * n34 - n33 * n24, t11 = n23 * n44 - n43 * n24, t12 = n33 * n44 - n43 * n34;
		const det = t1 * t12 - t2 * t11 + t3 * t10 + t4 * t9 - t5 * t8 + t6 * t7;
		if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		const detInv = 1 / det;
		te[0] = (n22 * t12 - n32 * t11 + n42 * t10) * detInv;
		te[1] = (n31 * t11 - n21 * t12 - n41 * t10) * detInv;
		te[2] = (n24 * t6 - n34 * t5 + n44 * t4) * detInv;
		te[3] = (n33 * t5 - n23 * t6 - n43 * t4) * detInv;
		te[4] = (n32 * t9 - n12 * t12 - n42 * t8) * detInv;
		te[5] = (n11 * t12 - n31 * t9 + n41 * t8) * detInv;
		te[6] = (n34 * t3 - n14 * t6 - n44 * t2) * detInv;
		te[7] = (n13 * t6 - n33 * t3 + n43 * t2) * detInv;
		te[8] = (n12 * t11 - n22 * t9 + n42 * t7) * detInv;
		te[9] = (n21 * t9 - n11 * t11 - n41 * t7) * detInv;
		te[10] = (n14 * t5 - n24 * t3 + n44 * t1) * detInv;
		te[11] = (n23 * t3 - n13 * t5 - n43 * t1) * detInv;
		te[12] = (n22 * t8 - n12 * t10 - n32 * t7) * detInv;
		te[13] = (n11 * t10 - n21 * t8 + n31 * t7) * detInv;
		te[14] = (n24 * t2 - n14 * t4 - n34 * t1) * detInv;
		te[15] = (n13 * t4 - n23 * t2 + n33 * t1) * detInv;
		return this;
	}
	/**
	* Scales each of the first three columns of this matrix by the corresponding component of the given vector.
	*
	* @param {Vector3} v - The scale vector.
	* @return {Matrix4} A reference to this matrix.
	*/
	scale(v) {
		const te = this.elements;
		const x = v.x, y = v.y, z = v.z;
		te[0] *= x;
		te[4] *= y;
		te[8] *= z;
		te[1] *= x;
		te[5] *= y;
		te[9] *= z;
		te[2] *= x;
		te[6] *= y;
		te[10] *= z;
		te[3] *= x;
		te[7] *= y;
		te[11] *= z;
		return this;
	}
	/**
	* Gets the maximum scale value of the three axes.
	*
	* @return {number} The maximum scale.
	*/
	getMaxScaleOnAxis() {
		const te = this.elements;
		const scaleXSq = te[0] * te[0] + te[1] * te[1] + te[2] * te[2];
		const scaleYSq = te[4] * te[4] + te[5] * te[5] + te[6] * te[6];
		const scaleZSq = te[8] * te[8] + te[9] * te[9] + te[10] * te[10];
		return Math.sqrt(Math.max(scaleXSq, scaleYSq, scaleZSq));
	}
	/**
	* Sets this matrix as a translation transform from the given vector.
	*
	* @param {number|Vector3} x - The amount to translate in the X axis or alternatively a translation vector.
	* @param {number} y - The amount to translate in the Y axis.
	* @param {number} z - The amount to translate in the z axis.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeTranslation(x, y, z) {
		if (x.isVector3) this.set(1, 0, 0, x.x, 0, 1, 0, x.y, 0, 0, 1, x.z, 0, 0, 0, 1);
		else this.set(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a rotational transformation around the X axis by
	* the given angle.
	*
	* @param {number} theta - The rotation in radians.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeRotationX(theta) {
		const c = Math.cos(theta), s = Math.sin(theta);
		this.set(1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a rotational transformation around the Y axis by
	* the given angle.
	*
	* @param {number} theta - The rotation in radians.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeRotationY(theta) {
		const c = Math.cos(theta), s = Math.sin(theta);
		this.set(c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a rotational transformation around the Z axis by
	* the given angle.
	*
	* @param {number} theta - The rotation in radians.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeRotationZ(theta) {
		const c = Math.cos(theta), s = Math.sin(theta);
		this.set(c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a rotational transformation around the given axis by
	* the given angle.
	*
	* @param {Vector3} axis - The normalized rotation axis.
	* @param {number} angle - The rotation in radians.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeRotationAxis(axis, angle) {
		const c = Math.cos(angle);
		const s = Math.sin(angle);
		const t = 1 - c;
		const x = axis.x, y = axis.y, z = axis.z;
		const tx = t * x, ty = t * y;
		this.set(tx * x + c, tx * y - s * z, tx * z + s * y, 0, tx * y + s * z, ty * y + c, ty * z - s * x, 0, tx * z - s * y, ty * z + s * x, t * z * z + c, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a scale transformation.
	*
	* @param {number} x - The amount to scale in the X axis.
	* @param {number} y - The amount to scale in the Y axis.
	* @param {number} z - The amount to scale in the Z axis.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeScale(x, y, z) {
		this.set(x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix as a shear transformation.
	*
	* @param {number} xy - The amount to shear X by Y.
	* @param {number} xz - The amount to shear X by Z.
	* @param {number} yx - The amount to shear Y by X.
	* @param {number} yz - The amount to shear Y by Z.
	* @param {number} zx - The amount to shear Z by X.
	* @param {number} zy - The amount to shear Z by Y.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeShear(xy, xz, yx, yz, zx, zy) {
		this.set(1, yx, zx, 0, xy, 1, zy, 0, xz, yz, 1, 0, 0, 0, 0, 1);
		return this;
	}
	/**
	* Sets this matrix to the transformation composed of the given position,
	* rotation (Quaternion) and scale.
	*
	* @param {Vector3} position - The position vector.
	* @param {Quaternion} quaternion - The rotation as a Quaternion.
	* @param {Vector3} scale - The scale vector.
	* @return {Matrix4} A reference to this matrix.
	*/
	compose(position, quaternion, scale) {
		const te = this.elements;
		const x = quaternion._x, y = quaternion._y, z = quaternion._z, w = quaternion._w;
		const x2 = x + x, y2 = y + y, z2 = z + z;
		const xx = x * x2, xy = x * y2, xz = x * z2;
		const yy = y * y2, yz = y * z2, zz = z * z2;
		const wx = w * x2, wy = w * y2, wz = w * z2;
		const sx = scale.x, sy = scale.y, sz = scale.z;
		te[0] = (1 - (yy + zz)) * sx;
		te[1] = (xy + wz) * sx;
		te[2] = (xz - wy) * sx;
		te[3] = 0;
		te[4] = (xy - wz) * sy;
		te[5] = (1 - (xx + zz)) * sy;
		te[6] = (yz + wx) * sy;
		te[7] = 0;
		te[8] = (xz + wy) * sz;
		te[9] = (yz - wx) * sz;
		te[10] = (1 - (xx + yy)) * sz;
		te[11] = 0;
		te[12] = position.x;
		te[13] = position.y;
		te[14] = position.z;
		te[15] = 1;
		return this;
	}
	/**
	* Decomposes this matrix into its position, rotation and scale components
	* and provides the result in the given objects.
	*
	* Note: Not all matrices are decomposable in this way. For example, if an
	* object has a non-uniformly scaled parent, then the object's world matrix
	* may not be decomposable, and this method may not be appropriate.
	*
	* @param {Vector3} position - The position vector.
	* @param {Quaternion} quaternion - The rotation as a Quaternion.
	* @param {Vector3} scale - The scale vector.
	* @return {Matrix4} A reference to this matrix.
	*/
	decompose(position, quaternion, scale) {
		const te = this.elements;
		position.x = te[12];
		position.y = te[13];
		position.z = te[14];
		const det = this.determinantAffine();
		if (det === 0) {
			scale.set(1, 1, 1);
			quaternion.identity();
			return this;
		}
		let sx = _v1$7.set(te[0], te[1], te[2]).length();
		const sy = _v1$7.set(te[4], te[5], te[6]).length();
		const sz = _v1$7.set(te[8], te[9], te[10]).length();
		if (det < 0) sx = -sx;
		_m1$2.copy(this);
		const invSX = 1 / sx;
		const invSY = 1 / sy;
		const invSZ = 1 / sz;
		_m1$2.elements[0] *= invSX;
		_m1$2.elements[1] *= invSX;
		_m1$2.elements[2] *= invSX;
		_m1$2.elements[4] *= invSY;
		_m1$2.elements[5] *= invSY;
		_m1$2.elements[6] *= invSY;
		_m1$2.elements[8] *= invSZ;
		_m1$2.elements[9] *= invSZ;
		_m1$2.elements[10] *= invSZ;
		quaternion.setFromRotationMatrix(_m1$2);
		scale.x = sx;
		scale.y = sy;
		scale.z = sz;
		return this;
	}
	/**
	* Creates a perspective projection matrix. This is used internally by
	* {@link PerspectiveCamera#updateProjectionMatrix}.
	
	* @param {number} left - Left boundary of the viewing frustum at the near plane.
	* @param {number} right - Right boundary of the viewing frustum at the near plane.
	* @param {number} top - Top boundary of the viewing frustum at the near plane.
	* @param {number} bottom - Bottom boundary of the viewing frustum at the near plane.
	* @param {number} near - The distance from the camera to the near plane.
	* @param {number} far - The distance from the camera to the far plane.
	* @param {(WebGLCoordinateSystem|WebGPUCoordinateSystem)} [coordinateSystem=WebGLCoordinateSystem] - The coordinate system.
	* @param {boolean} [reversedDepth=false] - Whether to use a reversed depth.
	* @return {Matrix4} A reference to this matrix.
	*/
	makePerspective(left, right, top, bottom, near, far, coordinateSystem = WebGLCoordinateSystem, reversedDepth = false) {
		const te = this.elements;
		const x = 2 * near / (right - left);
		const y = 2 * near / (top - bottom);
		const a = (right + left) / (right - left);
		const b = (top + bottom) / (top - bottom);
		let c, d;
		if (reversedDepth) {
			c = near / (far - near);
			d = far * near / (far - near);
		} else if (coordinateSystem === 2e3) {
			c = -(far + near) / (far - near);
			d = -2 * far * near / (far - near);
		} else if (coordinateSystem === 2001) {
			c = -far / (far - near);
			d = -far * near / (far - near);
		} else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + coordinateSystem);
		te[0] = x;
		te[4] = 0;
		te[8] = a;
		te[12] = 0;
		te[1] = 0;
		te[5] = y;
		te[9] = b;
		te[13] = 0;
		te[2] = 0;
		te[6] = 0;
		te[10] = c;
		te[14] = d;
		te[3] = 0;
		te[7] = 0;
		te[11] = -1;
		te[15] = 0;
		return this;
	}
	/**
	* Creates a orthographic projection matrix. This is used internally by
	* {@link OrthographicCamera#updateProjectionMatrix}.
	
	* @param {number} left - Left boundary of the viewing frustum at the near plane.
	* @param {number} right - Right boundary of the viewing frustum at the near plane.
	* @param {number} top - Top boundary of the viewing frustum at the near plane.
	* @param {number} bottom - Bottom boundary of the viewing frustum at the near plane.
	* @param {number} near - The distance from the camera to the near plane.
	* @param {number} far - The distance from the camera to the far plane.
	* @param {(WebGLCoordinateSystem|WebGPUCoordinateSystem)} [coordinateSystem=WebGLCoordinateSystem] - The coordinate system.
	* @param {boolean} [reversedDepth=false] - Whether to use a reversed depth.
	* @return {Matrix4} A reference to this matrix.
	*/
	makeOrthographic(left, right, top, bottom, near, far, coordinateSystem = WebGLCoordinateSystem, reversedDepth = false) {
		const te = this.elements;
		const x = 2 / (right - left);
		const y = 2 / (top - bottom);
		const a = -(right + left) / (right - left);
		const b = -(top + bottom) / (top - bottom);
		let c, d;
		if (reversedDepth) {
			c = 1 / (far - near);
			d = far / (far - near);
		} else if (coordinateSystem === 2e3) {
			c = -2 / (far - near);
			d = -(far + near) / (far - near);
		} else if (coordinateSystem === 2001) {
			c = -1 / (far - near);
			d = -near / (far - near);
		} else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + coordinateSystem);
		te[0] = x;
		te[4] = 0;
		te[8] = 0;
		te[12] = a;
		te[1] = 0;
		te[5] = y;
		te[9] = 0;
		te[13] = b;
		te[2] = 0;
		te[6] = 0;
		te[10] = c;
		te[14] = d;
		te[3] = 0;
		te[7] = 0;
		te[11] = 0;
		te[15] = 1;
		return this;
	}
	/**
	* Returns `true` if this matrix is equal with the given one.
	*
	* @param {Matrix4} matrix - The matrix to test for equality.
	* @return {boolean} Whether this matrix is equal with the given one.
	*/
	equals(matrix) {
		const te = this.elements;
		const me = matrix.elements;
		for (let i = 0; i < 16; i++) if (te[i] !== me[i]) return false;
		return true;
	}
	/**
	* Sets the elements of the matrix from the given array.
	*
	* @param {Array<number>} array - The matrix elements in column-major order.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Matrix4} A reference to this matrix.
	*/
	fromArray(array, offset = 0) {
		for (let i = 0; i < 16; i++) this.elements[i] = array[i + offset];
		return this;
	}
	/**
	* Writes the elements of this matrix to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the matrix elements in column-major order.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The matrix elements in column-major order.
	*/
	toArray(array = [], offset = 0) {
		const te = this.elements;
		array[offset] = te[0];
		array[offset + 1] = te[1];
		array[offset + 2] = te[2];
		array[offset + 3] = te[3];
		array[offset + 4] = te[4];
		array[offset + 5] = te[5];
		array[offset + 6] = te[6];
		array[offset + 7] = te[7];
		array[offset + 8] = te[8];
		array[offset + 9] = te[9];
		array[offset + 10] = te[10];
		array[offset + 11] = te[11];
		array[offset + 12] = te[12];
		array[offset + 13] = te[13];
		array[offset + 14] = te[14];
		array[offset + 15] = te[15];
		return array;
	}
};
const _v1$7 = /*@__PURE__*/ new Vector3();
const _m1$2 = /*@__PURE__*/ new Matrix4();
const _zero = /*@__PURE__*/ new Vector3(0, 0, 0);
const _one = /*@__PURE__*/ new Vector3(1, 1, 1);
const _x = /*@__PURE__*/ new Vector3();
const _y = /*@__PURE__*/ new Vector3();
const _z = /*@__PURE__*/ new Vector3();
const _matrix$2 = /*@__PURE__*/ new Matrix4();
const _quaternion$4 = /*@__PURE__*/ new Quaternion();
/**
* A class representing Euler angles.
*
* Euler angles describe a rotational transformation by rotating an object on
* its various axes in specified amounts per axis, and a specified axis
* order.
*
* Iterating through an instance will yield its components (x, y, z,
* order) in the corresponding order.
*
* ```js
* const a = new THREE.Euler( 0, 1, 1.57, 'XYZ' );
* const b = new THREE.Vector3( 1, 0, 1 );
* b.applyEuler(a);
* ```
*/
var Euler = class Euler {
	/**
	* Constructs a new euler instance.
	*
	* @param {number} [x=0] - The angle of the x axis in radians.
	* @param {number} [y=0] - The angle of the y axis in radians.
	* @param {number} [z=0] - The angle of the z axis in radians.
	* @param {string} [order=Euler.DEFAULT_ORDER] - A string representing the order that the rotations are applied.
	*/
	constructor(x = 0, y = 0, z = 0, order = Euler.DEFAULT_ORDER) {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		this.isEuler = true;
		this._x = x;
		this._y = y;
		this._z = z;
		this._order = order;
	}
	/**
	* The angle of the x axis in radians.
	*
	* @type {number}
	* @default 0
	*/
	get x() {
		return this._x;
	}
	set x(value) {
		this._x = value;
		this._onChangeCallback();
	}
	/**
	* The angle of the y axis in radians.
	*
	* @type {number}
	* @default 0
	*/
	get y() {
		return this._y;
	}
	set y(value) {
		this._y = value;
		this._onChangeCallback();
	}
	/**
	* The angle of the z axis in radians.
	*
	* @type {number}
	* @default 0
	*/
	get z() {
		return this._z;
	}
	set z(value) {
		this._z = value;
		this._onChangeCallback();
	}
	/**
	* A string representing the order that the rotations are applied.
	*
	* @type {string}
	* @default 'XYZ'
	*/
	get order() {
		return this._order;
	}
	set order(value) {
		this._order = value;
		this._onChangeCallback();
	}
	/**
	* Sets the Euler components.
	*
	* @param {number} x - The angle of the x axis in radians.
	* @param {number} y - The angle of the y axis in radians.
	* @param {number} z - The angle of the z axis in radians.
	* @param {string} [order] - A string representing the order that the rotations are applied.
	* @return {Euler} A reference to this Euler instance.
	*/
	set(x, y, z, order = this._order) {
		this._x = x;
		this._y = y;
		this._z = z;
		this._order = order;
		this._onChangeCallback();
		return this;
	}
	/**
	* Returns a new Euler instance with copied values from this instance.
	*
	* @return {Euler} A clone of this instance.
	*/
	clone() {
		return new this.constructor(this._x, this._y, this._z, this._order);
	}
	/**
	* Copies the values of the given Euler instance to this instance.
	*
	* @param {Euler} euler - The Euler instance to copy.
	* @return {Euler} A reference to this Euler instance.
	*/
	copy(euler) {
		this._x = euler._x;
		this._y = euler._y;
		this._z = euler._z;
		this._order = euler._order;
		this._onChangeCallback();
		return this;
	}
	/**
	* Sets the angles of this Euler instance from a pure rotation matrix.
	*
	* @param {Matrix4} m - A 4x4 matrix of which the upper 3x3 of matrix is a pure rotation matrix (i.e. unscaled).
	* @param {string} [order] - A string representing the order that the rotations are applied.
	* @param {boolean} [update=true] - Whether the internal `onChange` callback should be executed or not.
	* @return {Euler} A reference to this Euler instance.
	*/
	setFromRotationMatrix(m, order = this._order, update = true) {
		const te = m.elements;
		const m11 = te[0], m12 = te[4], m13 = te[8];
		const m21 = te[1], m22 = te[5], m23 = te[9];
		const m31 = te[2], m32 = te[6], m33 = te[10];
		switch (order) {
			case "XYZ":
				this._y = Math.asin(clamp$1(m13, -1, 1));
				if (Math.abs(m13) < .9999999) {
					this._x = Math.atan2(-m23, m33);
					this._z = Math.atan2(-m12, m11);
				} else {
					this._x = Math.atan2(m32, m22);
					this._z = 0;
				}
				break;
			case "YXZ":
				this._x = Math.asin(-clamp$1(m23, -1, 1));
				if (Math.abs(m23) < .9999999) {
					this._y = Math.atan2(m13, m33);
					this._z = Math.atan2(m21, m22);
				} else {
					this._y = Math.atan2(-m31, m11);
					this._z = 0;
				}
				break;
			case "ZXY":
				this._x = Math.asin(clamp$1(m32, -1, 1));
				if (Math.abs(m32) < .9999999) {
					this._y = Math.atan2(-m31, m33);
					this._z = Math.atan2(-m12, m22);
				} else {
					this._y = 0;
					this._z = Math.atan2(m21, m11);
				}
				break;
			case "ZYX":
				this._y = Math.asin(-clamp$1(m31, -1, 1));
				if (Math.abs(m31) < .9999999) {
					this._x = Math.atan2(m32, m33);
					this._z = Math.atan2(m21, m11);
				} else {
					this._x = 0;
					this._z = Math.atan2(-m12, m22);
				}
				break;
			case "YZX":
				this._z = Math.asin(clamp$1(m21, -1, 1));
				if (Math.abs(m21) < .9999999) {
					this._x = Math.atan2(-m23, m22);
					this._y = Math.atan2(-m31, m11);
				} else {
					this._x = 0;
					this._y = Math.atan2(m13, m33);
				}
				break;
			case "XZY":
				this._z = Math.asin(-clamp$1(m12, -1, 1));
				if (Math.abs(m12) < .9999999) {
					this._x = Math.atan2(m32, m22);
					this._y = Math.atan2(m13, m11);
				} else {
					this._x = Math.atan2(-m23, m33);
					this._y = 0;
				}
				break;
			default: warn("Euler: .setFromRotationMatrix() encountered an unknown order: " + order);
		}
		this._order = order;
		if (update === true) this._onChangeCallback();
		return this;
	}
	/**
	* Sets the angles of this Euler instance from a normalized quaternion.
	*
	* @param {Quaternion} q - A normalized Quaternion.
	* @param {string} [order] - A string representing the order that the rotations are applied.
	* @param {boolean} [update=true] - Whether the internal `onChange` callback should be executed or not.
	* @return {Euler} A reference to this Euler instance.
	*/
	setFromQuaternion(q, order, update) {
		_matrix$2.makeRotationFromQuaternion(q);
		return this.setFromRotationMatrix(_matrix$2, order, update);
	}
	/**
	* Sets the angles of this Euler instance from the given vector.
	*
	* @param {Vector3} v - The vector.
	* @param {string} [order] - A string representing the order that the rotations are applied.
	* @return {Euler} A reference to this Euler instance.
	*/
	setFromVector3(v, order = this._order) {
		return this.set(v.x, v.y, v.z, order);
	}
	/**
	* Resets the euler angle with a new order by creating a quaternion from this
	* euler angle and then setting this euler angle with the quaternion and the
	* new order.
	*
	* Warning: This discards revolution information.
	*
	* @param {string} [newOrder] - A string representing the new order that the rotations are applied.
	* @return {Euler} A reference to this Euler instance.
	*/
	reorder(newOrder) {
		_quaternion$4.setFromEuler(this);
		return this.setFromQuaternion(_quaternion$4, newOrder);
	}
	/**
	* Returns `true` if this Euler instance is equal with the given one.
	*
	* @param {Euler} euler - The Euler instance to test for equality.
	* @return {boolean} Whether this Euler instance is equal with the given one.
	*/
	equals(euler) {
		return euler._x === this._x && euler._y === this._y && euler._z === this._z && euler._order === this._order;
	}
	/**
	* Sets this Euler instance's components to values from the given array. The first three
	* entries of the array are assign to the x,y and z components. An optional fourth entry
	* defines the Euler order.
	*
	* @param {Array<number,number,number,?string>} array - An array holding the Euler component values.
	* @return {Euler} A reference to this Euler instance.
	*/
	fromArray(array) {
		this._x = array[0];
		this._y = array[1];
		this._z = array[2];
		if (array[3] !== void 0) this._order = array[3];
		this._onChangeCallback();
		return this;
	}
	/**
	* Writes the components of this Euler instance to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number,number,number,string>} [array=[]] - The target array holding the Euler components.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number,number,number,string>} The Euler components.
	*/
	toArray(array = [], offset = 0) {
		array[offset] = this._x;
		array[offset + 1] = this._y;
		array[offset + 2] = this._z;
		array[offset + 3] = this._order;
		return array;
	}
	_onChange(callback) {
		this._onChangeCallback = callback;
		return this;
	}
	_onChangeCallback() {}
	*[Symbol.iterator]() {
		yield this._x;
		yield this._y;
		yield this._z;
		yield this._order;
	}
};
/**
* The default Euler angle order.
*
* @static
* @type {string}
* @default 'XYZ'
*/
Euler.DEFAULT_ORDER = "XYZ";
/**
* A layers object assigns an 3D object to 1 or more of 32
* layers numbered `0` to `31` - internally the layers are stored as a
* bit mask], and by default all 3D objects are a member of layer `0`.
*
* This can be used to control visibility - an object must share a layer with
* a camera to be visible when that camera's view is
* rendered.
*
* All classes that inherit from {@link Object3D} have an `layers` property which
* is an instance of this class.
*/
var Layers = class {
	/**
	* Constructs a new layers instance, with membership
	* initially set to layer `0`.
	*/
	constructor() {
		/**
		* A bit mask storing which of the 32 layers this layers object is currently
		* a member of.
		*
		* @type {number}
		*/
		this.mask = 1;
	}
	/**
	* Sets membership to the given layer, and remove membership all other layers.
	*
	* @param {number} layer - The layer to set.
	*/
	set(layer) {
		this.mask = (1 << layer | 0) >>> 0;
	}
	/**
	* Adds membership of the given layer.
	*
	* @param {number} layer - The layer to enable.
	*/
	enable(layer) {
		this.mask |= 1 << layer | 0;
	}
	/**
	* Adds membership to all layers.
	*/
	enableAll() {
		this.mask = -1;
	}
	/**
	* Toggles the membership of the given layer.
	*
	* @param {number} layer - The layer to toggle.
	*/
	toggle(layer) {
		this.mask ^= 1 << layer | 0;
	}
	/**
	* Removes membership of the given layer.
	*
	* @param {number} layer - The layer to enable.
	*/
	disable(layer) {
		this.mask &= ~(1 << layer | 0);
	}
	/**
	* Removes the membership from all layers.
	*/
	disableAll() {
		this.mask = 0;
	}
	/**
	* Returns `true` if this and the given layers object have at least one
	* layer in common.
	*
	* @param {Layers} layers - The layers to test.
	* @return {boolean } Whether this and the given layers object have at least one layer in common or not.
	*/
	test(layers) {
		return (this.mask & layers.mask) !== 0;
	}
	/**
	* Returns `true` if the given layer is enabled.
	*
	* @param {number} layer - The layer to test.
	* @return {boolean } Whether the given layer is enabled or not.
	*/
	isEnabled(layer) {
		return (this.mask & (1 << layer | 0)) !== 0;
	}
};
let _object3DId = 0;
const _v1$6 = /*@__PURE__*/ new Vector3();
const _q1 = /*@__PURE__*/ new Quaternion();
const _m1$1 = /*@__PURE__*/ new Matrix4();
const _target = /*@__PURE__*/ new Vector3();
const _position$4 = /*@__PURE__*/ new Vector3();
const _scale$3 = /*@__PURE__*/ new Vector3();
const _quaternion$3 = /*@__PURE__*/ new Quaternion();
const _xAxis = /*@__PURE__*/ new Vector3(1, 0, 0);
const _yAxis = /*@__PURE__*/ new Vector3(0, 1, 0);
const _zAxis = /*@__PURE__*/ new Vector3(0, 0, 1);
/**
* Fires when the object has been added to its parent object.
*
* @event Object3D#added
* @type {Object}
*/
const _addedEvent = { type: "added" };
/**
* Fires when the object has been removed from its parent object.
*
* @event Object3D#removed
* @type {Object}
*/
const _removedEvent = { type: "removed" };
/**
* Fires when a new child object has been added.
*
* @event Object3D#childadded
* @type {Object}
*/
const _childaddedEvent = {
	type: "childadded",
	child: null
};
/**
* Fires when a child object has been removed.
*
* @event Object3D#childremoved
* @type {Object}
*/
const _childremovedEvent = {
	type: "childremoved",
	child: null
};
/**
* This is the base class for most objects in three.js and provides a set of
* properties and methods for manipulating objects in 3D space.
*
* @augments EventDispatcher
*/
var Object3D = class Object3D extends EventDispatcher {
	/**
	* Constructs a new 3D object.
	*/
	constructor() {
		super();
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		this.isObject3D = true;
		/**
		* The ID of the 3D object.
		*
		* @name Object3D#id
		* @type {number}
		* @readonly
		*/
		Object.defineProperty(this, "id", { value: _object3DId++ });
		/**
		* The UUID of the 3D object.
		*
		* @type {string}
		* @readonly
		*/
		this.uuid = generateUUID();
		/**
		* The name of the 3D object.
		*
		* @type {string}
		*/
		this.name = "";
		/**
		* The type property is used for detecting the object type
		* in context of serialization/deserialization.
		*
		* @type {string}
		* @readonly
		*/
		this.type = "Object3D";
		/**
		* A reference to the parent object.
		*
		* @type {?Object3D}
		* @default null
		*/
		this.parent = null;
		/**
		* An array holding the child 3D objects of this instance.
		*
		* @type {Array<Object3D>}
		*/
		this.children = [];
		/**
		* Defines the `up` direction of the 3D object which influences
		* the orientation via methods like {@link Object3D#lookAt}.
		*
		* The default values for all 3D objects is defined by `Object3D.DEFAULT_UP`.
		*
		* @type {Vector3}
		*/
		this.up = Object3D.DEFAULT_UP.clone();
		const position = new Vector3();
		const rotation = new Euler();
		const quaternion = new Quaternion();
		const scale = new Vector3(1, 1, 1);
		function onRotationChange() {
			quaternion.setFromEuler(rotation, false);
		}
		function onQuaternionChange() {
			rotation.setFromQuaternion(quaternion, void 0, false);
		}
		rotation._onChange(onRotationChange);
		quaternion._onChange(onQuaternionChange);
		Object.defineProperties(this, {
			/**
			* Represents the object's local position.
			*
			* @name Object3D#position
			* @type {Vector3}
			* @default (0,0,0)
			*/
			position: {
				configurable: true,
				enumerable: true,
				value: position
			},
			/**
			* Represents the object's local rotation as Euler angles, in radians.
			*
			* @name Object3D#rotation
			* @type {Euler}
			* @default (0,0,0)
			*/
			rotation: {
				configurable: true,
				enumerable: true,
				value: rotation
			},
			/**
			* Represents the object's local rotation as Quaternions.
			*
			* @name Object3D#quaternion
			* @type {Quaternion}
			*/
			quaternion: {
				configurable: true,
				enumerable: true,
				value: quaternion
			},
			/**
			* Represents the object's local scale.
			*
			* @name Object3D#scale
			* @type {Vector3}
			* @default (1,1,1)
			*/
			scale: {
				configurable: true,
				enumerable: true,
				value: scale
			},
			/**
			* Represents the object's model-view matrix.
			*
			* @name Object3D#modelViewMatrix
			* @type {Matrix4}
			*/
			modelViewMatrix: { value: new Matrix4() },
			/**
			* Represents the object's normal matrix.
			*
			* @name Object3D#normalMatrix
			* @type {Matrix3}
			*/
			normalMatrix: { value: new Matrix3() }
		});
		/**
		* Represents the object's transformation matrix in local space.
		*
		* @type {Matrix4}
		*/
		this.matrix = new Matrix4();
		/**
		* Represents the object's transformation matrix in world space.
		* If the 3D object has no parent, then it's identical to the local transformation matrix
		*
		* @type {Matrix4}
		*/
		this.matrixWorld = new Matrix4();
		/**
		* When set to `true`, the engine automatically computes the local matrix from position,
		* rotation and scale every frame. If set to `false`, the app is responsible for recomputing
		* the local matrix by calling `updateMatrix()`.
		*
		* The default values for all 3D objects is defined by `Object3D.DEFAULT_MATRIX_AUTO_UPDATE`.
		*
		* @type {boolean}
		* @default true
		*/
		this.matrixAutoUpdate = Object3D.DEFAULT_MATRIX_AUTO_UPDATE;
		/**
		* When set to `true`, the engine automatically computes the world matrix from the current local
		* matrix and the object's transformation hierarchy. If set to `false`, the app is responsible for
		* recomputing the world matrix by directly updating the `matrixWorld` property.
		*
		* The default values for all 3D objects is defined by `Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE`.
		*
		* @type {boolean}
		* @default true
		*/
		this.matrixWorldAutoUpdate = Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE;
		/**
		* When set to `true`, it calculates the world matrix in that frame and resets this property
		* to `false`.
		*
		* @type {boolean}
		* @default false
		*/
		this.matrixWorldNeedsUpdate = false;
		/**
		* The layer membership of the 3D object. The 3D object is only visible if it has
		* at least one layer in common with the camera in use. This property can also be
		* used to filter out unwanted objects in ray-intersection tests when using {@link Raycaster}.
		*
		* @type {Layers}
		*/
		this.layers = new Layers();
		/**
		* When set to `true`, the 3D object gets rendered.
		*
		* @type {boolean}
		* @default true
		*/
		this.visible = true;
		/**
		* When set to `true`, the 3D object gets rendered into shadow maps.
		*
		* @type {boolean}
		* @default false
		*/
		this.castShadow = false;
		/**
		* When set to `true`, the 3D object is affected by shadows in the scene.
		*
		* @type {boolean}
		* @default false
		*/
		this.receiveShadow = false;
		/**
		* When set to `true`, the 3D object is honored by view frustum culling.
		*
		* @type {boolean}
		* @default true
		*/
		this.frustumCulled = true;
		/**
		* This value allows the default rendering order of scene graph objects to be
		* overridden although opaque and transparent objects remain sorted independently.
		* When this property is set for an instance of {@link Group},all descendants
		* objects will be sorted and rendered together. Sorting is from lowest to highest
		* render order.
		*
		* @type {number}
		* @default 0
		*/
		this.renderOrder = 0;
		/**
		* An array holding the animation clips of the 3D object.
		*
		* @type {Array<AnimationClip>}
		*/
		this.animations = [];
		/**
		* Custom depth material to be used when rendering to the depth map. Can only be used
		* in context of meshes. When shadow-casting with a {@link DirectionalLight} or {@link SpotLight},
		* if you are modifying vertex positions in the vertex shader you must specify a custom depth
		* material for proper shadows.
		*
		* Only relevant in context of {@link WebGLRenderer}.
		*
		* @type {(Material|undefined)}
		* @default undefined
		*/
		this.customDepthMaterial = void 0;
		/**
		* Same as {@link Object3D#customDepthMaterial}, but used with {@link PointLight}.
		*
		* Only relevant in context of {@link WebGLRenderer}.
		*
		* @type {(Material|undefined)}
		* @default undefined
		*/
		this.customDistanceMaterial = void 0;
		/**
		* Whether the 3D object is supposed to be static or not. If set to `true`, it means
		* the 3D object is not going to be changed after the initial renderer. This includes
		* geometry and material settings. A static 3D object can be processed by the renderer
		* slightly faster since certain state checks can be bypassed.
		*
		* Only relevant in context of {@link WebGPURenderer}.
		*
		* @type {boolean}
		* @default false
		*/
		this.static = false;
		/**
		* An object that can be used to store custom data about the 3D object. It
		* should not hold references to functions as these will not be cloned.
		*
		* @type {Object}
		*/
		this.userData = {};
		/**
		* The pivot point for rotation and scale transformations.
		* When set, rotation and scale are applied around this point
		* instead of the object's origin.
		*
		* @type {?Vector3}
		* @default null
		*/
		this.pivot = null;
	}
	/**
	* A callback that is executed immediately before a 3D object is rendered to a shadow map.
	*
	* @param {Renderer|WebGLRenderer} renderer - The renderer.
	* @param {Object3D} object - The 3D object.
	* @param {Camera} camera - The camera that is used to render the scene.
	* @param {Camera} shadowCamera - The shadow camera.
	* @param {BufferGeometry} geometry - The 3D object's geometry.
	* @param {Material} depthMaterial - The depth material.
	* @param {Object} group - The geometry group data.
	*/
	onBeforeShadow() {}
	/**
	* A callback that is executed immediately after a 3D object is rendered to a shadow map.
	*
	* @param {Renderer|WebGLRenderer} renderer - The renderer.
	* @param {Object3D} object - The 3D object.
	* @param {Camera} camera - The camera that is used to render the scene.
	* @param {Camera} shadowCamera - The shadow camera.
	* @param {BufferGeometry} geometry - The 3D object's geometry.
	* @param {Material} depthMaterial - The depth material.
	* @param {Object} group - The geometry group data.
	*/
	onAfterShadow() {}
	/**
	* A callback that is executed immediately before a 3D object is rendered.
	*
	* @param {Renderer|WebGLRenderer} renderer - The renderer.
	* @param {Object3D} object - The 3D object.
	* @param {Camera} camera - The camera that is used to render the scene.
	* @param {BufferGeometry} geometry - The 3D object's geometry.
	* @param {Material} material - The 3D object's material.
	* @param {Object} group - The geometry group data.
	*/
	onBeforeRender() {}
	/**
	* A callback that is executed immediately after a 3D object is rendered.
	*
	* @param {Renderer|WebGLRenderer} renderer - The renderer.
	* @param {Object3D} object - The 3D object.
	* @param {Camera} camera - The camera that is used to render the scene.
	* @param {BufferGeometry} geometry - The 3D object's geometry.
	* @param {Material} material - The 3D object's material.
	* @param {Object} group - The geometry group data.
	*/
	onAfterRender() {}
	/**
	* Applies the given transformation matrix to the object and updates the object's position,
	* rotation and scale.
	*
	* @param {Matrix4} matrix - The transformation matrix.
	*/
	applyMatrix4(matrix) {
		if (this.matrixAutoUpdate) this.updateMatrix();
		this.matrix.premultiply(matrix);
		this.matrix.decompose(this.position, this.quaternion, this.scale);
	}
	/**
	* Applies a rotation represented by given the quaternion to the 3D object.
	*
	* @param {Quaternion} q - The quaternion.
	* @return {Object3D} A reference to this instance.
	*/
	applyQuaternion(q) {
		this.quaternion.premultiply(q);
		return this;
	}
	/**
	* Sets the given rotation represented as an axis/angle couple to the 3D object.
	*
	* @param {Vector3} axis - The (normalized) axis vector.
	* @param {number} angle - The angle in radians.
	*/
	setRotationFromAxisAngle(axis, angle) {
		this.quaternion.setFromAxisAngle(axis, angle);
	}
	/**
	* Sets the given rotation represented as Euler angles to the 3D object.
	*
	* @param {Euler} euler - The Euler angles.
	*/
	setRotationFromEuler(euler) {
		this.quaternion.setFromEuler(euler, true);
	}
	/**
	* Sets the given rotation represented as rotation matrix to the 3D object.
	*
	* @param {Matrix4} m - Although a 4x4 matrix is expected, the upper 3x3 portion must be
	* a pure rotation matrix (i.e, unscaled).
	*/
	setRotationFromMatrix(m) {
		this.quaternion.setFromRotationMatrix(m);
	}
	/**
	* Sets the given rotation represented as a Quaternion to the 3D object.
	*
	* @param {Quaternion} q - The Quaternion
	*/
	setRotationFromQuaternion(q) {
		this.quaternion.copy(q);
	}
	/**
	* Rotates the 3D object along an axis in local space.
	*
	* @param {Vector3} axis - The (normalized) axis vector.
	* @param {number} angle - The angle in radians.
	* @return {Object3D} A reference to this instance.
	*/
	rotateOnAxis(axis, angle) {
		_q1.setFromAxisAngle(axis, angle);
		this.quaternion.multiply(_q1);
		return this;
	}
	/**
	* Rotates the 3D object along an axis in world space.
	*
	* @param {Vector3} axis - The (normalized) axis vector.
	* @param {number} angle - The angle in radians.
	* @return {Object3D} A reference to this instance.
	*/
	rotateOnWorldAxis(axis, angle) {
		_q1.setFromAxisAngle(axis, angle);
		this.quaternion.premultiply(_q1);
		return this;
	}
	/**
	* Rotates the 3D object around its X axis in local space.
	*
	* @param {number} angle - The angle in radians.
	* @return {Object3D} A reference to this instance.
	*/
	rotateX(angle) {
		return this.rotateOnAxis(_xAxis, angle);
	}
	/**
	* Rotates the 3D object around its Y axis in local space.
	*
	* @param {number} angle - The angle in radians.
	* @return {Object3D} A reference to this instance.
	*/
	rotateY(angle) {
		return this.rotateOnAxis(_yAxis, angle);
	}
	/**
	* Rotates the 3D object around its Z axis in local space.
	*
	* @param {number} angle - The angle in radians.
	* @return {Object3D} A reference to this instance.
	*/
	rotateZ(angle) {
		return this.rotateOnAxis(_zAxis, angle);
	}
	/**
	* Translate the 3D object by a distance along the given axis in local space.
	*
	* @param {Vector3} axis - The (normalized) axis vector.
	* @param {number} distance - The distance in world units.
	* @return {Object3D} A reference to this instance.
	*/
	translateOnAxis(axis, distance) {
		_v1$6.copy(axis).applyQuaternion(this.quaternion);
		this.position.add(_v1$6.multiplyScalar(distance));
		return this;
	}
	/**
	* Translate the 3D object by a distance along its X-axis in local space.
	*
	* @param {number} distance - The distance in world units.
	* @return {Object3D} A reference to this instance.
	*/
	translateX(distance) {
		return this.translateOnAxis(_xAxis, distance);
	}
	/**
	* Translate the 3D object by a distance along its Y-axis in local space.
	*
	* @param {number} distance - The distance in world units.
	* @return {Object3D} A reference to this instance.
	*/
	translateY(distance) {
		return this.translateOnAxis(_yAxis, distance);
	}
	/**
	* Translate the 3D object by a distance along its Z-axis in local space.
	*
	* @param {number} distance - The distance in world units.
	* @return {Object3D} A reference to this instance.
	*/
	translateZ(distance) {
		return this.translateOnAxis(_zAxis, distance);
	}
	/**
	* Converts the given vector from this 3D object's local space to world space.
	*
	* @param {Vector3} vector - The vector to convert.
	* @return {Vector3} The converted vector.
	*/
	localToWorld(vector) {
		this.updateWorldMatrix(true, false);
		return vector.applyMatrix4(this.matrixWorld);
	}
	/**
	* Converts the given vector from this 3D object's world space to local space.
	*
	* @param {Vector3} vector - The vector to convert.
	* @return {Vector3} The converted vector.
	*/
	worldToLocal(vector) {
		this.updateWorldMatrix(true, false);
		return vector.applyMatrix4(_m1$1.copy(this.matrixWorld).invert());
	}
	/**
	* Rotates the object to face a point in world space.
	*
	* This method does not support objects having non-uniformly-scaled parent(s).
	*
	* @param {number|Vector3} x - The x coordinate in world space. Alternatively, a vector representing a position in world space
	* @param {number} [y] - The y coordinate in world space.
	* @param {number} [z] - The z coordinate in world space.
	*/
	lookAt(x, y, z) {
		if (x.isVector3) _target.copy(x);
		else _target.set(x, y, z);
		const parent = this.parent;
		this.updateWorldMatrix(true, false);
		_position$4.setFromMatrixPosition(this.matrixWorld);
		if (this.isCamera || this.isLight) _m1$1.lookAt(_position$4, _target, this.up);
		else _m1$1.lookAt(_target, _position$4, this.up);
		this.quaternion.setFromRotationMatrix(_m1$1);
		if (parent) {
			_m1$1.extractRotation(parent.matrixWorld);
			_q1.setFromRotationMatrix(_m1$1);
			this.quaternion.premultiply(_q1.invert());
		}
	}
	/**
	* Adds the given 3D object as a child to this 3D object. An arbitrary number of
	* objects may be added. Any current parent on an object passed in here will be
	* removed, since an object can have at most one parent.
	*
	* @fires Object3D#added
	* @fires Object3D#childadded
	* @param {Object3D} object - The 3D object to add.
	* @return {Object3D} A reference to this instance.
	*/
	add(object) {
		if (arguments.length > 1) {
			for (let i = 0; i < arguments.length; i++) this.add(arguments[i]);
			return this;
		}
		if (object === this) {
			error("Object3D.add: object can't be added as a child of itself.", object);
			return this;
		}
		if (object && object.isObject3D) {
			object.removeFromParent();
			object.parent = this;
			this.children.push(object);
			object.dispatchEvent(_addedEvent);
			_childaddedEvent.child = object;
			this.dispatchEvent(_childaddedEvent);
			_childaddedEvent.child = null;
		} else error("Object3D.add: object not an instance of THREE.Object3D.", object);
		return this;
	}
	/**
	* Removes the given 3D object as child from this 3D object.
	* An arbitrary number of objects may be removed.
	*
	* @fires Object3D#removed
	* @fires Object3D#childremoved
	* @param {Object3D} object - The 3D object to remove.
	* @return {Object3D} A reference to this instance.
	*/
	remove(object) {
		if (arguments.length > 1) {
			for (let i = 0; i < arguments.length; i++) this.remove(arguments[i]);
			return this;
		}
		const index = this.children.indexOf(object);
		if (index !== -1) {
			object.parent = null;
			this.children.splice(index, 1);
			object.dispatchEvent(_removedEvent);
			_childremovedEvent.child = object;
			this.dispatchEvent(_childremovedEvent);
			_childremovedEvent.child = null;
		}
		return this;
	}
	/**
	* Removes this 3D object from its current parent.
	*
	* @fires Object3D#removed
	* @fires Object3D#childremoved
	* @return {Object3D} A reference to this instance.
	*/
	removeFromParent() {
		const parent = this.parent;
		if (parent !== null) parent.remove(this);
		return this;
	}
	/**
	* Removes all child objects.
	*
	* @fires Object3D#removed
	* @fires Object3D#childremoved
	* @return {Object3D} A reference to this instance.
	*/
	clear() {
		return this.remove(...this.children);
	}
	/**
	* Adds the given 3D object as a child of this 3D object, while maintaining the object's world
	* transform. This method does not support scene graphs having non-uniformly-scaled nodes(s).
	*
	* @fires Object3D#added
	* @fires Object3D#childadded
	* @param {Object3D} object - The 3D object to attach.
	* @return {Object3D} A reference to this instance.
	*/
	attach(object) {
		this.updateWorldMatrix(true, false);
		_m1$1.copy(this.matrixWorld).invert();
		if (object.parent !== null) {
			object.parent.updateWorldMatrix(true, false);
			_m1$1.multiply(object.parent.matrixWorld);
		}
		object.applyMatrix4(_m1$1);
		object.removeFromParent();
		object.parent = this;
		this.children.push(object);
		object.updateWorldMatrix(false, true);
		object.dispatchEvent(_addedEvent);
		_childaddedEvent.child = object;
		this.dispatchEvent(_childaddedEvent);
		_childaddedEvent.child = null;
		return this;
	}
	/**
	* Searches through the 3D object and its children, starting with the 3D object
	* itself, and returns the first with a matching ID.
	*
	* @param {number} id - The id.
	* @return {Object3D|undefined} The found 3D object. Returns `undefined` if no 3D object has been found.
	*/
	getObjectById(id) {
		return this.getObjectByProperty("id", id);
	}
	/**
	* Searches through the 3D object and its children, starting with the 3D object
	* itself, and returns the first with a matching name.
	*
	* @param {string} name - The name.
	* @return {Object3D|undefined} The found 3D object. Returns `undefined` if no 3D object has been found.
	*/
	getObjectByName(name) {
		return this.getObjectByProperty("name", name);
	}
	/**
	* Searches through the 3D object and its children, starting with the 3D object
	* itself, and returns the first with a matching property value.
	*
	* @param {string} name - The name of the property.
	* @param {any} value - The value.
	* @return {Object3D|undefined} The found 3D object. Returns `undefined` if no 3D object has been found.
	*/
	getObjectByProperty(name, value) {
		if (this[name] === value) return this;
		for (let i = 0, l = this.children.length; i < l; i++) {
			const object = this.children[i].getObjectByProperty(name, value);
			if (object !== void 0) return object;
		}
	}
	/**
	* Searches through the 3D object and its children, starting with the 3D object
	* itself, and returns all 3D objects with a matching property value.
	*
	* @param {string} name - The name of the property.
	* @param {any} value - The value.
	* @param {Array<Object3D>} result - The method stores the result in this array.
	* @return {Array<Object3D>} The found 3D objects.
	*/
	getObjectsByProperty(name, value, result = []) {
		if (this[name] === value) result.push(this);
		const children = this.children;
		for (let i = 0, l = children.length; i < l; i++) children[i].getObjectsByProperty(name, value, result);
		return result;
	}
	/**
	* Returns a vector representing the position of the 3D object in world space.
	*
	* @param {Vector3} target - The target vector the result is stored to.
	* @return {Vector3} The 3D object's position in world space.
	*/
	getWorldPosition(target) {
		this.updateWorldMatrix(true, false);
		return target.setFromMatrixPosition(this.matrixWorld);
	}
	/**
	* Returns a Quaternion representing the position of the 3D object in world space.
	*
	* @param {Quaternion} target - The target Quaternion the result is stored to.
	* @return {Quaternion} The 3D object's rotation in world space.
	*/
	getWorldQuaternion(target) {
		this.updateWorldMatrix(true, false);
		this.matrixWorld.decompose(_position$4, target, _scale$3);
		return target;
	}
	/**
	* Returns a vector representing the scale of the 3D object in world space.
	*
	* @param {Vector3} target - The target vector the result is stored to.
	* @return {Vector3} The 3D object's scale in world space.
	*/
	getWorldScale(target) {
		this.updateWorldMatrix(true, false);
		this.matrixWorld.decompose(_position$4, _quaternion$3, target);
		return target;
	}
	/**
	* Returns a vector representing the ("look") direction of the 3D object in world space.
	*
	* @param {Vector3} target - The target vector the result is stored to.
	* @return {Vector3} The 3D object's direction in world space.
	*/
	getWorldDirection(target) {
		this.updateWorldMatrix(true, false);
		const e = this.matrixWorld.elements;
		return target.set(e[8], e[9], e[10]).normalize();
	}
	/**
	* Abstract method to get intersections between a casted ray and this
	* 3D object. Renderable 3D objects such as {@link Mesh}, {@link Line} or {@link Points}
	* implement this method in order to use raycasting.
	*
	* @abstract
	* @param {Raycaster} raycaster - The raycaster.
	* @param {Array<Object>} intersects - An array holding the result of the method.
	*/
	raycast() {}
	/**
	* Abstract method to test whether this 3D object intersects the given frustum.
	* Renderable 3D objects such as {@link Mesh}, {@link Line} or {@link Points}
	* implement this method in order to use frustum culling.
	*
	* @abstract
	* @param {Frustum|FrustumArray} frustum - The frustum to test.
	* @return {boolean|undefined} Whether this 3D object intersects the given frustum or not.
	*/
	intersectsFrustum() {}
	/**
	* Executes the callback on this 3D object and all descendants.
	*
	* Note: Modifying the scene graph inside the callback is discouraged.
	*
	* @param {Function} callback - A callback function that allows to process the current 3D object.
	*/
	traverse(callback) {
		callback(this);
		const children = this.children;
		for (let i = 0, l = children.length; i < l; i++) children[i].traverse(callback);
	}
	/**
	* Like {@link Object3D#traverse}, but the callback will only be executed for visible 3D objects.
	* Descendants of invisible 3D objects are not traversed.
	*
	* Note: Modifying the scene graph inside the callback is discouraged.
	*
	* @param {Function} callback - A callback function that allows to process the current 3D object.
	*/
	traverseVisible(callback) {
		if (this.visible === false) return;
		callback(this);
		const children = this.children;
		for (let i = 0, l = children.length; i < l; i++) children[i].traverseVisible(callback);
	}
	/**
	* Like {@link Object3D#traverse}, but the callback will only be executed for all ancestors.
	*
	* Note: Modifying the scene graph inside the callback is discouraged.
	*
	* @param {Function} callback - A callback function that allows to process the current 3D object.
	*/
	traverseAncestors(callback) {
		const parent = this.parent;
		if (parent !== null) {
			callback(parent);
			parent.traverseAncestors(callback);
		}
	}
	/**
	* Updates the transformation matrix in local space by computing it from the current
	* position, rotation and scale values.
	*/
	updateMatrix() {
		this.matrix.compose(this.position, this.quaternion, this.scale);
		const pivot = this.pivot;
		if (pivot !== null) {
			const px = pivot.x, py = pivot.y, pz = pivot.z;
			const te = this.matrix.elements;
			te[12] += px - te[0] * px - te[4] * py - te[8] * pz;
			te[13] += py - te[1] * px - te[5] * py - te[9] * pz;
			te[14] += pz - te[2] * px - te[6] * py - te[10] * pz;
		}
		this.matrixWorldNeedsUpdate = true;
	}
	/**
	* Updates the transformation matrix in world space of this 3D objects and its descendants.
	*
	* To ensure correct results, this method also recomputes the 3D object's transformation matrix in
	* local space. The computation of the local and world matrix can be controlled with the
	* {@link Object3D#matrixAutoUpdate} and {@link Object3D#matrixWorldAutoUpdate} flags which are both
	* `true` by default.  Set these flags to `false` if you need more control over the update matrix process.
	*
	* @param {boolean} [force=false] - When set to `true`, a recomputation of world matrices is forced even
	* when {@link Object3D#matrixWorldNeedsUpdate} is `false`.
	*/
	updateMatrixWorld(force) {
		if (this.matrixAutoUpdate) this.updateMatrix();
		if (this.matrixWorldNeedsUpdate || force) {
			if (this.matrixWorldAutoUpdate === true) {
				if (this.parent === null) this.matrixWorld.copy(this.matrix);
				else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
			}
			this.matrixWorldNeedsUpdate = false;
			force = true;
		}
		const children = this.children;
		for (let i = 0, l = children.length; i < l; i++) children[i].updateMatrixWorld(force);
	}
	/**
	* An alternative version of {@link Object3D#updateMatrixWorld} with more control over the
	* update of ancestor and descendant nodes.
	*
	* @param {boolean} [updateParents=false] Whether ancestor nodes should be updated or not.
	* @param {boolean} [updateChildren=false] Whether descendant nodes should be updated or not.
	* @param {boolean} [force=false] - When set to `true`, a recomputation of world matrices is forced even
	* when {@link Object3D#matrixWorldNeedsUpdate} is `false`.
	*/
	updateWorldMatrix(updateParents, updateChildren, force = false) {
		const parent = this.parent;
		if (updateParents === true && parent !== null) parent.updateWorldMatrix(true, false);
		if (this.matrixAutoUpdate) this.updateMatrix();
		if (this.matrixWorldNeedsUpdate || force) {
			if (this.matrixWorldAutoUpdate === true) {
				if (this.parent === null) this.matrixWorld.copy(this.matrix);
				else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
			}
			this.matrixWorldNeedsUpdate = false;
			force = true;
		}
		if (updateChildren === true) {
			const children = this.children;
			for (let i = 0, l = children.length; i < l; i++) children[i].updateWorldMatrix(false, true, force);
		}
	}
	/**
	* Serializes the 3D object into JSON.
	*
	* @param {?(Object|string)} meta - An optional value holding meta information about the serialization.
	* @return {Object} A JSON object representing the serialized 3D object.
	* @see {@link ObjectLoader#parse}
	*/
	toJSON(meta) {
		const isRootObject = meta === void 0 || typeof meta === "string";
		const output = {};
		if (isRootObject) {
			meta = {
				geometries: {},
				materials: {},
				textures: {},
				images: {},
				shapes: {},
				skeletons: {},
				animations: {},
				nodes: {}
			};
			output.metadata = {
				version: 4.7,
				type: "Object",
				generator: "Object3D.toJSON"
			};
		}
		const object = {};
		object.uuid = this.uuid;
		object.type = this.type;
		object.name = this.name;
		object.castShadow = this.castShadow;
		object.receiveShadow = this.receiveShadow;
		object.visible = this.visible;
		object.frustumCulled = this.frustumCulled;
		object.renderOrder = this.renderOrder;
		object.static = this.static;
		object.matrixAutoUpdate = this.matrixAutoUpdate;
		if (Object.keys(this.userData).length > 0) object.userData = this.userData;
		object.layers = this.layers.mask;
		object.matrix = this.matrix.toArray();
		object.up = this.up.toArray();
		if (this.pivot !== null) object.pivot = this.pivot.toArray();
		if (this.morphTargetDictionary !== void 0) object.morphTargetDictionary = Object.assign({}, this.morphTargetDictionary);
		if (this.morphTargetInfluences !== void 0) object.morphTargetInfluences = this.morphTargetInfluences.slice();
		if (this.isInstancedMesh) {
			object.type = "InstancedMesh";
			object.count = this.count;
			object.instanceMatrix = this.instanceMatrix.toJSON();
			if (this.instanceColor !== null) object.instanceColor = this.instanceColor.toJSON();
		}
		if (this.isBatchedMesh) {
			object.type = "BatchedMesh";
			object.perObjectFrustumCulled = this.perObjectFrustumCulled;
			object.sortObjects = this.sortObjects;
			object.drawRanges = this._drawRanges;
			object.reservedRanges = this._reservedRanges;
			object.geometryInfo = this._geometryInfo.map((info) => ({
				...info,
				boundingBox: info.boundingBox ? info.boundingBox.toJSON() : void 0,
				boundingSphere: info.boundingSphere ? info.boundingSphere.toJSON() : void 0
			}));
			object.instanceInfo = this._instanceInfo.map((info) => ({ ...info }));
			object.availableInstanceIds = this._availableInstanceIds.slice();
			object.availableGeometryIds = this._availableGeometryIds.slice();
			object.nextIndexStart = this._nextIndexStart;
			object.nextVertexStart = this._nextVertexStart;
			object.geometryCount = this._geometryCount;
			object.maxInstanceCount = this._maxInstanceCount;
			object.maxVertexCount = this._maxVertexCount;
			object.maxIndexCount = this._maxIndexCount;
			object.geometryInitialized = this._geometryInitialized;
			object.matricesTexture = this._matricesTexture.toJSON(meta);
			object.indirectTexture = this._indirectTexture.toJSON(meta);
			if (this._colorsTexture !== null) object.colorsTexture = this._colorsTexture.toJSON(meta);
			if (this.boundingSphere !== null) object.boundingSphere = this.boundingSphere.toJSON();
			if (this.boundingBox !== null) object.boundingBox = this.boundingBox.toJSON();
		}
		function serialize(library, element) {
			if (library[element.uuid] === void 0) library[element.uuid] = element.toJSON(meta);
			return element.uuid;
		}
		if (this.isScene) {
			if (this.background) {
				if (this.background.isColor) object.background = this.background.toJSON();
				else if (this.background.isTexture) object.background = this.background.toJSON(meta).uuid;
			}
			if (this.environment && this.environment.isTexture && this.environment.isRenderTargetTexture !== true) object.environment = this.environment.toJSON(meta).uuid;
		} else if (this.isMesh || this.isLine || this.isPoints) {
			object.geometry = serialize(meta.geometries, this.geometry);
			const parameters = this.geometry.parameters;
			if (parameters !== void 0 && parameters.shapes !== void 0) {
				const shapes = parameters.shapes;
				if (Array.isArray(shapes)) for (let i = 0, l = shapes.length; i < l; i++) {
					const shape = shapes[i];
					serialize(meta.shapes, shape);
				}
				else serialize(meta.shapes, shapes);
			}
		}
		if (this.isSkinnedMesh) {
			object.bindMode = this.bindMode;
			object.bindMatrix = this.bindMatrix.toArray();
			if (this.skeleton !== void 0) {
				serialize(meta.skeletons, this.skeleton);
				object.skeleton = this.skeleton.uuid;
			}
		}
		if (this.material !== void 0) {
			if (Array.isArray(this.material)) {
				const uuids = [];
				for (let i = 0, l = this.material.length; i < l; i++) uuids.push(serialize(meta.materials, this.material[i]));
				object.material = uuids;
			} else object.material = serialize(meta.materials, this.material);
		}
		if (this.children.length > 0) {
			object.children = [];
			for (let i = 0; i < this.children.length; i++) object.children.push(this.children[i].toJSON(meta).object);
		}
		if (this.animations.length > 0) {
			object.animations = [];
			for (let i = 0; i < this.animations.length; i++) {
				const animation = this.animations[i];
				object.animations.push(serialize(meta.animations, animation));
			}
		}
		if (isRootObject) {
			const geometries = extractFromCache(meta.geometries);
			const materials = extractFromCache(meta.materials);
			const textures = extractFromCache(meta.textures);
			const images = extractFromCache(meta.images);
			const shapes = extractFromCache(meta.shapes);
			const skeletons = extractFromCache(meta.skeletons);
			const animations = extractFromCache(meta.animations);
			const nodes = extractFromCache(meta.nodes);
			if (geometries.length > 0) output.geometries = geometries;
			if (materials.length > 0) output.materials = materials;
			if (textures.length > 0) output.textures = textures;
			if (images.length > 0) output.images = images;
			if (shapes.length > 0) output.shapes = shapes;
			if (skeletons.length > 0) output.skeletons = skeletons;
			if (animations.length > 0) output.animations = animations;
			if (nodes.length > 0) output.nodes = nodes;
		}
		output.object = object;
		return output;
		function extractFromCache(cache) {
			const values = [];
			for (const key in cache) {
				const data = cache[key];
				delete data.metadata;
				values.push(data);
			}
			return values;
		}
	}
	/**
	* Returns a new 3D object with copied values from this instance.
	*
	* @param {boolean} [recursive=true] - When set to `true`, descendants of the 3D object are also cloned.
	* @return {Object3D} A clone of this instance.
	*/
	clone(recursive) {
		return new this.constructor().copy(this, recursive);
	}
	/**
	* Copies the values of the given 3D object to this instance.
	*
	* @param {Object3D} source - The 3D object to copy.
	* @param {boolean} [recursive=true] - When set to `true`, descendants of the 3D object are cloned.
	* @return {Object3D} A reference to this instance.
	*/
	copy(source, recursive = true) {
		this.name = source.name;
		this.up.copy(source.up);
		this.position.copy(source.position);
		this.rotation.order = source.rotation.order;
		this.quaternion.copy(source.quaternion);
		this.scale.copy(source.scale);
		this.pivot = source.pivot !== null ? source.pivot.clone() : null;
		this.matrix.copy(source.matrix);
		this.matrixWorld.copy(source.matrixWorld);
		this.matrixAutoUpdate = source.matrixAutoUpdate;
		this.matrixWorldAutoUpdate = source.matrixWorldAutoUpdate;
		this.matrixWorldNeedsUpdate = source.matrixWorldNeedsUpdate;
		this.layers.mask = source.layers.mask;
		this.visible = source.visible;
		this.castShadow = source.castShadow;
		this.receiveShadow = source.receiveShadow;
		this.frustumCulled = source.frustumCulled;
		this.renderOrder = source.renderOrder;
		this.static = source.static;
		this.animations = source.animations.slice();
		this.userData = JSON.parse(JSON.stringify(source.userData));
		if (recursive === true) for (let i = 0; i < source.children.length; i++) {
			const child = source.children[i];
			this.add(child.clone());
		}
		return this;
	}
	/**
	* Frees the GPU-related resources allocated by this instance. Call this
	* method whenever this instance is no longer used in your app.
	*
	* Geometries, materials and textures are potentially shared with other
	* 3D objects and must be disposed of separately.
	*
	* @fires Object3D#dispose
	*/
	dispose() {
		/**
		* Fires when the 3D object has been disposed of.
		*
		* @event Object3D#dispose
		* @type {Object}
		*/
		this.dispatchEvent({ type: "dispose" });
	}
};
/**
* The default up direction for objects, also used as the default
* position for {@link DirectionalLight} and {@link HemisphereLight}.
*
* @static
* @type {Vector3}
* @default (0,1,0)
*/
Object3D.DEFAULT_UP = /*@__PURE__*/ new Vector3(0, 1, 0);
/**
* The default setting for {@link Object3D#matrixAutoUpdate} for
* newly created 3D objects.
*
* @static
* @type {boolean}
* @default true
*/
Object3D.DEFAULT_MATRIX_AUTO_UPDATE = true;
/**
* The default setting for {@link Object3D#matrixWorldAutoUpdate} for
* newly created 3D objects.
*
* @static
* @type {boolean}
* @default true
*/
Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = true;
const _colorKeywords = {
	"aliceblue": 15792383,
	"antiquewhite": 16444375,
	"aqua": 65535,
	"aquamarine": 8388564,
	"azure": 15794175,
	"beige": 16119260,
	"bisque": 16770244,
	"black": 0,
	"blanchedalmond": 16772045,
	"blue": 255,
	"blueviolet": 9055202,
	"brown": 10824234,
	"burlywood": 14596231,
	"cadetblue": 6266528,
	"chartreuse": 8388352,
	"chocolate": 13789470,
	"coral": 16744272,
	"cornflowerblue": 6591981,
	"cornsilk": 16775388,
	"crimson": 14423100,
	"cyan": 65535,
	"darkblue": 139,
	"darkcyan": 35723,
	"darkgoldenrod": 12092939,
	"darkgray": 11119017,
	"darkgreen": 25600,
	"darkgrey": 11119017,
	"darkkhaki": 12433259,
	"darkmagenta": 9109643,
	"darkolivegreen": 5597999,
	"darkorange": 16747520,
	"darkorchid": 10040012,
	"darkred": 9109504,
	"darksalmon": 15308410,
	"darkseagreen": 9419919,
	"darkslateblue": 4734347,
	"darkslategray": 3100495,
	"darkslategrey": 3100495,
	"darkturquoise": 52945,
	"darkviolet": 9699539,
	"deeppink": 16716947,
	"deepskyblue": 49151,
	"dimgray": 6908265,
	"dimgrey": 6908265,
	"dodgerblue": 2003199,
	"firebrick": 11674146,
	"floralwhite": 16775920,
	"forestgreen": 2263842,
	"fuchsia": 16711935,
	"gainsboro": 14474460,
	"ghostwhite": 16316671,
	"gold": 16766720,
	"goldenrod": 14329120,
	"gray": 8421504,
	"green": 32768,
	"greenyellow": 11403055,
	"grey": 8421504,
	"honeydew": 15794160,
	"hotpink": 16738740,
	"indianred": 13458524,
	"indigo": 4915330,
	"ivory": 16777200,
	"khaki": 15787660,
	"lavender": 15132410,
	"lavenderblush": 16773365,
	"lawngreen": 8190976,
	"lemonchiffon": 16775885,
	"lightblue": 11393254,
	"lightcoral": 15761536,
	"lightcyan": 14745599,
	"lightgoldenrodyellow": 16448210,
	"lightgray": 13882323,
	"lightgreen": 9498256,
	"lightgrey": 13882323,
	"lightpink": 16758465,
	"lightsalmon": 16752762,
	"lightseagreen": 2142890,
	"lightskyblue": 8900346,
	"lightslategray": 7833753,
	"lightslategrey": 7833753,
	"lightsteelblue": 11584734,
	"lightyellow": 16777184,
	"lime": 65280,
	"limegreen": 3329330,
	"linen": 16445670,
	"magenta": 16711935,
	"maroon": 8388608,
	"mediumaquamarine": 6737322,
	"mediumblue": 205,
	"mediumorchid": 12211667,
	"mediumpurple": 9662683,
	"mediumseagreen": 3978097,
	"mediumslateblue": 8087790,
	"mediumspringgreen": 64154,
	"mediumturquoise": 4772300,
	"mediumvioletred": 13047173,
	"midnightblue": 1644912,
	"mintcream": 16121850,
	"mistyrose": 16770273,
	"moccasin": 16770229,
	"navajowhite": 16768685,
	"navy": 128,
	"oldlace": 16643558,
	"olive": 8421376,
	"olivedrab": 7048739,
	"orange": 16753920,
	"orangered": 16729344,
	"orchid": 14315734,
	"palegoldenrod": 15657130,
	"palegreen": 10025880,
	"paleturquoise": 11529966,
	"palevioletred": 14381203,
	"papayawhip": 16773077,
	"peachpuff": 16767673,
	"peru": 13468991,
	"pink": 16761035,
	"plum": 14524637,
	"powderblue": 11591910,
	"purple": 8388736,
	"rebeccapurple": 6697881,
	"red": 16711680,
	"rosybrown": 12357519,
	"royalblue": 4286945,
	"saddlebrown": 9127187,
	"salmon": 16416882,
	"sandybrown": 16032864,
	"seagreen": 3050327,
	"seashell": 16774638,
	"sienna": 10506797,
	"silver": 12632256,
	"skyblue": 8900331,
	"slateblue": 6970061,
	"slategray": 7372944,
	"slategrey": 7372944,
	"snow": 16775930,
	"springgreen": 65407,
	"steelblue": 4620980,
	"tan": 13808780,
	"teal": 32896,
	"thistle": 14204888,
	"tomato": 16737095,
	"turquoise": 4251856,
	"violet": 15631086,
	"wheat": 16113331,
	"white": 16777215,
	"whitesmoke": 16119285,
	"yellow": 16776960,
	"yellowgreen": 10145074
};
const _hslA = {
	h: 0,
	s: 0,
	l: 0
};
const _hslB = {
	h: 0,
	s: 0,
	l: 0
};
function hue2rgb(p, q, t) {
	if (t < 0) t += 1;
	if (t > 1) t -= 1;
	if (t < 1 / 6) return p + (q - p) * 6 * t;
	if (t < 1 / 2) return q;
	if (t < 2 / 3) return p + (q - p) * 6 * (2 / 3 - t);
	return p;
}
/**
* A Color instance is represented by RGB components in the linear <i>working
* color space</i>, which defaults to `LinearSRGBColorSpace`. Inputs
* conventionally using `SRGBColorSpace` (such as hexadecimals and CSS
* strings) are converted to the working color space automatically.
*
* ```js
* // converted automatically from SRGBColorSpace to LinearSRGBColorSpace
* const color = new THREE.Color().setHex( 0x112233 );
* ```
* Source color spaces may be specified explicitly, to ensure correct conversions.
* ```js
* // assumed already LinearSRGBColorSpace; no conversion
* const color = new THREE.Color().setRGB( 0.5, 0.5, 0.5 );
*
* // converted explicitly from SRGBColorSpace to LinearSRGBColorSpace
* const color = new THREE.Color().setRGB( 0.5, 0.5, 0.5, SRGBColorSpace );
* ```
* If THREE.ColorManagement is disabled, no conversions occur. For details,
* see <i>Color management</i>. Iterating through a Color instance will yield
* its components (r, g, b) in the corresponding order. A Color can be initialised
* in any of the following ways:
* ```js
* //empty constructor - will default white
* const color1 = new THREE.Color();
*
* //Hexadecimal color (recommended)
* const color2 = new THREE.Color( 0xff0000 );
*
* //RGB string
* const color3 = new THREE.Color("rgb(255, 0, 0)");
* const color4 = new THREE.Color("rgb(100%, 0%, 0%)");
*
* //X11 color name - all 140 color names are supported.
* //Note the lack of CamelCase in the name
* const color5 = new THREE.Color( 'skyblue' );
* //HSL string
* const color6 = new THREE.Color("hsl(0, 100%, 50%)");
*
* //Separate RGB values between 0 and 1
* const color7 = new THREE.Color( 1, 0, 0 );
* ```
*/
var Color = class {
	/**
	* Constructs a new color.
	*
	* Note that standard method of specifying color in three.js is with a hexadecimal triplet,
	* and that method is used throughout the rest of the documentation.
	*
	* @param {(number|string|Color)} [r] - The red component of the color. If `g` and `b` are
	* not provided, it can be hexadecimal triplet, a CSS-style string or another `Color` instance.
	* @param {number} [g] - The green component.
	* @param {number} [b] - The blue component.
	*/
	constructor(r, g, b) {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		this.isColor = true;
		/**
		* The red component.
		*
		* @type {number}
		* @default 1
		*/
		this.r = 1;
		/**
		* The green component.
		*
		* @type {number}
		* @default 1
		*/
		this.g = 1;
		/**
		* The blue component.
		*
		* @type {number}
		* @default 1
		*/
		this.b = 1;
		return this.set(r, g, b);
	}
	/**
	* Sets the colors's components from the given values.
	*
	* @param {(number|string|Color)} [r] - The red component of the color. If `g` and `b` are
	* not provided, it can be hexadecimal triplet, a CSS-style string or another `Color` instance.
	* @param {number} [g] - The green component.
	* @param {number} [b] - The blue component.
	* @return {Color} A reference to this color.
	*/
	set(r, g, b) {
		if (g === void 0 && b === void 0) {
			const value = r;
			if (value && value.isColor) this.copy(value);
			else if (typeof value === "number") this.setHex(value);
			else if (typeof value === "string") this.setStyle(value);
		} else this.setRGB(r, g, b);
		return this;
	}
	/**
	* Sets the colors's components to the given scalar value.
	*
	* @param {number} scalar - The scalar value.
	* @return {Color} A reference to this color.
	*/
	setScalar(scalar) {
		this.r = scalar;
		this.g = scalar;
		this.b = scalar;
		return this;
	}
	/**
	* Sets this color from a hexadecimal value.
	*
	* @param {number} hex - The hexadecimal value.
	* @param {string} [colorSpace=SRGBColorSpace] - The color space.
	* @return {Color} A reference to this color.
	*/
	setHex(hex, colorSpace = SRGBColorSpace) {
		hex = Math.floor(hex);
		this.r = (hex >> 16 & 255) / 255;
		this.g = (hex >> 8 & 255) / 255;
		this.b = (hex & 255) / 255;
		ColorManagement.colorSpaceToWorking(this, colorSpace);
		return this;
	}
	/**
	* Sets this color from RGB values.
	*
	* @param {number} r - Red channel value between `0.0` and `1.0`.
	* @param {number} g - Green channel value between `0.0` and `1.0`.
	* @param {number} b - Blue channel value between `0.0` and `1.0`.
	* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
	* @return {Color} A reference to this color.
	*/
	setRGB(r, g, b, colorSpace = ColorManagement.workingColorSpace) {
		this.r = r;
		this.g = g;
		this.b = b;
		ColorManagement.colorSpaceToWorking(this, colorSpace);
		return this;
	}
	/**
	* Sets this color from RGB values.
	*
	* @param {number} h - Hue value between `0.0` and `1.0`.
	* @param {number} s - Saturation value between `0.0` and `1.0`.
	* @param {number} l - Lightness value between `0.0` and `1.0`.
	* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
	* @return {Color} A reference to this color.
	*/
	setHSL(h, s, l, colorSpace = ColorManagement.workingColorSpace) {
		h = euclideanModulo(h, 1);
		s = clamp$1(s, 0, 1);
		l = clamp$1(l, 0, 1);
		if (s === 0) this.r = this.g = this.b = l;
		else {
			const p = l <= .5 ? l * (1 + s) : l + s - l * s;
			const q = 2 * l - p;
			this.r = hue2rgb(q, p, h + 1 / 3);
			this.g = hue2rgb(q, p, h);
			this.b = hue2rgb(q, p, h - 1 / 3);
		}
		ColorManagement.colorSpaceToWorking(this, colorSpace);
		return this;
	}
	/**
	* Sets this color from a CSS-style string. For example, `rgb(250, 0,0)`,
	* `rgb(100%, 0%, 0%)`, `hsl(0, 100%, 50%)`, `#ff0000`, `#f00`, or `red` ( or
	* any [X11 color name](https://en.wikipedia.org/wiki/X11_color_names#Color_name_chart) -
	* all 140 color names are supported).
	*
	* @param {string} style - Color as a CSS-style string.
	* @param {string} [colorSpace=SRGBColorSpace] - The color space.
	* @return {Color} A reference to this color.
	*/
	setStyle(style, colorSpace = SRGBColorSpace) {
		function handleAlpha(string) {
			if (string === void 0) return;
			if (parseFloat(string) < 1) warn("Color: Alpha component of " + style + " will be ignored.");
		}
		let m;
		if (m = /^(\w+)\(([^\)]*)\)/.exec(style)) {
			let color;
			const name = m[1];
			const components = m[2];
			switch (name) {
				case "rgb":
				case "rgba":
					if (color = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
						handleAlpha(color[4]);
						return this.setRGB(Math.min(255, parseInt(color[1], 10)) / 255, Math.min(255, parseInt(color[2], 10)) / 255, Math.min(255, parseInt(color[3], 10)) / 255, colorSpace);
					}
					if (color = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
						handleAlpha(color[4]);
						return this.setRGB(Math.min(100, parseInt(color[1], 10)) / 100, Math.min(100, parseInt(color[2], 10)) / 100, Math.min(100, parseInt(color[3], 10)) / 100, colorSpace);
					}
					break;
				case "hsl":
				case "hsla":
					if (color = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
						handleAlpha(color[4]);
						return this.setHSL(parseFloat(color[1]) / 360, parseFloat(color[2]) / 100, parseFloat(color[3]) / 100, colorSpace);
					}
					break;
				default: warn("Color: Unknown color model " + style);
			}
		} else if (m = /^\#([A-Fa-f\d]+)$/.exec(style)) {
			const hex = m[1];
			const size = hex.length;
			if (size === 3) return this.setRGB(parseInt(hex.charAt(0), 16) / 15, parseInt(hex.charAt(1), 16) / 15, parseInt(hex.charAt(2), 16) / 15, colorSpace);
			else if (size === 6) return this.setHex(parseInt(hex, 16), colorSpace);
			else warn("Color: Invalid hex color " + style);
		} else if (style && style.length > 0) return this.setColorName(style, colorSpace);
		return this;
	}
	/**
	* Sets this color from a color name. Faster than {@link Color#setStyle} if
	* you don't need the other CSS-style formats.
	*
	* For convenience, the list of names is exposed in `Color.NAMES` as a hash.
	* ```js
	* Color.NAMES.aliceblue // returns 0xF0F8FF
	* ```
	*
	* @param {string} style - The color name.
	* @param {string} [colorSpace=SRGBColorSpace] - The color space.
	* @return {Color} A reference to this color.
	*/
	setColorName(style, colorSpace = SRGBColorSpace) {
		const hex = _colorKeywords[style.toLowerCase()];
		if (hex !== void 0) this.setHex(hex, colorSpace);
		else warn("Color: Unknown color " + style);
		return this;
	}
	/**
	* Returns a new color with copied values from this instance.
	*
	* @return {Color} A clone of this instance.
	*/
	clone() {
		return new this.constructor(this.r, this.g, this.b);
	}
	/**
	* Copies the values of the given color to this instance.
	*
	* @param {Color} color - The color to copy.
	* @return {Color} A reference to this color.
	*/
	copy(color) {
		this.r = color.r;
		this.g = color.g;
		this.b = color.b;
		return this;
	}
	/**
	* Copies the given color into this color, and then converts this color from
	* `SRGBColorSpace` to `LinearSRGBColorSpace`.
	*
	* @param {Color} color - The color to copy/convert.
	* @return {Color} A reference to this color.
	*/
	copySRGBToLinear(color) {
		this.r = SRGBToLinear(color.r);
		this.g = SRGBToLinear(color.g);
		this.b = SRGBToLinear(color.b);
		return this;
	}
	/**
	* Copies the given color into this color, and then converts this color from
	* `LinearSRGBColorSpace` to `SRGBColorSpace`.
	*
	* @param {Color} color - The color to copy/convert.
	* @return {Color} A reference to this color.
	*/
	copyLinearToSRGB(color) {
		this.r = LinearToSRGB(color.r);
		this.g = LinearToSRGB(color.g);
		this.b = LinearToSRGB(color.b);
		return this;
	}
	/**
	* Converts this color from `SRGBColorSpace` to `LinearSRGBColorSpace`.
	*
	* @return {Color} A reference to this color.
	*/
	convertSRGBToLinear() {
		this.copySRGBToLinear(this);
		return this;
	}
	/**
	* Converts this color from `LinearSRGBColorSpace` to `SRGBColorSpace`.
	*
	* @return {Color} A reference to this color.
	*/
	convertLinearToSRGB() {
		this.copyLinearToSRGB(this);
		return this;
	}
	/**
	* Returns the hexadecimal value of this color.
	*
	* @param {string} [colorSpace=SRGBColorSpace] - The color space.
	* @return {number} The hexadecimal value.
	*/
	getHex(colorSpace = SRGBColorSpace) {
		ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
		return Math.round(clamp$1(_color.r * 255, 0, 255)) * 65536 + Math.round(clamp$1(_color.g * 255, 0, 255)) * 256 + Math.round(clamp$1(_color.b * 255, 0, 255));
	}
	/**
	* Returns the hexadecimal value of this color as a string (for example, 'FFFFFF').
	*
	* @param {string} [colorSpace=SRGBColorSpace] - The color space.
	* @return {string} The hexadecimal value as a string.
	*/
	getHexString(colorSpace = SRGBColorSpace) {
		return ("000000" + this.getHex(colorSpace).toString(16)).slice(-6);
	}
	/**
	* Converts the colors RGB values into the HSL format and stores them into the
	* given target object.
	*
	* @param {{h:number,s:number,l:number}} target - The target object that is used to store the method's result.
	* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
	* @return {{h:number,s:number,l:number}} The HSL representation of this color.
	*/
	getHSL(target, colorSpace = ColorManagement.workingColorSpace) {
		ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
		const r = _color.r, g = _color.g, b = _color.b;
		const max = Math.max(r, g, b);
		const min = Math.min(r, g, b);
		let hue, saturation;
		const lightness = (min + max) / 2;
		if (min === max) {
			hue = 0;
			saturation = 0;
		} else {
			const delta = max - min;
			saturation = lightness <= .5 ? delta / (max + min) : delta / (2 - max - min);
			switch (max) {
				case r:
					hue = (g - b) / delta + (g < b ? 6 : 0);
					break;
				case g:
					hue = (b - r) / delta + 2;
					break;
				case b: hue = (r - g) / delta + 4;
			}
			hue /= 6;
		}
		target.h = hue;
		target.s = saturation;
		target.l = lightness;
		return target;
	}
	/**
	* Returns the RGB values of this color and stores them into the given target object.
	*
	* @param {Color} target - The target color that is used to store the method's result.
	* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
	* @return {Color} The RGB representation of this color.
	*/
	getRGB(target, colorSpace = ColorManagement.workingColorSpace) {
		ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
		target.r = _color.r;
		target.g = _color.g;
		target.b = _color.b;
		return target;
	}
	/**
	* Returns the value of this color as a CSS style string. Example: `rgb(255,0,0)`.
	*
	* @param {string} [colorSpace=SRGBColorSpace] - The color space.
	* @return {string} The CSS representation of this color.
	*/
	getStyle(colorSpace = SRGBColorSpace) {
		ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
		const r = _color.r, g = _color.g, b = _color.b;
		if (colorSpace !== "srgb") return `color(${colorSpace} ${r.toFixed(3)} ${g.toFixed(3)} ${b.toFixed(3)})`;
		return `rgb(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)})`;
	}
	/**
	* Adds the given HSL values to this color's values.
	* Internally, this converts the color's RGB values to HSL, adds HSL
	* and then converts the color back to RGB.
	*
	* @param {number} h - Hue value between `0.0` and `1.0`.
	* @param {number} s - Saturation value between `0.0` and `1.0`.
	* @param {number} l - Lightness value between `0.0` and `1.0`.
	* @return {Color} A reference to this color.
	*/
	offsetHSL(h, s, l) {
		this.getHSL(_hslA);
		return this.setHSL(_hslA.h + h, _hslA.s + s, _hslA.l + l);
	}
	/**
	* Adds the RGB values of the given color to the RGB values of this color.
	*
	* @param {Color} color - The color to add.
	* @return {Color} A reference to this color.
	*/
	add(color) {
		this.r += color.r;
		this.g += color.g;
		this.b += color.b;
		return this;
	}
	/**
	* Adds the RGB values of the given colors and stores the result in this instance.
	*
	* @param {Color} color1 - The first color.
	* @param {Color} color2 - The second color.
	* @return {Color} A reference to this color.
	*/
	addColors(color1, color2) {
		this.r = color1.r + color2.r;
		this.g = color1.g + color2.g;
		this.b = color1.b + color2.b;
		return this;
	}
	/**
	* Adds the given scalar value to the RGB values of this color.
	*
	* @param {number} s - The scalar to add.
	* @return {Color} A reference to this color.
	*/
	addScalar(s) {
		this.r += s;
		this.g += s;
		this.b += s;
		return this;
	}
	/**
	* Subtracts the RGB values of the given color from the RGB values of this color.
	*
	* @param {Color} color - The color to subtract.
	* @return {Color} A reference to this color.
	*/
	sub(color) {
		this.r = Math.max(0, this.r - color.r);
		this.g = Math.max(0, this.g - color.g);
		this.b = Math.max(0, this.b - color.b);
		return this;
	}
	/**
	* Multiplies the RGB values of the given color with the RGB values of this color.
	*
	* @param {Color} color - The color to multiply.
	* @return {Color} A reference to this color.
	*/
	multiply(color) {
		this.r *= color.r;
		this.g *= color.g;
		this.b *= color.b;
		return this;
	}
	/**
	* Multiplies the given scalar value with the RGB values of this color.
	*
	* @param {number} s - The scalar to multiply.
	* @return {Color} A reference to this color.
	*/
	multiplyScalar(s) {
		this.r *= s;
		this.g *= s;
		this.b *= s;
		return this;
	}
	/**
	* Linearly interpolates this color's RGB values toward the RGB values of the
	* given color. The alpha argument can be thought of as the ratio between
	* the two colors, where `0.0` is this color and `1.0` is the first argument.
	*
	* @param {Color} color - The color to converge on.
	* @param {number} alpha - The interpolation factor in the closed interval `[0,1]`.
	* @return {Color} A reference to this color.
	*/
	lerp(color, alpha) {
		this.r += (color.r - this.r) * alpha;
		this.g += (color.g - this.g) * alpha;
		this.b += (color.b - this.b) * alpha;
		return this;
	}
	/**
	* Linearly interpolates between the given colors and stores the result in this instance.
	* The alpha argument can be thought of as the ratio between the two colors, where `0.0`
	* is the first and `1.0` is the second color.
	*
	* @param {Color} color1 - The first color.
	* @param {Color} color2 - The second color.
	* @param {number} alpha - The interpolation factor in the closed interval `[0,1]`.
	* @return {Color} A reference to this color.
	*/
	lerpColors(color1, color2, alpha) {
		this.r = color1.r + (color2.r - color1.r) * alpha;
		this.g = color1.g + (color2.g - color1.g) * alpha;
		this.b = color1.b + (color2.b - color1.b) * alpha;
		return this;
	}
	/**
	* Linearly interpolates this color's HSL values toward the HSL values of the
	* given color. It differs from {@link Color#lerp} by not interpolating straight
	* from one color to the other, but instead going through all the hues in between
	* those two colors. The alpha argument can be thought of as the ratio between
	* the two colors, where 0.0 is this color and 1.0 is the first argument.
	*
	* @param {Color} color - The color to converge on.
	* @param {number} alpha - The interpolation factor in the closed interval `[0,1]`.
	* @return {Color} A reference to this color.
	*/
	lerpHSL(color, alpha) {
		this.getHSL(_hslA);
		color.getHSL(_hslB);
		const h = lerp(_hslA.h, _hslB.h, alpha);
		const s = lerp(_hslA.s, _hslB.s, alpha);
		const l = lerp(_hslA.l, _hslB.l, alpha);
		this.setHSL(h, s, l);
		return this;
	}
	/**
	* Sets the color's RGB components from the given 3D vector.
	*
	* @param {Vector3} v - The vector to set.
	* @return {Color} A reference to this color.
	*/
	setFromVector3(v) {
		this.r = v.x;
		this.g = v.y;
		this.b = v.z;
		return this;
	}
	/**
	* Transforms this color with the given 3x3 matrix.
	*
	* @param {Matrix3} m - The matrix.
	* @return {Color} A reference to this color.
	*/
	applyMatrix3(m) {
		const r = this.r, g = this.g, b = this.b;
		const e = m.elements;
		this.r = e[0] * r + e[3] * g + e[6] * b;
		this.g = e[1] * r + e[4] * g + e[7] * b;
		this.b = e[2] * r + e[5] * g + e[8] * b;
		return this;
	}
	/**
	* Returns `true` if this color is equal with the given one.
	*
	* @param {Color} c - The color to test for equality.
	* @return {boolean} Whether this bounding color is equal with the given one.
	*/
	equals(c) {
		return c.r === this.r && c.g === this.g && c.b === this.b;
	}
	/**
	* Sets this color's RGB components from the given array.
	*
	* @param {Array<number>} array - An array holding the RGB values.
	* @param {number} [offset=0] - The offset into the array.
	* @return {Color} A reference to this color.
	*/
	fromArray(array, offset = 0) {
		this.r = array[offset];
		this.g = array[offset + 1];
		this.b = array[offset + 2];
		return this;
	}
	/**
	* Writes the RGB components of this color to the given array. If no array is provided,
	* the method returns a new instance.
	*
	* @param {Array<number>} [array=[]] - The target array holding the color components.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Array<number>} The color components.
	*/
	toArray(array = [], offset = 0) {
		array[offset] = this.r;
		array[offset + 1] = this.g;
		array[offset + 2] = this.b;
		return array;
	}
	/**
	* Sets the components of this color from the given buffer attribute.
	*
	* @param {BufferAttribute} attribute - The buffer attribute holding color data.
	* @param {number} index - The index into the attribute.
	* @return {Color} A reference to this color.
	*/
	fromBufferAttribute(attribute, index) {
		this.r = attribute.getX(index);
		this.g = attribute.getY(index);
		this.b = attribute.getZ(index);
		return this;
	}
	/**
	* This methods defines the serialization result of this class. Returns the color
	* as a hexadecimal value.
	*
	* @return {number} The hexadecimal value.
	*/
	toJSON() {
		return this.getHex();
	}
	*[Symbol.iterator]() {
		yield this.r;
		yield this.g;
		yield this.b;
	}
};
const _color = /*@__PURE__*/ new Color();
/**
* A dictionary with X11 color names.
*
* Note that multiple words such as Dark Orange become the string 'darkorange'.
*
* @static
* @type {Object}
*/
Color.NAMES = _colorKeywords;
/**
* Converts an array to a specific type.
*
* @param {TypedArray|Array} array - The array to convert.
* @param {TypedArray.constructor} type - The constructor of a typed array that defines the new type.
* @return {TypedArray} The converted array.
*/
function convertArray(array, type) {
	if (!array || array.constructor === type) return array;
	if (typeof type.BYTES_PER_ELEMENT === "number") return new type(array);
	return Array.prototype.slice.call(array);
}
/**
* Returns `true` if the given keyframe track settings hold Bezier tangent data.
*
* @param {?Object} settings - The settings of a keyframe track.
* @return {boolean} Whether both tangent arrays are defined or not.
*/
function hasTangents(settings) {
	return settings !== void 0 && settings.inTangents !== void 0 && settings.outTangents !== void 0;
}
/**
* Abstract base class of interpolants over parametric samples.
*
* The parameter domain is one dimensional, typically the time or a path
* along a curve defined by the data.
*
* The sample values can have any dimensionality and derived classes may
* apply special interpretations to the data.
*
* This class provides the interval seek in a Template Method, deferring
* the actual interpolation to derived classes.
*
* Time complexity is O(1) for linear access crossing at most two points
* and O(log N) for random access, where N is the number of positions.
*
* References: {@link http://www.oodesign.com/template-method-pattern.html}
*
* @abstract
*/
var Interpolant = class {
	/**
	* Constructs a new interpolant.
	*
	* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
	* @param {TypedArray} sampleValues - The sample values.
	* @param {number} sampleSize - The sample size
	* @param {TypedArray} [resultBuffer] - The result buffer.
	*/
	constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
		/**
		* The parameter positions.
		*
		* @type {TypedArray}
		*/
		this.parameterPositions = parameterPositions;
		/**
		* A cache index.
		*
		* @private
		* @type {number}
		* @default 0
		*/
		this._cachedIndex = 0;
		/**
		* The result buffer.
		*
		* @type {TypedArray}
		*/
		this.resultBuffer = resultBuffer !== void 0 ? resultBuffer : new sampleValues.constructor(sampleSize);
		/**
		* The sample values.
		*
		* @type {TypedArray}
		*/
		this.sampleValues = sampleValues;
		/**
		* The value size.
		*
		* @type {TypedArray}
		*/
		this.valueSize = sampleSize;
		/**
		* The interpolation settings.
		*
		* @type {?Object}
		* @default null
		*/
		this.settings = null;
		/**
		* The default settings object.
		*
		* @type {Object}
		*/
		this.DefaultSettings_ = {};
	}
	/**
	* Evaluate the interpolant at position `t`.
	*
	* @param {number} t - The interpolation factor.
	* @return {TypedArray} The result buffer.
	*/
	evaluate(t) {
		const pp = this.parameterPositions;
		let i1 = this._cachedIndex, t1 = pp[i1], t0 = pp[i1 - 1];
		validate_interval: {
			seek: {
				let right;
				linear_scan: {
					forward_scan: if (!(t < t1)) {
						for (let giveUpAt = i1 + 2;;) {
							if (t1 === void 0) {
								if (t < t0) break forward_scan;
								i1 = pp.length;
								this._cachedIndex = i1;
								return this.copySampleValue_(i1 - 1);
							}
							if (i1 === giveUpAt) break;
							t0 = t1;
							t1 = pp[++i1];
							if (t < t1) break seek;
						}
						right = pp.length;
						break linear_scan;
					}
					if (!(t >= t0)) {
						const t1global = pp[1];
						if (t < t1global) {
							i1 = 2;
							t0 = t1global;
						}
						for (let giveUpAt = i1 - 2;;) {
							if (t0 === void 0) {
								this._cachedIndex = 0;
								return this.copySampleValue_(0);
							}
							if (i1 === giveUpAt) break;
							t1 = t0;
							t0 = pp[--i1 - 1];
							if (t >= t0) break seek;
						}
						right = i1;
						i1 = 0;
						break linear_scan;
					}
					break validate_interval;
				}
				while (i1 < right) {
					const mid = i1 + right >>> 1;
					if (t < pp[mid]) right = mid;
					else i1 = mid + 1;
				}
				t1 = pp[i1];
				t0 = pp[i1 - 1];
				if (t0 === void 0) {
					this._cachedIndex = 0;
					return this.copySampleValue_(0);
				}
				if (t1 === void 0) {
					i1 = pp.length;
					this._cachedIndex = i1;
					return this.copySampleValue_(i1 - 1);
				}
			}
			this._cachedIndex = i1;
			this.intervalChanged_(i1, t0, t1);
		}
		return this.interpolate_(i1, t0, t, t1);
	}
	/**
	* Returns the interpolation settings.
	*
	* @return {Object} The interpolation settings.
	*/
	getSettings_() {
		return this.settings || this.DefaultSettings_;
	}
	/**
	* Copies a sample value to the result buffer.
	*
	* @param {number} index - An index into the sample value buffer.
	* @return {TypedArray} The result buffer.
	*/
	copySampleValue_(index) {
		const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, offset = index * stride;
		for (let i = 0; i !== stride; ++i) result[i] = values[offset + i];
		return result;
	}
	/**
	* Copies a sample value to the result buffer.
	*
	* @abstract
	* @param {number} i1 - An index into the sample value buffer.
	* @param {number} t0 - The previous interpolation factor.
	* @param {number} t - The current interpolation factor.
	* @param {number} t1 - The next interpolation factor.
	* @return {TypedArray} The result buffer.
	*/
	interpolate_() {
		throw new Error("THREE.Interpolant: Call to abstract method.");
	}
	/**
	* Optional method that is executed when the interval has changed.
	*
	* @param {number} i1 - An index into the sample value buffer.
	* @param {number} t0 - The previous interpolation factor.
	* @param {number} t - The current interpolation factor.
	*/
	intervalChanged_() {}
};
/**
* Fast and simple cubic spline interpolant.
*
* It was derived from a Hermitian construction setting the first derivative
* at each sample position to the linear slope between neighboring positions
* over their parameter interval.
*
* @augments Interpolant
*/
var CubicInterpolant = class extends Interpolant {
	/**
	* Constructs a new cubic interpolant.
	*
	* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
	* @param {TypedArray} sampleValues - The sample values.
	* @param {number} sampleSize - The sample size
	* @param {TypedArray} [resultBuffer] - The result buffer.
	*/
	constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
		super(parameterPositions, sampleValues, sampleSize, resultBuffer);
		this._weightPrev = -0;
		this._offsetPrev = -0;
		this._weightNext = -0;
		this._offsetNext = -0;
		this.DefaultSettings_ = {
			endingStart: ZeroCurvatureEnding,
			endingEnd: ZeroCurvatureEnding
		};
	}
	intervalChanged_(i1, t0, t1) {
		const pp = this.parameterPositions;
		let iPrev = i1 - 2, iNext = i1 + 1, tPrev = pp[iPrev], tNext = pp[iNext];
		if (tPrev === void 0) switch (this.getSettings_().endingStart) {
			case ZeroSlopeEnding:
				iPrev = i1;
				tPrev = 2 * t0 - t1;
				break;
			case WrapAroundEnding:
				iPrev = pp.length - 2;
				tPrev = t0 + pp[iPrev] - pp[iPrev + 1];
				break;
			default:
				iPrev = i1;
				tPrev = t1;
		}
		if (tNext === void 0) switch (this.getSettings_().endingEnd) {
			case ZeroSlopeEnding:
				iNext = i1;
				tNext = 2 * t1 - t0;
				break;
			case WrapAroundEnding:
				iNext = 1;
				tNext = t1 + pp[1] - pp[0];
				break;
			default:
				iNext = i1 - 1;
				tNext = t0;
		}
		const halfDt = (t1 - t0) * .5, stride = this.valueSize;
		this._weightPrev = halfDt / (t0 - tPrev);
		this._weightNext = halfDt / (tNext - t1);
		this._offsetPrev = iPrev * stride;
		this._offsetNext = iNext * stride;
	}
	interpolate_(i1, t0, t, t1) {
		const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, o1 = i1 * stride, o0 = o1 - stride, oP = this._offsetPrev, oN = this._offsetNext, wP = this._weightPrev, wN = this._weightNext, p = (t - t0) / (t1 - t0), pp = p * p, ppp = pp * p;
		const sP = -wP * ppp + 2 * wP * pp - wP * p;
		const s0 = (1 + wP) * ppp + (-1.5 - 2 * wP) * pp + (-.5 + wP) * p + 1;
		const s1 = (-1 - wN) * ppp + (1.5 + wN) * pp + .5 * p;
		const sN = wN * ppp - wN * pp;
		for (let i = 0; i !== stride; ++i) result[i] = sP * values[oP + i] + s0 * values[o0 + i] + s1 * values[o1 + i] + sN * values[oN + i];
		return result;
	}
};
/**
* A basic linear interpolant.
*
* @augments Interpolant
*/
var LinearInterpolant = class extends Interpolant {
	/**
	* Constructs a new linear interpolant.
	*
	* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
	* @param {TypedArray} sampleValues - The sample values.
	* @param {number} sampleSize - The sample size
	* @param {TypedArray} [resultBuffer] - The result buffer.
	*/
	constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
		super(parameterPositions, sampleValues, sampleSize, resultBuffer);
	}
	interpolate_(i1, t0, t, t1) {
		const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, offset1 = i1 * stride, offset0 = offset1 - stride, weight1 = (t - t0) / (t1 - t0), weight0 = 1 - weight1;
		for (let i = 0; i !== stride; ++i) result[i] = values[offset0 + i] * weight0 + values[offset1 + i] * weight1;
		return result;
	}
};
/**
* Interpolant that evaluates to the sample value at the position preceding
* the parameter.
*
* @augments Interpolant
*/
var DiscreteInterpolant = class extends Interpolant {
	/**
	* Constructs a new discrete interpolant.
	*
	* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
	* @param {TypedArray} sampleValues - The sample values.
	* @param {number} sampleSize - The sample size
	* @param {TypedArray} [resultBuffer] - The result buffer.
	*/
	constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
		super(parameterPositions, sampleValues, sampleSize, resultBuffer);
	}
	interpolate_(i1) {
		return this.copySampleValue_(i1 - 1);
	}
};
/**
* A Bezier interpolant using cubic Bezier curves with 2D control points.
*
* This interpolant supports the COLLADA/Maya style of Bezier animation where
* each keyframe has explicit in/out tangent control points specified as
* 2D coordinates (time, value).
*
* Tangent data is read from `inTangents` and `outTangents` on the interpolant
* (populated by `KeyframeTrack.InterpolantFactoryMethodBezier`).
*
* For a track with N keyframes and stride S:
* - Each tangent array has N * S * 2 values
* - Layout: [k0_c0_time, k0_c0_value, k0_c1_time, k0_c1_value, ..., k0_cS_time, k0_cS_value,
*            k1_c0_time, k1_c0_value, ...]
*
* @augments Interpolant
*/
var BezierInterpolant = class extends Interpolant {
	interpolate_(i1, t0, t, t1) {
		const result = this.resultBuffer;
		const values = this.sampleValues;
		const stride = this.valueSize;
		const offset1 = i1 * stride;
		const offset0 = offset1 - stride;
		const inTangents = this.inTangents;
		const outTangents = this.outTangents;
		if (!inTangents || !outTangents) {
			const weight1 = (t - t0) / (t1 - t0);
			const weight0 = 1 - weight1;
			for (let i = 0; i !== stride; ++i) result[i] = values[offset0 + i] * weight0 + values[offset1 + i] * weight1;
			return result;
		}
		const tangentStride = stride * 2;
		const i0 = i1 - 1;
		for (let i = 0; i !== stride; ++i) {
			const v0 = values[offset0 + i];
			const v1 = values[offset1 + i];
			const outTangentOffset = i0 * tangentStride + i * 2;
			const c0x = outTangents[outTangentOffset];
			const c0y = outTangents[outTangentOffset + 1];
			const inTangentOffset = i1 * tangentStride + i * 2;
			const c1x = inTangents[inTangentOffset];
			const c1y = inTangents[inTangentOffset + 1];
			const s = solveBezierParameter(t, t0, c0x, c1x, t1);
			result[i] = cubicBezier(s, v0, c0y, c1y, v1);
		}
		return result;
	}
};
function cubicBezier(s, p0, p1, p2, p3) {
	const k = 1 - s;
	return k * k * k * p0 + 3 * k * k * s * p1 + 3 * k * s * s * p2 + s * s * s * p3;
}
function cubicBezierSlope(s, p0, p1, p2, p3) {
	const k = 1 - s;
	return 3 * k * k * (p1 - p0) + 6 * k * s * (p2 - p1) + 3 * s * s * (p3 - p2);
}
function solveBezierParameter(x, x0, x1, x2, x3) {
	let s = (x - x0) / (x3 - x0);
	for (let i = 0; i < 8; i++) {
		const error = cubicBezier(s, x0, x1, x2, x3) - x;
		if (Math.abs(error) < 1e-10) break;
		const slope = cubicBezierSlope(s, x0, x1, x2, x3);
		if (Math.abs(slope) < 1e-10) break;
		s = Math.max(0, Math.min(1, s - error / slope));
	}
	return s;
}
/**
* Represents a timed sequence of keyframes, which are composed of lists of
* times and related values, and which are used to animate a specific property
* of an object.
*/
var KeyframeTrack = class {
	/**
	* Constructs a new keyframe track.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<number|string|boolean>} values - A list of keyframe values.
	* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)} [interpolation] - The interpolation type.
	*/
	constructor(name, times, values, interpolation) {
		if (name === void 0) throw new Error("THREE.KeyframeTrack: track name is undefined");
		if (times === void 0 || times.length === 0) throw new Error("THREE.KeyframeTrack: no keyframes in track named " + name);
		/**
		* The track's name can refer to morph targets or bones or
		* possibly other values within an animated object. See {@link PropertyBinding#parseTrackName}
		* for the forms of strings that can be parsed for property binding.
		*
		* @type {string}
		*/
		this.name = name;
		/**
		* The keyframe times.
		*
		* @type {Float32Array}
		*/
		this.times = convertArray(times, this.TimeBufferType);
		/**
		* The keyframe values.
		*
		* @type {Float32Array}
		*/
		this.values = convertArray(values, this.ValueBufferType);
		this.setInterpolation(interpolation || this.DefaultInterpolation);
	}
	/**
	* Converts the keyframe track to JSON.
	*
	* @static
	* @param {KeyframeTrack} track - The keyframe track to serialize.
	* @return {Object} The serialized keyframe track as JSON.
	*/
	static toJSON(track) {
		const trackType = track.constructor;
		let json;
		if (trackType.toJSON !== this.toJSON) json = trackType.toJSON(track);
		else {
			json = {
				"name": track.name,
				"times": convertArray(track.times, Array),
				"values": convertArray(track.values, Array)
			};
			const interpolation = track.getInterpolation();
			if (interpolation !== track.DefaultInterpolation) json.interpolation = interpolation;
			if (hasTangents(track.settings)) json.settings = {
				inTangents: convertArray(track.settings.inTangents, Array),
				outTangents: convertArray(track.settings.outTangents, Array)
			};
		}
		json.type = track.ValueTypeName;
		return json;
	}
	/**
	* Factory method for creating a new discrete interpolant.
	*
	* @static
	* @param {TypedArray} [result] - The result buffer.
	* @return {DiscreteInterpolant} The new interpolant.
	*/
	InterpolantFactoryMethodDiscrete(result) {
		return new DiscreteInterpolant(this.times, this.values, this.getValueSize(), result);
	}
	/**
	* Factory method for creating a new linear interpolant.
	*
	* @static
	* @param {TypedArray} [result] - The result buffer.
	* @return {LinearInterpolant} The new interpolant.
	*/
	InterpolantFactoryMethodLinear(result) {
		return new LinearInterpolant(this.times, this.values, this.getValueSize(), result);
	}
	/**
	* Factory method for creating a new smooth interpolant.
	*
	* @static
	* @param {TypedArray} [result] - The result buffer.
	* @return {CubicInterpolant} The new interpolant.
	*/
	InterpolantFactoryMethodSmooth(result) {
		return new CubicInterpolant(this.times, this.values, this.getValueSize(), result);
	}
	/**
	* Factory method for creating a new Bezier interpolant.
	*
	* The Bezier interpolant requires tangent data to be set via the `settings` property
	* on the track before creating the interpolant. The settings should contain:
	* - `inTangents`: Float32Array with [time, value] pairs per keyframe per component
	* - `outTangents`: Float32Array with [time, value] pairs per keyframe per component
	*
	* @static
	* @param {TypedArray} [result] - The result buffer.
	* @return {BezierInterpolant} The new interpolant.
	*/
	InterpolantFactoryMethodBezier(result) {
		const interpolant = new BezierInterpolant(this.times, this.values, this.getValueSize(), result);
		if (this.settings) {
			interpolant.inTangents = this.settings.inTangents;
			interpolant.outTangents = this.settings.outTangents;
		}
		return interpolant;
	}
	/**
	* Defines the interpolation factor method for this keyframe track.
	*
	* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)} interpolation - The interpolation type.
	* @return {KeyframeTrack} A reference to this keyframe track.
	*/
	setInterpolation(interpolation) {
		let factoryMethod;
		switch (interpolation) {
			case InterpolateDiscrete:
				factoryMethod = this.InterpolantFactoryMethodDiscrete;
				break;
			case InterpolateLinear:
				factoryMethod = this.InterpolantFactoryMethodLinear;
				break;
			case InterpolateSmooth:
				factoryMethod = this.InterpolantFactoryMethodSmooth;
				break;
			case InterpolateBezier: factoryMethod = this.InterpolantFactoryMethodBezier;
		}
		if (factoryMethod === void 0) {
			const message = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
			if (this.createInterpolant === void 0) {
				if (interpolation !== this.DefaultInterpolation) this.setInterpolation(this.DefaultInterpolation);
				else throw new Error(message);
			}
			warn("KeyframeTrack:", message);
			return this;
		}
		this.createInterpolant = factoryMethod;
		return this;
	}
	/**
	* Returns the current interpolation type.
	*
	* @return {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)} The interpolation type.
	*/
	getInterpolation() {
		switch (this.createInterpolant) {
			case this.InterpolantFactoryMethodDiscrete: return InterpolateDiscrete;
			case this.InterpolantFactoryMethodLinear: return InterpolateLinear;
			case this.InterpolantFactoryMethodSmooth: return InterpolateSmooth;
			case this.InterpolantFactoryMethodBezier: return InterpolateBezier;
		}
	}
	/**
	* Returns the value size.
	*
	* @return {number} The value size.
	*/
	getValueSize() {
		return this.values.length / this.times.length;
	}
	/**
	* Moves all keyframes either forward or backward in time.
	*
	* @param {number} timeOffset - The offset to move the time values.
	* @return {KeyframeTrack} A reference to this keyframe track.
	*/
	shift(timeOffset) {
		if (timeOffset !== 0) {
			const times = this.times;
			for (let i = 0, n = times.length; i !== n; ++i) times[i] += timeOffset;
		}
		return this;
	}
	/**
	* Scale all keyframe times by a factor (useful for frame - seconds conversions).
	*
	* @param {number} timeScale - The time scale.
	* @return {KeyframeTrack} A reference to this keyframe track.
	*/
	scale(timeScale) {
		if (timeScale !== 1) {
			const times = this.times;
			for (let i = 0, n = times.length; i !== n; ++i) times[i] *= timeScale;
			if (hasTangents(this.settings)) {
				scaleTangentTimes(this.settings.inTangents, timeScale);
				scaleTangentTimes(this.settings.outTangents, timeScale);
			}
		}
		return this;
	}
	/**
	* Removes keyframes before and after animation without changing any values within the defined time range.
	*
	* Note: The method does not shift around keys to the start of the track time, because for interpolated
	* keys this will change their values
	*
	* @param {number} startTime - The start time.
	* @param {number} endTime - The end time.
	* @return {KeyframeTrack} A reference to this keyframe track.
	*/
	trim(startTime, endTime) {
		const times = this.times, nKeys = times.length;
		let from = 0, to = nKeys - 1;
		while (from !== nKeys && times[from] < startTime) ++from;
		while (to !== -1 && times[to] > endTime) --to;
		++to;
		if (from !== 0 || to !== nKeys) {
			if (from >= to) {
				to = Math.max(to, 1);
				from = to - 1;
			}
			const stride = this.getValueSize();
			this.times = times.slice(from, to);
			this.values = this.values.slice(from * stride, to * stride);
		}
		return this;
	}
	/**
	* Performs minimal validation on the keyframe track. Returns `true` if the values
	* are valid.
	*
	* @return {boolean} Whether the keyframes are valid or not.
	*/
	validate() {
		let valid = true;
		const valueSize = this.getValueSize();
		if (valueSize - Math.floor(valueSize) !== 0) {
			error("KeyframeTrack: Invalid value size in track.", this);
			valid = false;
		}
		const times = this.times, values = this.values, nKeys = times.length;
		if (nKeys === 0) {
			error("KeyframeTrack: Track is empty.", this);
			valid = false;
		}
		let prevTime = null;
		for (let i = 0; i !== nKeys; i++) {
			const currTime = times[i];
			if (typeof currTime === "number" && isNaN(currTime)) {
				error("KeyframeTrack: Time is not a valid number.", this, i, currTime);
				valid = false;
				break;
			}
			if (prevTime !== null && prevTime > currTime) {
				error("KeyframeTrack: Out of order keys.", this, i, currTime, prevTime);
				valid = false;
				break;
			}
			prevTime = currTime;
		}
		if (values !== void 0) {
			if (isTypedArray(values)) for (let i = 0, n = values.length; i !== n; ++i) {
				const value = values[i];
				if (isNaN(value)) {
					error("KeyframeTrack: Value is not a valid number.", this, i, value);
					valid = false;
					break;
				}
			}
		}
		return valid;
	}
	/**
	* Optimizes this keyframe track by removing equivalent sequential keys (which are
	* common in morph target sequences).
	*
	* @return {KeyframeTrack} A reference to this keyframe track.
	*/
	optimize() {
		const times = this.times.slice(), values = this.values.slice(), stride = this.getValueSize(), smoothInterpolation = this.getInterpolation() === InterpolateSmooth, lastIndex = times.length - 1;
		let writeIndex = 1;
		for (let i = 1; i < lastIndex; ++i) {
			let keep = false;
			const time = times[i];
			if (time !== times[i + 1] && (i !== 1 || time !== times[0])) {
				if (!smoothInterpolation) {
					const offset = i * stride, offsetP = offset - stride, offsetN = offset + stride;
					for (let j = 0; j !== stride; ++j) {
						const value = values[offset + j];
						if (value !== values[offsetP + j] || value !== values[offsetN + j]) {
							keep = true;
							break;
						}
					}
				} else keep = true;
			}
			if (keep) {
				if (i !== writeIndex) {
					times[writeIndex] = times[i];
					const readOffset = i * stride, writeOffset = writeIndex * stride;
					for (let j = 0; j !== stride; ++j) values[writeOffset + j] = values[readOffset + j];
				}
				++writeIndex;
			}
		}
		if (lastIndex > 0) {
			times[writeIndex] = times[lastIndex];
			for (let readOffset = lastIndex * stride, writeOffset = writeIndex * stride, j = 0; j !== stride; ++j) values[writeOffset + j] = values[readOffset + j];
			++writeIndex;
		}
		if (writeIndex !== times.length) {
			this.times = times.slice(0, writeIndex);
			this.values = values.slice(0, writeIndex * stride);
		} else {
			this.times = times;
			this.values = values;
		}
		return this;
	}
	/**
	* Returns a new keyframe track with copied values from this instance.
	*
	* @return {KeyframeTrack} A clone of this instance.
	*/
	clone() {
		const times = this.times.slice();
		const values = this.values.slice();
		const TypedKeyframeTrack = this.constructor;
		const track = new TypedKeyframeTrack(this.name, times, values);
		track.createInterpolant = this.createInterpolant;
		if (hasTangents(this.settings)) track.settings = {
			inTangents: this.settings.inTangents.slice(),
			outTangents: this.settings.outTangents.slice()
		};
		return track;
	}
};
function scaleTangentTimes(tangents, timeScale) {
	for (let i = 0, n = tangents.length; i !== n; i += 2) tangents[i] *= timeScale;
}
/**
* The value type name.
*
* @type {string}
* @default ''
*/
KeyframeTrack.prototype.ValueTypeName = "";
/**
* The time buffer type of this keyframe track.
*
* @type {TypedArray|Array}
* @default Float32Array.constructor
*/
KeyframeTrack.prototype.TimeBufferType = Float32Array;
/**
* The value buffer type of this keyframe track.
*
* @type {TypedArray|Array}
* @default Float32Array.constructor
*/
KeyframeTrack.prototype.ValueBufferType = Float32Array;
/**
* The default interpolation type of this keyframe track.
*
* @type {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)}
* @default InterpolateLinear
*/
KeyframeTrack.prototype.DefaultInterpolation = InterpolateLinear;
/**
* A track for boolean keyframe values.
*
* @augments KeyframeTrack
*/
var BooleanKeyframeTrack = class extends KeyframeTrack {
	/**
	* Constructs a new boolean keyframe track.
	*
	* This keyframe track type has no `interpolation` parameter because the
	* interpolation is always discrete.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<boolean>} values - A list of keyframe values.
	*/
	constructor(name, times, values) {
		super(name, times, values);
	}
};
/**
* The value type name.
*
* @type {string}
* @default 'bool'
*/
BooleanKeyframeTrack.prototype.ValueTypeName = "bool";
/**
* The value buffer type of this keyframe track.
*
* @type {TypedArray|Array}
* @default Array.constructor
*/
BooleanKeyframeTrack.prototype.ValueBufferType = Array;
/**
* The default interpolation type of this keyframe track.
*
* @type {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)}
* @default InterpolateDiscrete
*/
BooleanKeyframeTrack.prototype.DefaultInterpolation = InterpolateDiscrete;
BooleanKeyframeTrack.prototype.InterpolantFactoryMethodLinear = void 0;
BooleanKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
/**
* A track for color keyframe values.
*
* @augments KeyframeTrack
*/
var ColorKeyframeTrack = class extends KeyframeTrack {
	/**
	* Constructs a new color keyframe track.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<number>} values - A list of keyframe values.
	* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
	*/
	constructor(name, times, values, interpolation) {
		super(name, times, values, interpolation);
	}
};
/**
* The value type name.
*
* @type {string}
* @default 'color'
*/
ColorKeyframeTrack.prototype.ValueTypeName = "color";
/**
* A track for numeric keyframe values.
*
* @augments KeyframeTrack
*/
var NumberKeyframeTrack = class extends KeyframeTrack {
	/**
	* Constructs a new number keyframe track.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<number>} values - A list of keyframe values.
	* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
	*/
	constructor(name, times, values, interpolation) {
		super(name, times, values, interpolation);
	}
};
/**
* The value type name.
*
* @type {string}
* @default 'number'
*/
NumberKeyframeTrack.prototype.ValueTypeName = "number";
/**
* Spherical linear unit quaternion interpolant.
*
* @augments Interpolant
*/
var QuaternionLinearInterpolant = class extends Interpolant {
	/**
	* Constructs a new SLERP interpolant.
	*
	* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
	* @param {TypedArray} sampleValues - The sample values.
	* @param {number} sampleSize - The sample size
	* @param {TypedArray} [resultBuffer] - The result buffer.
	*/
	constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
		super(parameterPositions, sampleValues, sampleSize, resultBuffer);
	}
	interpolate_(i1, t0, t, t1) {
		const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, alpha = (t - t0) / (t1 - t0);
		let offset = i1 * stride;
		for (let end = offset + stride; offset !== end; offset += 4) Quaternion.slerpFlat(result, 0, values, offset - stride, values, offset, alpha);
		return result;
	}
};
/**
* A track for Quaternion keyframe values.
*
* @augments KeyframeTrack
*/
var QuaternionKeyframeTrack = class extends KeyframeTrack {
	/**
	* Constructs a new Quaternion keyframe track.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<number>} values - A list of keyframe values.
	* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
	*/
	constructor(name, times, values, interpolation) {
		super(name, times, values, interpolation);
	}
	/**
	* Overwritten so the method returns Quaternion based interpolant.
	*
	* @static
	* @param {TypedArray} [result] - The result buffer.
	* @return {QuaternionLinearInterpolant} The new interpolant.
	*/
	InterpolantFactoryMethodLinear(result) {
		return new QuaternionLinearInterpolant(this.times, this.values, this.getValueSize(), result);
	}
};
/**
* The value type name.
*
* @type {string}
* @default 'quaternion'
*/
QuaternionKeyframeTrack.prototype.ValueTypeName = "quaternion";
QuaternionKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
/**
* A track for string keyframe values.
*
* @augments KeyframeTrack
*/
var StringKeyframeTrack = class extends KeyframeTrack {
	/**
	* Constructs a new string keyframe track.
	*
	* This keyframe track type has no `interpolation` parameter because the
	* interpolation is always discrete.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<string>} values - A list of keyframe values.
	*/
	constructor(name, times, values) {
		super(name, times, values);
	}
};
/**
* The value type name.
*
* @type {string}
* @default 'string'
*/
StringKeyframeTrack.prototype.ValueTypeName = "string";
/**
* The value buffer type of this keyframe track.
*
* @type {TypedArray|Array}
* @default Array.constructor
*/
StringKeyframeTrack.prototype.ValueBufferType = Array;
/**
* The default interpolation type of this keyframe track.
*
* @type {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)}
* @default InterpolateDiscrete
*/
StringKeyframeTrack.prototype.DefaultInterpolation = InterpolateDiscrete;
StringKeyframeTrack.prototype.InterpolantFactoryMethodLinear = void 0;
StringKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
/**
* A track for vector keyframe values.
*
* @augments KeyframeTrack
*/
var VectorKeyframeTrack = class extends KeyframeTrack {
	/**
	* Constructs a new vector keyframe track.
	*
	* @param {string} name - The keyframe track's name.
	* @param {Array<number>} times - A list of keyframe times.
	* @param {Array<number>} values - A list of keyframe values.
	* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
	*/
	constructor(name, times, values, interpolation) {
		super(name, times, values, interpolation);
	}
};
/**
* The value type name.
*
* @type {string}
* @default 'vector'
*/
VectorKeyframeTrack.prototype.ValueTypeName = "vector";
/**
* Handles and keeps track of loaded and pending data. A default global
* instance of this class is created and used by loaders if not supplied
* manually.
*
* In general that should be sufficient, however there are times when it can
* be useful to have separate loaders - for example if you want to show
* separate loading bars for objects and textures.
*
* ```js
* const manager = new THREE.LoadingManager();
* manager.onLoad = () => console.log( 'Loading complete!' );
*
* const loader1 = new OBJLoader( manager );
* const loader2 = new ColladaLoader( manager );
* ```
*/
var LoadingManager = class {
	/**
	* Constructs a new loading manager.
	*
	* @param {Function} [onLoad] - Executes when all items have been loaded.
	* @param {Function} [onProgress] - Executes when single items have been loaded.
	* @param {Function} [onError] - Executes when an error occurs.
	*/
	constructor(onLoad, onProgress, onError) {
		const scope = this;
		let isLoading = false;
		let itemsLoaded = 0;
		let itemsTotal = 0;
		let urlModifier = void 0;
		const handlers = [];
		/**
		* Executes when an item starts loading.
		*
		* @type {Function|undefined}
		* @default undefined
		*/
		this.onStart = void 0;
		/**
		* Executes when all items have been loaded.
		*
		* @type {Function|undefined}
		* @default undefined
		*/
		this.onLoad = onLoad;
		/**
		* Executes when single items have been loaded.
		*
		* @type {Function|undefined}
		* @default undefined
		*/
		this.onProgress = onProgress;
		/**
		* Executes when an error occurs.
		*
		* @type {Function|undefined}
		* @default undefined
		*/
		this.onError = onError;
		/**
		* Used for aborting ongoing requests in loaders using this manager.
		*
		* @private
		* @type {AbortController | null}
		*/
		this._abortController = null;
		/**
		* This should be called by any loader using the manager when the loader
		* starts loading an item.
		*
		* @param {string} url - The URL to load.
		*/
		this.itemStart = function(url) {
			itemsTotal++;
			if (isLoading === false) {
				if (scope.onStart !== void 0) scope.onStart(url, itemsLoaded, itemsTotal);
			}
			isLoading = true;
		};
		/**
		* This should be called by any loader using the manager when the loader
		* ended loading an item.
		*
		* @param {string} url - The URL of the loaded item.
		*/
		this.itemEnd = function(url) {
			itemsLoaded++;
			if (scope.onProgress !== void 0) scope.onProgress(url, itemsLoaded, itemsTotal);
			if (itemsLoaded === itemsTotal) {
				isLoading = false;
				if (scope.onLoad !== void 0) scope.onLoad();
			}
		};
		/**
		* This should be called by any loader using the manager when the loader
		* encounters an error when loading an item.
		*
		* @param {string} url - The URL of the item that produces an error.
		*/
		this.itemError = function(url) {
			if (scope.onError !== void 0) scope.onError(url);
		};
		/**
		* Given a URL, uses the URL modifier callback (if any) and returns a
		* resolved URL. If no URL modifier is set, returns the original URL.
		*
		* @param {string} url - The URL to load.
		* @return {string} The resolved URL.
		*/
		this.resolveURL = function(url) {
			url = url.normalize("NFC");
			if (urlModifier) return urlModifier(url);
			return url;
		};
		/**
		* If provided, the callback will be passed each resource URL before a
		* request is sent. The callback may return the original URL, or a new URL to
		* override loading behavior. This behavior can be used to load assets from
		* .ZIP files, drag-and-drop APIs, and Data URIs.
		*
		* ```js
		* const blobs = {'fish.gltf': blob1, 'diffuse.png': blob2, 'normal.png': blob3};
		*
		* const manager = new THREE.LoadingManager();
		*
		* // Initialize loading manager with URL callback.
		* const objectURLs = [];
		* manager.setURLModifier( ( url ) => {
		*
		* 	url = URL.createObjectURL( blobs[ url ] );
		* 	objectURLs.push( url );
		* 	return url;
		*
		* } );
		*
		* // Load as usual, then revoke the blob URLs.
		* const loader = new GLTFLoader( manager );
		* loader.load( 'fish.gltf', (gltf) => {
		*
		* 	scene.add( gltf.scene );
		* 	objectURLs.forEach( ( url ) => URL.revokeObjectURL( url ) );
		*
		* } );
		* ```
		*
		* @param {function(string):string} transform - URL modifier callback. Called with an URL and must return a resolved URL.
		* @return {LoadingManager} A reference to this loading manager.
		*/
		this.setURLModifier = function(transform) {
			urlModifier = transform;
			return this;
		};
		/**
		* Registers a loader with the given regular expression. Can be used to
		* define what loader should be used in order to load specific files. A
		* typical use case is to overwrite the default loader for textures.
		*
		* ```js
		* // add handler for TGA textures
		* manager.addHandler( /\.tga$/i, new TGALoader() );
		* ```
		*
		* @param {string} regex - A regular expression.
		* @param {Loader} loader - A loader that should handle matched cases.
		* @return {LoadingManager} A reference to this loading manager.
		*/
		this.addHandler = function(regex, loader) {
			handlers.push(regex, loader);
			return this;
		};
		/**
		* Removes the loader for the given regular expression.
		*
		* @param {string} regex - A regular expression.
		* @return {LoadingManager} A reference to this loading manager.
		*/
		this.removeHandler = function(regex) {
			const index = handlers.indexOf(regex);
			if (index !== -1) handlers.splice(index, 2);
			return this;
		};
		/**
		* Can be used to retrieve the registered loader for the given file path.
		*
		* @param {string} file - The file path.
		* @return {?Loader} The registered loader. Returns `null` if no loader was found.
		*/
		this.getHandler = function(file) {
			for (let i = 0, l = handlers.length; i < l; i += 2) {
				const regex = handlers[i];
				const loader = handlers[i + 1];
				if (regex.global) regex.lastIndex = 0;
				if (regex.test(file)) return loader;
			}
			return null;
		};
		/**
		* Can be used to abort ongoing loading requests in loaders using this manager.
		* The abort only works if the loaders implement {@link Loader#abort} and `AbortSignal.any()`
		* is supported in the browser.
		*
		* @return {LoadingManager} A reference to this loading manager.
		*/
		this.abort = function() {
			this.abortController.abort();
			this._abortController = null;
			return this;
		};
	}
	/**
	* Used for aborting ongoing requests in loaders using this manager.
	*
	* @type {AbortController}
	*/
	get abortController() {
		if (!this._abortController) this._abortController = new AbortController();
		return this._abortController;
	}
};
/**
* The global default loading manager.
*
* @constant
* @type {LoadingManager}
*/
const DefaultLoadingManager = /*@__PURE__*/ new LoadingManager();
/**
* Abstract base class for loaders.
*
* @abstract
*/
var Loader = class {
	/**
	* Constructs a new loader.
	*
	* @param {LoadingManager} [manager] - The loading manager.
	*/
	constructor(manager) {
		/**
		* The loading manager.
		*
		* @type {LoadingManager}
		* @default DefaultLoadingManager
		*/
		this.manager = manager !== void 0 ? manager : DefaultLoadingManager;
		/**
		* The crossOrigin string to implement CORS for loading the url from a
		* different domain that allows CORS.
		*
		* @type {string}
		* @default 'anonymous'
		*/
		this.crossOrigin = "anonymous";
		/**
		* Whether the XMLHttpRequest uses credentials.
		*
		* @type {boolean}
		* @default false
		*/
		this.withCredentials = false;
		/**
		* The base path from which the asset will be loaded.
		*
		* @type {string}
		*/
		this.path = "";
		/**
		* The base path from which additional resources like textures will be loaded.
		*
		* @type {string}
		*/
		this.resourcePath = "";
		/**
		* The [request header](https://developer.mozilla.org/en-US/docs/Glossary/Request_header)
		* used in HTTP request.
		*
		* @type {Object<string, any>}
		*/
		this.requestHeader = {};
		if (typeof __THREE_DEVTOOLS__ !== "undefined") __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
	}
	/**
	* This method needs to be implemented by all concrete loaders. It holds the
	* logic for loading assets from the backend.
	*
	* @abstract
	* @param {string} url - The path/URL of the file to be loaded.
	* @param {Function} onLoad - Executed when the loading process has been finished.
	* @param {onProgressCallback} [onProgress] - Executed while the loading is in progress.
	* @param {onErrorCallback} [onError] - Executed when errors occur.
	*/
	load() {}
	/**
	* A async version of {@link Loader#load}.
	*
	* @param {string} url - The path/URL of the file to be loaded.
	* @param {onProgressCallback} [onProgress] - Executed while the loading is in progress.
	* @return {Promise} A Promise that resolves when the asset has been loaded.
	*/
	loadAsync(url, onProgress) {
		const scope = this;
		return new Promise(function(resolve, reject) {
			scope.load(url, resolve, onProgress, reject);
		});
	}
	/**
	* This method needs to be implemented by all concrete loaders. It holds the
	* logic for parsing the asset into three.js entities.
	*
	* @abstract
	* @param {any} data - The data to parse.
	*/
	parse() {}
	/**
	* Sets the `crossOrigin` String to implement CORS for loading the URL
	* from a different domain that allows CORS.
	*
	* @param {string} crossOrigin - The `crossOrigin` value.
	* @return {Loader} A reference to this instance.
	*/
	setCrossOrigin(crossOrigin) {
		this.crossOrigin = crossOrigin;
		return this;
	}
	/**
	* Whether the XMLHttpRequest uses credentials such as cookies, authorization
	* headers or TLS client certificates, see [XMLHttpRequest.withCredentials](https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/withCredentials).
	*
	* Note: This setting has no effect if you are loading files locally or from the same domain.
	*
	* @param {boolean} value - The `withCredentials` value.
	* @return {Loader} A reference to this instance.
	*/
	setWithCredentials(value) {
		this.withCredentials = value;
		return this;
	}
	/**
	* Sets the base path for the asset.
	*
	* @param {string} path - The base path.
	* @return {Loader} A reference to this instance.
	*/
	setPath(path) {
		this.path = path;
		return this;
	}
	/**
	* Sets the base path for dependent resources like textures.
	*
	* @param {string} resourcePath - The resource path.
	* @return {Loader} A reference to this instance.
	*/
	setResourcePath(resourcePath) {
		this.resourcePath = resourcePath;
		return this;
	}
	/**
	* Sets the given request header.
	*
	* @param {Object} requestHeader - A [request header](https://developer.mozilla.org/en-US/docs/Glossary/Request_header)
	* for configuring the HTTP request.
	* @return {Loader} A reference to this instance.
	*/
	setRequestHeader(requestHeader) {
		this.requestHeader = requestHeader;
		return this;
	}
	/**
	* This method can be implemented in loaders for aborting ongoing requests.
	*
	* @abstract
	* @return {Loader} A reference to this instance.
	*/
	abort() {
		return this;
	}
};
/**
* Callback for onProgress in loaders.
*
* @callback onProgressCallback
* @param {ProgressEvent} event - An instance of `ProgressEvent` that represents the current loading status.
*/
/**
* Callback for onError in loaders.
*
* @callback onErrorCallback
* @param {Error} error - The error which occurred during the loading process.
*/
/**
* The default material name that is used by loaders
* when creating materials for loaded 3D objects.
*
* Note: Not all loaders might honor this setting.
*
* @static
* @type {string}
* @default '__DEFAULT'
*/
Loader.DEFAULT_MATERIAL_NAME = "__DEFAULT";
const _RESERVED_CHARS_RE = "\\[\\]\\.:\\/";
const _reservedRe = /* @__PURE__ */ new RegExp("[\\[\\]\\.:\\/]", "g");
const _wordChar = "[^\\[\\]\\.:\\/]";
const _wordCharOrDot = "[^" + _RESERVED_CHARS_RE.replace("\\.", "") + "]";
const _directoryRe = /*@__PURE__*/ /((?:WC+[\/:])*)/.source.replace("WC", _wordChar);
const _nodeRe = /*@__PURE__*/ /(WCOD+)?/.source.replace("WCOD", _wordCharOrDot);
const _objectRe = /*@__PURE__*/ /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", _wordChar);
const _propertyRe = /*@__PURE__*/ /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", _wordChar);
const _trackRe = new RegExp("^" + _directoryRe + _nodeRe + _objectRe + _propertyRe + "$");
const _supportedObjectNames = [
	"material",
	"materials",
	"bones",
	"map"
];
var Composite = class {
	constructor(targetGroup, path, optionalParsedPath) {
		const parsedPath = optionalParsedPath || PropertyBinding.parseTrackName(path);
		this._targetGroup = targetGroup;
		this._bindings = targetGroup.subscribe_(path, parsedPath);
	}
	getValue(array, offset) {
		this.bind();
		const firstValidIndex = this._targetGroup.nCachedObjects_, binding = this._bindings[firstValidIndex];
		if (binding !== void 0) binding.getValue(array, offset);
	}
	setValue(array, offset) {
		const bindings = this._bindings;
		for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) bindings[i].setValue(array, offset);
	}
	bind() {
		const bindings = this._bindings;
		for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) bindings[i].bind();
	}
	unbind() {
		const bindings = this._bindings;
		for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) bindings[i].unbind();
	}
};
/**
* This holds a reference to a real property in the scene graph; used internally.
*/
var PropertyBinding = class PropertyBinding {
	/**
	* Constructs a new property binding.
	*
	* @param {Object} rootNode - The root node.
	* @param {string} path - The path.
	* @param {?Object} [parsedPath] - The parsed path.
	*/
	constructor(rootNode, path, parsedPath) {
		/**
		* The object path to the animated property.
		*
		* @type {string}
		*/
		this.path = path;
		/**
		* An object holding information about the path.
		*
		* @type {Object}
		*/
		this.parsedPath = parsedPath || PropertyBinding.parseTrackName(path);
		/**
		* The object owns the animated property.
		*
		* @type {?Object}
		*/
		this.node = PropertyBinding.findNode(rootNode, this.parsedPath.nodeName);
		/**
		* The root node.
		*
		* @type {Object3D|Skeleton}
		*/
		this.rootNode = rootNode;
		this.getValue = this._getValue_unbound;
		this.setValue = this._setValue_unbound;
	}
	/**
	* Factory method for creating a property binding from the given parameters.
	*
	* @static
	* @param {Object} root - The root node.
	* @param {string} path - The path.
	* @param {?Object} [parsedPath] - The parsed path.
	* @return {PropertyBinding|Composite} The created property binding or composite.
	*/
	static create(root, path, parsedPath) {
		if (!(root && root.isAnimationObjectGroup)) return new PropertyBinding(root, path, parsedPath);
		else return new PropertyBinding.Composite(root, path, parsedPath);
	}
	/**
	* Replaces spaces with underscores and removes unsupported characters from
	* node names, to ensure compatibility with parseTrackName().
	*
	* @param {string} name - Node name to be sanitized.
	* @return {string} The sanitized node name.
	*/
	static sanitizeNodeName(name) {
		return name.replace(/\s/g, "_").replace(_reservedRe, "");
	}
	/**
	* Parses the given track name (an object path to an animated property) and
	* returns an object with information about the path. Matches strings in the following forms:
	*
	* - nodeName.property
	* - nodeName.property[accessor]
	* - nodeName.material.property[accessor]
	* - uuid.property[accessor]
	* - uuid.objectName[objectIndex].propertyName[propertyIndex]
	* - parentName/nodeName.property
	* - parentName/parentName/nodeName.property[index]
	* - .bone[Armature.DEF_cog].position
	* - scene:helium_balloon_model:helium_balloon_model.position
	*
	* @static
	* @param {string} trackName - The track name to parse.
	* @return {Object} The parsed track name as an object.
	*/
	static parseTrackName(trackName) {
		const matches = _trackRe.exec(trackName);
		if (matches === null) throw new Error("THREE.PropertyBinding: Cannot parse trackName: " + trackName);
		const results = {
			nodeName: matches[2],
			objectName: matches[3],
			objectIndex: matches[4],
			propertyName: matches[5],
			propertyIndex: matches[6]
		};
		const lastDot = results.nodeName && results.nodeName.lastIndexOf(".");
		if (lastDot !== void 0 && lastDot !== -1) {
			const objectName = results.nodeName.substring(lastDot + 1);
			if (_supportedObjectNames.indexOf(objectName) !== -1) {
				results.nodeName = results.nodeName.substring(0, lastDot);
				results.objectName = objectName;
			}
		}
		if (results.propertyName === null || results.propertyName.length === 0) throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: " + trackName);
		return results;
	}
	/**
	* Searches for a node in the hierarchy of the given root object by the given
	* node name.
	*
	* @static
	* @param {Object} root - The root object.
	* @param {string|number} nodeName - The name of the node.
	* @return {?Object} The found node. Returns `null` if no object was found.
	*/
	static findNode(root, nodeName) {
		if (nodeName === void 0 || nodeName === "" || nodeName === "." || nodeName === -1 || nodeName === root.name || nodeName === root.uuid) return root;
		if (root.skeleton) {
			const bone = root.skeleton.getBoneByName(nodeName);
			if (bone !== void 0) return bone;
		}
		if (root.children) {
			const searchNodeSubtree = function(children) {
				for (let i = 0; i < children.length; i++) {
					const childNode = children[i];
					if (childNode.name === nodeName || childNode.uuid === nodeName) return childNode;
					const result = searchNodeSubtree(childNode.children);
					if (result) return result;
				}
				return null;
			};
			const subTreeNode = searchNodeSubtree(root.children);
			if (subTreeNode) return subTreeNode;
		}
		return null;
	}
	_getValue_unavailable() {}
	_setValue_unavailable() {}
	_getValue_direct(buffer, offset) {
		buffer[offset] = this.targetObject[this.propertyName];
	}
	_getValue_array(buffer, offset) {
		const source = this.resolvedProperty;
		for (let i = 0, n = source.length; i !== n; ++i) buffer[offset++] = source[i];
	}
	_getValue_arrayElement(buffer, offset) {
		buffer[offset] = this.resolvedProperty[this.propertyIndex];
	}
	_getValue_toArray(buffer, offset) {
		this.resolvedProperty.toArray(buffer, offset);
	}
	_setValue_direct(buffer, offset) {
		this.targetObject[this.propertyName] = buffer[offset];
	}
	_setValue_direct_setNeedsUpdate(buffer, offset) {
		this.targetObject[this.propertyName] = buffer[offset];
		this.targetObject.needsUpdate = true;
	}
	_setValue_direct_setMatrixWorldNeedsUpdate(buffer, offset) {
		this.targetObject[this.propertyName] = buffer[offset];
		this.targetObject.matrixWorldNeedsUpdate = true;
	}
	_setValue_array(buffer, offset) {
		const dest = this.resolvedProperty;
		for (let i = 0, n = dest.length; i !== n; ++i) dest[i] = buffer[offset++];
	}
	_setValue_array_setNeedsUpdate(buffer, offset) {
		const dest = this.resolvedProperty;
		for (let i = 0, n = dest.length; i !== n; ++i) dest[i] = buffer[offset++];
		this.targetObject.needsUpdate = true;
	}
	_setValue_array_setMatrixWorldNeedsUpdate(buffer, offset) {
		const dest = this.resolvedProperty;
		for (let i = 0, n = dest.length; i !== n; ++i) dest[i] = buffer[offset++];
		this.targetObject.matrixWorldNeedsUpdate = true;
	}
	_setValue_arrayElement(buffer, offset) {
		this.resolvedProperty[this.propertyIndex] = buffer[offset];
	}
	_setValue_arrayElement_setNeedsUpdate(buffer, offset) {
		this.resolvedProperty[this.propertyIndex] = buffer[offset];
		this.targetObject.needsUpdate = true;
	}
	_setValue_arrayElement_setMatrixWorldNeedsUpdate(buffer, offset) {
		this.resolvedProperty[this.propertyIndex] = buffer[offset];
		this.targetObject.matrixWorldNeedsUpdate = true;
	}
	_setValue_fromArray(buffer, offset) {
		this.resolvedProperty.fromArray(buffer, offset);
	}
	_setValue_fromArray_setNeedsUpdate(buffer, offset) {
		this.resolvedProperty.fromArray(buffer, offset);
		this.targetObject.needsUpdate = true;
	}
	_setValue_fromArray_setMatrixWorldNeedsUpdate(buffer, offset) {
		this.resolvedProperty.fromArray(buffer, offset);
		this.targetObject.matrixWorldNeedsUpdate = true;
	}
	_getValue_unbound(targetArray, offset) {
		this.bind();
		this.getValue(targetArray, offset);
	}
	_setValue_unbound(sourceArray, offset) {
		this.bind();
		this.setValue(sourceArray, offset);
	}
	/**
	* Creates a getter / setter pair for the property tracked by this binding.
	*/
	bind() {
		let targetObject = this.node;
		const parsedPath = this.parsedPath;
		const objectName = parsedPath.objectName;
		const propertyName = parsedPath.propertyName;
		let propertyIndex = parsedPath.propertyIndex;
		if (!targetObject) {
			targetObject = PropertyBinding.findNode(this.rootNode, parsedPath.nodeName);
			this.node = targetObject;
		}
		this.getValue = this._getValue_unavailable;
		this.setValue = this._setValue_unavailable;
		if (!targetObject) {
			warn("PropertyBinding: No target node found for track: " + this.path + ".");
			return;
		}
		if (objectName) {
			let objectIndex = parsedPath.objectIndex;
			switch (objectName) {
				case "materials":
					if (!targetObject.material) {
						error("PropertyBinding: Can not bind to material as node does not have a material.", this);
						return;
					}
					if (!targetObject.material.materials) {
						error("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
						return;
					}
					targetObject = targetObject.material.materials;
					break;
				case "bones":
					if (!targetObject.skeleton) {
						error("PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
						return;
					}
					targetObject = targetObject.skeleton.bones;
					for (let i = 0; i < targetObject.length; i++) if (targetObject[i].name === objectIndex) {
						objectIndex = i;
						break;
					}
					break;
				case "map":
					if ("map" in targetObject) {
						targetObject = targetObject.map;
						break;
					}
					if (!targetObject.material) {
						error("PropertyBinding: Can not bind to material as node does not have a material.", this);
						return;
					}
					if (!targetObject.material.map) {
						error("PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
						return;
					}
					targetObject = targetObject.material.map;
					break;
				default:
					if (targetObject[objectName] === void 0) {
						error("PropertyBinding: Can not bind to objectName of node undefined.", this);
						return;
					}
					targetObject = targetObject[objectName];
			}
			if (objectIndex !== void 0) {
				if (targetObject[objectIndex] === void 0) {
					error("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, targetObject);
					return;
				}
				targetObject = targetObject[objectIndex];
			}
		}
		const nodeProperty = targetObject[propertyName];
		if (nodeProperty === void 0) {
			const nodeName = parsedPath.nodeName;
			error("PropertyBinding: Trying to update property for track: " + nodeName + "." + propertyName + " but it wasn't found.", targetObject);
			return;
		}
		let versioning = this.Versioning.None;
		this.targetObject = targetObject;
		if (targetObject.isMaterial === true) versioning = this.Versioning.NeedsUpdate;
		else if (targetObject.isObject3D === true) versioning = this.Versioning.MatrixWorldNeedsUpdate;
		let bindingType = this.BindingType.Direct;
		if (propertyIndex !== void 0) {
			if (propertyName === "morphTargetInfluences") {
				if (!targetObject.geometry) {
					error("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
					return;
				}
				if (!targetObject.geometry.morphAttributes) {
					error("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
					return;
				}
				if (targetObject.morphTargetDictionary[propertyIndex] !== void 0) propertyIndex = targetObject.morphTargetDictionary[propertyIndex];
			}
			bindingType = this.BindingType.ArrayElement;
			this.resolvedProperty = nodeProperty;
			this.propertyIndex = propertyIndex;
		} else if (nodeProperty.fromArray !== void 0 && nodeProperty.toArray !== void 0) {
			bindingType = this.BindingType.HasFromToArray;
			this.resolvedProperty = nodeProperty;
		} else if (Array.isArray(nodeProperty)) {
			bindingType = this.BindingType.EntireArray;
			this.resolvedProperty = nodeProperty;
		} else this.propertyName = propertyName;
		this.getValue = this.GetterByBindingType[bindingType];
		this.setValue = this.SetterByBindingTypeAndVersioning[bindingType][versioning];
	}
	/**
	* Unbinds the property.
	*/
	unbind() {
		this.node = null;
		this.getValue = this._getValue_unbound;
		this.setValue = this._setValue_unbound;
	}
};
PropertyBinding.Composite = Composite;
PropertyBinding.prototype.BindingType = {
	Direct: 0,
	EntireArray: 1,
	ArrayElement: 2,
	HasFromToArray: 3
};
PropertyBinding.prototype.Versioning = {
	None: 0,
	NeedsUpdate: 1,
	MatrixWorldNeedsUpdate: 2
};
PropertyBinding.prototype.GetterByBindingType = [
	PropertyBinding.prototype._getValue_direct,
	PropertyBinding.prototype._getValue_array,
	PropertyBinding.prototype._getValue_arrayElement,
	PropertyBinding.prototype._getValue_toArray
];
PropertyBinding.prototype.SetterByBindingTypeAndVersioning = [
	[
		PropertyBinding.prototype._setValue_direct,
		PropertyBinding.prototype._setValue_direct_setNeedsUpdate,
		PropertyBinding.prototype._setValue_direct_setMatrixWorldNeedsUpdate
	],
	[
		PropertyBinding.prototype._setValue_array,
		PropertyBinding.prototype._setValue_array_setNeedsUpdate,
		PropertyBinding.prototype._setValue_array_setMatrixWorldNeedsUpdate
	],
	[
		PropertyBinding.prototype._setValue_arrayElement,
		PropertyBinding.prototype._setValue_arrayElement_setNeedsUpdate,
		PropertyBinding.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate
	],
	[
		PropertyBinding.prototype._setValue_fromArray,
		PropertyBinding.prototype._setValue_fromArray_setNeedsUpdate,
		PropertyBinding.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate
	]
];
(class Matrix2 {
	static {
		/**
		* This flag can be used for type testing.
		*
		* @type {boolean}
		* @readonly
		* @default true
		*/
		Matrix2.prototype.isMatrix2 = true;
	}
	/**
	* Constructs a new 2x2 matrix. The arguments are supposed to be
	* in row-major order. If no arguments are provided, the constructor
	* initializes the matrix as an identity matrix.
	*
	* @param {number} [n11] - 1-1 matrix element.
	* @param {number} [n12] - 1-2 matrix element.
	* @param {number} [n21] - 2-1 matrix element.
	* @param {number} [n22] - 2-2 matrix element.
	*/
	constructor(n11, n12, n21, n22) {
		/**
		* A column-major list of matrix values.
		*
		* @type {Array<number>}
		*/
		this.elements = [
			1,
			0,
			0,
			1
		];
		if (n11 !== void 0) this.set(n11, n12, n21, n22);
	}
	/**
	* Sets this matrix to the 2x2 identity matrix.
	*
	* @return {Matrix2} A reference to this matrix.
	*/
	identity() {
		this.set(1, 0, 0, 1);
		return this;
	}
	/**
	* Sets the elements of the matrix from the given array.
	*
	* @param {Array<number>} array - The matrix elements in column-major order.
	* @param {number} [offset=0] - Index of the first element in the array.
	* @return {Matrix2} A reference to this matrix.
	*/
	fromArray(array, offset = 0) {
		for (let i = 0; i < 4; i++) this.elements[i] = array[i + offset];
		return this;
	}
	/**
	* Sets the elements of the matrix.The arguments are supposed to be
	* in row-major order.
	*
	* @param {number} n11 - 1-1 matrix element.
	* @param {number} n12 - 1-2 matrix element.
	* @param {number} n21 - 2-1 matrix element.
	* @param {number} n22 - 2-2 matrix element.
	* @return {Matrix2} A reference to this matrix.
	*/
	set(n11, n12, n21, n22) {
		const te = this.elements;
		te[0] = n11;
		te[2] = n12;
		te[1] = n21;
		te[3] = n22;
		return this;
	}
});
if (typeof __THREE_DEVTOOLS__ !== "undefined") __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", { detail: { revision: "186" } }));
if (typeof window !== "undefined") {
	if (window.__THREE__) warn("WARNING: Multiple instances of Three.js being imported.");
	else window.__THREE__ = "186";
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/Overturn.ts
/**
* The overturn a plunging wave draws, carried over from Pick & Feddersen
* (2026, J. Fluid Mech. 1040 A8): fully nonlinear potential-flow runs of
* shoaling solitary waves on planar slopes s = 1/100…1/10 with H0/h0 =
* 0.2…0.6. Their parameter ψ0 = s / (H0/h0)^(1/4) collapses the overturn's
* size, shape and tilt at jet impact. The depth-averaged surf zone cannot
* overturn, so a plunging break takes its overturn from these fits.
*/
/** The fitted ψ0 span: overturn areas 0.04–0.43 H² (their figures 8–9). */
const PSI_RANGE = {
	min: .0156,
	max: .0889
};
/** Area of Longuet-Higgins's (1982) overturn curve, as a fraction of its width times its length. */
const LH82_AREA = 2 * Math.sqrt(3) / 5;
/** ψ0 = s / (H0/h0)^(1/4) from the bed slope and the incoming wave's height over the offshore depth. */
function overturnParameter(slope, nonlinearity) {
	return slope / Math.pow(nonlinearity, .25);
}
/** The overturn at ψ0, held to the fitted span. */
function overturn(psi) {
	const p = Math.min(PSI_RANGE.max, Math.max(PSI_RANGE.min, psi));
	return {
		area: 5.319 * p - .043,
		jetArea: 37.072 * p * p - .587 * p + .02,
		aspect: 1.661 * p + .298,
		tilt: (-5746.4 * p * p + 225.2 * p + 48.4) * Math.PI / 180
	};
}
/**
* A reef break's overturn (the Teahupo'o Reef spec, Part B; docs/research/teahupoo-reef-sources.md): the
* tube's width over its length is 1 / Mead & Black's (2001) vortex ratio for the gradient the wave climbs,
* held within the ratios they measured at surfed breaks, 1.42 (Shark Island, their steepest bed) to 3.43.
* The fit has no data beyond them, and nothing says a break over a submerged crest collapses (collapse and
* surge are for slopes that reach the shore), so a steeper bed throws the roundest tube measured and a
* gentler one breaks as a plane slope does. Inside Pick & Feddersen's fits (ψ0 within their range, slopes to
* about 1:10) their void area, jet and tilt are sourced, and only the roundness is Mead & Black's. Beyond them,
* where Teahupo'o's ledge lies, the lip is `lipThickness` of the wave's height thick (Shand 2024) over the
* void's length, and the void's area and tilt are Pick & Feddersen's at their steepest fit (provisional). The
* Teahupo'o Reef's own jet there is the periodic Basilisk runs', not this slab (`LIP_JET` in SurfZoneSimulation), so
* its lip is that jet over the void's in-flight length (about 0.58 H in calm air, provisional), not `lipThickness`; the slab stays for any
* other spot's break over a submerged crest. The gradient is averaged `band` m above and below the breaking depth:
* Mead & Black's stated 2–3 m band absorbs height and tide errors, and 2.5 m is the game's pick within it.
*/
const REEF_OVERTURN = {
	area: .43,
	lipThickness: .5,
	tiltDegrees: 23,
	roundestRatio: 1.42,
	gentlestRatio: 3.43,
	band: 2.5,
	/**
	* The wind over celerity Mead & Black's ratios were measured in: surf-magazine photos, almost surely offshore
	* days, taken as a moderate offshore wind where its rounding saturates (provisional, the shape advisor's).
	*/
	windOverCelerity: -.4
};
/** Mead & Black's (2001) vortex ratio, the tube's length over its width, for an orthogonal gradient (rise over run). */
function vortexRatio(orthogonalGradient) {
	return .065 * (1 / orthogonalGradient) + .821;
}
/**
* A reef break's overturn for the gradient it climbs, under a sea `nonlinearity` (H0/h0) high, or undefined
* where it is gentler than any measured. Beyond Pick & Feddersen's fits the jet is the lip's thickness over the
* void's length, unless the spot has measured its own: `jetArea`, A_J / H² (the Teahupo'o Reef's, `LIP_JET`
* in SurfZoneSimulation). Inside the fits the jet stays theirs.
*/
function reefOverturn(orthogonalGradient, nonlinearity, jetArea) {
	if (!(orthogonalGradient > 0)) return void 0;
	const fit = vortexRatio(orthogonalGradient);
	if (fit > REEF_OVERTURN.gentlestRatio) return void 0;
	const aspect = 1 / Math.max(REEF_OVERTURN.roundestRatio, fit);
	const psi = overturnParameter(orthogonalGradient, nonlinearity);
	if (psi <= PSI_RANGE.max) return {
		...overturn(psi),
		aspect
	};
	const lengthOverHeight = Math.sqrt(REEF_OVERTURN.area / (LH82_AREA * aspect));
	return {
		area: REEF_OVERTURN.area,
		jetArea: jetArea ?? REEF_OVERTURN.lipThickness * lengthOverHeight,
		aspect,
		tilt: REEF_OVERTURN.tiltDegrees * Math.PI / 180
	};
}
/**
* Mead & Black's (2001) orthogonal gradient, rise over run: the bed's average gradient along the wave's path
* from `REEF_OVERTURN.band` shallower (no shallower than the shoreline) to as much deeper than its breaking
* depth. `depthAhead(s)` is the still depth s m ahead of the break along its travel (behind it for s < 0),
* NaN off the water it is sampled from, taken every `step` m out to `reach` m each way. A band reaching past a
* crest or below a shelf ends there; a path that runs out first ends where it does.
*/
function orthogonalGradient(depthAhead, breakingDepth, step, reach) {
	const shallow = Math.max(0, breakingDepth - REEF_OVERTURN.band);
	const deep = breakingDepth + REEF_OVERTURN.band;
	const ahead = contour(depthAhead, 1, shallow, step, reach);
	const behind = contour(depthAhead, -1, deep, step, reach);
	const run = ahead.distance + behind.distance;
	return run > 0 ? (behind.depth - ahead.depth) / run : 0;
}
/**
* Where the path, walked `direction`, first reaches the `target` depth (shallower ahead, deeper behind): between
* samples. Where the bed stops climbing (ahead) or falling (behind) for a band's width first, at a crest or a shelf,
* the path ends there: the gradient is the one the wave climbs, not the flat beyond it. Otherwise it ends at its
* reach, or where the water it is sampled from does.
*/
function contour(depthAhead, direction, target, step, reach) {
	const reached = (depth) => direction > 0 ? depth <= target : depth >= target;
	const beyond = (depth, than) => direction > 0 ? depth < than : depth > than;
	let previous = depthAhead(0);
	if (reached(previous)) return {
		distance: 0,
		depth: previous
	};
	let extreme = {
		distance: 0,
		depth: previous
	};
	for (let k = 1; k * step <= reach; k += 1) {
		const distance = k * step;
		const depth = depthAhead(direction * distance);
		if (!Number.isFinite(depth)) return {
			distance: (k - 1) * step,
			depth: previous
		};
		if (reached(depth)) return {
			distance: (k - 1 + (target - previous) / (depth - previous)) * step,
			depth: target
		};
		if (beyond(depth, extreme.depth)) extreme = {
			distance,
			depth
		};
		else if (distance - extreme.distance > REEF_OVERTURN.band) return extreme;
		previous = depth;
	}
	return {
		distance: reach,
		depth: depthAhead(direction * reach)
	};
}
/** The void's length along its long axis and its width across it, m, under a wave H m high. */
function overturnSize(shape, height) {
	const length = height * Math.sqrt(shape.area / (LH82_AREA * shape.aspect));
	return {
		length,
		width: shape.aspect * length
	};
}
/**
* The void under a wave H m high. Its pointed back sits half its width
* under the crest, where the face has gone vertical, and its long axis runs
* forward and down to the round front end where the jet lands.
*/
function tubeGeometry(shape, height) {
	return {
		...overturnSize(shape, height),
		tilt: shape.tilt
	};
}
/**
* How fast, relative to its crest, a ballistic jet leaves the crest level to
* land at the void's front end: it covers L cos θ while it falls W/2 + L sin θ,
* m/s. Added to the crest's speed, this spans 1.2–1.6 times it over the fitted
* range, as measured jets leave: 1.15–1.18 (Erinin et al. 2023), 1.3 (Perlin
* et al. 1996), 1.68 (Chang & Liu 1998) and 1.73 (Kjeldsen 1984).
*/
function jetRelativeSpeed(shape, height) {
	const { length, tilt } = tubeGeometry(shape, height);
	return length * Math.cos(tilt) / jetFlightTime(shape, height);
}
/**
* How long the jet takes from the crest top to the void's front end, s. The jet
* keeps pouring from its crest over this long: measured jets take 1.5–1.6 √(H/g)
* from forming to impact (Erinin et al. 2023).
*/
function jetFlightTime(shape, height) {
	const { length, width, tilt } = tubeGeometry(shape, height);
	return Math.sqrt(2 * (width / 2 + length * Math.sin(tilt)) / GRAVITY$1);
}
/** The half-width of Longuet-Higgins's curve across its axis at u = x′/L along it, as a fraction of W. */
function halfWidth(u) {
	return 3 * Math.sqrt(3) / 4 * u * Math.sqrt(Math.max(0, 1 - u));
}
/**
* How far below its crest the void's floor lies, m, `ahead` m ahead of the
* crest along its travel; NaN outside the void. The floor is the lower half
* of Longuet-Higgins's curve, tilted down by θ: the face the rider meets
* inside a tube.
*/
function tubeFloorDepth(tube, ahead) {
	const { length, width, tilt } = tube;
	const cos = Math.cos(tilt);
	const sin = Math.sin(tilt);
	if (!(ahead >= 0 && ahead <= length * cos)) return NaN;
	const aheadAt = (u) => length * u * cos - width * halfWidth(u) * sin;
	let low = 0;
	let high = 1;
	for (let step = 0; step < 40; step += 1) {
		const middle = (low + high) / 2;
		if (aheadAt(middle) < ahead) low = middle;
		else high = middle;
	}
	const u = (low + high) / 2;
	return width / 2 + length * u * sin + width * halfWidth(u) * cos;
}
/**
* A void's floor meets the surface over this much behind it (from the crest),
* m, instead of standing as a wall there, half the void's width deep: a height
* field draws a wall on a diagonal as a staircase, a column wide in the physics
* and a cell wide in the Rich water. Wider than the Rich patch's 0.25 m cell;
* the void only gives up its back edge. Its front, where the jet lands, is
* left as it is, so the jet lands where it did.
*/
const TUBE_EDGE = .35;
const smoothstep = (edge, x) => {
	const t = Math.min(1, Math.max(0, x / edge));
	return t * t * (3 - 2 * t);
};
const T = {
	crestX: 0,
	crestZ: 1,
	y: 2,
	dirX: 3,
	dirZ: 4,
	open: 5,
	length: 6,
	width: 7,
	tilt: 8,
	column: 9,
	scale: 10
};
/** Where tube `tube`'s void floor lies under (x, z), m; NaN outside its void. */
function tubeFloor(table, tube, x, z) {
	const o = tube * 12;
	const ahead = (x - table[o + T.crestX]) * table[o + T.dirX] + (z - table[o + T.crestZ]) * table[o + T.dirZ];
	const scale = table[o + T.scale];
	if (!(ahead >= 0 && ahead <= table[o + T.open]) || !(scale > 0)) return NaN;
	const depth = tubeFloorDepth({
		length: table[o + T.length] * scale,
		width: table[o + T.width] * scale,
		tilt: table[o + T.tilt]
	}, ahead);
	return table[o + T.y] - depth * smoothstep(TUBE_EDGE, ahead);
}
const between = /* @__PURE__ */ new Float64Array(12);
/**
* The surface at (x, z) where the tubes leave it, m. Between two column
* centres that both hold a tube, the tube itself is interpolated (its crest,
* opening and size, from each column's most open one): a peeling tube is one
* shape, and its columns are samples of it at neighbouring stages. Beside a
* column with none, each column's tubes cut the surface to their lowest floor
* and the two columns blend linearly, as the water does between nodes.
*/
function carveAt(table, count, columnWidth, x, z, surface) {
	if (count === 0) return surface;
	const u = x / columnWidth - .5;
	const c0 = Math.floor(u);
	const t = u - c0;
	let m0 = surface;
	let m1 = surface;
	let open0 = -1;
	let open1 = -1;
	for (let tube = 0; tube < count; tube += 1) {
		const o = tube * 12;
		const column = table[o + T.column];
		if (column !== c0 && column !== c0 + 1) continue;
		if (column === c0 && (open0 < 0 || table[o + T.open] > table[open0 * 12 + T.open])) open0 = tube;
		if (column === c0 + 1 && (open1 < 0 || table[o + T.open] > table[open1 * 12 + T.open])) open1 = tube;
		const floor = tubeFloor(table, tube, x, z);
		if (!(floor === floor)) continue;
		if (column === c0) m0 = Math.min(m0, floor);
		else m1 = Math.min(m1, floor);
	}
	const blended = m0 + (m1 - m0) * t;
	if (open0 >= 0 && open1 >= 0) {
		const a = open0 * 12;
		const b = open1 * 12;
		const gap = (table[b + T.crestX] - table[a + T.crestX]) * table[a + T.dirX] + (table[b + T.crestZ] - table[a + T.crestZ]) * table[a + T.dirZ];
		const alignment = table[a + T.dirX] * table[b + T.dirX] + table[a + T.dirZ] * table[b + T.dirZ];
		if (Math.abs(gap) <= 2 && alignment >= .5) {
			for (let k = 0; k < 12; k += 1) between[k] = table[a + k] + (table[b + k] - table[a + k]) * t;
			const length = Math.hypot(between[T.dirX], between[T.dirZ]);
			between[T.dirX] /= length;
			between[T.dirZ] /= length;
			const floor = tubeFloor(between, 0, x, z);
			return floor === floor ? Math.min(blended, floor) : blended;
		}
	}
	return blended;
}
let marks = /* @__PURE__ */ new Uint8Array(0);
/**
* Carve a render grid's interleaved (height, foam) in place: every node within
* a tube's reach, once, from its raw height. The reach is its column's blend
* span across, and its crest to its open front along its travel, padded by a
* node spacing.
*/
function carveGrid(data, grid, table, count, columnWidth) {
	if (count === 0) return;
	const { xMin, zMin, spacing, nx, nz } = grid;
	if (marks.length < nx * nz) marks = new Uint8Array(nx * nz);
	marks.fill(0, 0, nx * nz);
	let any = false;
	for (let tube = 0; tube < count; tube += 1) {
		const o = tube * 12;
		const column = table[o + T.column];
		const reach = Math.min(table[o + T.open], table[o + T.length] * Math.cos(table[o + T.tilt]));
		const frontX = table[o + T.crestX] + table[o + T.dirX] * reach;
		const frontZ = table[o + T.crestZ] + table[o + T.dirZ] * reach;
		const x0 = Math.min((column - .5) * columnWidth, Math.min(table[o + T.crestX], frontX) - spacing - 1);
		const x1 = Math.max((column + 1.5) * columnWidth, Math.max(table[o + T.crestX], frontX) + spacing + 1);
		const z0 = Math.min(table[o + T.crestZ], frontZ) - spacing - 1;
		const z1 = Math.max(table[o + T.crestZ], frontZ) + spacing + 1;
		const c0 = Math.max(0, Math.ceil((x0 - xMin) / spacing));
		const c1 = Math.min(nx - 1, Math.floor((x1 - xMin) / spacing));
		const r0 = Math.max(0, Math.ceil((z0 - zMin) / spacing));
		const r1 = Math.min(nz - 1, Math.floor((z1 - zMin) / spacing));
		for (let r = r0; r <= r1; r += 1) for (let c = c0; c <= c1; c += 1) {
			marks[r * nx + c] = 1;
			any = true;
		}
	}
	if (!any) return;
	for (let r = 0; r < nz; r += 1) for (let c = 0; c < nx; c += 1) {
		if (!marks[r * nx + c]) continue;
		const k = (r * nx + c) * 2;
		data[k] = carveAt(table, count, columnWidth, xMin + c * spacing, zMin + r * spacing, data[k]);
	}
}
/**
* The jet leaves the crest over this long, s, unless a throw says otherwise
* (a plunging break pours for its jet's flight): the strip's parcels are
* released evenly across it, each from where the crest has moved to, so a
* strip is the jet's cross-section from its fallen tip back up to the crest.
*/
const JET_RELEASE_TIME = .25;
/**
* The splash-up a landing jet throws (G9, docs/research/whitewater-sources.md;
* provisional, bounded by Peregrine 1983 and the measured splash-up speeds): the
* share of a landing jet parcel's water it re-throws, its speed over the
* impact's, up and on, and the least downward impact speed that throws one, m/s.
*/
const SPLASH_UP = {
	share: .3,
	vertical: .6,
	horizontal: .8,
	minImpact: .5
};
/**
* A tube's trapped air (G9, docs/research/whitewater-sources.md): once its jet has
* all landed the void closes, shrinking over its free-fall time t_c = √(2W/g) as
* its air is squeezed out as the void loses volume. `escape` of it leaves as spray (the
* spit, out of a peel's open end; or an eruption up through the lip where a
* section closes all at once) and the rest breaks into bubbles. Provisional,
* but for the air's volume, which is conserved.
*/
const TUBE_AIR = { escape: .5 };
/** Densities of seawater and of air, kg/m³. */
const WATER_DENSITY$1 = 1025;
const AIR_DENSITY = 1.2;
/**
* The fastest a collapsing tube can blow its air out of its mouth, m/s. The
* roof falls on the air at about √(gW/2) (its free fall over the void's
* height W), so the air's pressure can rise no higher than the roof's dynamic
* pressure, ½ρ_w·gW/2; air driven by that leaves at √(ρ_w/ρ_a)·√(gW/2). Air
* the mouth cannot pass that fast bursts up through the lip instead. (G9,
* provisional: a mechanism, not a measurement.)
*/
function spitSpeedLimit(width) {
	return Math.sqrt(WATER_DENSITY$1 / AIR_DENSITY * GRAVITY$1 * width / 2);
}
/** A closing void's bubbles are spread over this many points along it (numerical). */
const BUBBLE_POINTS = 4;
/** A breaking roller's cross-section per H² (G9, κ_r; Svendsen 1984): the foam ball tumbling in a collapsing tube. */
const ROLLER_AREA = .9;
/**
* Largest share of its water above the wave's trough a source cell may give one throw (the P7 bound), so the
* crest is never cut flat. The throw's ask sets the jet; this only caps it. Round 6's Basilisk jet at Padang's
* peak is about a fifth of the water above still level within 1.5 m of its crest (the water-physics advisor,
* 2026-09-29). This is every lip's unless its spot says otherwise (`LIP_JET` in SurfZoneSimulation).
*/
const SOURCE_SHARE = .2;
/** Parcels still airborne after this long land where they are, s. */
const MAX_FLIGHT = 3;
function clamp(value, low, high) {
	return Math.min(high, Math.max(low, value));
}
/** A column's water above a level `levelDepth` m above its bed, m: all of it when the level is below the bed. */
function aboveLevel(depth, levelDepth) {
	return Math.max(0, depth - Math.max(0, levelDepth));
}
/**
* Overturn area A/H² against U/C (positive onshore), through the Surf Ranch
* values of Feddersen et al. (2023): ≈ 0.2 at U/C = 0.75 and ≈ 0.4 for offshore
* U/C < −0.4, clamped to that range.
*/
function overturnArea(windOverCelerity) {
	return clamp(.2 + .2 * (.75 - windOverCelerity) / 1.15, .2, .4);
}
/**
* A lip only leaves plunging breakers, 0.4 ≤ ξ_b ≤ 2.0 (plan §1.9, Q12). Its
* overturn is Pick & Feddersen's (2026) for the bed slope and the sea, and
* the wind reshapes the void as measured at Surf Ranch: its area by
* `overturnArea`'s ratio to calm, and its aspect by −0.18 per unit U/C
* (Feddersen et al. 2023).
*/
function lipThrow(conditions) {
	const { iribarren, slope, nonlinearity, breakerHeight, windOverCelerity, width } = conditions;
	if (conditions.reef && breakerHeight > 0) {
		const reef = reefOverturn(conditions.reef.orthogonalGradient, nonlinearity, conditions.reef.jetArea);
		if (reef) {
			const wind = Math.max(windOverCelerity, REEF_OVERTURN.windOverCelerity) - REEF_OVERTURN.windOverCelerity;
			const shape = {
				...reef,
				aspect: clamp(reef.aspect - .18 * wind, .2, 1)
			};
			return {
				volume: shape.jetArea * breakerHeight * breakerHeight * width,
				relativeSpeed: jetRelativeSpeed(shape, breakerHeight),
				shape,
				reef: { vortexRatio: 1 / reef.aspect }
			};
		}
	}
	if (!(iribarren >= .4 && iribarren <= 2) || !(breakerHeight > 0)) return void 0;
	const calm = overturn(overturnParameter(slope, nonlinearity));
	const shape = {
		...calm,
		area: calm.area * overturnArea(windOverCelerity) / overturnArea(0),
		aspect: clamp(calm.aspect - .18 * windOverCelerity, .2, 1)
	};
	return {
		volume: shape.jetArea * breakerHeight * breakerHeight * width,
		relativeSpeed: jetRelativeSpeed(shape, breakerHeight),
		shape
	};
}
/** A void under a flying jet, riding with the crest that threw it. */
/** A lip parcel's per-slot fields, as the sea handover carries them (spec N1). */
const PARCEL_FIELDS = [
	"x",
	"y",
	"z",
	"volume",
	"vx",
	"vy",
	"vz",
	"px",
	"py",
	"pz",
	"id",
	"age",
	"active",
	"lx",
	"ly",
	"lz",
	"crestSpeed",
	"state",
	"releaseAt",
	"strip",
	"column",
	"index",
	"launchTime",
	"kind"
];
/** The share of a tube's collapse done by `time`: 0 while it flies, 1 once its void is gone. */
function collapsed(tube, time) {
	if (Number.isNaN(tube.closedAt)) return 0;
	const collapseTime = Math.sqrt(2 * tube.geometry.width / GRAVITY$1);
	return collapseTime > 0 ? Math.min(1, (time - tube.closedAt) / collapseTime) : 1;
}
/**
* Mass-conserving plunging lip for the physical surf zone (plan §1.9, Q12).
* A throw takes water from the crest cell and its across-shore neighbours (at
* most `sourceShare` of each, a fifth unless its spot says otherwise), with the
* momentum the jet carries off, and launches it as ballistic parcels. A parcel
* that falls back through the surface returns its volume and horizontal
* momentum to the cell it lands in, which drives the splash-up and the
* secondary bore; its vertical momentum is lost to turbulence.
* The parcels are a coarse sample of the jet: one throw is a strip of
* STRIP_PARCELS.
*/
var PlungingLip = class {
	solver;
	capacity;
	sourceShare;
	x;
	y;
	z;
	volume;
	/** Landings since the lip was created. */
	landings = 0;
	/** Throws their crest could not fill, and the water they fell short by, m³. */
	starvedThrows = 0;
	starvedVolume = 0;
	/** Throws whose crest carried less momentum along the jet than the jet takes, and what it could not give, m⁴/s. */
	momentumClamps = 0;
	unplacedMomentum = 0;
	/** Landings that came down past an open along-shore edge, whole or in part, and the water they took out of the window, m³. */
	escapedLandings = 0;
	escapedVolume = 0;
	/** Air its tubes have trapped as they closed, m³ (G9; a running total for the air's balance). */
	trappedAir = 0;
	/**
	* Swept jets (PR 5) whose void was still open as their pour began, and closed then (a check: none should be, as a held
	* jet pours only from its crash or as its point leaves the front, and both close its void first).
	*/
	closedAtPour = 0;
	/**
	* Told of every landing: where the parcel fell, how much water it returned
	* (m³), how fast it hit (m/s), and its flight: where it left the crest and
	* the height it landed at (the tube it drew, `measureTube`).
	*/
	onLand;
	/** Told of a closing tube's air breaking into bubbles (G9): where, how much, m³, and how deep it is driven, m. */
	onAir;
	/** This step's spits, eruptions and foam balls from closing tubes (G9). */
	spits = [];
	eruptions = [];
	rollers = [];
	/** Scratch for `tubeChains`: the strips already in a chain. */
	chained = /* @__PURE__ */ new Set();
	vx;
	vy;
	vz;
	/** Each parcel's position before the latest step, for swept contact, and its id (unique per throw). */
	px;
	py;
	pz;
	id;
	nextId = 1;
	contact = {
		id: 0,
		previousPosition: new Vector3(),
		position: new Vector3(),
		velocity: new Vector3(),
		volume: 0,
		radius: 0
	};
	age;
	active;
	/** Where each parcel left the crest. */
	lx;
	ly;
	lz;
	/** The speed of the crest each parcel left, m/s. */
	crestSpeed;
	/** 0 free, 1 flying, 2 waiting to leave the crest. */
	state;
	/** When a waiting parcel leaves, s on the lip's clock. */
	releaseAt;
	/** Each parcel's strip (throw), world column, place along the strip and the strip's launch time. */
	strip;
	column;
	index;
	launchTime;
	/** Live strips: their parcels, by strip id; and the strips of each world column. */
	strips = /* @__PURE__ */ new Map();
	/** Each parcel's kind: 0 a jet's water, 1 a splash-up's (G9). */
	kind;
	byColumn = /* @__PURE__ */ new Map();
	nextStrip = 1;
	/** The lip's clock, s. */
	time = 0;
	view = {
		slot: 0,
		x: 0,
		y: 0,
		z: 0,
		vx: 0,
		vy: 0,
		vz: 0,
		column: 0,
		index: 0,
		launchTime: 0,
		age: 0,
		volume: 0,
		kind: 0
	};
	/** Marks parcels a query found linked, by query number. */
	linked;
	query = 0;
	near = {
		a: new Vector3(),
		b: new Vector3(),
		pa: new Vector3(),
		pb: new Vector3(),
		velocity: new Vector3()
	};
	flight = {
		launch: {
			x: 0,
			y: 0,
			z: 0
		},
		y: 0,
		age: 0,
		crestSpeed: 0,
		kind: 0,
		volume: 0,
		waveHeight: 0,
		swept: false
	};
	free = [];
	/** The flying tubes as a `tubeTable` (G9), refreshed as the clock moves and strips come and go. */
	tubes = /* @__PURE__ */ new Float64Array(768);
	tubeRows = 0;
	/**
	* `sourceShare` is the most of a source cell's water above the wave's trough one throw may take
	* (`drawFromCrest`): SOURCE_SHARE, or the spot's own.
	*/
	constructor(solver, capacity = 16384, sourceShare = SOURCE_SHARE) {
		this.solver = solver;
		this.capacity = capacity;
		this.sourceShare = sourceShare;
		this.x = new Float64Array(capacity);
		this.y = new Float64Array(capacity);
		this.z = new Float64Array(capacity);
		this.volume = new Float64Array(capacity);
		this.vx = new Float64Array(capacity);
		this.vy = new Float64Array(capacity);
		this.vz = new Float64Array(capacity);
		this.px = new Float64Array(capacity);
		this.py = new Float64Array(capacity);
		this.pz = new Float64Array(capacity);
		this.id = new Float64Array(capacity);
		this.age = new Float64Array(capacity);
		this.active = new Uint8Array(capacity);
		this.lx = new Float64Array(capacity);
		this.ly = new Float64Array(capacity);
		this.lz = new Float64Array(capacity);
		this.crestSpeed = new Float64Array(capacity);
		this.state = new Uint8Array(capacity);
		this.releaseAt = new Float64Array(capacity);
		this.strip = new Int32Array(capacity);
		this.column = new Int32Array(capacity);
		this.index = new Uint8Array(capacity);
		this.launchTime = new Float64Array(capacity);
		this.kind = new Uint8Array(capacity);
		this.linked = new Uint32Array(capacity);
		for (let index = capacity - 1; index >= 0; index -= 1) this.free.push(index);
	}
	/** Every per-parcel array, by name, for the sea handover (spec N1). */
	parcelArrays() {
		return {
			x: this.x,
			y: this.y,
			z: this.z,
			volume: this.volume,
			vx: this.vx,
			vy: this.vy,
			vz: this.vz,
			px: this.px,
			py: this.py,
			pz: this.pz,
			id: this.id,
			age: this.age,
			active: this.active,
			lx: this.lx,
			ly: this.ly,
			lz: this.lz,
			crestSpeed: this.crestSpeed,
			state: this.state,
			releaseAt: this.releaseAt,
			strip: this.strip,
			column: this.column,
			index: this.index,
			launchTime: this.launchTime,
			kind: this.kind
		};
	}
	/** The lip as plain data (spec N1: the sea handover): its clock, its parcels in flight or waiting, and their strips. */
	exportState() {
		const slots = [];
		for (let slot = 0; slot < this.capacity; slot += 1) if (this.state[slot] !== 0 || this.active[slot] !== 0) slots.push(slot);
		const arrays = this.parcelArrays();
		const fields = Object.fromEntries(PARCEL_FIELDS.map((name) => [name, slots.map((slot) => arrays[name][slot])]));
		return {
			capacity: this.capacity,
			time: this.time,
			landings: this.landings,
			nextId: this.nextId,
			nextStrip: this.nextStrip,
			free: [...this.free],
			slots,
			fields,
			strips: [...this.strips].map(([id, strip]) => [id, {
				column: strip.column,
				launchTime: strip.launchTime,
				parcels: [...strip.parcels],
				live: strip.live,
				kind: strip.kind,
				waveHeight: strip.waveHeight,
				...strip.splash === void 0 ? {} : { splash: strip.splash },
				...strip.swept ? { swept: true } : {},
				...strip.held ? { held: true } : {},
				...strip.tube ? { tube: {
					...strip.tube,
					geometry: { ...strip.tube.geometry },
					closedAt: Number.isNaN(strip.tube.closedAt) ? null : strip.tube.closedAt
				} } : {}
			}]),
			byColumn: [...this.byColumn].map(([column, ids]) => [column, [...ids]])
		};
	}
	/** Takes over another lip's state (the same capacity): what it has in the air lands here as it would there. */
	importState(state) {
		if (state.capacity !== this.capacity) throw new Error(`A lip state for ${state.capacity} parcels, not ${this.capacity}`);
		const arrays = this.parcelArrays();
		for (const name of PARCEL_FIELDS) {
			arrays[name].fill(0);
			state.slots.forEach((slot, k) => {
				arrays[name][slot] = state.fields[name][k];
			});
		}
		this.linked.fill(0);
		this.free.length = 0;
		this.free.push(...state.free);
		this.strips.clear();
		for (const [id, strip] of state.strips) {
			const { tube } = strip;
			this.strips.set(id, {
				column: strip.column,
				launchTime: strip.launchTime,
				parcels: [...strip.parcels],
				live: strip.live,
				kind: strip.kind ?? 0,
				waveHeight: strip.waveHeight ?? 0,
				...strip.splash === void 0 ? {} : { splash: strip.splash },
				...strip.swept ? { swept: true } : {},
				...strip.held ? { held: true } : {},
				...tube ? { tube: {
					...tube,
					geometry: { ...tube.geometry },
					id: tube.id ?? id,
					closedAt: typeof tube.closedAt === "number" ? tube.closedAt : NaN,
					air: tube.air ?? 0,
					released: tube.released ?? 0,
					drop: tube.drop ?? 0
				} } : {}
			});
		}
		this.byColumn.clear();
		for (const [column, ids] of state.byColumn) this.byColumn.set(column, [...ids]);
		this.time = state.time;
		this.landings = state.landings;
		this.nextId = state.nextId;
		this.nextStrip = state.nextStrip;
	}
	/**
	* Take up to `volume` m³ of jet from the crest at `cell` of a breaking wave `waveHeight` m high (the
	* water-physics advisor, 2026-09-29), and return what was taken. The jet is the top of the wave: it comes
	* from the wave's upper half, the cells across shore through the crest standing at least H/2 above its
	* trough (crest − H, where the wave's height is measured to), within SOURCE_REACH wave heights of the crest.
	* Each gives its water above the trough, tapered as 1 − (d / 2H)² with its distance d from the crest, times
	* one share, at most `sourceShare`: most from the crest's top, and none at the window's ends. The trough, not
	* still level: at the Reef's step the trough drains metres below still level ahead of crests standing at
	* or below it. Told no wave height, it measures the wave from still level.
	*
	* The jet's momentum (volume × jet velocity) comes from the wave's forward-moving upper half, nearest the
	* crest first: out from the crest a cell each way at a time until their flow along the jet covers it, and
	* never past the upper half. Each cell reached gives in proportion to its own flow along the jet and is
	* never reversed; what the upper half cannot give is counted. The jet's extra speed comes from the crest's
	* pressure, acting over the moving crest, not only the cells its water leaves; at the Reef's step the
	* depth-mean flow under the crest runs seaward as the trough drains back beneath it.
	*/
	drawFromCrest(cell, velocity, volume, waveHeight) {
		const { nx, nz, h, qx, qz, dx, dz, bed, restLevel, zCenters } = this.solver;
		const surface = (index) => h[index] + bed[index];
		const height = waveHeight > 0 ? waveHeight : surface(cell) - restLevel;
		if (!(height > 0) || !(h[cell] > 0)) return 0;
		const trough = surface(cell) - height;
		const reach = 2 * height;
		const column = cell % nx;
		const row = Math.floor(cell / nx);
		const area = (index) => dx * dz[Math.floor(index / nx)];
		const inUpperHalf = (iz) => iz >= 0 && iz < nz && h[iz * nx + column] > 0 && surface(iz * nx + column) - trough >= .5 * height;
		const rings = [[cell]];
		for (let k = 1, back = true, ahead = true; back || ahead; k += 1) {
			back &&= inUpperHalf(row - k);
			ahead &&= inUpperHalf(row + k);
			const ring = [...back ? [(row - k) * nx + column] : [], ...ahead ? [(row + k) * nx + column] : []];
			if (ring.length > 0) rings.push(ring);
		}
		const window = [];
		const weights = [];
		let water = 0;
		for (const index of rings.flat()) {
			const distance = Math.abs(zCenters[Math.floor(index / nx)] - zCenters[row]);
			if (distance >= reach) continue;
			const weight = aboveLevel(h[index], trough - bed[index]) * (1 - (distance / reach) ** 2);
			window.push(index);
			weights.push(weight);
			water += weight * area(index);
		}
		if (!(water > 0)) return 0;
		const share = Math.min(this.sourceShare, volume / water);
		const thrown = share * water;
		if (thrown < volume) {
			this.starvedThrows += 1;
			this.starvedVolume += volume - thrown;
		}
		for (const [q, speed] of [[qx, velocity.x], [qz, velocity.z]]) {
			const wanted = Math.abs(thrown * speed);
			if (!(wanted > 0)) continue;
			const sign = Math.sign(speed);
			let carried = 0;
			let reached = 0;
			for (; reached < rings.length && carried < wanted; reached += 1) for (const index of rings[reached]) carried += Math.max(0, sign * q[index]) * area(index);
			const taken = Math.min(wanted, carried);
			if (taken < wanted) {
				this.momentumClamps += 1;
				this.unplacedMomentum += wanted - taken;
			}
			if (!(carried > 0)) continue;
			for (const index of rings.slice(0, reached).flat()) q[index] -= sign * taken * Math.max(0, sign * q[index]) / carried;
		}
		window.forEach((index, n) => {
			h[index] -= share * weights[n];
		});
		return thrown;
	}
	/**
	* Throw up to `volume` m³ from `cell` at `height` (m above datum) with
	* horizontal `velocity` (m/s), from a breaking wave `waveHeight` m high (its
	* landings say so). Returns the volume actually thrown (`drawFromCrest`): 0
	* when the parcel pool is full or the crest holds no water above its trough.
	*/
	launch(cell, velocity, height, volume, crestSpeed = 0, tube, releaseTime = JET_RELEASE_TIME, waveHeight = 0) {
		if (this.free.length < 8 || !(volume > 0)) return 0;
		const thrown = this.drawFromCrest(cell, velocity, volume, waveHeight);
		if (!(thrown > 0)) return 0;
		const { solver } = this;
		const { nx, dx } = solver;
		const row = Math.floor(cell / nx);
		const x = solver.xCenters[cell - row * nx];
		const z = solver.zCenters[row];
		const stripId = this.nextStrip;
		this.nextStrip += 1;
		const column = Math.round(x / dx - .5);
		const strip = {
			column,
			launchTime: this.time,
			parcels: [],
			live: 8,
			kind: 0,
			waveHeight
		};
		const spacing = releaseTime / 7;
		const jetSpeed = Math.hypot(velocity.x, velocity.z);
		const crestX = jetSpeed > 0 ? velocity.x / jetSpeed * crestSpeed : 0;
		const crestZ = jetSpeed > 0 ? velocity.z / jetSpeed * crestSpeed : 0;
		if (tube && jetSpeed > 0) strip.tube = {
			id: stripId,
			geometry: tube,
			x,
			z,
			y: height,
			dirX: velocity.x / jetSpeed,
			dirZ: velocity.z / jetSpeed,
			crestSpeed,
			relativeSpeed: jetSpeed - crestSpeed,
			closedAt: NaN,
			air: 0,
			released: 0,
			drop: 0
		};
		for (let k = 0; k < 8; k += 1) {
			const parcel = this.free.pop();
			strip.parcels.push(parcel);
			this.active[parcel] = 1;
			this.state[parcel] = k === 0 ? 1 : 2;
			this.releaseAt[parcel] = this.time + k * spacing;
			this.x[parcel] = this.px[parcel] = this.lx[parcel] = x + crestX * k * spacing;
			this.y[parcel] = this.py[parcel] = this.ly[parcel] = height;
			this.z[parcel] = this.pz[parcel] = this.lz[parcel] = z + crestZ * k * spacing;
			this.crestSpeed[parcel] = crestSpeed;
			this.id[parcel] = this.nextId;
			this.nextId += 1;
			this.vx[parcel] = velocity.x;
			this.vy[parcel] = 0;
			this.vz[parcel] = velocity.z;
			this.volume[parcel] = thrown / 8;
			this.age[parcel] = 0;
			this.strip[parcel] = stripId;
			this.column[parcel] = column;
			this.index[parcel] = k;
			this.launchTime[parcel] = this.time;
			this.kind[parcel] = 0;
		}
		this.strips.set(stripId, strip);
		const inColumn = this.byColumn.get(column);
		if (inColumn) inColumn.push(stripId);
		else this.byColumn.set(column, [stripId]);
		this.refreshTubes();
		return thrown;
	}
	/**
	* A swept barrel's jet (the Padang Padang spec, Part B, PR 5; the advisor's rulings, 2026-10-01 and 2026-10-03): its
	* water leaves the crest at the barrel's throw, by `drawFromCrest`'s rule (its momentum along the jet nearest first,
	* never reversed, the rest counted), and waits, held, as a strip of parcels. It pours at its crash, from the crash curve
	* (`crashJet`; `movePour` follows the drawn lip), or, if its point leaves the front first, as foreseen at the throw:
	* from the foreseen place, a parcel every `pourSpacing`, from when its point leaves (`closeJet`). The drawn barrel is
	* the tube, so its void carves nothing. Returns the strip and the water thrown; strip −1 when none was (the pool can't
	* hold a strip, or the crest has nothing above its trough).
	*/
	holdJet(jet) {
		if (this.free.length < 8 || !(jet.volume > 0)) return {
			strip: -1,
			thrown: 0
		};
		const thrown = this.drawFromCrest(jet.cell, {
			x: jet.velocityX,
			z: jet.velocityZ
		}, jet.volume, jet.waveHeight);
		if (!(thrown > 0)) return {
			strip: -1,
			thrown: 0
		};
		const stripId = this.nextStrip;
		this.nextStrip += 1;
		const column = Math.round(jet.launchX / this.solver.dx - .5);
		const strip = {
			column,
			launchTime: this.time,
			parcels: [],
			live: 8,
			kind: 0,
			waveHeight: jet.waveHeight,
			swept: true,
			held: true,
			tube: {
				id: stripId,
				geometry: {
					length: jet.voidLength,
					width: jet.voidHeight,
					tilt: 0
				},
				x: jet.launchX,
				z: jet.launchZ,
				y: jet.launchY,
				dirX: jet.dirX,
				dirZ: jet.dirZ,
				crestSpeed: jet.crestSpeed,
				relativeSpeed: jet.relativeSpeed,
				closedAt: NaN,
				air: 0,
				released: 0,
				drop: 0,
				area: jet.voidArea,
				span: jet.span,
				axisX: jet.axisX,
				axisY: jet.axisY
			}
		};
		for (let k = 0; k < 8; k += 1) {
			const parcel = this.free.pop();
			strip.parcels.push(parcel);
			this.active[parcel] = 1;
			this.state[parcel] = 2;
			this.releaseAt[parcel] = this.time + k * jet.pourSpacing;
			this.x[parcel] = this.px[parcel] = jet.pourX;
			this.y[parcel] = this.py[parcel] = jet.pourY;
			this.z[parcel] = this.pz[parcel] = jet.pourZ;
			this.lx[parcel] = jet.launchX;
			this.ly[parcel] = jet.launchY;
			this.lz[parcel] = jet.launchZ;
			this.crestSpeed[parcel] = jet.crestSpeed;
			this.id[parcel] = this.nextId;
			this.nextId += 1;
			this.vx[parcel] = jet.velocityX;
			this.vy[parcel] = jet.pourVY;
			this.vz[parcel] = jet.velocityZ;
			this.volume[parcel] = thrown / 8;
			this.age[parcel] = 0;
			this.strip[parcel] = stripId;
			this.column[parcel] = column;
			this.index[parcel] = k;
			this.launchTime[parcel] = this.time;
			this.kind[parcel] = 0;
		}
		this.strips.set(stripId, strip);
		const inColumn = this.byColumn.get(column);
		if (inColumn) inColumn.push(stripId);
		else this.byColumn.set(column, [stripId]);
		return {
			strip: stripId,
			thrown
		};
	}
	/**
	* A held jet's lip touches down (the crash, PR 5): its void closes now, trapping its own air (its cross-section over
	* the crest it spans), and rides on from the drawn crest `crest`; its water still waiting pours from (x, y, z), a
	* parcel every `spacing` s from now, falling at `vy`, m/s. False for a strip that is not a swept jet.
	*/
	crashJet(stripId, pour, crest) {
		const strip = this.strips.get(stripId);
		if (!strip?.swept || !strip.tube) return false;
		strip.held = false;
		const { tube } = strip;
		if (Number.isNaN(tube.closedAt)) this.closeHeld(tube);
		const age = this.time - strip.launchTime;
		tube.x = crest.x - tube.dirX * tube.crestSpeed * age;
		tube.z = crest.z - tube.dirZ * tube.crestSpeed * age;
		tube.y = crest.y;
		let n = 0;
		for (const parcel of strip.parcels) {
			if (parcel < 0 || this.state[parcel] !== 2) continue;
			this.releaseAt[parcel] = this.time + n * pour.spacing;
			this.x[parcel] = this.px[parcel] = pour.x;
			this.y[parcel] = this.py[parcel] = pour.y;
			this.z[parcel] = this.pz[parcel] = pour.z;
			this.vy[parcel] = pour.vy;
			n += 1;
		}
		return true;
	}
	/**
	* A held jet the crash couldn't follow to its touchdown (its point alone on its front, or past its collapse), or whose
	* point left the front, crashes where it was foreseen at its throw (PR 5; the advisor, 2026-10-03): its void closes
	* now, trapping its air where its tube has ridden, and its foreseen schedule starts now: from the foreseen place, its
	* first parcel now and the rest as far apart as foreseen. True when it did so now; false for a strip no longer held.
	*/
	closeJet(stripId) {
		const strip = this.strips.get(stripId);
		if (!strip?.swept || !strip.tube || !strip.held) return false;
		strip.held = false;
		if (Number.isNaN(strip.tube.closedAt)) this.closeHeld(strip.tube);
		let first = Infinity;
		for (const parcel of strip.parcels) if (parcel >= 0 && this.state[parcel] === 2 && this.releaseAt[parcel] < first) first = this.releaseAt[parcel];
		for (const parcel of strip.parcels) if (parcel >= 0 && this.state[parcel] === 2) this.releaseAt[parcel] = this.time + (this.releaseAt[parcel] - first);
		return true;
	}
	/** Each swept jet still held (its pour waiting for its crash or its point's leaving), by strip (PR 5). */
	forEachHeldJet(visit) {
		for (const [id, strip] of this.strips) if (strip.held) visit(id);
	}
	/** A held jet's void closes now, trapping its own air: its cross-section over the crest it spans (PR 5). */
	closeHeld(tube) {
		tube.closedAt = this.time;
		tube.air = (tube.area ?? 0) * (tube.span ?? this.solver.dx);
		this.trappedAir += tube.air;
	}
	/** A pouring jet's parcels still waiting move to (x, y, z), where its drawn lip now lands (PR 5). */
	movePour(stripId, x, y, z) {
		const strip = this.strips.get(stripId);
		if (!strip?.swept) return;
		for (const parcel of strip.parcels) {
			if (parcel < 0 || this.state[parcel] !== 2) continue;
			this.x[parcel] = this.px[parcel] = x;
			this.y[parcel] = this.py[parcel] = y;
			this.z[parcel] = this.pz[parcel] = z;
		}
	}
	/** Release the parcels whose time has come, fly them under gravity, and land those that fall through the surface. */
	step(dt) {
		if (!(dt > 0)) return;
		const { solver } = this;
		this.time += dt;
		this.refreshTubes();
		for (let parcel = 0; parcel < this.capacity; parcel += 1) {
			const state = this.state[parcel];
			if (state === 0) continue;
			if (state === 1 && this.kind[parcel] === 1 && this.age[parcel] === 0 && this.releaseAt[parcel] === this.time) continue;
			let flight = dt;
			if (state === 2) {
				if (this.releaseAt[parcel] > this.time) continue;
				const strip = this.strips.get(this.strip[parcel]);
				if (strip?.held) continue;
				this.state[parcel] = 1;
				flight = this.time - this.releaseAt[parcel];
				if (!strip?.swept) {
					const crest = solver.sampleCentered(solver.h, this.x[parcel], this.z[parcel]) + solver.sampleCentered(solver.bed, this.x[parcel], this.z[parcel]);
					if (crest > this.y[parcel]) this.y[parcel] = this.ly[parcel] = crest;
				} else if (strip.tube && Number.isNaN(strip.tube.closedAt)) {
					this.closeHeld(strip.tube);
					this.closedAtPour += 1;
				}
			}
			this.px[parcel] = this.x[parcel];
			this.py[parcel] = this.y[parcel];
			this.pz[parcel] = this.z[parcel];
			this.vy[parcel] -= GRAVITY$1 * flight;
			this.x[parcel] += this.vx[parcel] * flight;
			this.y[parcel] += this.vy[parcel] * flight;
			this.z[parcel] += this.vz[parcel] * flight;
			this.age[parcel] += flight;
			const water = solver.sampleCentered(solver.h, this.x[parcel], this.z[parcel]) + solver.sampleCentered(solver.bed, this.x[parcel], this.z[parcel]);
			const surface = this.carve(this.x[parcel], this.z[parcel], water);
			if (this.vy[parcel] < 0 && this.y[parcel] <= surface || this.age[parcel] > MAX_FLIGHT) this.land(parcel);
		}
		this.releaseAir(dt);
	}
	/**
	* The water surface where the lip's voids leave it, m. Under a flying jet,
	* inside its overturn, the rider and the eye meet the void's floor (the lower
	* half of the overturn curve), not the depth-averaged face that stands where
	* a real face has gone vertical. A void rides with its crest, opens as far as
	* the jet's tip has flown, and once its jet lands shrinks away as its air is
	* squeezed out (G9, `TUBE_AIR`). The solver's water is left as it is.
	*/
	carve(x, z, surface) {
		return carveAt(this.tubes, this.tubeRows, this.solver.dx, x, z, surface);
	}
	/** The flying tubes as a `tubeTable` (G9); `tubeCount` rows are live. */
	get tubeTable() {
		return this.tubes;
	}
	get tubeCount() {
		return this.tubeRows;
	}
	/**
	* Copy up to `capacity` flying tubes into `into` as a `tubeTable`; returns how
	* many. Past capacity it keeps the newest (the table runs oldest first): they
	* are at the peel's front, where the rider is.
	*/
	writeTubes(into, capacity) {
		const count = Math.min(this.tubeRows, capacity, Math.floor(into.length / 12));
		const first = (this.tubeRows - count) * 12;
		for (let k = 0; k < count * 12; k += 1) into[k] = this.tubes[first + k];
		return count;
	}
	/** Pack every live strip's void where its crest is now, opened as far as its jet's tip has flown and shrunk as far as it has collapsed. */
	refreshTubes() {
		let rows = 0;
		for (const strip of this.strips.values()) {
			const tube = strip.tube;
			if (!tube || strip.swept) continue;
			const scale = 1 - collapsed(tube, this.time);
			if (!(scale > 0)) continue;
			if ((rows + 1) * 12 > this.tubes.length) {
				const grown = new Float64Array(this.tubes.length * 2);
				grown.set(this.tubes);
				this.tubes = grown;
			}
			const age = this.time - strip.launchTime;
			const o = rows * 12;
			const t = this.tubes;
			t[o] = tube.x + tube.dirX * tube.crestSpeed * age;
			t[o + 1] = tube.z + tube.dirZ * tube.crestSpeed * age;
			t[o + 2] = tube.y;
			t[o + 3] = tube.dirX;
			t[o + 4] = tube.dirZ;
			t[o + 5] = tube.relativeSpeed * age;
			t[o + 6] = tube.geometry.length;
			t[o + 7] = tube.geometry.width;
			t[o + 8] = tube.geometry.tilt;
			t[o + 9] = strip.column;
			t[o + 10] = scale;
			t[o + 11] = tube.air * scale * scale;
			rows += 1;
		}
		this.tubeRows = rows;
	}
	/** Air the closing tubes still hold, m³: what they trapped and have not yet let go (G9). */
	get heldAir() {
		let held = 0;
		for (const strip of this.strips.values()) {
			const { tube } = strip;
			if (tube && !Number.isNaN(tube.closedAt)) held += tube.air * (1 - tube.released);
		}
		return held;
	}
	/** Water thrown and not yet landed, flying or still to leave the crest, m³. */
	airborneVolume() {
		let total = 0;
		for (let parcel = 0; parcel < this.capacity; parcel += 1) if (this.active[parcel]) total += this.volume[parcel];
		return total;
	}
	/** Parcels in use, flying or still to leave the crest. */
	activeCount() {
		return this.capacity - this.free.length;
	}
	/**
	* Offer each flying parcel for swept contact over the latest step, as a
	* sphere of its own volume. A velocity the visitor changes stays with the
	* parcel, so it lands with its momentum after the strike.
	*/
	forEachContact(visit) {
		const c = this.contact;
		for (let parcel = 0; parcel < this.capacity; parcel += 1) {
			if (this.state[parcel] !== 1 || this.kind[parcel] === 1) continue;
			c.id = this.id[parcel];
			c.previousPosition.set(this.px[parcel], this.py[parcel], this.pz[parcel]);
			c.position.set(this.x[parcel], this.y[parcel], this.z[parcel]);
			c.velocity.set(this.vx[parcel], this.vy[parcel], this.vz[parcel]);
			c.volume = this.volume[parcel];
			c.radius = Math.cbrt(3 * c.volume / (4 * Math.PI));
			visit(c);
			this.vx[parcel] = c.velocity.x;
			this.vy[parcel] = c.velocity.y;
			this.vz[parcel] = c.velocity.z;
		}
	}
	/**
	* Offer the sheet within `reach` of `center` for contact (plan P7): each link
	* at its closest point to `center`, with the link's interpolated motion, the
	* water around that point (the two parcels' volumes, weighted) and the
	* sheet's half thickness there (that volume over the link's length and a
	* column's width, at least 5 cm); and each lone flying parcel as its sphere.
	* A velocity change the visitor makes goes back to the link's two parcels in
	* proportion to their weights, so momentum is conserved.
	*/
	forEachContactNear(center, reach, visit) {
		if (!Number.isFinite(center.x + center.y + center.z + reach)) return;
		const { near, contact: c } = this;
		this.query = this.query + 1 >>> 0 || 1;
		const query = this.query;
		const width = this.solver.dx;
		this.forEachLink((a, b) => {
			if (this.kind[a] === 1) return;
			this.linked[a] = query;
			this.linked[b] = query;
			near.a.set(this.x[a], this.y[a], this.z[a]);
			near.b.set(this.x[b], this.y[b], this.z[b]);
			const along = near.b.sub(near.a);
			const length = along.length();
			const t = length > 1e-9 ? Math.min(1, Math.max(0, near.pa.subVectors(center, near.a).dot(along) / (length * length))) : 0;
			c.position.copy(near.a).addScaledVector(along, t);
			if (c.position.distanceTo(center) > reach) return;
			near.pa.set(this.px[a], this.py[a], this.pz[a]);
			near.pb.set(this.px[b], this.py[b], this.pz[b]);
			c.previousPosition.copy(near.pa).lerp(near.pb, t);
			near.velocity.set(this.vx[a] + (this.vx[b] - this.vx[a]) * t, this.vy[a] + (this.vy[b] - this.vy[a]) * t, this.vz[a] + (this.vz[b] - this.vz[a]) * t);
			c.velocity.copy(near.velocity);
			c.volume = this.volume[a] * (1 - t) + this.volume[b] * t;
			c.radius = Math.max(.05, c.volume / (2 * Math.max(.05, length) * width));
			c.id = -(this.id[a] * 4194304 + this.id[b]);
			visit(c);
			const change = near.velocity.subVectors(c.velocity, near.velocity).multiplyScalar(c.volume);
			if (change.lengthSq() === 0) return;
			this.vx[a] += change.x * (1 - t) / this.volume[a];
			this.vy[a] += change.y * (1 - t) / this.volume[a];
			this.vz[a] += change.z * (1 - t) / this.volume[a];
			this.vx[b] += change.x * t / this.volume[b];
			this.vy[b] += change.y * t / this.volume[b];
			this.vz[b] += change.z * t / this.volume[b];
		});
		for (let parcel = 0; parcel < this.capacity; parcel += 1) {
			if (this.state[parcel] !== 1 || this.linked[parcel] === query || this.kind[parcel] === 1) continue;
			c.position.set(this.x[parcel], this.y[parcel], this.z[parcel]);
			if (c.position.distanceTo(center) > reach) continue;
			c.id = this.id[parcel];
			c.previousPosition.set(this.px[parcel], this.py[parcel], this.pz[parcel]);
			c.velocity.set(this.vx[parcel], this.vy[parcel], this.vz[parcel]);
			c.volume = this.volume[parcel];
			c.radius = Math.cbrt(3 * c.volume / (4 * Math.PI));
			visit(c);
			this.vx[parcel] = c.velocity.x;
			this.vy[parcel] = c.velocity.y;
			this.vz[parcel] = c.velocity.z;
		}
	}
	forEachActive(visit) {
		for (let parcel = 0; parcel < this.capacity; parcel += 1) if (this.state[parcel] === 1) visit(this.x[parcel], this.y[parcel], this.z[parcel], this.volume[parcel]);
	}
	/** Each flying parcel with its place in the sheet: pool slot, world column, index along its strip and the strip's launch time. */
	forEachActiveParcel(visit) {
		const view = this.view;
		for (let parcel = 0; parcel < this.capacity; parcel += 1) {
			if (this.state[parcel] !== 1) continue;
			view.slot = parcel;
			view.x = this.x[parcel];
			view.y = this.y[parcel];
			view.z = this.z[parcel];
			view.vx = this.vx[parcel];
			view.vy = this.vy[parcel];
			view.vz = this.vz[parcel];
			view.column = this.column[parcel];
			view.index = this.index[parcel];
			view.launchTime = this.launchTime[parcel];
			view.age = this.age[parcel];
			view.volume = this.volume[parcel];
			view.kind = this.kind[parcel];
			visit(view);
		}
	}
	/**
	* The sheet's links between flying parcels (pool slots): along each strip,
	* k to k + 1; and across to the next world column's strips thrown within
	* LINK_TIME, k to k. A peeling wave's strips so join into one curling sheet.
	*/
	forEachLink(visit) {
		const flying = (parcel) => this.state[parcel] === 1;
		for (const strip of this.strips.values()) {
			const { parcels } = strip;
			for (let k = 0; k + 1 < parcels.length; k += 1) if (flying(parcels[k]) && flying(parcels[k + 1])) visit(parcels[k], parcels[k + 1]);
			for (const neighbourId of this.byColumn.get(strip.column + 1) ?? []) {
				const neighbour = this.strips.get(neighbourId);
				if (neighbour.kind !== strip.kind || Math.abs(neighbour.launchTime - strip.launchTime) >= 1) continue;
				for (let k = 0; k < parcels.length; k += 1) if (flying(parcels[k]) && flying(neighbour.parcels[k])) visit(parcels[k], neighbour.parcels[k]);
			}
		}
	}
	/**
	* A parcel falls back in. A jet's water hitting hard enough throws a
	* splash-up (G9): SPLASH_UP's share of it, up and on; the rest returns to
	* the cell it lands in at once, with all the parcel's forward momentum but
	* the splash-up's, so the water's momentum is conserved. A splash-up lands
	* whole.
	*/
	land(parcel) {
		const { solver } = this;
		const [x, y, z] = [
			this.x[parcel],
			this.y[parcel],
			this.z[parcel]
		];
		const [vx, vy, vz] = [
			this.vx[parcel],
			this.vy[parcel],
			this.vz[parcel]
		];
		const volume = this.volume[parcel];
		const splash = this.kind[parcel] === 0 && -vy > SPLASH_UP.minImpact && !solver.beyondOpenEdge(x) ? SPLASH_UP.share * volume : 0;
		const stripId = this.strip[parcel];
		const strip = this.strips.get(stripId);
		const thickness = this.kind[parcel] === 0 && strip?.tube ? 8 * volume / solver.dx / strip.tube.geometry.length : 0;
		const speed = Math.hypot(vx, vz);
		const pieces = speed > 0 ? Math.max(1, Math.ceil(thickness / solver.dx - 1e-9)) : 1;
		let escaped = 0;
		for (let k = 0; k < pieces; k += 1) {
			const along = ((k + .5) / pieces - .5) * thickness;
			const [px, pz] = pieces > 1 ? [x + vx / speed * along, z + vz / speed * along] : [x, z];
			const momentumX = volume * vx - splash * SPLASH_UP.horizontal * vx;
			const momentumZ = volume * vz - splash * SPLASH_UP.horizontal * vz;
			if (!this.deposit(px, pz, volume - splash, momentumX, momentumZ, pieces)) escaped += (volume - splash) / pieces;
		}
		if (escaped > 0) {
			this.escapedLandings += 1;
			this.escapedVolume += escaped;
		}
		const { flight } = this;
		flight.launch.x = this.lx[parcel];
		flight.launch.y = this.ly[parcel];
		flight.launch.z = this.lz[parcel];
		flight.y = y;
		flight.age = this.age[parcel];
		flight.crestSpeed = this.crestSpeed[parcel];
		flight.kind = this.kind[parcel];
		flight.volume = volume;
		flight.waveHeight = strip?.waveHeight ?? 0;
		flight.swept = strip?.swept ?? false;
		this.active[parcel] = 0;
		this.state[parcel] = 0;
		this.free.push(parcel);
		this.landings += 1;
		if (strip) {
			strip.parcels[strip.parcels.indexOf(parcel)] = -1;
			strip.live -= 1;
			const { tube } = strip;
			if (tube && tube.drop === 0) tube.drop = Math.max(.1, flight.launch.y - y);
			if (tube && strip.live === 0 && Number.isNaN(tube.closedAt)) {
				tube.closedAt = this.time;
				tube.air = (tube.area ?? LH82_AREA * tube.geometry.length * tube.geometry.width) * (tube.span ?? solver.dx);
				this.trappedAir += tube.air;
			}
			if (strip.live === 0 && (!tube || collapsed(tube, this.time) >= 1)) this.removeStrip(stripId, strip);
		}
		const flies = splash > 0 && this.throwSplash(strip, x, y, z, splash, vx, vy, vz);
		this.onLand?.(x, z, flies ? volume - splash : volume, vx, vy, vz, flight);
	}
	/**
	* Return one of `pieces` equal shares of `volume` m³ of water, with its momentum (`momentumX`, `momentumZ`, m⁴/s),
	* to the cell it comes down in; false if it has left the window. Past an open along-shore edge it has, as water
	* running out through that edge does (a particle-mesh model's rule: deleted at open boundaries, wrapped at periodic
	* ones, kept by walls). Clamped into the edge column instead, the jets a Big set threw out past the Reef's +x edge
	* piled 5 m³ into three cells in 0.4 s: a one-cell spike 4 m high there (dη/dz 4.2 in 7 m of water).
	*/
	deposit(x, z, volume, momentumX, momentumZ, pieces = 1) {
		const { solver } = this;
		const { nx, dx, xCenters } = solver;
		if (solver.beyondOpenEdge(x)) return false;
		let along = x;
		if (solver.periodicAlongShore) {
			const west = xCenters[0] - dx / 2;
			along = west + ((x - west) % (nx * dx) + nx * dx) % (nx * dx);
		}
		const cell = solver.cellIndex(along, z);
		const area = pieces * dx * solver.dz[Math.floor(cell / nx)];
		solver.h[cell] += volume / area;
		solver.qx[cell] += momentumX / area;
		solver.qz[cell] += momentumZ / area;
		return true;
	}
	removeStrip(stripId, strip) {
		this.strips.delete(stripId);
		const inColumn = this.byColumn.get(strip.column);
		inColumn.splice(inColumn.indexOf(stripId), 1);
		if (inColumn.length === 0) this.byColumn.delete(strip.column);
	}
	/**
	* Squeeze out this step's share of every closing tube's air (G9, `TUBE_AIR`).
	* `escape` of it leaves as spray. Where the closing tube's peel (its chain of
	* tubes in neighbouring columns thrown within LINK_TIME) still has an open
	* end, it blows out of the nearer one, along the tube, as fast as that much
	* air must go through the mouth's void cross-section; where the peel has
	* closed all along, it bursts up through the lip. The rest breaks into
	* bubbles where the void was, driven down as far as the jet fell. Each
	* closing tube rolls a foam ball where its void was.
	*/
	releaseAir(dt) {
		this.spits.length = 0;
		this.eruptions.length = 0;
		this.rollers.length = 0;
		let closing = false;
		for (const [stripId, strip] of this.strips) {
			const { tube } = strip;
			if (!tube || Number.isNaN(tube.closedAt)) continue;
			if (tube.released < 1) closing = true;
			else if (strip.live === 0) this.removeStrip(stripId, strip);
		}
		if (!closing) return;
		for (const chain of this.tubeChains()) {
			let lowest = Infinity;
			let highest = -Infinity;
			for (const strip of chain) {
				lowest = Math.min(lowest, strip.column);
				highest = Math.max(highest, strip.column);
			}
			const mouths = chain.filter((strip) => Number.isNaN(strip.tube.closedAt) && (strip.column === lowest || strip.column === highest));
			const fed = mouths.map(() => ({
				rate: 0,
				x: 0,
				z: 0
			}));
			const burst = {
				rate: 0,
				x: 0,
				y: 0,
				z: 0,
				speed: 0
			};
			for (const strip of chain) {
				const tube = strip.tube;
				if (Number.isNaN(tube.closedAt) || tube.released >= 1) continue;
				const done = collapsed(tube, this.time);
				const gone = 1 - (1 - done) * (1 - done);
				const volume = tube.air * (gone - tube.released);
				tube.released = gone;
				if (!(volume > 0)) continue;
				const centre = this.voidCentre(strip, 1 - done);
				this.rollers.push({
					id: tube.id,
					x: centre.x,
					y: centre.y,
					z: centre.z,
					dirX: tube.dirX,
					dirZ: tube.dirZ,
					speed: tube.crestSpeed,
					area: ROLLER_AREA * tube.drop * tube.drop,
					width: tube.span ?? this.solver.dx
				});
				const escaping = TUBE_AIR.escape * volume;
				this.breakIntoBubbles(strip, 1 - done, volume - escaping);
				const rate = escaping / dt;
				if (mouths.length > 0) {
					let nearest = 0;
					for (let m = 1; m < mouths.length; m += 1) if (Math.abs(mouths[m].column - strip.column) < Math.abs(mouths[nearest].column - strip.column)) nearest = m;
					fed[nearest].rate += rate;
					fed[nearest].x += rate * centre.x;
					fed[nearest].z += rate * centre.z;
				} else {
					burst.rate += rate;
					burst.x += rate * centre.x;
					burst.y += rate * tube.y;
					burst.z += rate * centre.z;
					burst.speed += rate * Math.sqrt(GRAVITY$1 * tube.geometry.width / 2);
				}
			}
			mouths.forEach((mouth, m) => {
				const { rate } = fed[m];
				if (!(rate > 0)) return;
				const tube = mouth.tube;
				const centre = this.voidCentre(mouth, 1);
				const alongX = -tube.dirZ;
				const alongZ = tube.dirX;
				const outward = (centre.x - fed[m].x / rate) * alongX + (centre.z - fed[m].z / rate) * alongZ >= 0 ? 1 : -1;
				const area = tube.area ?? LH82_AREA * tube.geometry.length * tube.geometry.width;
				const spat = Math.min(rate, spitSpeedLimit(tube.geometry.width) * area);
				this.spits.push({
					x: centre.x,
					y: centre.y,
					z: centre.z,
					dirX: outward * alongX,
					dirZ: outward * alongZ,
					speed: spat / area,
					airRate: spat
				});
				const excess = rate - spat;
				if (excess > 0) {
					burst.rate += excess;
					burst.x += excess * fed[m].x / rate;
					burst.y += excess * tube.y;
					burst.z += excess * fed[m].z / rate;
					burst.speed += excess * Math.sqrt(GRAVITY$1 * tube.geometry.width / 2);
				}
			});
			if (burst.rate > 0) this.eruptions.push({
				x: burst.x / burst.rate,
				y: burst.y / burst.rate,
				z: burst.z / burst.rate,
				airRate: burst.rate,
				speed: burst.speed / burst.rate
			});
		}
	}
	/**
	* A closing void's air that does not escape breaks into bubbles all along
	* it, crest to jet tip (as it now stands, shrunk to `scale`), driven down as
	* far as the jet fell.
	*/
	breakIntoBubbles(strip, scale, volume) {
		if (!this.onAir) return;
		const tube = strip.tube;
		const reach = tube.geometry.length * Math.max(scale, 0) * (tube.axisX ?? Math.cos(tube.geometry.tilt));
		const age = this.time - strip.launchTime;
		const crestX = tube.x + tube.dirX * tube.crestSpeed * age;
		const crestZ = tube.z + tube.dirZ * tube.crestSpeed * age;
		for (let k = 0; k < BUBBLE_POINTS; k += 1) {
			const ahead = (k + .5) / BUBBLE_POINTS * reach;
			this.onAir(crestX + tube.dirX * ahead, crestZ + tube.dirZ * ahead, volume / BUBBLE_POINTS, AERATION$2.plungeDepth * tube.drop);
		}
	}
	/** The middle of a strip's void now, shrunk to `scale`: ahead of its crest and down, halfway along its long axis. */
	voidCentre(strip, scale) {
		const tube = strip.tube;
		const { length, width, tilt } = tube.geometry;
		const age = this.time - strip.launchTime;
		const ahead = .5 * length * scale * (tube.axisX ?? Math.cos(tilt));
		return {
			x: tube.x + tube.dirX * (tube.crestSpeed * age + ahead),
			y: tube.y - .5 * width * scale - .5 * length * scale * (tube.axisY === void 0 ? Math.sin(tilt) : -tube.axisY),
			z: tube.z + tube.dirZ * (tube.crestSpeed * age + ahead)
		};
	}
	/** The tubed strips, grouped into peels: tubes of neighbouring columns thrown within LINK_TIME of each other. */
	tubeChains() {
		const seen = this.chained;
		seen.clear();
		const chains = [];
		for (const strip of this.strips.values()) {
			if (!strip.tube || seen.has(strip)) continue;
			const chain = [strip];
			seen.add(strip);
			for (let k = 0; k < chain.length; k += 1) {
				const at = chain[k];
				for (const column of [at.column - 1, at.column + 1]) for (const id of this.byColumn.get(column) ?? []) {
					const other = this.strips.get(id);
					if (!other.tube || seen.has(other) || Math.abs(other.launchTime - at.launchTime) >= 1) continue;
					seen.add(other);
					chain.push(other);
				}
			}
			chains.push(chain);
		}
		return chains;
	}
	/** One splash-up parcel, gathered with the rest of its jet's into one strip, so they draw as one sheet. */
	throwSplash(jet, x, y, z, volume, vx, vy, vz) {
		const parcel = jet ? this.free.pop() : void 0;
		if (!jet || parcel === void 0) {
			if (!this.deposit(x, z, volume, volume * SPLASH_UP.horizontal * vx, volume * SPLASH_UP.horizontal * vz)) {
				this.escapedLandings += 1;
				this.escapedVolume += volume;
			}
			return false;
		}
		let splashId = jet.splash;
		let splash = splashId === void 0 ? void 0 : this.strips.get(splashId);
		if (!splash) {
			splashId = this.nextStrip;
			this.nextStrip += 1;
			splash = {
				column: jet.column,
				launchTime: this.time,
				parcels: [],
				live: 0,
				kind: 1,
				waveHeight: 0
			};
			this.strips.set(splashId, splash);
			const inColumn = this.byColumn.get(jet.column);
			if (inColumn) inColumn.push(splashId);
			else this.byColumn.set(jet.column, [splashId]);
			jet.splash = splashId;
		}
		splash.parcels.push(parcel);
		splash.live += 1;
		this.active[parcel] = 1;
		this.state[parcel] = 1;
		this.releaseAt[parcel] = this.time;
		this.x[parcel] = this.px[parcel] = this.lx[parcel] = x;
		this.y[parcel] = this.py[parcel] = this.ly[parcel] = y;
		this.z[parcel] = this.pz[parcel] = this.lz[parcel] = z;
		this.crestSpeed[parcel] = 0;
		this.id[parcel] = this.nextId;
		this.nextId += 1;
		this.vx[parcel] = SPLASH_UP.horizontal * vx;
		this.vy[parcel] = SPLASH_UP.vertical * Math.abs(vy);
		this.vz[parcel] = SPLASH_UP.horizontal * vz;
		this.volume[parcel] = volume;
		this.age[parcel] = 0;
		this.strip[parcel] = splashId;
		this.column[parcel] = splash.column;
		this.index[parcel] = splash.parcels.length - 1;
		this.launchTime[parcel] = splash.launchTime;
		this.kind[parcel] = 1;
		return true;
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/Refraction.ts
/** Spacing of the launched rays along x, m. */
const RAY_SPACING = .25;
/** Step along a ray, m, and the spacing of the celerity grid it reads. */
const RAY_STEP = 1;
/** Shallowest water a ray's celerity is taken at, m. */
const MIN_DEPTH$3 = .05;
/**
* Where a straight-crested swell's rays cross z = toZ, launched evenly spaced
* along z = fromZ and refracted by the bed: linear geometric optics, in which
* a ray turns toward slower water at the rate |∇c across the ray| / c (Snell's
* law on a varying bed; ray theory in Mei, Stiassnie & Yue 2005). Rays that
* turn back offshore, or wander past the traced strip, are dropped. Sorted.
*/
function crossings(depthAt, swell, fromZ, toZ, xMin, xMax) {
	const run = toZ - fromZ;
	const reach = run * (1 + Math.abs(Math.tan(swell.direction)));
	const left = xMin - 2 * reach;
	const nx = Math.ceil((xMax - xMin + 4 * reach) / RAY_STEP) + 1;
	const nz = Math.ceil(run / RAY_STEP) + 1;
	const omega = 2 * Math.PI / swell.period;
	const celerity = new Float64Array(nx * nz);
	for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
		const depth = Math.max(MIN_DEPTH$3, depthAt(left + ix * RAY_STEP, fromZ + iz * RAY_STEP));
		celerity[iz * nx + ix] = omega / waveNumber(omega, depth);
	}
	const sample = (x, z) => {
		const gx = Math.min(nx - 1.000001, Math.max(0, (x - left) / RAY_STEP));
		const gz = Math.min(nz - 1.000001, Math.max(0, (z - fromZ) / RAY_STEP));
		const ix = Math.floor(gx);
		const iz = Math.floor(gz);
		const tx = gx - ix;
		const tz = gz - iz;
		const i = iz * nx + ix;
		return (celerity[i] * (1 - tx) + celerity[i + 1] * tx) * (1 - tz) + (celerity[i + nx] * (1 - tx) + celerity[i + nx + 1] * tx) * tz;
	};
	const turn = (x, z, dx, dz, out) => {
		const c = sample(x, z);
		const cx = (sample(x + RAY_STEP, z) - sample(x - RAY_STEP, z)) / 2;
		const cz = (sample(x, z + RAY_STEP) - sample(x, z - RAY_STEP)) / 2;
		const along = cx * dx + cz * dz;
		out[0] = -(cx - along * dx) / c;
		out[1] = -(cz - along * dz) / c;
	};
	const hits = [];
	const k1 = [0, 0];
	const k2 = [0, 0];
	const h = RAY_STEP;
	for (let x0 = xMin - reach; x0 <= xMax + reach; x0 += RAY_SPACING) {
		let x = x0;
		let z = fromZ;
		let dx = Math.sin(swell.direction);
		let dz = Math.cos(swell.direction);
		for (let step = 0; step < 4 * nz; step += 1) {
			turn(x, z, dx, dz, k1);
			let mx = dx + .5 * h * k1[0];
			let mz = dz + .5 * h * k1[1];
			const midLength = Math.hypot(mx, mz);
			mx /= midLength;
			mz /= midLength;
			turn(x + .5 * h * dx, z + .5 * h * dz, mx, mz, k2);
			const nextX = x + h * mx;
			const nextZ = z + h * mz;
			dx += h * k2[0];
			dz += h * k2[1];
			const length = Math.hypot(dx, dz);
			dx /= length;
			dz /= length;
			if (nextZ >= toZ) {
				hits.push(x + (toZ - z) / (nextZ - z) * (nextX - x));
				break;
			}
			x = nextX;
			z = nextZ;
			if (z < fromZ || x < left || x > left + (nx - 1) * RAY_STEP) break;
		}
	}
	return Float64Array.from(hits).sort();
}
/** How many sorted values lie below `value`. */
function countBelow(sorted, value) {
	let low = 0;
	let high = sorted.length;
	while (low < high) {
		const middle = low + high >> 1;
		if (sorted[middle] < value) low = middle + 1;
		else high = middle;
	}
	return low;
}
function concentrationAt(hits, x, width) {
	return (countBelow(hits, x + width / 2) - countBelow(hits, x - width / 2)) * RAY_SPACING / width;
}
/**
* Where along z = toZ, between xMin and xMax, the bed gathers most of the
* swell, averaged over half a local wavelength: rays resolve nothing finer,
* and diffraction smooths the caustics they draw. Against the Boussinesq
* surf zone at the Canyon, this lands where its waves are 89–96 % of their
* largest height along the lineup; averaged over a whole wavelength it fell
* 30–40 m off the peak of 12–14 s swells. Ties go to the smaller x.
*/
function focusX(depthAt, swell, fromZ, toZ, xMin, xMax) {
	const omega = 2 * Math.PI / swell.period;
	const middle = (xMin + xMax) / 2;
	const width = Math.PI / waveNumber(omega, Math.max(MIN_DEPTH$3, depthAt(middle, toZ)));
	const hits = crossings(depthAt, swell, fromZ, toZ, xMin - width / 2, xMax + width / 2);
	let best = xMin;
	let most = -Infinity;
	for (let x = xMin; x <= xMax; x += RAY_STEP) {
		const here = concentrationAt(hits, x, width);
		if (here > most) {
			most = here;
			best = x;
		}
	}
	return best;
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/CrestKinematics.ts
/** Crests over thinner water are shore swash, not waves, m. */
const WET$5 = .05;
/** How far ahead of the crest to look for its front face, m. */
const FACE_REACH$3 = 10;
/** A flatter face does not show the crest's motion. */
const MIN_FACE_SLOPE = .005;
/**
* No crest outruns this many long-wave speeds √(g h) of the water under it: a strong bore into water a tenth as
* deep runs at 2.3 of them; the game's thrown crests measure up to 1.4–1.7. A face rising faster than that is water
* piling up in place (a lip landing, bores meeting), not a travelling form: on the Reef's Big swell such readings
* gave 40–66 m/s crests in 10 m of water, and the jet's momentum taken from the water ran it away.
*/
const MAX_CREST_FROUDE = 2;
/**
* How a breaking crest goes, from the local Iribarren number under it (Battjes
* 1974): a plunging jet for 0.4 ≤ ξ ≤ 2, a spilling roller below, and above
* it a surging wave that throws nothing. Surging needs the slope to run up to
* the still-water line; over a submerged crest (a reef ledge levelling off
* under water) the wave cannot surge and plunges instead (Yao et al. 2013;
* Blenkinsopp & Chaplin 2008). The lip of such a reef break takes its shape
* from `reefOverturn` (Mead & Black 2001; the Teahupo'o Reef, Part B); this
* flag keeps the readout's breaker type in step with it.
*/
function breakerForm(localIribarren, overSubmergedCrest = false) {
	if (localIribarren < .4) return "roller";
	return localIribarren <= 2 || overSubmergedCrest ? "jet" : "none";
}
/** Still water this thin is the shoreline, m. */
const SHORELINE = .01;
/**
* Whether the slope under a break ends in a submerged crest: where the local
* slope, carried on as a plane, would reach the still-water line (stillDepth /
* slope ahead), the bed is still under water. A plane beach face reaches it; a
* reef ledge has levelled off below it. `depthAhead(d)` is the still depth d m
* shoreward of the break.
*/
function submergedCrest(depthAhead, stillDepth, slope) {
	if (!(slope > 0) || !(stillDepth > 0)) return false;
	return depthAhead(stillDepth / slope) > SHORELINE;
}
/**
* The motion of the crest at `crest`, from the surface's own motion on its
* front face (plan P7). A form travelling at c satisfies η_t = c |∇η| where
* the surface falls ahead of it, so c = η_t / |∇η| at the steepest point of
* the face within FACE_REACH shoreward, and it travels down that gradient.
* The depth-averaged water cannot give the crest's speed: at a breaking crest
* it moves at about half of it. Undefined without a rising, sloping face that
* travels no faster than MAX_CREST_FROUDE long-wave speeds of the crest's water.
*/
function crestMotion(solver, crest) {
	const { nx, nz, zCenters, dx, h } = solver;
	const rise = solver.surfaceRiseRate;
	const column = crest % nx;
	const crestRow = Math.floor(crest / nx);
	const eta = (i) => h[i] + solver.bed[i];
	let best;
	let steepest = MIN_FACE_SLOPE;
	const fastest = MAX_CREST_FROUDE * Math.sqrt(GRAVITY$1 * Math.max(0, h[crest]));
	for (let row = crestRow + 1; row < nz - 1 && zCenters[row] - zCenters[crestRow] <= FACE_REACH$3; row += 1) {
		const cell = row * nx + column;
		if (!(h[cell] > WET$5) || !(rise[cell] > 0)) continue;
		const slopeZ = (eta(cell + nx) - eta(cell - nx)) / (zCenters[row + 1] - zCenters[row - 1]);
		const slopeX = column > 0 && column < nx - 1 ? (eta(cell + 1) - eta(cell - 1)) / (2 * dx) : 0;
		const slope = Math.hypot(slopeX, slopeZ);
		if (!(slopeZ < 0) || slope <= steepest || !(rise[cell] <= fastest * slope)) continue;
		steepest = slope;
		best = {
			speed: rise[cell] / slope,
			direction: {
				x: -slopeX / slope,
				z: -slopeZ / slope
			}
		};
	}
	return best;
}
/** The crest's height above the lowest water within `reach` m shoreward of it along its column, m. */
function waveHeightAt(solver, crest, reach) {
	const { nx, nz, zCenters, h, bed } = solver;
	const column = crest % nx;
	const crestRow = Math.floor(crest / nx);
	let trough = h[crest] + bed[crest];
	for (let row = crestRow + 1; row < nz && zCenters[row] - zCenters[crestRow] <= reach; row += 1) {
		const cell = row * nx + column;
		if (h[cell] > WET$5) trough = Math.min(trough, h[cell] + bed[cell]);
	}
	return h[crest] + bed[crest] - trough;
}
/** Mean of the highest `fraction` of the values, at least one: H1/3 with 1/3, H1/10 with 1/10. */
function highestMean(values, fraction) {
	if (!values.length) return NaN;
	const sorted = [...values].sort((a, b) => b - a);
	const count = Math.max(1, Math.ceil(sorted.length * fraction));
	let sum = 0;
	for (let i = 0; i < count; i += 1) sum += sorted[i];
	return sum / count;
}
/**
* Measures the waves breaking in along-shore bands. The onsets in a band
* within half a period of a wave's first onset are that wave; its face is the
* largest of theirs, and it is placed where that face was.
*/
var SurfMeter = class {
	period;
	keep;
	bands;
	constructor(bands, period, keep = 120) {
		this.period = period;
		this.keep = keep;
		this.bands = bands.map(({ xMin, xMax }) => ({
			xMin,
			xMax,
			waves: []
		}));
	}
	add(wave) {
		const band = this.bands.find(({ xMin, xMax }) => wave.x >= xMin && wave.x <= xMax);
		if (!band) return;
		if (band.waves.length && wave.time < band.waves.at(-1).time) band.waves.length = 0;
		const last = band.waves.at(-1);
		if (last && wave.time - last.time < .5 * this.period) {
			if (wave.face > last.face) Object.assign(last, {
				x: wave.x,
				z: wave.z,
				face: wave.face
			});
			return;
		}
		band.waves.push({ ...wave });
		while (band.waves.length && band.waves[0].time < wave.time - this.keep) band.waves.shift();
	}
	/** Forget every wave measured (a sea taken over or restored starts measuring afresh). */
	clear() {
		for (const band of this.bands) band.waves.length = 0;
	}
	/** Every band's waves that started breaking at or after `since`. */
	waves(since = -Infinity) {
		return this.bands.flatMap((band) => band.waves.filter((wave) => wave.time >= since));
	}
	/** The surf over the last `window` seconds, or undefined while fewer than MIN_SURF_WAVES have broken. */
	reading(now, window = 120) {
		const faces = this.waves(now - window).map((wave) => wave.face);
		if (faces.length < 3) return void 0;
		return {
			typical: highestMean(faces, 1 / 3),
			sets: highestMean(faces, 1 / 10),
			waves: faces.length
		};
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/SeaStateBoundary.ts
/**
* Relaxation target reproducing a linear sea state inside a solver zone, with
* the linear flux q = c η along each component. Each component's phase splits
* into an along-shore part (per column, refreshed when the window slides) and
* a cross-shore part (per zone row, refreshed per time), so a cell costs two
* multiply-adds per component per step.
*/
var SeaStateBoundary = class {
	grid;
	sea;
	weights;
	offset;
	count;
	firstRow;
	rows;
	amplitude;
	kx;
	omega;
	speedX;
	speedZ;
	rowPhase;
	columnCos;
	columnSin;
	rowCos;
	rowSin;
	cachedTime = NaN;
	cachedFirstX = NaN;
	/** Sea time at solver time 0, s. */
	get timeOffset() {
		return this.offset;
	}
	/** A new offset (the sea handover takes the donor's, spec N1); the cached phases are dropped. */
	set timeOffset(offset) {
		this.offset = offset;
		this.cachedTime = NaN;
	}
	constructor(grid, sea, weights, offset = 0) {
		this.grid = grid;
		this.sea = sea;
		this.weights = weights;
		this.offset = offset;
		const components = sea.components;
		this.count = components.length;
		let first = grid.nz;
		let last = -1;
		for (let iz = 0; iz < grid.nz; iz += 1) for (let ix = 0; ix < grid.nx; ix += 1) {
			if (weights[iz * grid.nx + ix] <= 0) continue;
			first = Math.min(first, iz);
			last = Math.max(last, iz);
		}
		this.firstRow = first;
		this.rows = Math.max(0, last - first + 1);
		const perComponent = () => new Float64Array(this.count);
		this.amplitude = perComponent();
		this.kx = perComponent();
		this.omega = perComponent();
		this.speedX = perComponent();
		this.speedZ = perComponent();
		this.rowPhase = new Float64Array(this.rows * this.count);
		this.rowCos = new Float64Array(this.rows * this.count);
		this.rowSin = new Float64Array(this.rows * this.count);
		this.columnCos = new Float64Array(grid.nx * this.count);
		this.columnSin = new Float64Array(grid.nx * this.count);
		components.forEach((component, c) => {
			const speed = component.omega / component.k;
			this.amplitude[c] = component.amplitude;
			this.kx[c] = component.kx;
			this.omega[c] = component.omega;
			this.speedX[c] = speed * Math.sin(component.direction);
			this.speedZ[c] = speed * Math.cos(component.direction);
			for (let r = 0; r < this.rows; r += 1) this.rowPhase[r * this.count + c] = component.kz * grid.zCenters[this.firstRow + r] + component.phase;
		});
	}
	target(x, z, t, out, index = -1) {
		const row = index >= 0 ? Math.floor(index / this.grid.nx) - this.firstRow : -1;
		if (row < 0 || row >= this.rows) {
			this.direct(x, z, t, out);
			return;
		}
		this.refresh(t);
		const column = index % this.grid.nx * this.count;
		const rowBase = row * this.count;
		let eta = 0;
		let qx = 0;
		let qz = 0;
		for (let c = 0; c < this.count; c += 1) {
			const value = this.amplitude[c] * (this.columnCos[column + c] * this.rowCos[rowBase + c] - this.columnSin[column + c] * this.rowSin[rowBase + c]);
			eta += value;
			qx += this.speedX[c] * value;
			qz += this.speedZ[c] * value;
		}
		out.eta = eta;
		out.qx = qx;
		out.qz = qz;
	}
	refresh(t) {
		const firstX = this.grid.xCenters[0];
		if (firstX !== this.cachedFirstX) {
			for (let ix = 0; ix < this.grid.nx; ix += 1) {
				const x = this.grid.xCenters[ix];
				for (let c = 0; c < this.count; c += 1) {
					this.columnCos[ix * this.count + c] = Math.cos(this.kx[c] * x);
					this.columnSin[ix * this.count + c] = Math.sin(this.kx[c] * x);
				}
			}
			this.cachedFirstX = firstX;
		}
		if (t !== this.cachedTime) {
			const seaTime = t + this.offset;
			for (let r = 0; r < this.rows; r += 1) for (let c = 0; c < this.count; c += 1) {
				const phase = this.rowPhase[r * this.count + c] - this.omega[c] * seaTime;
				this.rowCos[r * this.count + c] = Math.cos(phase);
				this.rowSin[r * this.count + c] = Math.sin(phase);
			}
			this.cachedTime = t;
		}
	}
	direct(x, z, t, out) {
		let eta = 0;
		let qx = 0;
		let qz = 0;
		const seaTime = t + this.offset;
		this.sea.components.forEach((component, c) => {
			const value = component.amplitude * Math.cos(component.kx * x + component.kz * z - component.omega * seaTime + component.phase);
			eta += value;
			qx += this.speedX[c] * value;
			qz += this.speedZ[c] * value;
		});
		out.eta = eta;
		out.qx = qx;
		out.qz = qz;
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/warmStart.ts
const MIN_DEPTH$2 = .05;
/**
* The linear sea shoaled and refracted along column `ix` (WKB), row by row from
* offshore: contours are treated as straight within a column, kx is conserved,
* kz comes from the local depth with the sea's own dispersion, and amplitude
* follows conserved cross-shore energy flux, a² c_g cosθ = const. Local Hs is
* capped at γh. `visit` gets each row; its arrays are reused between rows.
* Offshore of `referenceZ` the bed matches the sea's reference depth.
*/
function transformedSea(solver, sea, referenceZ, ix, gamma, visit) {
	const components = sea.components;
	const count = components.length;
	const referenceFlux = components.map((c) => groupSpeed(sea.waveNumberAt, c.omega, sea.depth) * (c.kz / c.k));
	const phase = new Float64Array(count);
	const alive = new Uint8Array(count);
	const row = {
		depth: 0,
		hs: 0,
		scale: 1,
		amplitude: new Float64Array(count),
		phase: new Float64Array(count),
		speedX: new Float64Array(count),
		speedZ: new Float64Array(count)
	};
	const { nx, nz } = solver;
	const x = solver.xCenters[ix];
	let previousZ = referenceZ;
	let previousKz = components.map((c) => c.kz);
	for (let c = 0; c < count; c += 1) {
		phase[c] = components[c].kx * x + components[c].kz * referenceZ + components[c].phase;
		alive[c] = components[c].kz > 0 ? 1 : 0;
	}
	for (let iz = 0; iz < nz; iz += 1) {
		const i = iz * nx + ix;
		const z = solver.zCenters[iz];
		const depth = solver.restLevel - solver.bed[i];
		let hs = 0;
		const localKz = new Array(count);
		for (let c = 0; c < count; c += 1) {
			const component = components[c];
			if (z <= referenceZ) {
				row.amplitude[c] = component.amplitude;
				row.speedX[c] = component.omega / component.k * (component.kx / component.k);
				row.speedZ[c] = component.omega / component.k * (component.kz / component.k);
				row.phase[c] = component.kx * x + component.kz * z + component.phase;
				localKz[c] = component.kz;
				continue;
			}
			if (!alive[c] || depth <= MIN_DEPTH$2) {
				alive[c] = 0;
				row.amplitude[c] = 0;
				localKz[c] = 0;
				continue;
			}
			const k = sea.waveNumberAt(component.omega, depth);
			if (k <= Math.abs(component.kx)) {
				alive[c] = 0;
				row.amplitude[c] = 0;
				localKz[c] = 0;
				continue;
			}
			const kz = Math.sqrt(k * k - component.kx * component.kx);
			localKz[c] = kz;
			phase[c] += .5 * (previousKz[c] + kz) * (z - previousZ);
			const flux = groupSpeed(sea.waveNumberAt, component.omega, depth) * (kz / k);
			row.amplitude[c] = component.amplitude * Math.sqrt(referenceFlux[c] / flux);
			row.speedX[c] = component.omega / k * (component.kx / k);
			row.speedZ[c] = component.omega / k * (kz / k);
			row.phase[c] = phase[c];
			hs += .5 * row.amplitude[c] * row.amplitude[c];
		}
		if (z > referenceZ) {
			previousZ = z;
			previousKz = localKz;
		}
		hs = 4 * Math.sqrt(hs);
		row.depth = depth;
		row.hs = hs;
		row.scale = depth > MIN_DEPTH$2 && hs > gamma * depth ? gamma * depth / hs : 1;
		visit(iz, row);
	}
}
/**
* Fill the solver with the linear sea shoaled and refracted along each column
* (`transformedSea`), capped at γh, so the spin-up only has to settle the nonlinear shape.
*/
function warmStart(solver, sea, options) {
	const { referenceZ, seaTime } = options;
	const gamma = options.breakerIndex ?? .78;
	const components = sea.components;
	const count = components.length;
	const { nx } = solver;
	for (let ix = 0; ix < nx; ix += 1) transformedSea(solver, sea, referenceZ, ix, gamma, (iz, row) => {
		const i = iz * nx + ix;
		let eta = 0;
		let qx = 0;
		let qz = 0;
		for (let c = 0; c < count; c += 1) {
			if (row.amplitude[c] === 0) continue;
			const value = row.scale * row.amplitude[c] * Math.cos(row.phase[c] - components[c].omega * seaTime);
			eta += value;
			qx += row.speedX[c] * value;
			qz += row.speedZ[c] * value;
		}
		const total = Math.max(0, solver.restLevel + eta - solver.bed[i]);
		const wet = total > 1e-4;
		solver.h[i] = total;
		solver.qx[i] = wet ? qx : 0;
		solver.qz[i] = wet ? qz : 0;
	});
}
/**
* Pick sea times so the player takes control `lead` seconds before the next
* set peaks at (x, referenceZ), after a `spinUp` of simulated settling.
*/
function planSetRun(sea, x, referenceZ, fromSeaTime, lead, spinUp, horizon = 600) {
	const setPeakSeaTime = sea.nextSetPeak(x, referenceZ, fromSeaTime + lead + spinUp, horizon);
	const handOverSeaTime = setPeakSeaTime - lead;
	return {
		warmStartSeaTime: handOverSeaTime - spinUp,
		handOverSeaTime,
		setPeakSeaTime
	};
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/SideFeed.ts
/**
* The side feed (the wave-sizes spec): the window's open side edges let a
* directionally spread sea's energy drift out, and nothing entered from the
* neighbouring coast, so a 160 m window lost up to a third of its wave height
* within 150 m. The outer `width` m of each side now relax toward the incoming
* sea, shoaled and refracted over the bed as the warm start fills it, from the
* offshore zone's inner edge while the shoaled Hs stays under `breakingShare`
* of the depth and the bed no steeper than `maxSlope` (where the warm start's
* mild-slope transform holds: a reef's steep edge reflects), fading over
* `fade` m. The share is the warm start's depth-limited cap (McCowan γ): the
* feed reaches where the sets break, because a big day's outer surf zone is
* hundreds of metres wide and stopping outside it (at 0.45 h) let it drain
* (the user's decision, 2026-09-28).
*/
/** The warm start's depth-limited cap on the fed sea (McCowan γ). */
const GAMMA = .78;
const SIDE_FEED = {
	width: 30,
	breakingShare: GAMMA,
	fade: 40,
	maxSlope: .06
};
var SideFeed = class {
	solver;
	sea;
	weights;
	/** Sea time at solver time 0, s (a handed-over sea takes the donor's, as the offshore zone does). */
	timeOffset;
	referenceZ;
	count;
	omega;
	strips = [];
	/** Per solver cell: which strip, row and column it is (strip + 2·(column + columns·row)), or −1. */
	where;
	/** cos ωt and sin ωt of each component at the cached sea time. */
	timeCos;
	timeSin;
	cachedSeaTime = NaN;
	constructor(solver, sea, options) {
		this.solver = solver;
		this.sea = sea;
		this.referenceZ = options.referenceZ;
		this.timeOffset = options.timeOffset;
		this.count = sea.components.length;
		this.omega = Float64Array.from(sea.components, (component) => component.omega);
		this.timeCos = new Float64Array(this.count);
		this.timeSin = new Float64Array(this.count);
		this.weights = new Float64Array(solver.nx * solver.nz);
		this.where = new Int32Array(solver.nx * solver.nz);
		this.build();
	}
	/** The window slid along shore: the strips stay at its edges, over the bed now under them. */
	afterShift() {
		this.build();
	}
	/** How many strip cells the device steps, and the sea's components. */
	deviceShape() {
		let slots = 0;
		for (const weight of this.weights) if (weight > 0) slots += 1;
		return {
			slots,
			components: this.count
		};
	}
	target(_x, _z, t, out, index) {
		const where = index >= 0 ? this.where[index] : -1;
		if (where < 0) {
			out.eta = 0;
			out.qx = 0;
			out.qz = 0;
			return;
		}
		const seaTime = t + this.timeOffset;
		if (seaTime !== this.cachedSeaTime) {
			for (let c = 0; c < this.count; c += 1) {
				this.timeCos[c] = Math.cos(this.omega[c] * seaTime);
				this.timeSin[c] = Math.sin(this.omega[c] * seaTime);
			}
			this.cachedSeaTime = seaTime;
		}
		const strip = this.strips[where % 2];
		const cell = (where - where % 2) / 2;
		const column = cell % strip.columns;
		const rowBase = (cell - column) / strip.columns * this.count * 4;
		const columnBase = column * this.count * 2;
		const { rowTable, columnTable } = strip;
		let eta = 0;
		let qx = 0;
		let qz = 0;
		for (let c = 0; c < this.count; c += 1) {
			const r = rowBase + c * 4;
			const k = columnBase + c * 2;
			const real = rowTable[r] * columnTable[k] - rowTable[r + 1] * columnTable[k + 1];
			const imaginary = rowTable[r] * columnTable[k + 1] + rowTable[r + 1] * columnTable[k];
			const value = real * this.timeCos[c] + imaginary * this.timeSin[c];
			eta += value;
			qx += rowTable[r + 2] * value;
			qz += rowTable[r + 3] * value;
		}
		out.eta = eta;
		out.qx = qx;
		out.qz = qz;
	}
	/** The strips as flat tables for the device (GpuBoussinesq): every weighted cell, and each strip's factors. */
	deviceTables() {
		const rowOffsets = [];
		const columnOffsets = [];
		let rowsLength = 0;
		let columnsLength = 0;
		for (const strip of this.strips) {
			rowOffsets.push(rowsLength);
			columnOffsets.push(columnsLength);
			rowsLength += strip.rowTable.length;
			columnsLength += strip.columnTable.length;
		}
		const rows = new Float64Array(rowsLength);
		const columns = new Float64Array(columnsLength);
		this.strips.forEach((strip, s) => {
			rows.set(strip.rowTable, rowOffsets[s]);
			columns.set(strip.columnTable, columnOffsets[s]);
		});
		const slots = [];
		for (let i = 0; i < this.weights.length; i += 1) {
			if (!(this.weights[i] > 0)) continue;
			const where = this.where[i];
			const s = where % 2;
			const strip = this.strips[s];
			const cell = (where - s) / 2;
			const column = cell % strip.columns;
			const row = (cell - column) / strip.columns;
			slots.push(i, this.weights[i], rowOffsets[s] + row * this.count * 4, columnOffsets[s] + column * this.count * 2);
		}
		return {
			components: this.count,
			omega: this.omega,
			slots: Float64Array.from(slots),
			rows,
			columns
		};
	}
	build() {
		const { solver, count } = this;
		const { nx, dx } = solver;
		this.weights.fill(0);
		this.where.fill(-1);
		const width = Math.min(SIDE_FEED.width, nx * dx / 4);
		const columns = Math.ceil(width / dx - 1e-9);
		const components = this.sea.components;
		this.strips = [0, nx - 1].map((edge, s) => {
			const step = s === 0 ? 1 : -1;
			const rows = [];
			let end = Infinity;
			let previous;
			transformedSea(solver, this.sea, this.referenceZ, edge, GAMMA, (iz, row) => {
				const z = solver.zCenters[iz];
				if (z <= this.referenceZ || end < Infinity) return;
				const slope = previous ? (previous.depth - row.depth) / (z - previous.z) : 0;
				previous = {
					z,
					depth: row.depth
				};
				if (!(row.depth > 0) || row.hs >= SIDE_FEED.breakingShare * row.depth || slope > SIDE_FEED.maxSlope) {
					end = z;
					return;
				}
				const values = new Float64Array(count * 4);
				for (let c = 0; c < count; c += 1) {
					const amplitude = row.scale * row.amplitude[c];
					values[c * 4] = amplitude * Math.cos(row.phase[c]);
					values[c * 4 + 1] = amplitude * Math.sin(row.phase[c]);
					values[c * 4 + 2] = row.speedX[c];
					values[c * 4 + 3] = row.speedZ[c];
				}
				rows.push({
					iz,
					values
				});
			});
			const firstRow = rows.length ? rows[0].iz : 0;
			const rowTable = new Float64Array(rows.length * count * 4);
			rows.forEach((row, r) => rowTable.set(row.values, r * count * 4));
			const columnTable = new Float64Array(columns * count * 2);
			for (let j = 0; j < columns; j += 1) {
				const offset = solver.xCenters[edge + step * j] - solver.xCenters[edge];
				for (let c = 0; c < count; c += 1) {
					columnTable[(j * count + c) * 2] = Math.cos(components[c].kx * offset);
					columnTable[(j * count + c) * 2 + 1] = Math.sin(components[c].kx * offset);
				}
			}
			rows.forEach((row, r) => {
				const z = solver.zCenters[row.iz];
				const fade = end === Infinity ? 1 : smoothstep$1(end, end - SIDE_FEED.fade, z);
				for (let j = 0; j < columns; j += 1) {
					const weight = relaxationRamp(1 - (j + .5) * dx / width) * fade;
					if (!(weight > 0)) continue;
					const i = row.iz * nx + edge + step * j;
					this.weights[i] = weight;
					this.where[i] = s + 2 * (j + columns * r);
				}
			});
			return {
				edge,
				step,
				columns,
				firstRow,
				rows: rows.length,
				rowTable,
				columnTable
			};
		});
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/BreakingFront.ts
/** Crests in neighbouring columns this many rows apart in z are one front (provisional). */
const LINK_ROWS = 3;
/** A crest this close in z to last step's in its column is the same point, m (provisional: 20 m/s × 0.1 s), plus a row, its cell's jump. */
const MATCH_REACH = 2;
/**
* A crest on its way in, not yet breaking, is the same one this close, m: a long swell's crest is broad and flat on
* the ramp, so its highest cell jumps metres between steps, while crests there stand a wavelength (100 m and more) apart
* (provisional).
*/
const TRACK_REACH = 10;
/** A point unseen this long is gone, s. */
const HOLD = .5;
/** A point's crest speed is the mean of its crest's `crestMotion` speeds over about this long, s (PR 5; provisional). */
const PACE_SECONDS = .1;
/**
* Neighbours whose joins differ by more than this per metre between them are two waves, not a peel: 1 s/m is a peel
* under 1 m/s, a crest running almost straight up the contours (θ > 79° at c ≈ 5 m/s), where Padang Padang peels at
* 0.1–0.2 s/m and consecutive waves join most of a 16 s period apart (the advisor, 2026-09-30).
*/
const SPLIT = 1;
/** A crest first seen this far shoreward of the wedge's foot has no foot height to size it by, m (provisional). */
const FOOT_BAND = 1;
/** Kennedy's fresh onset for Padang Padang, η_t over √(g d): the swell table's own condition (a diagnostic here). */
const FRESH = .65;
/**
* The crest jump's reach in wave heights, as the advisor first put it (about 1.5 H or 10 m, whichever is smaller,
* 2026-10-01): recorded beside the metres (`BreakingFront.waveJumps`), not used, since the Reef's maxima jump 2.8–10.8 H.
*/
const JUMP_WAVES = 1.5;
/**
* With `clockLink`: the farthest a front's head may be from the chain end it continues, m (provisional: the crest jump's
* reach; the advisor, 2026-10-03).
*/
const CLOCK_REACH = 10;
/**
* With `clockLink`: the most the two joins may differ per metre between them, s/m (provisional): twice the 0.083 s/m at
* which the fronts' own joins peeled on Padang Padang's base before the jump rule (the padangFrontGap runs; the medians
* on #105's are 0.086–0.090). That is 6 times under SPLIT, so a peel links and a split wave does not: of the probe's 364
* true splits on Medium, 2 passed it at some frame, and 0 of 4 on Small.
*/
const CLOCK_SLOPE = .166;
/** With `clockLink`: how many empty columns a head may bridge to the chain end it continues (the advisor, 2026-10-03: one-column gaps). */
const CLOCK_BRIDGE = 1;
/**
* The breaking front as lines of points (swept-barrel-build.md, "Front line"; Thürey et al. 2007).
*
* - **The join, by depth** (the advisor, 2026-09-30). Each crest is followed from where it crosses the wedge's foot
*   (the timing's h0), and sized by its highest over a band of depth nearer the break (the timing's), before anything
*   near it breaks. It joins where it crosses the depth at which the solver first breaks swell that size fresh (the 1D runs,
*   `OnsetTiming.joinDepth`), at the moment it crosses, provided the solver breaks its segment before it reaches the
*   depth where its lip throws, where the Navier–Stokes wave its foot height goes vertical (`OnsetTiming.throwDepth`),
*   at the latest in the step it gets there. A crest reads its own place, not its rise: once a neighbour
*   breaks, the eddy viscosity damps a column's rise (fresh crossings came ~2 s late, or never) and its inherited age
*   is the event's, so neither can time a peel. Here the peel is each column's crest reaching its breaking depth in
*   turn, from the bed.
* - **On the front** a crest stays while its segment breaks. Crests in neighbouring columns within LINK_ROWS rows in
*   z link, a column's own never do (two crests in a column are two fronts, an empty column splits one), and
*   neighbours whose joins differ by more than SPLIT per metre are two waves: two fronts, smoothed apart. A point
*   matched to last step's in its column keeps its ID, join and clock.
* - **A spot's own rules** (`FrontOptions`; the Reef's): a sized crest follows its highest cell as it jumps forward
*   over a ledge, and may join a little past its throw depth when the solver breaks it there.
* - **The clock link** (`FrontOptions.clockLink`, off): after the links above, a point left at the head of a new chain
*   continues the nearest chain end up to a column further back, within CLOCK_REACH m, when their joins agree within
*   CLOCK_SLOPE per metre. It only joins chains the rules above left apart: every link they make stands, the points stay
*   the switch-off front's, and with the switch off none of this runs.
*
* Columns go in order, with no randomness, and only + − × ÷ and √, for online determinism.
*/
var BreakingFront = class {
	timing;
	options;
	/** This step's points, by front (in order of their −x ends) and σ. */
	points = [];
	/**
	* With `clockLink`, after a step whose clock links joined fronts: the same points as the chains list them before the
	* joins, the order the front lists them in without the switch. The next step matches crests to points in this order, so
	* a crest as far from two points in its column takes the one it would take without the switch.
	*/
	order;
	/** Points unseen since an earlier step, kept HOLD s for a crest that flickers. */
	held = [];
	nextId = 0;
	nextFront = 0;
	tracks = [];
	/** Links refused since the start because the two crests joined too far apart to be one wave (a diagnostic). */
	splits = 0;
	/**
	* Crests followed from the foot that joined, crossed their join depth without breaking, and were lost before either;
	* and crests first seen past the foot (reformed and broken water), never sized (diagnostics).
	*/
	joins = 0;
	unbroken = 0;
	lost = 0;
	unsized = 0;
	/**
	* Crest jumps (diagnostics): with `jumpReach`, the sized crests that continued as a crest ahead of the one nearest them;
	* without, the new crests first seen ahead of a sized one in its column within TRACK_REACH, which the reach would give
	* it. `waveJumps`: those within JUMP_WAVES of the wave's heights. `latePasses`: joins past the throw depth (`joinPast`).
	*/
	jumps = 0;
	waveJumps = 0;
	latePasses = 0;
	/** Steps a point on its pace (jet or not) ran on at it with no crest in reach (PR 5; a diagnostic). */
	coasted = 0;
	/** With `ownOnset`: jumped crests that crossed their throw depth before their own fresh onset came (a diagnostic). */
	unrisen = 0;
	/**
	* With `clockLink`, counted a step as `splits` is (diagnostics): the heads that continued a chain end in the column before,
	* each past the 3-row reach (an end within it that the 1 s/m split refused, the clock refuses too), and those that
	* continued one across a column in which neither chain had a point (another front's may stand there).
	*/
	clockLinks = 0;
	bridges = 0;
	linkReach;
	matchReach;
	/**
	* `cell`: the rows' spacing where fronts form, m; `timing`: the wedge’s foot, the join and throw depths (sliceClock);
	* `options`: the spot's rules beyond Padang Padang's (none there).
	*/
	constructor(cell, timing, options = {}) {
		this.timing = timing;
		this.options = options;
		this.linkReach = LINK_ROWS * cell;
		this.matchReach = MATCH_REACH + cell;
	}
	update(samples, count, time) {
		const previous = [...this.order ?? this.points, ...this.held];
		const pointsOf = byColumn(previous);
		const tracksOf = byColumn(this.tracks);
		const matched = /* @__PURE__ */ new Set();
		const followed = /* @__PURE__ */ new Set();
		const points = [];
		const tracks = [];
		const { h0 } = this.timing;
		const jetCrests = this.keptCrests(previous, samples, count, time);
		const plainOf = jetCrests ? byColumn(previous.filter((point) => !runsOnPace(point))) : pointsOf;
		const jumped = /* @__PURE__ */ new Set();
		const leading = this.options.jumpReach === void 0 ? void 0 : this.leadingCrests(samples, count, tracksOf, plainOf, jetCrests, followed, jumped);
		for (let k = 0; k < count; k += 1) {
			const s = samples[k];
			const holder = jetCrests?.get(s);
			if (holder && !matched.has(holder)) {
				matched.add(holder);
				const next = {
					...holder,
					sigma: 0,
					x: s.x,
					z: holder.z + holder.jetPace * (time - holder.seen),
					b: s.b,
					height: s.eta,
					crestDepth: s.depth,
					seen: time,
					crestZ: s.z
				};
				recordOwnThrow(next, holder, s, time, holder.crestZ);
				points.push(next);
				continue;
			}
			const point = this.nearest(plainOf.get(s.column), matched, s.z);
			if (point) {
				if (!(s.strength > 0)) continue;
				matched.add(point);
				const fresh = point.fresh ?? (s.rise >= FRESH ? s.depth : null);
				const crestSpeed = s.speed > 0 ? point.crestSpeed === void 0 ? s.speed : point.crestSpeed + (s.speed - point.crestSpeed) * Math.min(1, (time - point.seen) / PACE_SECONDS) : point.crestSpeed;
				const next = {
					...point,
					sigma: 0,
					x: s.x,
					z: s.z,
					b: s.b,
					height: s.eta,
					crestDepth: s.depth,
					seen: time,
					fresh,
					...crestSpeed === void 0 ? {} : { crestSpeed }
				};
				recordOwnThrow(next, point, s, time, point.z);
				points.push(next);
				continue;
			}
			const track = leading?.get(s) ?? this.nearest(tracksOf.get(s.column), followed, s.z, TRACK_REACH);
			if (!track) {
				if (s.depth <= h0) {
					if (!leading) this.countJump(tracksOf.get(s.column), s);
					const footHeight = s.depth >= h0 - FOOT_BAND ? s.eta : null;
					if (footHeight === null) this.unsized += 1;
					const refHeight = footHeight !== null && s.depth <= this.timing.band[0] ? s.eta : null;
					tracks.push({
						column: s.column,
						z: s.z,
						footHeight,
						refHeight,
						depth: s.depth,
						seen: time,
						crossed: null,
						fresh: s.rise >= FRESH ? s.depth : null
					});
				}
				continue;
			}
			followed.add(track);
			const next = {
				...track,
				z: s.z,
				depth: s.depth,
				seen: time,
				fresh: track.fresh ?? (s.rise >= FRESH ? s.depth : null)
			};
			const jumpedNow = jumped.has(track);
			if (jumpedNow) next.jumped = (track.jumped ?? 0) + 1;
			const ownOnset = this.options.ownOnset === true && next.jumped !== void 0;
			if (ownOnset && jumpedNow) next.risen = false;
			if (ownOnset && s.rise >= FRESH) next.risen = true;
			const [deeper, shallower] = this.timing.band;
			if (track.footHeight !== null && s.depth <= deeper && (s.depth >= shallower || next.refHeight === null)) next.refHeight = Math.max(next.refHeight ?? s.eta, s.eta);
			if (next.footHeight !== null && next.refHeight !== null && s.depth < shallower) {
				const joinDepth = this.timing.joinDepth(next.refHeight);
				const throwDepth = Math.min(joinDepth, this.timing.throwDepth(next.footHeight));
				if (next.crossed === null) {
					const joinF = crossingFraction(track.depth, s.depth, joinDepth);
					if (joinF !== null) next.crossed = ownOnset && jumpedNow ? time : track.seen + joinF * (time - track.seen);
				}
				const { joinPast } = this.options;
				if (joinPast !== void 0 && next.passedZ === void 0 && s.depth <= throwDepth) {
					const passF = crossingFraction(track.depth, s.depth, throwDepth) ?? 1;
					next.passedZ = track.z + passF * (s.z - track.z);
					next.passedWave = s.wave;
				}
				const late = joinPast !== void 0 && next.passedZ !== void 0 && s.z - next.passedZ <= joinPast * next.passedWave;
				const own = ownOnset && next.risen === true;
				if (next.crossed !== null && s.strength > 0 && (!ownOnset || own) && (track.depth > throwDepth || late || own && jumpedNow)) {
					this.joins += 1;
					if (track.depth <= throwDepth) this.latePasses += 1;
					const throwF = track.depth <= throwDepth || ownOnset && jumpedNow && s.depth <= throwDepth ? 1 : crossingFraction(track.depth, s.depth, throwDepth);
					points.push({
						id: this.nextId++,
						front: -1,
						column: s.column,
						sigma: 0,
						x: s.x,
						z: s.z,
						b: s.b,
						height: s.eta,
						joined: ownOnset ? time : next.crossed,
						depth: joinDepth,
						throwDepth,
						crestDepth: s.depth,
						thrown: throwF === null ? null : track.seen + throwF * (time - track.seen),
						throwZ: throwF === null ? null : track.z + throwF * (s.z - track.z),
						footHeight: next.footHeight,
						footDepth: this.timing.h0,
						broke: time,
						tau: this.timing.earliest,
						seen: time,
						fresh: next.fresh,
						...next.jumped ? { jumped: next.jumped } : {}
					});
					continue;
				}
				if (next.crossed !== null && track.depth <= throwDepth && !late) {
					this.unbroken += 1;
					if (ownOnset && track.risen === false) this.unrisen += 1;
					continue;
				}
			}
			tracks.push(next);
		}
		let coasting = false;
		for (const point of previous) {
			if (matched.has(point) || !runsOnPace(point)) continue;
			matched.add(point);
			this.coasted += 1;
			coasting = true;
			points.push({
				...point,
				sigma: 0,
				z: point.z + point.jetPace * (time - point.seen),
				seen: time,
				crestZ: void 0
			});
		}
		if (coasting) points.sort((a, b) => a.column - b.column || a.z - b.z);
		const linked = this.link(points);
		this.points = linked.fronts;
		this.order = linked.order;
		this.held = previous.filter((old) => !matched.has(old) && time - old.seen <= HOLD);
		const kept = this.tracks.filter((old) => !followed.has(old) && time - old.seen <= HOLD);
		for (const old of this.tracks) if (!followed.has(old) && !kept.includes(old) && old.footHeight !== null) this.lost += 1;
		this.tracks = [...tracks, ...kept];
	}
	/**
	* With `jumpReach`: each sized crest's continuation, the furthest crest in its column from a match reach behind it to
	* the jump reach ahead, claimed before the other crests match; a crest beside a front point is the point's, and a
	* crest a point on its pace has kept (`kept`, from `keptCrests`, PR 5: jet or not, from its throw until its slice has
	* faded) is its: `pointsOf` holds the points that match by z, not those on their pace, which claim theirs apart. A
	* jump when it is not the crest nearest it.
	*/
	leadingCrests(samples, count, tracksOf, pointsOf, kept, followed, jumped) {
		const leading = /* @__PURE__ */ new Map();
		const reach = this.options.jumpReach;
		let start = 0;
		while (start < count) {
			const column = samples[start].column;
			let end = start;
			while (end < count && samples[end].column === column) end += 1;
			const points = pointsOf.get(column) ?? [];
			for (const track of tracksOf.get(column) ?? []) {
				if (track.footHeight === null) continue;
				let furthest;
				let nearest;
				for (let k = start; k < end; k += 1) {
					const s = samples[k];
					const ahead = s.z - track.z;
					if (ahead < -this.matchReach || ahead > reach || leading.has(s) || kept?.has(s)) continue;
					if (points.some((point) => Math.abs(point.z - s.z) < this.matchReach)) continue;
					if (!furthest || s.z > furthest.z) furthest = s;
					if (!nearest || Math.abs(ahead) < Math.abs(nearest.z - track.z)) nearest = s;
				}
				if (!furthest) continue;
				if (furthest !== nearest) {
					this.jumps += 1;
					jumped.add(track);
					if (furthest.z - track.z <= JUMP_WAVES * furthest.wave) this.waveJumps += 1;
				}
				leading.set(furthest, track);
				followed.add(track);
			}
			start = end;
		}
		return leading;
	}
	/** Without `jumpReach`: counts a new crest first seen ahead of a sized one in its column within TRACK_REACH. */
	countJump(tracks, s) {
		for (const sized of tracks ?? []) {
			const ahead = s.z - sized.z;
			if (sized.footHeight === null || !(ahead > 0) || ahead > TRACK_REACH) continue;
			this.jumps += 1;
			if (ahead <= JUMP_WAVES * s.wave) this.waveJumps += 1;
			return;
		}
	}
	/**
	* The swept barrel's crash (PR 5; the advisor, 2026-10-01 and 2026-10-03). Once its lip is thrown, the depth-averaged
	* solver can't hold the overturn: the crest's highest cell leaps 3–8 m as the face turns into a bore, so it no longer
	* says where the plunging wave is, and following it made the drawing jump and the links break. So from its throw until
	* its slice has faded (`jetUntil`) a point, jet or not, runs on its own pace (`jetPace`): its z advances from where it
	* was last seen, and its links are tested there. It still claims its column's crest nearest that z within the match
	* reach plus the throw's window (`jetWindow`, #86's 2 H), at most TRACK_REACH (waves stand about 100 m apart), so no
	* second point forms on its wave in the column, but it doesn't take the crest's z (`crestZ`). Each such point picks its
	* crest here, before the others match; two wanting one crest: the nearer keeps it. With none in reach it runs on all
	* the same (`coasted`). Past `jetUntil` it goes back to the ordinary match. Points before their throw are matched as
	* before; none run on a pace without the crash (undefined then).
	*/
	keptCrests(previous, samples, count, time) {
		let kept;
		let samplesOf;
		for (const point of previous) {
			if (!runsOnPace(point)) continue;
			samplesOf ??= byColumn(samples.slice(0, count));
			const z = point.z + point.jetPace * (time - point.seen);
			const reach = Math.min(TRACK_REACH, this.matchReach + Math.max(0, point.jetWindow ?? 0));
			let best;
			for (const s of samplesOf.get(point.column) ?? []) {
				if (!(Math.abs(s.z - z) < reach)) continue;
				if (!best || Math.abs(s.z - z) < Math.abs(best.z - z)) best = s;
			}
			if (!best) continue;
			kept ??= /* @__PURE__ */ new Map();
			const other = kept.get(best);
			if (!other || Math.abs(best.z - z) < Math.abs(best.z - (other.z + other.jetPace * (time - other.seen)))) kept.set(best, point);
		}
		return kept;
	}
	/** The unclaimed one of `candidates` nearest `z` within the match reach. */
	nearest(candidates, claimed, z, reach = this.matchReach) {
		let best;
		for (const candidate of candidates ?? []) {
			if (claimed.has(candidate) || !(Math.abs(candidate.z - z) < reach)) continue;
			if (!best || Math.abs(candidate.z - z) < Math.abs(best.z - z)) best = candidate;
		}
		return best;
	}
	/**
	* Chains the points column to column into fronts, each numbered as its first matched point's was; with `clockLink`, when
	* its links joined chains, also the points as the chains list them before the joins (`order`).
	*/
	link(points) {
		const chains = [];
		const clock = this.options.clockLink === true ? {
			parents: /* @__PURE__ */ new Map(),
			continued: /* @__PURE__ */ new Set()
		} : void 0;
		let start = 0;
		while (start < points.length) {
			let end = start;
			while (end < points.length && points[end].column === points[start].column) end += 1;
			const column = points[start].column;
			const before = chains.filter((chain) => chain.at(-1).column === column - 1);
			const heads = clock ? [] : void 0;
			for (let k = start; k < end; k += 1) {
				const point = points[k];
				let best;
				for (const chain of before) {
					const tail = chain.at(-1);
					if (tail.column !== column - 1 || !(Math.abs(tail.z - point.z) < this.linkReach)) continue;
					const dx = point.x - tail.x;
					const dz = point.z - tail.z;
					if (Math.abs(point.joined - tail.joined) > SPLIT * Math.sqrt(dx * dx + dz * dz)) {
						this.splits += 1;
						continue;
					}
					if (!best || Math.abs(tail.z - point.z) < Math.abs(best.at(-1).z - point.z)) best = chain;
				}
				if (best) {
					const tail = best.at(-1);
					const dx = point.x - tail.x;
					const dz = point.z - tail.z;
					point.sigma = tail.sigma + Math.sqrt(dx * dx + dz * dz);
					best.push(point);
				} else {
					const head = [point];
					chains.push(head);
					heads?.push(head);
				}
			}
			if (clock && heads && heads.length > 0) this.linkByClock(chains, heads, column, clock.parents, clock.continued);
			start = end;
		}
		const order = clock && clock.parents.size > 0 ? chains.flat() : void 0;
		const fronts = clock && order ? joinChains(chains, clock.parents) : chains;
		const claimed = /* @__PURE__ */ new Set();
		for (const chain of fronts) {
			const front = chain.find((point) => point.front >= 0 && !claimed.has(point.front))?.front ?? this.nextFront++;
			claimed.add(front);
			for (const point of chain) point.front = front;
		}
		return {
			fronts: fronts.flat(),
			order
		};
	}
	/**
	* With `clockLink`, after a column's links: each of its heads (points no neighbour took) in turn, in the column's order
	* (z), continues the nearest end of a chain that stops in the column before or CLOCK_BRIDGE columns earlier and is not
	* continued yet, if that end lies within CLOCK_REACH of the head and its join within CLOCK_SLOPE per metre between them
	* of the head's, both bounds inclusive (the advisor's "within 10 m" and "≤ 0.166 s/m × the gap"). It is the 3-row
	* link's own order: with two heads in reach of one end, the first in z takes it, even when the other is nearer (pairing
	* the nearest first instead, synthetic crest lines had a third more clock links crossing one another, and fewer links). The
	* head's chain is recorded under the one it continues (`parents`); the chains themselves, and so the links above, are
	* left as they are.
	*/
	linkByClock(chains, heads, column, parents, continued) {
		const ends = chains.filter((chain) => {
			const last = chain.at(-1).column;
			return last < column && last >= column - 1 - CLOCK_BRIDGE && !continued.has(chain);
		});
		for (const head of heads) {
			const point = head[0];
			let best;
			let nearest = Infinity;
			for (const chain of ends) {
				if (continued.has(chain)) continue;
				const tail = chain.at(-1);
				const dx = point.x - tail.x;
				const dz = point.z - tail.z;
				const gap = Math.sqrt(dx * dx + dz * dz);
				if (gap <= CLOCK_REACH && Math.abs(point.joined - tail.joined) <= CLOCK_SLOPE * gap && gap < nearest) {
					best = chain;
					nearest = gap;
				}
			}
			if (!best) continue;
			parents.set(head, best);
			continued.add(best);
			if (best.at(-1).column === column - 1) this.clockLinks += 1;
			else this.bridges += 1;
		}
	}
	exportState() {
		return {
			nextId: this.nextId,
			nextFront: this.nextFront,
			points: this.points.map((p) => ({ ...p })),
			held: this.held.map((p) => ({ ...p })),
			tracks: this.tracks.map((t) => ({ ...t })),
			...this.order ? { order: this.order.map((p) => p.id) } : {}
		};
	}
	importState(state) {
		const points = state.points.map((p) => ({ ...p }));
		const byId = new Map(points.map((p) => [p.id, p]));
		const order = state.order?.map((id) => {
			const point = byId.get(id);
			if (!point) throw new Error(`A front state whose order names point ${id}, which it does not hold`);
			return point;
		});
		if (order && (order.length !== points.length || new Set(order).size !== points.length)) throw new Error(`A front state whose order does not list each of its ${points.length} points once`);
		this.nextId = state.nextId;
		this.nextFront = state.nextFront;
		this.points = points;
		this.order = order;
		this.held = state.held.map((p) => ({ ...p }));
		this.tracks = (state.tracks ?? []).map((t) => ({ ...t }));
	}
};
/**
* `chains` with each chain that continues another (`parents`) appended to the front it continues, as one line, its points'
* σ carried on straight across the gap. Chains go in the order they began, so a parent comes before its child, and a
* chain end is continued once, so a front's last point is always the end its next chain continues.
*/
function joinChains(chains, parents) {
	const fronts = [];
	const frontOf = /* @__PURE__ */ new Map();
	for (const chain of chains) {
		const parent = parents.get(chain);
		if (!parent) {
			const front = [...chain];
			fronts.push(front);
			frontOf.set(chain, front);
			continue;
		}
		const front = frontOf.get(parent);
		const tail = front.at(-1);
		const dx = chain[0].x - tail.x;
		const dz = chain[0].z - tail.z;
		const offset = tail.sigma + Math.sqrt(dx * dx + dz * dz);
		for (const point of chain) {
			point.sigma += offset;
			front.push(point);
		}
		frontOf.set(chain, front);
	}
	return fronts;
}
/** Records the crest's own throw-depth crossing, independently of the point's paced position. */
function recordOwnThrow(next, previous, sample, time, previousCrestZ) {
	if (previous.thrown !== null || sample.depth > previous.throwDepth) return;
	if (previousCrestZ === void 0) {
		next.thrown = time;
		next.throwZ = sample.z;
		return;
	}
	const fraction = crossingFraction(previous.crestDepth, sample.depth, previous.throwDepth);
	next.thrown = previous.seen + fraction * (time - previous.seen);
	next.throwZ = previousCrestZ + fraction * (sample.z - previousCrestZ);
}
/** How far between a crest at `fromDepth` and at `depth` it crossed `at`, 0–1, linear in depth; null if it has not. */
function crossingFraction(fromDepth, depth, at) {
	if (depth > at) return null;
	return fromDepth > depth ? Math.min(1, Math.max(0, (fromDepth - at) / (fromDepth - depth))) : 1;
}
/**
* Whether a point runs on its own pace (PR 5; `keptCrests`): its pace is set at its throw, jet or not, and its slice
* hasn't faded (its clock short of `jetUntil`), crashed or not (the advisor, 2026-10-03).
*/
function runsOnPace(point) {
	return point.jetPace !== void 0 && point.jetUntil !== void 0 && point.tau < point.jetUntil;
}
function byColumn(items) {
	const map = /* @__PURE__ */ new Map();
	for (const item of items) {
		const list = map.get(item.column);
		if (list) list.push(item);
		else map.set(item.column, [item]);
	}
	return map;
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/sliceClock.ts
/**
* The slice clock's constants (the advisor, 2026-09-30):
* - `smoothing`, m: the onsets are smoothed along the front over a 2 m standard deviation, about a quarter of
*   Padang Padang's open curl (V_p ≈ 9–10 m/s over the 0.82–0.85 s open phase of round 6's run: 7–8 m);
* - `bunched`, m²: below this weighted variance of σ (two points under about 0.6 m apart; two a column apart are
*   0.25), a fit's slope is meaningless and the mean is used;
* - `earliest`, √(h0/g): the library's first frame before the face goes vertical (its runs output from 3 before),
*   the earliest a slice's clock reads. All provisional.
*/
const CLOCK = {
	smoothing: 2,
	bunched: .1,
	earliest: -3
};
/** Padang Padang's tables (round 6's transect: the 7 m foot, 1:19 along the path to the 1.25 m flat). */
const PADANG_ONSET = {
	h0: 7,
	band: [6, 5],
	join: [
		{
			period: 14,
			rows: [
				[1.2, 2.29],
				[1.75, 2.82],
				[2.29, 3.24],
				[2.74, 3.61],
				[3.15, 3.92]
			]
		},
		{
			period: 16,
			rows: [
				[1.19, 2.61],
				[1.6, 3.18],
				[1.84, 3.66],
				[2.21, 4.13],
				[2.68, 4.55]
			]
		},
		{
			period: 17,
			rows: [
				[1.29, 2.61],
				[1.74, 3.13],
				[2.16, 3.5],
				[2.51, 3.82],
				[2.82, 3.92]
			]
		},
		{
			period: 18,
			rows: [
				[1.29, 2.55],
				[1.82, 2.92],
				[2.37, 3.34],
				[2.86, 3.71],
				[3.3, 3.82]
			]
		}
	],
	throwDepth: {
		intercept: 1.56,
		slope: .56,
		heights: [.99, 2.5]
	}
};
/** Linear in x between the table's rows, clamped at its ends: never extrapolated. */
function interpolate(table, x) {
	if (x <= table[0][0]) return table[0][1];
	for (let k = 1; k < table.length; k += 1) {
		const [x1, y1] = table[k];
		if (x <= x1) {
			const [x0, y0] = table[k - 1];
			return y0 + (x - x0) / (x1 - x0) * (y1 - y0);
		}
	}
	return table[table.length - 1][1];
}
/**
* The onset timing for a bed whose slope rises from `h0` m (the library cases' foot depth, at the tide) under swell of
* `period` s, from its transect's `tables` (Padang Padang's unless given): the join depth (linear in height, then
* between the two nearest periods, clamped) and the throw depth (linear in foot height, clamped), both scaled from the
* tables' foot to h0 by depth (about ±7 % for a ±0.5 m tide). `lagged` throws where the Navier–Stokes wave goes
* vertical (the default); unlagged throws at the join (PR 3's loft shows both).
*/
function onsetTiming(h0, period, lagged = true, tables = PADANG_ONSET) {
	const unit = Math.sqrt(h0 / GRAVITY$1);
	const scale = h0 / tables.h0;
	const { join, band, throwDepth } = tables;
	const [lowest, highest] = throwDepth.heights;
	const joinAt = (measured) => {
		const height = measured / scale;
		const first = join[0];
		const last = join[join.length - 1];
		if (period <= first.period) return interpolate(first.rows, height);
		if (period >= last.period) return interpolate(last.rows, height);
		const k = join.findIndex((entry) => entry.period >= period);
		const [below, above] = [join[k - 1], join[k]];
		const t = (period - below.period) / (above.period - below.period);
		return interpolate(below.rows, height) + t * (interpolate(above.rows, height) - interpolate(below.rows, height));
	};
	return {
		h0,
		band: [band[0] * scale, band[1] * scale],
		joinDepth: (height) => joinAt(height) * scale,
		throwDepth: (footHeight) => {
			const depth = (throwDepth.intercept + throwDepth.slope * Math.min(highest, Math.max(lowest, footHeight / scale))) * scale;
			return tables.floor === void 0 ? depth : Math.max(depth, tables.floor + h0 - tables.h0);
		},
		lagged,
		earliest: CLOCK.earliest * unit
	};
}
/** The biweight kernel's radius: its standard deviation is radius/√7. */
const RADIUS = CLOCK.smoothing * Math.sqrt(7);
/**
* Sets every front point's clock at `time` s: τ, the time since its lip threw (swept-barrel-build.md, "Smooth clock";
* the advisor's rulings, 2026-09-30). Returns how many clocks paused this step rather than run back.
*
* - **The throw.** A point's lip throws when its crest crosses its throw depth, where the Navier–Stokes wave its size
*   goes vertical (BreakingFront, `timing.throwDepth`), and never before the solver broke it; unlagged, when it joined.
*   Till then τ is negative, the library's steepening frames from `timing.earliest`, its throw foreseen at the pace
*   its crest has come shoreward since it joined. So the front's newest end reads the earliest frames, where the loft
*   blends into the height field, with no taper.
* - **Smoothing.** Along each front, a point's throw time is read from a local line through its neighbours',
*   weighted by a biweight (1 − u²)² of 2 m standard deviation in σ. That turns the solver's grouped onsets (a
*   staircase of small close-outs) into a ramp at their mean gradient, the physical peel, and reproduces a steady peel
*   exactly, to its leading edge, where a weighted mean would sit 0.31 of the radius behind. One point uses its own,
*   and points bunched within about half a metre their weighted mean. The fit is clamped to the window's throw
*   times, so it never extrapolates.
* - **Causality.** A point's τ starts at the earliest frame (BreakingFront), and never falls: when a later neighbour
*   moves the fit, the lip pauses rather than retracts. Frequent pauses would mean the onsets are still noisy at the 2 m scale.
*
* Only + − × ÷ and loops over points in σ order, for online determinism.
*/
function advanceClocks(points, time, timing) {
	let pauses = 0;
	let start = 0;
	while (start < points.length) {
		let end = start + 1;
		while (end < points.length && points[end].front === points[start].front) end += 1;
		for (let k = start; k < end; k += 1) {
			const point = points[k];
			const shown = Math.max(timing.earliest, time - fittedThrow(points, start, end, k, time, timing));
			if (shown < point.tau) pauses += 1;
			else point.tau = shown;
		}
		start = end;
	}
	return pauses;
}
/**
* When `point`'s lip throws, s, as known at `time`: when its crest crossed its throw depth, or, before it has, when it
* will at the pace it has come shoreward since it joined, no later than its clock's earliest frame from now (a crest
* not yet moving throws no sooner than that); unlagged, when it joined. Never before the solver broke it.
*/
function throwTime(point, time, timing) {
	if (!timing.lagged) return Math.max(point.joined, point.broke);
	if (point.thrown !== null) return Math.max(point.thrown, point.broke);
	const latest = time - timing.earliest;
	const come = point.depth - point.crestDepth;
	const foreseen = come > 0 ? point.joined + (point.depth - point.throwDepth) * (time - point.joined) / come : latest;
	return Math.max(Math.min(foreseen, latest), point.broke);
}
/** Point k's throw time from a biweight-weighted line through the throw times of points[start, end) near it. */
function fittedThrow(points, start, end, k, time, timing) {
	const centre = points[k].sigma;
	let s0 = 0;
	let s1 = 0;
	let s2 = 0;
	let t0 = 0;
	let t1 = 0;
	let low = Infinity;
	let high = -Infinity;
	let from = k;
	while (from > start && centre - points[from - 1].sigma < RADIUS) from -= 1;
	for (let j = from; j < end && points[j].sigma - centre < RADIUS; j += 1) {
		const other = points[j];
		const thrown = throwTime(other, time, timing);
		const d = other.sigma - centre;
		const u = d / RADIUS;
		const w = (1 - u * u) * (1 - u * u);
		s0 += w;
		s1 += w * d;
		s2 += w * d * d;
		t0 += w * thrown;
		t1 += w * d * thrown;
		if (thrown < low) low = thrown;
		if (thrown > high) high = thrown;
	}
	const mean = t0 / s0;
	const fitted = s2 / s0 - s1 / s0 * (s1 / s0) < CLOCK.bunched ? mean : (s2 * t0 - s1 * t1) / (s0 * s2 - s1 * s1);
	return Math.min(high, Math.max(low, fitted));
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/barrelSpots.ts
/**
* How far over a reef's top its throw's floor sits, m: the pass's Gaussian tail lifts the flat's still depth by up to
* 0.4 mm across the window, so a floor at exactly the top's depth was never crossed there (a numerical margin, not a
* physical one; the advisor kept it, 2026-10-01).
*/
const FLOOR_MARGIN = .01;
/**
* Padang Padang's front rules (the advisor, 2026-10-01; the peak PR): as a crest's face steepens, its highest cell jumps
* forward, and the crest ahead started a track of its own, unsized, which never joined (163 jumps in 180 s of its Small
* sea, against 23 joins and 199 lost, with the rule off: as often as the Reef's). So a sized crest continues as the
* furthest crest within 10 m ahead of it in its column, as the Reef's does. Its join past the throw depth is the Reef's alone.
*/
const PADANG_FRONT = { jumpReach: 10 };
/**
* The Reef's transect (Part B, PR 7; the advisor's rulings, 2026-10-01): its 10 m shelf, the ledge at 1:4.2 along the
* swell's path (the slope the Teahupo'o Reef report measured along the path, and the advisor's periodic_reef42 run) to
* the 1.5 m reef crest. All provisional.
* - **The join:** the game's solver's fresh onset on that transect (the spotOnset probe, 2026-10-01: regular waves
*   driven in 10 m, each wave's highest over the band, the median still depth under its crest where Kennedy's fresh test
*   first fired, 12 waves a row). Drives that broke before the ledge, whose onsets outnumbered their waves by more than
*   two (the 5.5 m drive at every period, the 4.5 m at 15 s), are left out: big Reef sets breaking before the ledge sit
*   outside the ledge's library, a Reef behaviour question for the Reef session. At 16–17 s the 3.5 m drive first breaks
*   at 2.0 m, against 4.9–5.6 m at 14–15 s: longer periods shoal longer before breaking.
* - **The band:** Padang Padang's 6–5 m at 7 m, scaled to the 10 m foot (the probe read the same band).
* - **The throw:** the line through the two runs, foot crest against the still depth where the face goes vertical
*   (`plunge_measure.py`): reef42's 2.127 m crest at 1.928 m, at the top's edge, and reef42_a35's 3.503 m at 5.159 m,
*   15 m seaward of the top on the ledge's face, H/d ≈ 0.95 at the vertical in both. So d = 2.35 η − 3.07 (the advisor,
*   2026-10-01; provisional: a third case near A0 0.28 would test whether it is linear). Through the origin it would
*   throw reef42's own wave 0.9 m too deep. Bigger waves break deeper: a 4 m crest throws about 6.3 m down the face.
* - **The floor:** no shallower than the reef's top at the tide, which the line meets at η ≈ 1.95 m. It stands for crests
*   the solver breaks near the edge (the advisor, refined after the front's check): the smallest waves cross the edge
*   unbroken (H/h ≈ 0.4 there) and break depth-limited where the inner flat shoals to about 0.73 m, which the ledge's
*   cases would draw wrongly, so the front's join reach (1.5 H past the throw depth) lets them go as the solver's bores.
* - **Its cases:** reef42 (A0 0.21) alone. reef60 (1:6) waits for per-slice slopes. reef42_a35 (A0 0.35) sets the throw
*   line but is out of the index: its lip landmark flickers between the curl's top and the jet's tip, so even the
*   advisor's robust trace leaves 13 of its 77 open frames flagged and its tip fit up to 6 √(g h0) (the bar: about 90 %
*   clean, at most about 1.5). The small case (A0 ≈ 0.09, over the inner flat) is owed at level 13.
*/
const REEF_THROW_SLOPE = 3.231 / (3.503 - 2.127);
/**
* Every spot's barrel transect, where its cases are in the library. Padang Padang's is round 6's (the owner's 1:19 along
* the path from the wedge's 7 m foot, read live for the design sweep); the Reef's, its shelf's 10 m and the ledge along
* the swell's path. The Reef's fine zone starts at the shelf's edge, so its front follows crests from there.
*
* The Reef's front (the advisor's rulings, 2026-10-01; provisional): its crests' highest cells jump forward to the
* ledge's edge as their faces steepen, so a sized crest follows the furthest crest within 10 m ahead (the advisor's
* 1.5 H would catch none of the jumps measured); and its small waves break only as they cross onto the top, so a crest
* may join up to 1.5 of its wave heights past its throw depth.
*/
const BARREL_SPOTS = {
	padang: {
		slope: 1 / 19,
		get footDepth() {
			return PADANG.baseDepth;
		},
		onset: PADANG_ONSET,
		frontFrom: "zone",
		front: PADANG_FRONT
	},
	point: {
		slope: .0465116,
		footDepth: 7,
		onset: {
			h0: 7,
			band: [6, 5],
			join: [
				{
					period: 9,
					rows: [
						[.62, 1.58],
						[1.01, 2.14],
						[1.37, 2.65],
						[1.73, 3.16],
						[1.99, 3.67]
					]
				},
				{
					period: 11,
					rows: [
						[.6, 1.72],
						[.91, 2.33],
						[1.19, 2.88],
						[1.33, 3.44],
						[1.68, 4.05]
					]
				},
				{
					period: 12,
					rows: [
						[.69, 1.67],
						[1.08, 2.19],
						[1.4, 2.7],
						[1.75, 3.12],
						[2.12, 3.49]
					]
				},
				{
					period: 14,
					rows: [
						[.77, 1.67],
						[1.22, 2.14],
						[1.78, 2.6],
						[2.4, 3.12],
						[2.88, 3.49]
					]
				}
			],
			throwDepth: {
				intercept: 1.551,
				slope: .946,
				heights: [.558, 2.099]
			}
		},
		frontFrom: "zone"
	},
	reef: {
		slope: .238095,
		get footDepth() {
			return REEF.shelfDepth;
		},
		onset: {
			h0: 10,
			band: [60 / 7, 50 / 7],
			join: [
				{
					period: 14,
					rows: [
						[.9, 3.69],
						[1.67, 4.17],
						[2.41, 4.88],
						[3.14, 5.83]
					]
				},
				{
					period: 15,
					rows: [
						[.89, 4.17],
						[1.63, 5.12],
						[2.26, 5.6]
					]
				},
				{
					period: 16,
					rows: [
						[.9, 4.17],
						[1.68, 5.12],
						[2.27, 2.02],
						[2.83, 2.98]
					]
				},
				{
					period: 17,
					rows: [
						[.89, 4.17],
						[1.72, 5.36],
						[2.46, 2.02],
						[2.92, 3.21]
					]
				}
			],
			throwDepth: {
				intercept: 1.928 - 2.127 * REEF_THROW_SLOPE,
				slope: REEF_THROW_SLOPE,
				heights: [0, Infinity]
			},
			get floor() {
				return REEF.crestDepth + FLOOR_MARGIN;
			}
		},
		frontFrom: "fine",
		front: {
			jumpReach: 10,
			joinPast: 1.5
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/crestOnset.ts
/**
* Each column's crests for the swept barrel's front (the Padang Padang spec, 13.3). The front joins a crest by where it
* is (BreakingFront: its breaking depth, from its height at the wedge's foot), not by how its surface moves: once a
* neighbour breaks, the solver's eddy viscosity damps a column's rise, and its breaking age is the event's (the
* advisor and three probes, 2026-09-30). The segment's breaking strength gates the join; its fresh rise (Kennedy's
* test, η_t over √(g d)) and B = U/C are diagnostics. B is no trigger: with the depth-averaged ū, Padang Padang's
* breaking crests read 0.1–0.5, no different from calm ones, since q ≈ cη makes U/C ≈ η/(h + η); Derakhti's 0.85 and
* 1.0, and Bacigaluppi's 0.75, are for the surface velocity.
*/
/** Crests over thinner water are shore swash, not waves, m (as CrestKinematics). */
const WET$4 = .05;
/** How far shoreward of a crest its face is read, m (as CrestKinematics' FACE_REACH). */
const FACE_REACH$2 = 10;
/** A crest slower than this share of √(gh) is not a travelling form, so its U/C is noise (the advisor, provisional). */
const MIN_CREST_FROUDE = .5;
/** The shallowest still depth the rise is scaled by, m (the solver's breaking floor). */
const RISE_DEPTH = .05;
/**
* Every crest in every column from `fromRow` shoreward: strict local maxima of the surface along the column, higher
* than `minHeight` above still water, with their segment's breaking. Written into `out` (reused, grown as needed); the
* count is returned. Columns go in order, rows seaward first.
*/
function columnCrests(solver, breaking, fromRow, minHeight, out) {
	const { nx, nz, h, bed, qx, qz, xCenters, zCenters, restLevel } = solver;
	const rate = solver.surfaceRiseRate;
	let count = 0;
	for (let ix = 0; ix < nx; ix += 1) for (let iz = Math.max(1, fromRow); iz < nz - 1; iz += 1) {
		const i = iz * nx + ix;
		if (!(h[i] > WET$4)) continue;
		const eta = h[i] + bed[i];
		if (!(eta - restLevel > minHeight) || !(eta > h[i - nx] + bed[i - nx]) || !(eta > h[i + nx] + bed[i + nx])) continue;
		let strength = 0;
		let rise = 0;
		let trough = eta;
		for (let row = iz; row < nz && zCenters[row] - zCenters[iz] <= FACE_REACH$2; row += 1) {
			const cell = row * nx + ix;
			if (!(h[cell] > WET$4)) continue;
			if (breaking.strength[cell] > strength) strength = breaking.strength[cell];
			if (h[cell] + bed[cell] < trough) trough = h[cell] + bed[cell];
			const fresh = rate[cell] / Math.sqrt(GRAVITY$1 * Math.max(RISE_DEPTH, restLevel - bed[cell]));
			if (fresh > rise) rise = fresh;
		}
		const found = crestMotion(solver, i);
		const motion = found && found.speed >= MIN_CREST_FROUDE * Math.sqrt(9.81 * h[i]) ? found : void 0;
		const sample = out[count] ??= {
			column: 0,
			row: 0,
			x: 0,
			z: 0,
			eta: 0,
			wave: 0,
			strength: 0,
			rise: 0,
			depth: 0,
			b: NaN,
			speed: 0
		};
		sample.column = ix;
		sample.row = iz;
		sample.x = xCenters[ix];
		sample.z = zCenters[iz];
		sample.eta = eta - restLevel;
		sample.wave = eta - trough;
		sample.strength = strength;
		sample.rise = rise;
		sample.depth = restLevel - bed[i];
		sample.b = motion ? (qx[i] * motion.direction.x + qz[i] * motion.direction.z) / h[i] / motion.speed : NaN;
		sample.speed = motion ? motion.speed : 0;
		count += 1;
	}
	return count;
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/frontRecords.ts
const FRONT_FIELD = {
	x: 0,
	z: 1,
	front: 2,
	sigma: 3,
	tau: 4,
	footHeight: 5,
	footDepth: 6,
	throwZ: 7,
	pace: 8
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/ProfileLibrary.ts
const LANDMARK = {
	back: 0,
	crest: 32,
	lip: 64,
	throat: 88,
	toe: 112,
	front: 127
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/crestRays.ts
/**
* Base slices divide a span of at least 2*extension into ceil(span/spacing) intervals; refinement halves them.
* Since ceil(a)<a+1, this lower bound also covers very short fronts and nonintegral spans.
*/
function minimumCrestRaySpacing(extension, spacing) {
	return .5 * spacing * (2 * extension) / (2 * extension + spacing);
}
/** A phase-independent authored reach, in case units. Frame blending preserves these crest-relative bounds. */
function authoredCrestReach(cases, slope, points, crest) {
	if (cases.length === 0) return /* @__PURE__ */ new Float64Array(2);
	let closest = cases[0].slope;
	for (const c of cases) if (Math.abs(c.slope - slope) < Math.abs(closest - slope)) closest = c.slope;
	let low = Infinity;
	let high = -Infinity;
	for (const c of cases) {
		if (c.slope !== closest) continue;
		for (let f = 0; f < c.frames.length; f += 2 * points) {
			const origin = c.frames[f + 2 * crest];
			for (let j = 0; j < points; j += 1) {
				const along = c.frames[f + 2 * j] - origin;
				if (!Number.isFinite(along)) throw new RangeError("Non-finite authored crest reach");
				low = Math.min(low, along);
				high = Math.max(high, along);
			}
		}
	}
	return new Float64Array([low, high]);
}
/** Immutable authored library data is shared by the drawing, contact and crash plans. */
const envelopes = /* @__PURE__ */ new WeakMap();
/**
* One phase/tessellation-independent ray authority over a complete front and its shoulder extensions. Both input
* paths capture the same float32 transport controls. The raw vector V=C(sigma+2)-C(sigma-2) is piecewise linear;
* shifted control knots bound its length and nearby source derivative pairs bound its normalized derivative at every
* sigma, including between drawn rows. The nearby-pair bound stays continuous when shifted knots coincide.
* For any pair separated by dSigma, BOTH endpoint tangent advances are at least
* dSigma*(B-U*D-R*(1-lambda)*Omega/L): B=min C'·Tref, U=max|C'|, R=profile reach,
* D=max|n-nref|, Omega=max|nRaw'| and L=min|blend|. Own-profile offsets cancel at their own endpoints.
*/
var CrestRayPlan = class {
	library;
	slope;
	extension;
	minSpacing;
	diagnostics = {
		blend: 0,
		minimumAdvancePerSigma: 0,
		invalidIntervals: 0
	};
	envelope;
	lowCase;
	highCase;
	count = 0;
	x = /* @__PURE__ */ new Float64Array(0);
	z = /* @__PURE__ */ new Float64Array(0);
	sigma = /* @__PURE__ */ new Float64Array(0);
	height = /* @__PURE__ */ new Float64Array(0);
	depth = /* @__PURE__ */ new Float64Array(0);
	knots = /* @__PURE__ */ new Float64Array(0);
	derivativeX = /* @__PURE__ */ new Float64Array(0);
	derivativeZ = /* @__PURE__ */ new Float64Array(0);
	a = /* @__PURE__ */ new Float64Array(2);
	b = /* @__PURE__ */ new Float64Array(2);
	v = /* @__PURE__ */ new Float64Array(2);
	referenceX = 0;
	referenceZ = 1;
	constructor(library, slope, extension = 1.5, minSpacing = minimumCrestRaySpacing(extension, .5)) {
		this.library = library;
		this.slope = slope;
		this.extension = extension;
		this.minSpacing = minSpacing;
		let bySlope = envelopes.get(library);
		if (!bySlope) {
			bySlope = /* @__PURE__ */ new Map();
			envelopes.set(library, bySlope);
		}
		let envelope = bySlope.get(slope);
		if (!envelope) {
			envelope = authoredCrestReach(library.cases, slope, 128, LANDMARK.crest);
			bySlope.set(slope, envelope);
		}
		this.envelope = envelope;
		let closest = library.cases[0]?.slope ?? slope;
		for (const c of library.cases) if (Math.abs(c.slope - slope) < Math.abs(closest - slope)) closest = c.slope;
		let low = Infinity;
		let high = -Infinity;
		for (const c of library.cases) if (c.slope === closest) {
			low = Math.min(low, c.nonlinearity);
			high = Math.max(high, c.nonlinearity);
		}
		this.lowCase = low;
		this.highCase = high;
	}
	prepare(controls, start = 0, end = controls.length) {
		this.load(end - start, (i, key) => controls[start + i][key]);
	}
	prepareRecords(records, start, end) {
		this.load(end - start, (i, key) => records[(start + i) * 9 + FRONT_FIELD[key]]);
	}
	load(count, read) {
		if (this.x.length < count) {
			const capacity = Math.max(count, 2 * this.x.length);
			this.x = new Float64Array(capacity);
			this.z = new Float64Array(capacity);
			this.sigma = new Float64Array(capacity);
			this.height = new Float64Array(capacity);
			this.depth = new Float64Array(capacity);
			this.knots = new Float64Array(2 * capacity + 4);
			this.derivativeX = new Float64Array(capacity + 1);
			this.derivativeZ = new Float64Array(capacity + 1);
		}
		this.count = count;
		this.diagnostics.blend = 0;
		this.diagnostics.minimumAdvancePerSigma = 0;
		this.diagnostics.invalidIntervals = 0;
		for (let k = 0; k < count; k += 1) {
			this.x[k] = Math.fround(read(k, "x"));
			this.z[k] = Math.fround(read(k, "z"));
			this.sigma[k] = Math.fround(read(k, "sigma"));
			this.height[k] = Math.fround(read(k, "footHeight"));
			this.depth[k] = Math.fround(read(k, "footDepth"));
			if (!Number.isFinite(this.x[k]) || !Number.isFinite(this.z[k]) || !Number.isFinite(this.sigma[k]) || !Number.isFinite(this.height[k]) || !Number.isFinite(this.depth[k])) throw new RangeError("Non-finite front ray control");
			if (k > 0 && (!(this.x[k] > this.x[k - 1]) || !(this.sigma[k] > this.sigma[k - 1]))) this.diagnostics.invalidIntervals += 1;
		}
		if (count < 2 || this.diagnostics.invalidIntervals > 0) return;
		this.prepareBound();
	}
	prepareBound() {
		const last = this.count - 1;
		let lowSlope = -Infinity;
		let highSlope = Infinity;
		let maximumCoordinate = 0;
		let maximumScale = 0;
		for (let k = 0; k <= last; k += 1) {
			maximumCoordinate = Math.max(maximumCoordinate, Math.abs(this.x[k]), Math.abs(this.z[k]));
			maximumScale = Math.max(maximumScale, this.library.caseBlend({
				slope: this.slope,
				footHeight: this.height[k],
				footDepth: this.depth[k]
			}).scale);
			if (k === last) continue;
			const dx = this.x[k + 1] - this.x[k];
			const dz = this.z[k + 1] - this.z[k];
			if (dz > 0) lowSlope = Math.max(lowSlope, -dx / dz);
			if (dz < 0) highSlope = Math.min(highSlope, -dx / dz);
			for (let side = 0; side < 2; side += 1) {
				const edge = side === 0 ? this.lowCase : this.highCase;
				const a = this.height[k] - edge * this.depth[k];
				const b = this.height[k + 1] - edge * this.depth[k + 1];
				if (a < 0 && b > 0 || a > 0 && b < 0) {
					const share = a / (a - b);
					maximumScale = Math.max(maximumScale, this.depth[k] + share * (this.depth[k + 1] - this.depth[k]));
				}
			}
		}
		let slope = (this.z[last] - this.z[0]) / (this.x[last] - this.x[0]);
		if (lowSlope !== -Infinity) slope = Math.max(slope, .9 * lowSlope);
		if (highSlope !== Infinity) slope = Math.min(slope, .9 * highSlope);
		const norm = Math.sqrt(1 + slope * slope);
		const tx = 1 / norm;
		const tz = slope / norm;
		this.referenceX = -tz;
		this.referenceZ = tx;
		let speed = 1;
		let progress = Infinity;
		for (let k = 0; k < last; k += 1) {
			const dx = this.x[k + 1] - this.x[k];
			const dz = this.z[k + 1] - this.z[k];
			const length = Math.sqrt(dx * dx + dz * dz);
			const ds = this.sigma[k + 1] - this.sigma[k];
			this.derivativeX[k + 1] = dx / ds;
			this.derivativeZ[k + 1] = dz / ds;
			if (k === 0) {
				this.derivativeX[0] = dx / length;
				this.derivativeZ[0] = dz / length;
			}
			if (k + 1 === last) {
				this.derivativeX[this.count] = dx / length;
				this.derivativeZ[this.count] = dz / length;
			}
			speed = Math.max(speed, length / ds);
			progress = Math.min(progress, (dx * tx + dz * tz) / ds);
			if (k === 0 || k + 1 === last) progress = Math.min(progress, (dx * tx + dz * tz) / length);
		}
		const reach = Math.max(Math.abs(this.envelope[0]), Math.abs(this.envelope[1])) * maximumScale + this.extension;
		const from = this.sigma[0] - this.extension;
		const to = this.sigma[last] + this.extension;
		let used = 0;
		this.knots[used++] = from;
		this.knots[used++] = to;
		for (let k = 0; k <= last; k += 1) {
			const left = this.sigma[k] - 2;
			const right = this.sigma[k] + 2;
			if (left > from && left < to) this.knots[used++] = left;
			if (right > from && right < to) this.knots[used++] = right;
		}
		this.knots.subarray(0, used).sort();
		let minimumVectorLength = Infinity;
		let cosine = 1;
		this.rawVector(this.knots[0], this.a);
		for (let k = 1; k < used; k += 1) {
			if (!(this.knots[k] - this.knots[k - 1] > 0)) continue;
			this.rawVector(this.knots[k], this.b);
			const dx = this.b[0] - this.a[0];
			const dz = this.b[1] - this.a[1];
			const squared = dx * dx + dz * dz;
			const share = squared > 0 ? Math.max(0, Math.min(1, -(this.a[0] * dx + this.a[1] * dz) / squared)) : 0;
			const mx = this.a[0] + share * dx;
			const mz = this.a[1] + share * dz;
			const minimumLength = Math.sqrt(mx * mx + mz * mz);
			if (!(minimumLength > 1e-9)) {
				this.diagnostics.invalidIntervals += 1;
				return;
			}
			minimumVectorLength = Math.min(minimumVectorLength, minimumLength);
			const la = Math.sqrt(this.a[0] * this.a[0] + this.a[1] * this.a[1]);
			const lb = Math.sqrt(this.b[0] * this.b[0] + this.b[1] * this.b[1]);
			cosine = Math.min(cosine, (this.a[0] * tx + this.a[1] * tz) / la, (this.b[0] * tx + this.b[1] * tz) / lb);
			this.a[0] = this.b[0];
			this.a[1] = this.b[1];
		}
		let derivativeDifference = 0;
		for (let i = 0; i <= this.count; i += 1) {
			const end = i < this.count ? this.sigma[i] : to + 2;
			for (let j = i + 1; j <= this.count; j += 1) {
				const start = this.sigma[j - 1];
				const gap = Math.max(0, start - end);
				if (gap >= 5) break;
				const weight = Math.min(1, 5 - gap);
				const dx = this.derivativeX[j] - this.derivativeX[i];
				const dz = this.derivativeZ[j] - this.derivativeZ[i];
				derivativeDifference = Math.max(derivativeDifference, weight * Math.sqrt(dx * dx + dz * dz));
			}
		}
		const omega = derivativeDifference / minimumVectorLength;
		cosine = Math.max(0, Math.min(1, cosine));
		const distance = Math.sqrt(2 - 2 * cosine);
		const rounding = (4 * (maximumCoordinate + reach + this.extension) + 1) / (1048576 * this.minSpacing);
		const target = .05 * progress + rounding;
		const bound = (weight) => {
			const u = 1 - weight;
			const length = Math.sqrt(1 - 2 * u * weight * (1 - cosine));
			return progress - u / length * (2 * speed * distance + reach * omega);
		};
		if (target >= progress) {
			this.diagnostics.invalidIntervals += 1;
			this.diagnostics.blend = 1;
			return;
		}
		if (bound(0) >= target) {
			this.diagnostics.minimumAdvancePerSigma = bound(0);
			return;
		}
		let lower = 0;
		let upper = 1;
		for (let k = 0; k < 24; k += 1) {
			const middle = (lower + upper) / 2;
			if (bound(middle) >= target) upper = middle;
			else lower = middle;
		}
		this.diagnostics.blend = upper;
		this.diagnostics.minimumAdvancePerSigma = bound(upper);
	}
	/** Evaluate the original polyline/extrapolation arithmetic over captured transport controls. */
	pointAt(at, into) {
		const last = this.count - 1;
		if (at <= this.sigma[0] || at >= this.sigma[last]) {
			const k = at <= this.sigma[0] ? 0 : last;
			const neighbor = k === 0 ? 1 : last - 1;
			const dx = this.x[k] - this.x[neighbor];
			const dz = this.z[k] - this.z[neighbor];
			const length = Math.sqrt(dx * dx + dz * dz);
			const beyond = k === 0 ? this.sigma[0] - at : at - this.sigma[last];
			into[0] = this.x[k];
			into[1] = this.z[k];
			if (length > 1e-9) {
				into[0] += beyond * dx / length;
				into[1] += beyond * dz / length;
			}
			return;
		}
		let low = 1;
		let high = last;
		while (low < high) {
			const mid = low + high >>> 1;
			if (this.sigma[mid] < at) low = mid + 1;
			else high = mid;
		}
		const k = low - 1;
		const ds = this.sigma[k + 1] - this.sigma[k];
		const share = ds > 1e-12 ? (at - this.sigma[k]) / ds : 0;
		into[0] = this.x[k] + share * (this.x[k + 1] - this.x[k]);
		into[1] = this.z[k] + share * (this.z[k + 1] - this.z[k]);
	}
	rawVector(at, into) {
		this.pointAt(at + 2, this.v);
		const x = this.v[0];
		const z = this.v[1];
		this.pointAt(at - 2, this.v);
		into[0] = x - this.v[0];
		into[1] = z - this.v[1];
	}
	rayAt(sigma, into) {
		if (this.count < 2) {
			into[0] = 0;
			into[1] = 1;
			return into;
		}
		this.rawVector(sigma, into);
		const length = Math.sqrt(into[0] * into[0] + into[1] * into[1]);
		if (length > 1e-9) {
			into[0] /= length;
			into[1] /= length;
		} else {
			into[0] = 1;
			into[1] = 0;
		}
		const nx = -into[1];
		const nz = into[0];
		const weight = this.diagnostics.blend;
		if (weight === 0) {
			into[0] = nx;
			into[1] = nz;
			return into;
		}
		into[0] = nx + weight * (this.referenceX - nx);
		into[1] = nz + weight * (this.referenceZ - nz);
		const n = Math.sqrt(into[0] * into[0] + into[1] * into[1]);
		into[0] /= n;
		into[1] /= n;
		return into;
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/heldOverturn.ts
const FLOATS = 256;
/** How far ahead of the tip the face is searched for its point nearest the tip, h0 (metrics.py's 2.0). */
const FACE_REACH$1 = 2;
const none = () => ({
	jetArea: 0,
	voidArea: 0,
	voidLength: 0,
	axisX: 1,
	axisY: 0
});
/** Frame `frame`'s overturn, from a case's frames (PROFILE_POINTS (x, y) pairs per frame, h0). */
function overturnAt(frames, frame) {
	const o = frame * FLOATS;
	const x = (i) => frames[o + 2 * i];
	const y = (i) => frames[o + 2 * i + 1];
	const tipX = x(LANDMARK.lip);
	const tipY = y(LANDMARK.lip);
	if (!(tipX - x(LANDMARK.throat) > 0)) return none();
	let k = -1;
	let nearest = Infinity;
	for (let i = LANDMARK.throat; i < 128; i += 1) {
		if (!(x(i) < tipX + FACE_REACH$1)) continue;
		const dx = x(i) - tipX;
		const dy = y(i) - tipY;
		const d = dx * dx + dy * dy;
		if (d < nearest) {
			nearest = d;
			k = i;
		}
	}
	if (k - LANDMARK.lip < 2) return none();
	let twice = 0;
	for (let i = LANDMARK.lip; i <= k; i += 1) {
		const j = i === k ? LANDMARK.lip : i + 1;
		twice += x(i) * y(j) - x(j) * y(i);
	}
	let longest = 0;
	let from = LANDMARK.lip;
	let to = LANDMARK.lip;
	for (let i = LANDMARK.lip; i <= k; i += 1) for (let j = i + 1; j <= k; j += 1) {
		const dx = x(j) - x(i);
		const dy = y(j) - y(i);
		const d = dx * dx + dy * dy;
		if (d > longest) {
			longest = d;
			from = i;
			to = j;
		}
	}
	const length = Math.sqrt(longest);
	const axisX = length > 0 ? Math.abs(x(to) - x(from)) / length : 1;
	const axisY = length > 0 ? -Math.abs(y(to) - y(from)) / length : 0;
	const throatX = x(LANDMARK.throat);
	let crossing = -1;
	for (let i = 0; i < LANDMARK.lip; i += 1) if ((x(i) - throatX) * (x(i + 1) - throatX) <= 0) crossing = i;
	let jetArea = 0;
	if (crossing >= 0) {
		const run = x(crossing + 1) - x(crossing);
		const t = run !== 0 ? (throatX - x(crossing)) / run : 0;
		const startX = x(crossing) + t * run;
		const startY = y(crossing) + t * (y(crossing + 1) - y(crossing));
		let jet = 0;
		let px = startX;
		let py = startY;
		for (let i = crossing + 1; i <= LANDMARK.throat; i += 1) {
			jet += px * y(i) - x(i) * py;
			px = x(i);
			py = y(i);
		}
		jet += px * startY - startX * py;
		jetArea = Math.abs(jet) / 2;
	}
	return {
		jetArea,
		voidArea: Math.abs(twice) / 2,
		voidLength: length,
		axisX,
		axisY
	};
}
/** Two overturns blended by `weight` (0 the first, 1 the second), as the library blends their frames; the axis renormalised with √. */
function blendOverturn(a, b, weight) {
	if (weight === 0) return a;
	if (weight === 1) return b;
	const lerp = (p, q) => p + weight * (q - p);
	const ax = lerp(a.axisX, b.axisX);
	const ay = lerp(a.axisY, b.axisY);
	const norm = Math.sqrt(ax * ax + ay * ay);
	return {
		jetArea: lerp(a.jetArea, b.jetArea),
		voidArea: lerp(a.voidArea, b.voidArea),
		voidLength: lerp(a.voidLength, b.voidLength),
		axisX: norm > 0 ? ax / norm : 1,
		axisY: norm > 0 ? ay / norm : 0
	};
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/sweptLoft.ts
/**
* The swept loft's constants (the Padang Padang spec, Part B, PR 3; docs/research/water-physics/swept-barrel-build.md,
* "Lofting" and "The seam"; the advisor's rulings, 2026-09-30):
* - `spacing`, `fine`, m: slices every half metre along the front, a quarter where neighbouring clocks differ by more
*   than `frames` library frames (the advisor: 2–4, so neighbours stay within a stage);
* - `budget`, vertices: past it the spacing widens and neighbouring clocks are clamped to T_open/4 (the advisor);
* - `pinned`: samples at each end of a profile blended onto the water, never reaching the lip or throat [inferred];
* - `extension`, `extensionSamples`: the surface runs on over the water this far past each end, m, in this many
*   samples, so the seam's band always has both surfaces [inferred];
* - `band`, m: the dithered overlap at the mask's edge [inferred];
* - `endBlend`, m: a front's ends blend into the water over this length [inferred].
* (After touchdown a slice fades into the water over its tube's own collapse, `ProfileLookup.collapseSeconds`, and a
* faded slice is dropped.)
*/
const LOFT = {
	spacing: .5,
	fine: .25,
	frames: 3,
	budget: 4e4,
	pinned: 6,
	extension: 1.5,
	extensionSamples: 3,
	band: 1,
	endBlend: 2.5
};
/** Vertices per slice: the profile and its extensions over the water at each end. */
const LOFT_SAMPLES = 128 + 2 * LOFT.extensionSamples;
/**
* The library's runs' slope along the wave's path, per spot with a barrel transect (`BARREL_SPOTS`; the owner's 1:19 at
* Padang Padang).
*/
const BARREL_SLOPE = Object.fromEntries(Object.entries(BARREL_SPOTS).flatMap(([spot, barrel]) => barrel ? [[spot, barrel.slope]] : []));
Math.floor(LOFT.budget / LOFT_SAMPLES);
const E = LOFT.extensionSamples;
LOFT.extension / E;
/**
* A slice's fade after touchdown: 1 until then, falling to 0 over its tube's collapse, √(2W/g) (the advisor,
* 2026-09-30: neither the drawing nor the contact may outlast the pocket); a tube without a void goes at touchdown.
*/
function collapseFade(tau, touchdown, collapse) {
	if (tau <= touchdown) return 1;
	return collapse > 0 ? Math.max(0, 1 - (tau - touchdown) / collapse) : 0;
}
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/crashCurve.ts
function createCrashSlice() {
	return {
		rayX: 0,
		rayZ: 1,
		width: 0,
		endWeight: 0,
		scale: 0,
		touchdown: 0,
		clear: 0,
		collapse: 0,
		anchorX: 0,
		anchorZ: 0,
		fade: 1,
		weight: 0,
		tipX: 0,
		tipY: 0,
		tipZ: 0,
		crestX: 0,
		crestY: 0,
		crestZ: 0,
		landX: 0,
		landY: 0,
		landZ: 0,
		reachBack: 0,
		reachFront: 0,
		footBack: 0,
		footFront: 0,
		jetArea: 0,
		voidArea: 0,
		voidLength: 0,
		axisX: 1,
		axisY: 0,
		voidHeight: 0
	};
}
const LAST = 127;
/** How far ahead of the tip the face is searched for its point nearest the tip, h0 (metrics.py's 2.0). */
const FACE_REACH = 2;
/** The drawn crest's speed is read over this many library frames before the clear one. */
const CREST_FRAMES = 10;
/** How much a profile sample is pinned onto the water (the loft's seam, `LOFT.pinned`). */
function pinOf(i) {
	if (i < LOFT.pinned) return (LOFT.pinned - i) / LOFT.pinned;
	if (i > LAST - LOFT.pinned) return (i - (LAST - LOFT.pinned)) / LOFT.pinned;
	return 0;
}
/**
* The swept barrel at one front point, as the loft draws it (the Padang Padang spec, Part B, 13.6: the crash curve along
* the landing line). It mirrors `SweptLoft.loftFront` in drawing mode at the point's own σ, and the crash test holds them
* together, so keep them in step:
* - the shared front ray plan from its tangent over ±2 m, stabilized over the whole authored reach;
* - the end weight, the profile at the clock (the touchdown frame from touchdown on: the drawing keeps it), and PR 4's
*   fade over the tube's collapse;
* - the anchor: the crest point K = S − c n, so the profile's crest landmark sits on the point's crest, before the
*   throw and from it alike (the advisor, 2026-10-03: u = 1 from the throw).
* Where the lip lands (the advisor, 2026-10-01): on the drawn frame's face, at its point nearest the tip, `metrics.py`'s
* closing of the void, whose gap closing is the runs' touchdown. In the runs the face rises to meet the jet, so the tip
* carried on at its own velocity to a still face would land 0.3–1 m too far. The jet and void are the cases' held
* frames' (`overturnAt`), blended as the frames are. Only + − × ÷, √ and floor, for online determinism.
*/
var CrashCurve = class {
	library;
	slope;
	profile = /* @__PURE__ */ new Float32Array(256);
	earlier = /* @__PURE__ */ new Float32Array(256);
	overturns = /* @__PURE__ */ new Map();
	normal = {
		x: 0,
		z: 0
	};
	raySample = /* @__PURE__ */ new Float64Array(2);
	directRays;
	constructor(library, slope) {
		this.library = library;
		this.slope = slope;
		this.directRays = new CrestRayPlan(library, slope, LOFT.extension, minimumCrestRaySpacing(LOFT.extension, LOFT.spacing));
		for (const c of library.cases) {
			const held = library.heldFrameOf(c);
			this.overturns.set(c, overturnAt(c.frames, Math.floor((held.tau - c.tauStart) / c.tauStep + .5)));
		}
	}
	/**
	* Front point k (its front's points are [start, end), at least two) at its clock, as the loft draws it, into `into`;
	* `heightAt` is the water under a vertex resting on it.
	*/
	slice(points, start, end, k, stillLevel, heightAt, into, clock = {}, rays) {
		const p = points[k];
		const tau = clock.tau ?? p.tau;
		const first = points[start].sigma;
		const last = points[end - 1].sigma;
		const { x: nx, z: nz } = this.ray(points, start, end, k, this.normal, rays);
		into.rayX = nx;
		into.rayZ = nz;
		into.width = ((k > start ? p.sigma - points[k - 1].sigma : 0) + (k + 1 < end ? points[k + 1].sigma - p.sigma : 0)) / 2;
		const d = Math.min(p.sigma - first, last - p.sigma);
		const r = Math.min(1, d / LOFT.endBlend);
		into.endWeight = d <= 0 ? 0 : r * r * (3 - 2 * r);
		const query = {
			slope: this.slope,
			footHeight: p.footHeight,
			footDepth: p.footDepth
		};
		const profile = this.profile;
		const lookup = this.library.profileAt({
			...query,
			seconds: tau,
			hold: "drawing"
		}, profile);
		const touchdown = lookup.touchdownSeconds;
		into.scale = lookup.scale;
		into.touchdown = touchdown;
		into.clear = lookup.clearSeconds;
		into.collapse = lookup.collapseSeconds;
		into.fade = collapseFade(tau, touchdown, lookup.collapseSeconds);
		into.weight = into.endWeight * into.fade;
		const z = clock.z ?? p.z;
		const crest = profile[2 * LANDMARK.crest];
		const ax = p.x - crest * nx;
		const az = z - crest * nz;
		into.anchorX = ax;
		into.anchorZ = az;
		const place = (along, above, pin, axis, weight = into.weight) => {
			const px = ax + along * nx;
			const pz = az + along * nz;
			if (axis === "x") return px;
			if (axis === "z") return pz;
			const e = weight * (1 - pin);
			if (e === 1) return stillLevel + above;
			const h = heightAt(px, pz);
			return e === 0 ? h : h + e * (stillLevel + above - h);
		};
		const tipAlong = profile[2 * LANDMARK.lip];
		const tipAbove = profile[2 * LANDMARK.lip + 1];
		into.tipX = place(tipAlong, tipAbove, 0, "x");
		into.tipY = place(tipAlong, tipAbove, 0, "y");
		into.tipZ = place(tipAlong, tipAbove, 0, "z");
		const crestAbove = profile[2 * LANDMARK.crest + 1];
		into.crestX = place(crest, crestAbove, 0, "x");
		into.crestY = place(crest, crestAbove, 0, "y");
		into.crestZ = place(crest, crestAbove, 0, "z");
		const reach = tipAlong + FACE_REACH * lookup.scale;
		let nearest = Infinity;
		let landAlong = tipAlong;
		let landAbove = tipAbove;
		let landPin = 0;
		for (let i = LANDMARK.throat; i < LAST; i += 1) {
			const x0 = profile[2 * i];
			const y0 = profile[2 * i + 1];
			if (!(x0 < reach)) continue;
			const ex = profile[2 * i + 2] - x0;
			const ey = profile[2 * i + 3] - y0;
			const length = ex * ex + ey * ey;
			const s = length > 0 ? Math.min(1, Math.max(0, ((tipAlong - x0) * ex + (tipAbove - y0) * ey) / length)) : 0;
			const qx = x0 + s * ex;
			const qy = y0 + s * ey;
			const gap = (tipAlong - qx) * (tipAlong - qx) + (tipAbove - qy) * (tipAbove - qy);
			if (gap < nearest) {
				nearest = gap;
				landAlong = qx;
				landAbove = qy;
				landPin = pinOf(i) + s * (pinOf(i + 1) - pinOf(i));
			}
		}
		into.landX = place(landAlong, landAbove, landPin, "x");
		into.landY = place(landAlong, landAbove, landPin, "y", into.endWeight);
		into.landZ = place(landAlong, landAbove, landPin, "z");
		let back = Infinity;
		let front = -Infinity;
		for (let i = LOFT.pinned; i <= LAST - LOFT.pinned; i += 1) {
			const x = profile[2 * i];
			if (x < back) back = x;
			if (x > front) front = x;
		}
		into.reachBack = back;
		into.reachFront = front;
		into.footBack = profile[0] - LOFT.extension;
		into.footFront = profile[254] + LOFT.extension;
		const blend = this.library.caseBlend(query);
		const o = blendOverturn(this.overturnOf(blend.lower), this.overturnOf(blend.upper), blend.weight);
		const s = blend.scale;
		into.jetArea = o.jetArea * s * s;
		into.voidArea = o.voidArea * s * s;
		into.voidLength = o.voidLength * s;
		into.axisX = o.axisX;
		into.axisY = o.axisY;
		into.voidHeight = GRAVITY$1 * into.collapse * into.collapse / 2;
		return into;
	}
	/**
	* Explicitly prepare the whole front after its positions and arc length have been finalized. The plan copies
	* transport-precision controls, so later point mutations cannot change an already prepared scope. `into` lets
	* SweptCrash reuse storage while preparing afresh at each coordinate-finalization stage.
	*/
	prepareRays(points, start, end, into) {
		const plan = into ?? new CrestRayPlan(this.library, this.slope, LOFT.extension, minimumCrestRaySpacing(LOFT.extension, LOFT.spacing));
		plan.prepare(points, start, end);
		return plan;
	}
	/**
	* Front point k's shared drawing/contact/crash ray. An explicit plan belongs to the caller's prepared scope;
	* without it, always prepare from the current values, rather than caching a mutable points-array identity.
	*/
	ray(points, start, end, k, into, rays) {
		(rays ?? this.prepareRays(points, start, end, this.directRays)).rayAt(Math.fround(points[k].sigma), this.raySample);
		into.x = this.raySample[0];
		into.z = this.raySample[1];
		return into;
	}
	/** A point's touchdown and collapse times, s, without building its profile. */
	times(point) {
		return this.library.profileTimes({
			slope: this.slope,
			footHeight: point.footHeight,
			footDepth: point.footDepth
		});
	}
	/**
	* The held lip's velocity along the ray and up (m/s): each blended case's at its own held frame, as the contact holds it
	* after touchdown (the advisor's PR 4 rulings: the held frame's velocity through the collapse). And the drawn crest's
	* speed along the ray (m/s), over the CREST_FRAMES frames before touchdown.
	*/
	jetMotion(point, into) {
		const query = {
			slope: this.slope,
			footHeight: point.footHeight,
			footDepth: point.footDepth
		};
		const times = this.library.profileTimes(query);
		const held = this.library.profileAt({
			...query,
			seconds: times.touchdownSeconds + times.frameSeconds,
			hold: "contact"
		}, this.earlier);
		into.tipAlong = held.tipAlong;
		into.tipUp = held.tipUp;
		const span = CREST_FRAMES * times.frameSeconds;
		this.library.profileAt({
			...query,
			seconds: times.touchdownSeconds - times.frameSeconds
		}, this.profile);
		const late = this.profile[2 * LANDMARK.crest];
		this.library.profileAt({
			...query,
			seconds: times.touchdownSeconds - times.frameSeconds - span
		}, this.earlier);
		into.crestSpeed = span > 0 ? (late - this.earlier[2 * LANDMARK.crest]) / span : 0;
		return into;
	}
	overturnOf(c) {
		let o = this.overturns.get(c);
		if (!o) {
			const held = this.library.heldFrameOf(c);
			o = overturnAt(c.frames, Math.floor((held.tau - c.tauStart) / c.tauStep + .5));
			this.overturns.set(c, o);
		}
		return o;
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/barrel/SweptCrash.ts
/**
* A thrown point, jet or not, runs on its crest's pace from the throw until its slice has faded (the advisor, 2026-10-01
* and 2026-10-03), held to `slowest`–`fastest` × the long-wave speed √(g (h + η)) at its crest, as the contact's crest
* pace is (CREST_SPEED; provisional), then turned along its column by the ray's z part, at least `leastRayZ` (a crest
* line moving c_n along its normal crosses a column at c_n / cos θ).
*/
const PACE = {
	slowest: .5,
	fastest: 1.5,
	leastRayZ: .5
};
/**
* The swept barrel's jets (the Padang Padang spec, Part B, 13.1 and 13.6; the advisor's rulings, 2026-10-01). The solver
* stays the mass ledger, but at a swept spot its lips leave and land on the barrel's clock. Each step, for every point
* of every front the loft draws (two points or more):
* - **The throw** (its clock reaches 0): every point, jet or not, runs from here on its pace (`PACE`), claiming its crest
*   (BreakingFront), until its slice has faded (the advisor, 2026-10-03). Its pace is set before its slice is taken, so
*   from that very step its z, crest point, launch point and anchor run on z = jetBase + jetPace τ, from where its crest
*   crossed its throw depth. The jet the loft will draw, the cases' held frames' A_J, blended and scaled as their
*   frames, over the point's share of its front times the loft's end weight, still leaves the solver's crest under it by
*   the lip's own rule (#86): from the wave's upper half, its momentum along the held lip's velocity taken nearest first,
*   never reversed, the rest counted. It waits as a held strip
*   (`PlungingLip.holdJet`, in the sea handover), its pour foreseen where the lip would land: the slice at its
*   touchdown, on the anchor's own rule there with its paced z then.
* - **The crash** (its clock reaches touchdown): its void closes, trapping the held frame's A_O over its share, and its
*   water pours from where the lip lands (`CrashCurve`), a parcel every 1/7 of the tube's collapse √(2W/g), each landing as
*   a lip parcel does. A held jet pours only at its crash, or as its point leaves the front. A point first seen past
*   touchdown throws and pours at once; past its collapse it was never drawn, and throws nothing.
* - **The pour** follows the drawn lip, until it has all left.
* - **The whitewater** waits for the touchdown: over the drawn curl's footprint in the point's column, the breaking is
*   withheld from the whitewater (the foam's bore source, its spray and bubbles, the bore's air and turbulence, the roar).
*   An open tube's face is clear water; Kennedy's onset leads the lip by up to 2 s on Padang Padang's wedge.
* - **A stall** (the advisor, 2026-10-03): a point whose clock hasn't reached touchdown 2 T of solver time after its
*   throw leaves the front (`exits`), and its jet crashes where it was foreseen. One still on its pace 2 (T + collapse)
*   after its throw, its clock stalled in its slice's fade, leaves too (`fadeExits`), its pour running on from its last
*   place.
* A point alone on its front at its touchdown, past its collapse, leaving the front at a stall or lost, crashes where it
* was foreseen: its void closes, and its pour starts from the foreseen place at the foreseen spacing. Where two fronts'
* barrels overlap, the loft draws the first (PR 4), so a later front's point under it throws nothing and gates nothing.
* Only + − × ÷ and √ (online determinism).
*/
var SweptCrash = class {
	counts = {
		onsets: 0,
		throws: 0,
		asked: 0,
		thrown: 0,
		starved: 0,
		starvedVolume: 0,
		crashes: 0,
		late: 0,
		missed: 0,
		covered: 0,
		foreseen: 0,
		exits: 0,
		exitJets: 0,
		fadeExits: 0,
		fadeExitJets: 0,
		lost: 0,
		paceSlow: 0,
		paceFast: 0,
		paceUnmeasured: 0,
		gated: 0
	};
	/** This step's crash curve: the points pouring. */
	curve = [];
	/** The points that left the front this step at a stall, short of touchdown and in the fade (diagnostics): see `CrashCounts`. */
	exited = [];
	fadeExited = [];
	/** This step's throws, paced before their slices were taken (a diagnostic). */
	paced = [];
	/** The crash's own time, ms, summed over its updates (a diagnostic). */
	updateMs = 0;
	geometry;
	foreseen = createCrashSlice();
	motion = {
		tipAlong: 0,
		tipUp: 0,
		crestSpeed: 0
	};
	pool = [];
	/** This step's drawn fronts, as [start, end) pairs of point indices. */
	runs = [];
	/** Explicit plans for this update's fronts, rebuilt whenever a coordinate-finalization stage changes them. */
	rayPlans = [];
	/**
	* Per point this step: as drawn; whether it is live (before its collapse ends), and under an earlier front's barrel;
	* whether it throws, and the solver's crest cell its water leaves and the wave height measured there.
	*/
	slices = [];
	live = /* @__PURE__ */ new Uint8Array(0);
	covered = /* @__PURE__ */ new Uint8Array(0);
	throwing = /* @__PURE__ */ new Uint8Array(0);
	throwCell = /* @__PURE__ */ new Int32Array(0);
	throwHeight = /* @__PURE__ */ new Float64Array(0);
	ray = {
		x: 0,
		z: 1
	};
	/** Per point, its strip's footprint: corners (x, z × 4) and box (x0, x1, z0, z1), as the loft judges overlaps. */
	corners = /* @__PURE__ */ new Float64Array(0);
	boxes = /* @__PURE__ */ new Float64Array(0);
	/** This step's points' held jets, by strip. */
	holders = /* @__PURE__ */ new Set();
	constructor(library, slope) {
		this.geometry = new CrashCurve(library, slope);
	}
	/**
	* One step, after the fronts' clocks have advanced: the stalls, the throws, crashes and pours, and the whitewater. A
	* stalled point is taken off `points` (the front's own list). Returns this step's throws and their water, m³.
	*/
	update(points, sea) {
		const started = performance.now();
		this.curve.length = 0;
		sea.whitewater.set(sea.strength);
		const { solver, lip } = sea;
		this.exited.length = 0;
		this.fadeExited.length = 0;
		let kept = 0;
		for (const p of points) {
			if (p.jetAt !== void 0 && this.stalled(p, solver.time, lip)) continue;
			points[kept] = p;
			kept += 1;
		}
		points.length = kept;
		const holders = this.holders;
		holders.clear();
		for (const p of points) if (p.jetStrip !== void 0 && p.jetStrip >= 0 && p.crashedAt === void 0) holders.add(p.jetStrip);
		lip.forEachHeldJet((strip) => {
			if (holders.has(strip)) return;
			lip.closeJet(strip);
			this.counts.lost += 1;
		});
		for (const p of points) {
			if (p.jetPace === void 0 || p.jetBase === void 0 || p.jetUntil === void 0 || !(p.tau < p.jetUntil)) continue;
			p.z = p.jetBase + p.jetPace * p.tau;
		}
		this.measureArc(points);
		const heightAt = (x, z) => solver.sampleCentered(solver.h, x, z) + solver.sampleCentered(solver.bed, x, z);
		const runs = this.runs;
		runs.length = 0;
		let start = 0;
		while (start < points.length) {
			let end = start + 1;
			while (end < points.length && points[end].front === points[start].front) end += 1;
			if (end - start >= 2 && points[end - 1].sigma - points[start].sigma > 1e-6) runs.push(start, end);
			start = end;
		}
		this.reserve(points.length);
		this.paced.length = 0;
		for (let r = 0; r < runs.length; r += 2) {
			const rays = this.rayPlans[r / 2] = this.geometry.prepareRays(points, runs[r], runs[r + 1], this.rayPlans[r / 2]);
			for (let k = runs[r]; k < runs[r + 1]; k += 1) {
				const p = points[k];
				const times = this.geometry.times(p);
				this.live[k] = p.tau < times.touchdownSeconds + times.collapseSeconds ? 1 : 0;
				if (this.live[k] && p.jetStrip === void 0 && p.tau >= 0) this.paceThrow(points, runs[r], runs[r + 1], k, times, sea, rays);
			}
		}
		for (const thrown of this.paced) thrown.point.z = thrown.point.jetBase + thrown.point.jetPace * thrown.point.tau;
		if (this.paced.length > 0) {
			this.measureArc(points);
			for (let r = 0; r < runs.length; r += 2) this.geometry.prepareRays(points, runs[r], runs[r + 1], this.rayPlans[r / 2]);
		}
		for (let r = 0; r < runs.length; r += 2) for (let k = runs[r]; k < runs[r + 1]; k += 1) {
			const p = points[k];
			if (!this.live[k]) {
				if (p.jetStrip === void 0) {
					p.jetStrip = -1;
					this.counts.missed += 1;
				}
				continue;
			}
			this.footprint(k, this.geometry.slice(points, runs[r], runs[r + 1], k, sea.stillLevel, heightAt, this.slices[k], {}, this.rayPlans[r / 2]));
		}
		this.dropOverlaps(runs);
		let throws = 0;
		let volume = 0;
		for (let r = 0; r < runs.length; r += 2) for (let k = runs[r]; k < runs[r + 1]; k += 1) {
			if (!this.live[k]) continue;
			const thrown = this.advance(points, runs[r], runs[r + 1], k, sea, heightAt, this.rayPlans[r / 2]);
			if (thrown > 0) {
				throws += 1;
				volume += thrown;
			}
		}
		for (const p of points) {
			if (p.jetStrip === void 0 || p.jetStrip < 0 || p.crashedAt !== void 0) continue;
			if (p.tau < this.geometry.times(p).touchdownSeconds) continue;
			lip.closeJet(p.jetStrip);
			p.crashedAt = sea.solver.time;
			this.counts.foreseen += 1;
		}
		this.updateMs += performance.now() - started;
		return {
			throws,
			volume
		};
	}
	/** Point k's step: the gate, the throw, the crash and the pour. Returns the water it threw. */
	advance(points, start, end, k, sea, heightAt, rays) {
		const p = points[k];
		const s = this.slices[k];
		const drawn = this.covered[k] === 0;
		if (drawn && p.tau < s.touchdown && s.endWeight > 0) this.gate(p, s, sea);
		let thrown = 0;
		let throwing = false;
		if (this.throwing[k]) {
			if (drawn) {
				thrown = this.throwJet(points, start, end, k, s, sea, heightAt, this.geometry.jetMotion(p, this.motion), this.throwCell[k], this.throwHeight[k], rays);
				throwing = true;
			} else {
				p.jetStrip = -1;
				this.counts.covered += 1;
			}
		}
		const strip = p.jetStrip ?? -1;
		if (strip >= 0 && p.crashedAt === void 0 && p.tau >= s.touchdown) {
			const motion = this.geometry.jetMotion(p, this.motion);
			sea.lip.crashJet(strip, {
				x: s.landX,
				y: s.landY,
				z: s.landZ,
				spacing: s.collapse / 7,
				vy: motion.tipUp
			}, {
				x: s.crestX,
				y: s.crestY,
				z: s.crestZ
			});
			p.crashedAt = sea.solver.time;
			this.counts.crashes += 1;
			if (throwing) this.counts.late += 1;
		}
		if (strip >= 0 && p.crashedAt !== void 0 && p.tau < s.touchdown + s.collapse) {
			sea.lip.movePour(strip, s.landX, s.landY, s.landZ);
			this.pour(p, s);
		}
		return thrown;
	}
	/**
	* Whether point p, thrown at `jetAt`, leaves the front at a stall now (the advisor, 2026-10-03): short of touchdown 2 T
	* after its throw, its jet, if any, crashing where it was foreseen (`exits`); or still on its pace 2 (T + collapse)
	* after it, past touchdown (the first rule takes any short of it), its jet's pour running on from its last place
	* (`fadeExits`).
	*/
	stalled(p, time, lip) {
		const { touchdownSeconds: touchdown, collapseSeconds: collapse } = this.geometry.times(p);
		const age = time - p.jetAt;
		if (p.tau < touchdown && age >= 2 * touchdown) {
			this.exited.push(p);
			this.counts.exits += 1;
			if (p.jetStrip !== void 0 && p.jetStrip >= 0 && p.crashedAt === void 0) {
				lip.closeJet(p.jetStrip);
				p.crashedAt = time;
				this.counts.exitJets += 1;
			}
			return true;
		}
		if (p.jetUntil !== void 0 && p.tau < p.jetUntil && age >= 2 * (touchdown + collapse)) {
			this.fadeExited.push(p);
			this.counts.fadeExits += 1;
			if (p.jetStrip !== void 0 && p.jetStrip >= 0) this.counts.fadeExitJets += 1;
			return true;
		}
		return false;
	}
	/**
	* Front point k's throw this step, before its slice is taken: its pace (`pace`) from the front as it stands (this step's
	* other throws not yet on theirs), and the solver's crest cell it stands on, which its jet's water leaves (#86), with
	* the wave height measured there. Listed in `paced`.
	*/
	paceThrow(points, start, end, k, times, sea, rays) {
		const p = points[k];
		const motion = this.geometry.jetMotion(p, this.motion);
		const cell = sea.solver.cellIndex(p.x, p.z);
		const waveHeight = waveHeightAt(sea.solver, cell, .5 * Math.max(0, motion.crestSpeed) * sea.period);
		const rayZ = this.geometry.ray(points, start, end, k, this.ray, rays).z;
		this.pace(p, times, rayZ, sea, cell, waveHeight);
		this.throwing[k] = 1;
		this.throwCell[k] = cell;
		this.throwHeight[k] = waveHeight;
		this.paced.push({
			point: p,
			crestZ: p.z,
			rayZ
		});
	}
	/**
	* A point's pace from its throw, jet or not (the advisor, 2026-10-01 and 2026-10-03): its crest's over the last few
	* frames (crestMotion's, along the crest's own normal), held to PACE × the long-wave speed there, then along its column:
	* c_n / n_z, n_z its ray's at the throw (`rayZ`, the loft's). It runs on it from where its crest crossed its throw depth
	* (`throwZ`; with none, from its z now less its pace since τ = 0) until its slice has faded, at touchdown + collapse,
	* and claims its column's crest over the throw's own window meanwhile (BreakingFront).
	*/
	pace(p, times, rayZ, sea, cell, waveHeight) {
		const { solver } = sea;
		const height = waveHeight > 0 ? waveHeight : solver.h[cell] + solver.bed[cell] - solver.restLevel;
		p.jetWindow = 2 * Math.max(0, height);
		const wave = Math.sqrt(GRAVITY$1 * Math.max(0, p.crestDepth + p.height));
		let normal = p.crestSpeed !== void 0 && p.crestSpeed > 0 ? p.crestSpeed : wave;
		if (p.crestSpeed === void 0 || !(p.crestSpeed > 0)) this.counts.paceUnmeasured += 1;
		else if (normal < PACE.slowest * wave) {
			normal = PACE.slowest * wave;
			this.counts.paceSlow += 1;
		} else if (normal > PACE.fastest * wave) {
			normal = PACE.fastest * wave;
			this.counts.paceFast += 1;
		}
		const pace = normal / Math.max(PACE.leastRayZ, rayZ);
		p.crestZ = p.z;
		p.jetPace = pace;
		p.jetBase = p.throwZ ?? p.z - pace * p.tau;
		p.jetUntil = times.touchdownSeconds + times.collapseSeconds;
		p.jetAt = solver.time;
	}
	/** The point's jet leaves the crest, held until it pours (see the class). */
	throwJet(points, start, end, k, s, sea, heightAt, motion, cell, waveHeight, rays) {
		const p = points[k];
		const volume = s.jetArea * s.width * s.endWeight;
		if (!(volume > 0)) {
			p.jetStrip = -1;
			return 0;
		}
		const tau = Math.max(p.tau, s.touchdown);
		const f = this.geometry.slice(points, start, end, k, sea.stillLevel, heightAt, this.foreseen, {
			tau,
			z: p.jetBase + p.jetPace * tau
		}, rays);
		const { strip, thrown } = sea.lip.holdJet({
			cell,
			velocityX: motion.tipAlong * s.rayX,
			velocityZ: motion.tipAlong * s.rayZ,
			volume,
			waveHeight,
			launchX: s.crestX,
			launchY: s.crestY,
			launchZ: s.crestZ,
			pourX: f.landX,
			pourY: f.landY,
			pourZ: f.landZ,
			pourSpacing: s.collapse / 7,
			pourVY: motion.tipUp,
			voidLength: s.voidLength,
			axisX: s.axisX,
			axisY: s.axisY,
			voidHeight: s.voidHeight,
			voidArea: s.voidArea,
			span: s.width * s.endWeight,
			dirX: s.rayX,
			dirZ: s.rayZ,
			crestSpeed: motion.crestSpeed,
			relativeSpeed: motion.tipAlong - motion.crestSpeed
		});
		p.jetStrip = strip;
		this.counts.asked += volume;
		if (strip >= 0) {
			this.counts.throws += 1;
			this.counts.thrown += thrown;
		}
		if (thrown < volume) {
			this.counts.starved += 1;
			this.counts.starvedVolume += volume - thrown;
		}
		return thrown;
	}
	/** A pouring point on this step's crash curve. */
	pour(p, s) {
		const n = this.curve.length;
		const point = this.pool[n] ?? (this.pool[n] = {
			x: 0,
			y: 0,
			z: 0,
			vx: 0,
			vy: 0,
			vz: 0,
			air: 0
		});
		const motion = this.geometry.jetMotion(p, this.motion);
		point.x = s.landX;
		point.y = s.landY;
		point.z = s.landZ;
		point.vx = motion.tipAlong * s.rayX;
		point.vy = motion.tipUp;
		point.vz = motion.tipAlong * s.rayZ;
		const left = s.collapse > 0 ? Math.max(0, 1 - (p.tau - s.touchdown) / s.collapse) : 0;
		point.air = s.voidArea * s.width * s.endWeight * left * left;
		this.curve.push(point);
	}
	/** Room for `count` points' slices, throws and footprints. */
	reserve(count) {
		while (this.slices.length < count) this.slices.push(createCrashSlice());
		if (this.live.length < count) {
			const size = Math.max(count, 2 * this.live.length);
			this.live = new Uint8Array(size);
			this.covered = new Uint8Array(size);
			this.throwing = new Uint8Array(size);
			this.throwCell = new Int32Array(size);
			this.throwHeight = new Float64Array(size);
			this.corners = new Float64Array(8 * size);
			this.boxes = new Float64Array(4 * size);
		}
		this.live.fill(0, 0, count);
		this.covered.fill(0, 0, count);
		this.throwing.fill(0, 0, count);
	}
	/** The current coordinates' arc length, reset at each surviving front's first point, before any plan or width. */
	measureArc(points) {
		for (let k = 0; k < points.length; k += 1) {
			const point = points[k];
			const previous = points[k - 1];
			if (!previous || previous.front !== point.front) point.sigma = 0;
			else {
				const dx = point.x - previous.x;
				const dz = point.z - previous.z;
				point.sigma = previous.sigma + Math.sqrt(dx * dx + dz * dz);
			}
		}
	}
	/**
	* Point k's strip's footprint, as the loft judges overlapping fronts on its strips: the drawn reach, its extensions
	* included, from its anchor along its ray, half its share of the front either side along the front.
	*/
	footprint(k, s) {
		const { corners, boxes } = this;
		const tx = s.rayZ;
		const tz = -s.rayX;
		const half = s.width / 2;
		let c = 8 * k;
		for (const side of [-half, half]) for (const reach of [s.footBack, s.footFront]) {
			corners[c] = s.anchorX + side * tx + reach * s.rayX;
			corners[c + 1] = s.anchorZ + side * tz + reach * s.rayZ;
			c += 2;
		}
		const b = 4 * k;
		boxes[b] = Infinity;
		boxes[b + 1] = -Infinity;
		boxes[b + 2] = Infinity;
		boxes[b + 3] = -Infinity;
		for (let i = 0; i < 4; i += 1) {
			boxes[b] = Math.min(boxes[b], corners[8 * k + 2 * i]);
			boxes[b + 1] = Math.max(boxes[b + 1], corners[8 * k + 2 * i]);
			boxes[b + 2] = Math.min(boxes[b + 2], corners[8 * k + 2 * i + 1]);
			boxes[b + 3] = Math.max(boxes[b + 3], corners[8 * k + 2 * i + 1]);
		}
	}
	/**
	* Overlapping fronts, as the loft drops them (PR 4: the first front wins, in the drawing and the contact alike): a
	* later front's point whose footprint overlaps a live, uncovered point of an earlier front is covered.
	*/
	dropOverlaps(runs) {
		const { boxes } = this;
		const apart = (i, j) => boxes[i + 1] < boxes[j] || boxes[j + 1] < boxes[i] || boxes[i + 3] < boxes[j + 2] || boxes[j + 3] < boxes[i + 2];
		for (let later = 2; later < runs.length; later += 2) for (let earlier = 0; earlier < later; earlier += 2) for (let k = runs[later]; k < runs[later + 1]; k += 1) {
			if (!this.live[k] || this.covered[k]) continue;
			for (let j = runs[earlier]; j < runs[earlier + 1]; j += 1) {
				if (!this.live[j] || this.covered[j] || apart(4 * k, 4 * j) || !this.hullsOverlap(8 * k, 8 * j)) continue;
				this.covered[k] = 1;
				break;
			}
		}
	}
	/** Whether two footprints overlap: the convex hulls of their four corners each, by separating axes (the loft's test). */
	hullsOverlap(a, b) {
		const c = this.corners;
		for (let hull = 0; hull < 2; hull += 1) {
			const base = hull === 0 ? a : b;
			for (let i = 0; i < 4; i += 1) for (let j = i + 1; j < 4; j += 1) {
				const ax = c[base + 2 * i + 1] - c[base + 2 * j + 1];
				const az = c[base + 2 * j] - c[base + 2 * i];
				if (ax === 0 && az === 0) continue;
				let minA = Infinity;
				let maxA = -Infinity;
				let minB = Infinity;
				let maxB = -Infinity;
				for (let k = 0; k < 4; k += 1) {
					const pa = c[a + 2 * k] * ax + c[a + 2 * k + 1] * az;
					const pb = c[b + 2 * k] * ax + c[b + 2 * k + 1] * az;
					minA = Math.min(minA, pa);
					maxA = Math.max(maxA, pa);
					minB = Math.min(minB, pb);
					maxB = Math.max(maxB, pb);
				}
				if (maxA <= minB || maxB <= minA) return false;
			}
		}
		return true;
	}
	/** The point's column, over the drawn curl's footprint: the whitewater waits for its touchdown. */
	gate(p, s, sea) {
		const { solver, whitewater } = sea;
		const { nx, nz, dx, xCenters, zCenters } = solver;
		const column = Math.min(nx - 1, Math.max(0, Math.floor((p.x - xCenters[0]) / dx + .5)));
		const back = s.anchorZ + s.reachBack * s.rayZ;
		const front = s.anchorZ + s.reachFront * s.rayZ;
		const low = Math.min(back, front);
		const high = Math.max(back, front);
		for (let row = solver.rowBelow(low); row < nz && zCenters[row] <= high; row += 1) {
			if (zCenters[row] < low) continue;
			const cell = row * nx + column;
			if (whitewater[cell] !== 0) {
				whitewater[cell] = 0;
				this.counts.gated += 1;
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/SurfZoneSimulation.ts
/** Sea water, kg/m³ (the lip's impact energy for the aeration, G9). */
const WATER_DENSITY = 1025;
/**
* Spots whose barrel is the swept surface (the Padang Padang spec, Part B): their breaking fronts and slice clocks run.
* The owner's switch: a spot with a barrel transect (`BARREL_SPOTS`) is switched on by adding it here (Part B, PR 7).
*/
const SWEPT_BARREL = ["padang"];
/** Whether a sea runs, and draws, the swept barrel: the config's say, else SWEPT_BARREL; never at a spot without a barrel transect. */
function sweptBarrelOn(config) {
	return (config.sweptBarrel ?? SWEPT_BARREL.includes(config.spot)) && BARREL_SPOTS[config.spot] !== void 0;
}
/** A crest joins a breaking front from this share of the edge's wave height above still water (provisional). */
const FRONT_MIN_HEIGHT = .25;
/** Columns at each open along-shore edge where no lip is thrown: the reach of the solver's stencils. */
const OPEN_EDGE_COLUMNS = 2;
/** How far a breaking crest's path is followed for the gradient it climbs, m: past any window's bounds, which end it first. */
const REEF_PATH_REACH = 400;
/** The window's along-shore width, m: the config's, else Padang Padang's own (its peak clear of the side feed), else ALONG_SHORE. */
function alongShoreOf(config) {
	return config.alongShore ?? (config.spot === "padang" ? PADANG.alongShore : config.spot === "pool" ? POOL.alongShore : 160);
}
/**
* Spots that always run stage 2 (the Teahupo'o Reef and Padang Padang specs): shallow water steepens waves far
* too early in the Reef's 30 m water and under Padang Padang's 16–18 s swells, so a machine that cannot keep up
* runs them slower than real time instead.
*/
const STAGE_2_ONLY = [
	"reef",
	"padang",
	"pool"
];
/** The solver stage a spot runs on: the asked one, or 2 where the spot needs it. */
function solverStage(spot, stage) {
	return STAGE_2_ONLY.includes(spot) ? 2 : stage ?? 2;
}
/** Wave-tank layout across shore, m (z increases toward the beach). */
const TANK = {
	offshore: -330,
	zoneInner: -270,
	blendEnd: -190,
	fineFrom: -150,
	shore: 30
};
/** Flat tank bed offshore of each spot's blend, m below datum: Padang Padang's is the deep water beyond its forereef, read live for the sweep. */
const OFFSHORE_DEPTH = {
	beach: 5,
	point: 8,
	reef: REEF.deep,
	canyon: 5,
	get padang() {
		return PADANG.deep;
	},
	get pool() {
		return POOL.feedDepth;
	}
};
/** A big day's edge is this many buoy heights deep, so the zone's linear sea stays near linear (the wave-sizes spec). */
const EDGE_DEPTH_PER_HS = 3.3;
/** …and at most this share of the deep-water wavelength, keeping kh ≤ 2.5 where the solver's dispersion holds. */
const EDGE_DEPTH_MAX_WAVELENGTHS = .4;
/** A deeper tank's relaxation zone is at least this share of the edge wavelength long. */
const ZONE_WAVELENGTHS = .75;
/** The furthest a tank reaches offshore, m. */
const TANK_REACH = -3e3;
/** A bed that gets no more than FLAT_RISE deeper anywhere within FLAT_REACH seaward has levelled off, m: the edge stops there. */
const FLAT_REACH = 300;
const FLAT_RISE = .1;
/**
* The tank for a swell (the wave-sizes spec): today's for small days, Practice and the Canyon; for a big day,
* its edge where the take-off transect's bed first reaches the edge depth (or levels off short of it), and far
* enough out that the blend onto the spot's bed lies 20 m seaward of the fine zone, which starts 40 m seaward
* of where the sets break (Komar–Gaughan's H1/10 over the breaker index). The relaxation zone is at least 60 m
* and 0.75 of the edge wavelength long; the edge takes the bed's depth there, within the kh limit.
*/
function tankLayout(config) {
	const today = {
		...TANK,
		edgeDepth: OFFSHORE_DEPTH[config.spot]
	};
	if (config.spot === "canyon") return today;
	if (config.spot === "pool") return {
		...poolTankLayout(TANK.shore),
		edgeDepth: today.edgeDepth
	};
	if (config.spot === "reef") {
		const zone = Math.max(TANK.zoneInner - TANK.offshore, ZONE_WAVELENGTHS * waveKinematics(config.peakPeriod, today.edgeDepth).wavelength);
		return {
			...today,
			offshore: TANK.zoneInner - zone
		};
	}
	if (config.spot === "padang") {
		const spot = createSpot("padang", config.seed);
		const sets = Math.min(.9 * (today.edgeDepth + config.tide), SETS_OVER_TYPICAL * komarGaughan(config.significantHeight, config.peakPeriod) / BREAKER_INDEX);
		const reach = alongShoreOf(config) / 2;
		let setBreak = TANK.fineFrom + 40;
		for (let x = -reach; x <= reach; x += 5) {
			let z = TANK.shore;
			while (z > TANK_REACH && spot.depthAt(x, z) + config.tide < sets) z -= 1;
			setBreak = Math.min(setBreak, z);
		}
		const fineFrom = Math.min(TANK.fineFrom, setBreak - 40);
		const blend = TANK.blendEnd - TANK.zoneInner;
		const foreFoot = padangForeFootZ() - PADANG.foreRounding;
		const zoneInner = Math.min(fineFrom - 20 - blend, foreFoot - blend);
		return {
			offshore: zoneInner - Math.max(TANK.zoneInner - TANK.offshore, ZONE_WAVELENGTHS * waveKinematics(config.peakPeriod, today.edgeDepth).wavelength),
			zoneInner,
			blendEnd: zoneInner + blend,
			fineFrom,
			shore: TANK.shore,
			edgeDepth: today.edgeDepth
		};
	}
	const deepWavelength = GRAVITY$1 * config.peakPeriod ** 2 / (2 * Math.PI);
	const wanted = Math.max(today.edgeDepth, Math.min(EDGE_DEPTH_PER_HS * config.significantHeight, EDGE_DEPTH_MAX_WAVELENGTHS * deepWavelength));
	if (wanted <= today.edgeDepth) return today;
	const spot = createSpot(config.spot, config.seed);
	const depth = (z) => spot.depthAt(0, z);
	const deepens = (z) => {
		for (let ahead = 10; ahead <= FLAT_REACH; ahead += 10) if (depth(z - ahead) - depth(z) >= FLAT_RISE) return true;
		return false;
	};
	let reached = TANK.zoneInner;
	while (depth(reached) < wanted && reached > TANK_REACH && deepens(reached)) reached -= 1;
	if (Math.min(wanted, depth(reached)) <= today.edgeDepth) return today;
	const setDepth = SETS_OVER_TYPICAL * komarGaughan(config.significantHeight, config.peakPeriod) / BREAKER_INDEX;
	let setBreak = reached;
	while (depth(setBreak) > setDepth && setBreak < TANK.fineFrom) setBreak += 1;
	const fineFrom = Math.min(TANK.fineFrom, setBreak - 40);
	const blend = TANK.blendEnd - TANK.zoneInner;
	const zoneInner = Math.min(reached, fineFrom - 20 - blend);
	const edgeDepth = Math.min(depth(zoneInner), EDGE_DEPTH_MAX_WAVELENGTHS * deepWavelength);
	return {
		offshore: zoneInner - Math.max(TANK.zoneInner - TANK.offshore, ZONE_WAVELENGTHS * waveKinematics(config.peakPeriod, edgeDepth).wavelength),
		zoneInner,
		blendEnd: zoneInner + blend,
		fineFrom,
		shore: TANK.shore,
		edgeDepth
	};
}
/**
* Spots whose tank sides are fed with the incoming sea (the wave-sizes work: open sides drained a directional sea).
* Padang Padang only, for now (the owner, 2026-09-30): its 320 m window and its peak are laid out around the feed, and
* on the other spots the feed is not finished (on a 40 m window it ran the Reef's Big swell to 64 m/s, and it moves
* their take-offs), so they keep main's open sides until the feed's own rollout.
*/
const SIDE_FEED_SPOTS = ["padang"];
/** Kennedy onset per spot (plan Q27): 0.35√(gh) on the barred beach, 0.65√(gh) on plain or steep beds. */
const BREAKING_ONSET = {
	beach: .35,
	point: .65,
	reef: .65,
	canyon: .65,
	padang: .65,
	pool: .65
};
/**
* Foam e-folding times per spot, s (plan §2.4, G4). Dense whitewater decays like
* oceanic whitecap foam, whose effective decay time is 1.4–4.8 s (Callaghan,
* Deane & Stokes 2012). Surfactants stabilise a residual lace for much longer
* (Callaghan et al. 2013, 2017); its times are game values, longest in the
* beach's sandy surf and shortest in the reef's clear water.
*/
const FOAM_DECAY = {
	beach: {
		dense: 3,
		residual: 20
	},
	point: {
		dense: 3,
		residual: 12
	},
	reef: {
		dense: 3,
		residual: 8
	},
	canyon: {
		dense: 3,
		residual: 15
	},
	padang: {
		dense: 3,
		residual: 20
	},
	pool: {
		dense: 3,
		residual: 8
	}
};
/**
* The lip jets of the spots that have their own (the owner, 2026-10-03, on the water-physics advisor's recommendation
* of 2026-09-30); every other spot keeps the slab and `SOURCE_SHARE`.
* - **The Teahupo'o Reef's jet, 0.585 H²,** is the median of the advisor's two periodic Basilisk runs of its ledge:
*   0.55 H² on the 1:4.2 ledge and 0.62 H² on the 1:6, each the jet's area just before the lip lands over the
*   breaking wave's height squared (0.5485 and 0.6224; docs/research/water-physics/notes/round6-tube-profiles/periodic-runs.md,
*   data/periodic_reef42_L12_plunge.json and data/periodic_reef60_L12_plunge.json). It replaces the slab's 0.47 H²
*   (a 0.5 H lip over the void's length, unsourced). The tube (0.43 H², 1.42 and 23°) stays: the runs support it
*   (0.34-0.45 H², 1.5-1.8 at 85 % of the flight).
* - **So the Reef's lip thickens.** A jet lands as a sheet, its water over the void's length (`PlungingLip`), and the
*   void stays about 1 H long in calm air, so the sheet goes from 0.47 H to about 0.58 H (provisional: the jet over its
*   in-flight void; landing over the runs' 1.35 H was tried and not kept, see the report) and each jet lands spread that
*   much wider along its travel. The runs' lip is thinner, 0.41-0.46 H, because they measure it over the tube just
*   before it lands, flattened to 1.2-1.5 H long. A consequence of the owner's call, measured in
*   docs/research/teahupoo-reef-report.md.
* - **The Reef's cap, 0.3, is provisional** (the advisor's inference, not a measurement). The game's broad crest holds about
*   2.6 H² of water in the source window, so a 0.585 H² jet takes a share of about 0.225 of it: over the 0.2 cap,
*   which starved 39-69 % of the 0.47 H² throws on main (docs/research/teahupoo-reef-report.md); 0.3 leaves the
*   biggest waves headroom.
*/
const LIP_JET = { reef: {
	jetArea: .585,
	sourceShare: .3
} };
/**
* Wind shifts breaking onset (plan Q23), as a factor on the breaking thresholds
* like the breaker index γ. With u = U/√(g h_b), positive onshore: γ(1 − 0.10u)
* onshore and γ(1 + 0.05|u|) offshore, clamped to 0.6–1.1. Lab studies (Douglass
* 1990 to U/√(gh) = ±2.3; King & Baker 1996 to ±1.1; reviewed by Zdyrski &
* Feddersen 2022) find onshore wind lowers H_b/h_b by up to ~40 % and offshore
* wind raises it by up to ~10 %, mostly by moving the breaker depth.
*/
function windOnsetScale(windSpeed, breakerDepth) {
	const u = windSpeed / Math.sqrt(GRAVITY$1 * Math.max(.1, breakerDepth));
	return u >= 0 ? Math.max(.6, 1 - .1 * u) : Math.min(1.1, 1 - .05 * u);
}
/**
* Spots that take their swell at the tank's edge, as before the wave-sizes work: the Canyon (its seas are the
* riding reference and Surf School's). The Reef's 30 m edge takes the buoy's deep-water swell shoaled to it.
*/
const EDGE_SWELL_SPOTS = ["canyon", "pool"];
/** The sea's Hs at the tank's edge, m: the buoy's deep-water height shoaled by linear theory, unless given at the edge. */
function edgeHeight(config, edgeDepth = OFFSHORE_DEPTH[config.spot]) {
	if (EDGE_SWELL_SPOTS.includes(config.spot) || config.heightAt === "edge") return config.significantHeight;
	return config.significantHeight * shoalingCoefficient(config.peakPeriod, edgeDepth + config.tide);
}
/**
* The seeded sea a surf zone is built from, at the tank's edge depth. Pure,
* so the renderer can rebuild the same sea (for the far field) outside the worker.
* A deeper tank's sea travels at the stage 2 solver's own (Madsen–Sørensen)
* speeds, so its zone forces the waves the solver carries; today's tanks keep
* the shallow-water numbers they were built with.
*/
function surfZoneSea(config) {
	const tank = tankLayout(config);
	if (config.spot === "pool") return poolSea(edgeHeight(config, tank.edgeDepth), tank.edgeDepth + config.tide, madsenSorensenWaveNumber);
	const deeper = tank.edgeDepth > OFFSHORE_DEPTH[config.spot] && solverStage(config.spot, config.stage) === 2;
	return SeaState.fromSpectrum({
		significantHeight: edgeHeight(config, tank.edgeDepth),
		peakPeriod: config.peakPeriod,
		direction: config.directionDegrees * Math.PI / 180,
		spreading: config.spreading,
		componentCount: config.componentCount ?? 24,
		depth: tank.edgeDepth + config.tide,
		bandwidth: config.bandwidth
	}, config.seed, deeper || STAGE_2_ONLY.includes(config.spot) ? madsenSorensenWaveNumber : shallowWaterWaveNumber);
}
/**
* How each spot finds its take-off transect: straight out from the window's
* centre, or where its bed gathers the swell. A canyon's peak sits beside the
* shadow it casts (as measured over the Scripps canyon, Magne et al. 2007),
* and moves with the swell's direction and period.
*/
const TAKE_OFF = {
	beach: "centre",
	point: "centre",
	reef: "peak",
	canyon: "focus",
	padang: "peak",
	pool: "peak"
};
/**
* The breaker index a big day's take-off is placed with, per spot: the size report measures where each spot's
* sets break and sets these so the take-off lands there (the wave-sizes spec). Today's tanks keep BREAKER_INDEX;
* the Reef's is the Reef rework's to set. The Point's and the Beach's are fitted to their sets' measured breaks at
* 14 s (Point Hs 2–4 m: 1.05–1.16; Beach Hs 2–3 m: 1.08–1.20), before the side feed; they are refitted after it.
* Padang Padang's take-off follows PADANG_TAKE_OFF_INDEX instead.
*/
const TAKE_OFF_INDEX = {
	beach: 1.14,
	point: 1.13,
	reef: BREAKER_INDEX,
	canyon: BREAKER_INDEX,
	padang: BREAKER_INDEX,
	pool: BREAKER_INDEX
};
/**
* Padang Padang's take-off index against the swell's height at its edge, m: on its wedge a bigger set breaks shallower
* for its height, so one index seated Practice's and Small's take-offs where their sets broke but left Medium's 23 m
* and Big's 89 m seaward of theirs. The size report's sets broke, at mid tide, where γ is 0.57, 0.70, 0.90 and 1.20
* for Practice, Small, Medium and Big (Hs at the edge 0.60, 1.18, 2.21 and 3.89 m): a least-squares line through
* them (provisional; refit when the sizes change).
*/
const PADANG_TAKE_OFF_INDEX = {
	intercept: .47,
	perMetre: .19
};
/** Where a peak take-off waits along shore: at the Reef's or Padang Padang's own peak. */
function peakTakeOffX(spot) {
	return spot === "padang" ? PADANG.takeOffX : spot === "pool" ? POOL.takeOffX : REEF.takeOffX;
}
/**
* Where the rider waits for waves: on the spot's take-off transect, where the
* still depth first reaches the shoaled breaker depth. A focus transect is
* where linear rays from the relaxation zone gather most densely at the break
* line (`focusX`), inside the window's open edges.
*/
function takeOffPoint(config) {
	const spot = createSpot(config.spot, config.seed);
	const tank = tankLayout(config);
	const deeper = tank.edgeDepth > OFFSHORE_DEPTH[config.spot];
	const height = edgeHeight(config, tank.edgeDepth);
	const index = config.spot === "padang" ? PADANG_TAKE_OFF_INDEX.intercept + PADANG_TAKE_OFF_INDEX.perMetre * height : deeper ? TAKE_OFF_INDEX[config.spot] : BREAKER_INDEX;
	const target = config.spot === "pool" ? poolBreakDepth(height / Math.SQRT2) : breakerDepthFor(height, tank.edgeDepth + config.tide, index);
	const breakZ = (x) => {
		for (let z = tank.zoneInner; z < tank.shore; z += .5) if (tankDepth(spot, tank.edgeDepth, x, z, tank) + config.tide <= target) return z;
		return tank.fineFrom;
	};
	const reach = Math.max(0, alongShoreOf(config) / 2 - 30);
	if (TAKE_OFF[config.spot] === "centre" || reach === 0) return {
		x: 0,
		z: breakZ(0)
	};
	if (TAKE_OFF[config.spot] === "peak") {
		const x = Math.min(reach, Math.max(-reach, peakTakeOffX(config.spot)));
		return {
			x,
			z: breakZ(x)
		};
	}
	const bed = (x, z) => tankDepth(spot, tank.edgeDepth, x, z, tank) + config.tide;
	const x = focusX(bed, {
		period: config.peakPeriod,
		direction: config.directionDegrees * Math.PI / 180
	}, tank.zoneInner, breakZ(0), -reach, reach);
	return {
		x,
		z: breakZ(x)
	};
}
/**
* Where the swept barrel's front follows crests from, z: the spot's rows (`BarrelSpot.frontFrom`) unless the config says
* (`barrelFrontFrom`): the relaxation zone's inner edge, or the fine zone's first row (Padang Padang's before the
* peak-sizing fix). At Padang Padang's peak, on Practice and Small, the fine
* zone starts 3.7–6 m deep, shallower than the 6–7 m foot band, so crests first seen there were never sized and the
* peak drew no barrel (the advisor, 2026-10-01). No crest is followed seaward of the foot, so what changes is where a
* crest is sized: at the foot itself rather than at the fine zone's first row.
*/
function barrelFrontFrom(config, layout) {
	return (config.barrelFrontFrom ?? BARREL_SPOTS[config.spot]?.frontFrom ?? "zone") === "fine" ? layout.fineFrom : layout.zoneInner;
}
/** Spot seabed with a flat floor under the relaxation zone at the edge depth, blended over the layout's zoneInner…blendEnd. */
function tankDepth(spot, edgeDepth, x, z, layout = TANK) {
	const toSpot = smoothstep$1(layout.zoneInner, layout.blendEnd, z);
	return edgeDepth + (spot.depthAt(x, z) - edgeDepth) * toSpot;
}
const WET$3 = .01;
/**
* Physical surf zone for one spot: a seeded sea enters through an offshore
* relaxation zone into the stretched solver (stage 2 Boussinesq by default,
* stage 1 shallow water on request), which starts from a warm WKB field a
* set's lead time before its peak.
*/
var SurfZoneSimulation = class {
	config;
	spot;
	/** The tank this swell needs (the wave-sizes spec). */
	tank;
	sea;
	solver;
	plan;
	breaking;
	/** Ballistic lip parcels thrown by plunging breakers (plan Q12). */
	lip;
	/** Lip parcels that landed during the latest step: where spray splashes up (G6). */
	lipImpacts = [];
	/** Foam carried by the flow (plan §2.4): made by bores and lip splashes. */
	foam;
	/** G9: the air breaking drives into the water. */
	aeration;
	/** Lip throws so far, and their total volume, m³. */
	lipLaunches = 0;
	lipVolume = 0;
	/** Breaks since the start that threw a plunging jet, and that spilled as a roller (plan P7). */
	lipJets = 0;
	lipRollers = 0;
	/** Each throw, for reports: the jet asked for and thrown, the wave, its void and, for a reef break, its vortex ratio. */
	onThrow;
	peel;
	/** The waves breaking at the take-off, as surf reports measure them (the wave-sizes spec). */
	surf;
	/** Called with every wave measured starting to break, anywhere in the window (reports listen here). */
	onBreak;
	/** The swept barrel's breaking front and its slice clocks, on SWEPT_BARREL spots only. It reads the water, never writes it. */
	front;
	/** Shown slice clocks that paused rather than ran back, since the start (the advisor's check on the onsets' noise). */
	frontPauses = 0;
	/**
	* The swept barrel's jets on its own clock (the Padang Padang spec, Part B, PR 5), at a swept spot given the profile
	* library: they replace Kennedy's lip there, and the whitewater waits for their touchdown.
	*/
	crash;
	/** The breaking the whitewater sees at a swept spot with the crash: withheld over open curls (`SweptCrash`). */
	whitewater;
	crestSamples = [];
	/** When a front's lips throw after the solver's onset: the spot's barrel transect, its foot at the tide (BARREL_SPOTS). */
	onsetTiming;
	/** Where the front follows crests from, z: the fine zone's start, or the relaxation zone's inner edge (`BarrelSpot.frontFrom`). */
	frontFrom;
	lastStepMs = 0;
	/** Latest step's wall time by stage, including the device readback wait in `water`. */
	stepCosts = {
		water: 0,
		breaking: 0,
		front: 0,
		lip: 0,
		foam: 0,
		airSources: 0,
		aeration: 0
	};
	/** Most offshore breaking cell per column last step (Infinity when none). */
	outerBreak;
	/** The first pass only records the spin-up's bores; onsets count from the next step. */
	onsetsArmed = false;
	/** When each column last started a wave that could throw a lip, s. */
	lastThrow;
	/** When each column last started breaking a new wave, s. */
	lastOnset;
	/** Sea time at solver time 0, s: set by the warm start, or taken over with a handed-over sea (spec N1). */
	seaTimeOffset;
	boundary;
	/** The incoming sea fed into the window's sides (the wave-sizes spec): open sides drained a directional sea. */
	sideFeed;
	takeOff;
	mapping;
	/** Per-cell velocity scratch for `writeUniformFlow`. */
	velocityX;
	velocityZ;
	/** Each cell's void fraction, for `writeUniformAeration`. */
	voidFractions;
	/** Foam and aeration move over the same post-water flow; only their field values change between them. */
	advectionStencil = new AdvectionStencil$1();
	/** Solver seconds of spin-up that settle the warm-started sea's nonlinear shape. */
	spinUpSeconds;
	/** `barrel`: the swept barrel's profile library, at a swept spot (the page's cases): the crash runs on it (PR 5). */
	constructor(config, start = "spun-up", barrel) {
		this.config = config;
		this.spot = createSpot(config.spot, config.seed);
		const tank = tankLayout(config);
		this.tank = tank;
		const offshoreDepth = tank.edgeDepth;
		const alongShore = alongShoreOf(config);
		const dx = config.dx ?? 1;
		const grid = {
			nx: Math.round(alongShore / dx),
			xMin: -alongShore / 2,
			dx,
			xBoundary: "open",
			zEdges: stretchedEdges(tank.offshore, tank.shore, tank.fineFrom, config.fineSpacing ?? 1, config.coarseSpacing ?? 4)
		};
		const depthAt = (x, z) => tankDepth(this.spot, offshoreDepth, x, z, tank);
		const onset = config.breakingOnset ?? BREAKING_ONSET[config.spot];
		this.solver = solverStage(config.spot, config.stage) === 2 ? new BoussinesqSolver(grid, depthAt, {
			waterLevel: config.tide,
			breaking: { onset }
		}) : new ShallowWaterSolver(grid, depthAt, { waterLevel: config.tide });
		this.sea = surfZoneSea(config);
		if (this.solver instanceof BoussinesqSolver) this.solver.onsetScale = windOnsetScale(config.windSpeed ?? 0, this.breakerDepth());
		const spinUp = (config.spinUpPeriods ?? 2) * config.peakPeriod;
		this.plan = planSetRun(this.sea, 0, tank.zoneInner, 0, config.lead ?? 25, spinUp);
		this.seaTimeOffset = config.startSeaTime !== void 0 ? config.startSeaTime - spinUp : this.plan.warmStartSeaTime;
		warmStart(this.solver, this.sea, {
			referenceZ: tank.zoneInner,
			seaTime: this.seaTimeOffset
		});
		this.boundary = new SeaStateBoundary(this.solver, this.sea, this.solver.zoneWeightsAlongZ(tank.zoneInner, tank.offshore), this.seaTimeOffset);
		this.solver.addRelaxationZone(this.boundary);
		if (SIDE_FEED_SPOTS.includes(config.spot)) {
			this.sideFeed = new SideFeed(this.solver, this.sea, {
				referenceZ: tank.zoneInner,
				timeOffset: this.seaTimeOffset
			});
			this.solver.addRelaxationZone(this.sideFeed);
		}
		this.spinUpSeconds = spinUp;
		this.breaking = new BreakingModel(this.solver, { onset });
		this.breaking.onsetScale = windOnsetScale(config.windSpeed ?? 0, this.breakerDepth());
		const xCenters = this.solver.xCenters;
		const ridden = config.spot === "reef" ? reefLedgeAt : config.spot === "padang" ? padangReefAt : config.spot === "pool" ? poolRiddenAt : void 0;
		this.peel = new PeelTracker(xCenters, config.peakPeriod, void 0, ridden && ((column) => ridden(xCenters[column])));
		this.outerBreak = new Float64Array(this.solver.nx).fill(Infinity);
		this.lip = new PlungingLip(this.solver, void 0, LIP_JET[config.spot]?.sourceShare);
		this.foam = new FoamField$1(this.solver, config.foamDecay ?? FOAM_DECAY[config.spot]);
		this.aeration = new AerationField$2(this.solver, { period: config.peakPeriod });
		this.lip.onLand = (x, z, volume, vx, vy, vz, flight) => {
			this.foam.addSplash(x, z, volume);
			this.lipImpacts.push({
				x,
				z,
				volume,
				vx,
				vy,
				vz,
				whole: flight?.volume ?? volume,
				kind: flight?.kind ?? 0,
				...flight?.swept ? { y: flight.y } : {}
			});
			const drop = flight ? Math.max(.1, flight.launch.y - flight.y) : 1;
			this.aeration.addPlunge(x, z, .5 * WATER_DENSITY * volume * (vx * vx + vy * vy + vz * vz), AERATION$2.plungeDepth * drop);
			if (this.solver instanceof BoussinesqSolver) {
				const speed = Math.hypot(vx, vz);
				const flown = flight && speed > 0 ? ((x - flight.launch.x) * vx + (z - flight.launch.z) * vz) / speed : Infinity;
				this.solver.holdPlunge(x, z, vx, vz, flight && flight.waveHeight > 0 ? flight.waveHeight : drop, flown);
			}
		};
		this.lip.onAir = (x, z, volume, penetration) => this.aeration.addAir(x, z, volume, penetration);
		this.lastThrow = new Float64Array(this.solver.nx).fill(-Infinity);
		this.lastOnset = new Float64Array(this.solver.nx).fill(-Infinity);
		this.frontFrom = tank.fineFrom;
		if (sweptBarrelOn(config)) {
			const record = BARREL_SPOTS[config.spot];
			this.onsetTiming = onsetTiming(record.footDepth + config.tide, config.peakPeriod, config.barrelLag !== "none", record.onset);
			this.front = new BreakingFront(config.fineSpacing ?? 1, this.onsetTiming, config.barrelFront ?? record.front);
			this.frontFrom = barrelFrontFrom(config, tank);
			const slope = BARREL_SLOPE[config.spot];
			if (barrel && slope !== void 0 && config.sweptCrash !== false) {
				this.crash = new SweptCrash(barrel, slope);
				this.whitewater = new Float64Array(this.solver.h.length);
			}
		}
		const takeOff = this.breakPoint();
		this.surf = new SurfMeter([{
			xMin: takeOff.x - 10,
			xMax: takeOff.x + 10
		}], config.peakPeriod);
		if (start === "spun-up") {
			while (this.spinUpLeft() > 0) this.solver.step(this.spinUpStep());
			this.breaking.update(0);
		}
	}
	/**
	* Spin a `'warm'`-built surf zone up: on its device when it has one (the GPU
	* is several times faster), else on the CPU. A failing device is dropped and
	* the CPU finishes from where it stopped.
	*/
	async spinUp() {
		while (this.spinUpLeft() > 0) {
			const dt = this.spinUpStep();
			const { device } = this;
			if (!device) {
				this.solver.step(dt);
				continue;
			}
			try {
				await device.step(dt);
			} catch (error) {
				console.warn("Surf zone device failed during the spin-up; finishing it on the CPU.", error);
				device.dispose();
				this.device = void 0;
				this.solver.step(dt);
			}
		}
		this.breaking.update(0);
	}
	spinUpLeft() {
		return this.spinUpSeconds - 1e-9 - this.solver.time;
	}
	/**
	* The next spin-up step: one substep at the CFL limit, re-checked every time. A trough draining a
	* shallow reef can shrink the stable step fivefold within a quarter second, and a stale bound diverges.
	*/
	spinUpStep() {
		return Math.min(this.solver.maxStableStep(), this.spinUpSeconds - this.solver.time);
	}
	/** The arrays that carry the sea's history (the handover's state probe found them; spec N1), by name. */
	stateArrays() {
		const { solver } = this;
		const arrays = {
			h: solver.h,
			qx: solver.qx,
			qz: solver.qz,
			"foam.dense": this.foam.dense,
			"foam.residual": this.foam.residual,
			"aeration.air": this.aeration.air,
			"aeration.depth": this.aeration.depth,
			outerBreak: this.outerBreak,
			lastThrow: this.lastThrow,
			lastOnset: this.lastOnset
		};
		if (solver instanceof BoussinesqSolver) {
			arrays.breakingStrength = solver.breakingStrength;
			arrays.breakingAge = solver.breakingAge;
			arrays.plungeHold = solver.plungeHold;
			const { predictor } = solver;
			if (predictor) {
				arrays["predictor.x"] = predictor.x;
				arrays["predictor.z"] = predictor.z;
			}
		}
		return arrays;
	}
	/**
	* This sea's state for a player joining the room late (spec N1: the sea
	* handover): the water, its breaking and foam, the lip in the air, and the
	* clock, copied. A sea built from the same room config and given it with
	* `importState` steps on exactly as this one does.
	*/
	exportState() {
		const arrays = Object.fromEntries(Object.entries(this.stateArrays()).map(([name, array]) => [name, array.slice()]));
		return {
			nx: this.solver.nx,
			nz: this.solver.nz,
			solverTime: this.solver.time,
			seaTimeOffset: this.seaTimeOffset,
			arrays,
			counters: {
				lipLaunches: this.lipLaunches,
				lipVolume: this.lipVolume,
				lipJets: this.lipJets,
				lipRollers: this.lipRollers,
				onsetsArmed: this.onsetsArmed
			},
			lip: this.lip.exportState(),
			...this.front ? { front: this.front.exportState() } : {}
		};
	}
	/** Takes over another player's sea (`exportState`): this sea must be built from the same room config. */
	importState(state) {
		const { solver } = this;
		if (state.nx !== solver.nx || state.nz !== solver.nz) throw new Error(`A sea state from another tank (${state.nx}×${state.nz}, not ${solver.nx}×${solver.nz})`);
		const arrays = this.stateArrays();
		for (const [name, values] of Object.entries(state.arrays)) {
			const target = arrays[name];
			if (!target || target.length !== values.length) throw new Error(`A sea state from another tank: ${name} does not fit`);
			target.set(values);
		}
		this.aeration.turbulence.fill(0);
		solver.time = state.solverTime;
		this.onsetsArmed = state.counters.onsetsArmed ?? state.solverTime > 0;
		this.surf.clear();
		this.seaTimeOffset = state.seaTimeOffset;
		this.boundary.timeOffset = state.seaTimeOffset;
		if (this.sideFeed) this.sideFeed.timeOffset = state.seaTimeOffset;
		this.lipLaunches = state.counters.lipLaunches;
		this.lipVolume = state.counters.lipVolume;
		this.lipJets = state.counters.lipJets;
		this.lipRollers = state.counters.lipRollers;
		this.lip.importState(state.lip);
		this.front?.importState(state.front ?? {
			nextId: 0,
			nextFront: 0,
			points: [],
			held: [],
			tracks: []
		});
		if (solver instanceof BoussinesqSolver) solver.invalidateDeviceLayout();
	}
	get seaTime() {
		return this.solver.time + this.seaTimeOffset;
	}
	/** Seconds until the planned set peaks at the offshore zone line (negative once it has passed). */
	get timeToSet() {
		return this.plan.setPeakSeaTime - this.seaTime;
	}
	get windowXMin() {
		return this.solver.xCenters[0] - .5 * this.solver.dx;
	}
	/** Steps the water on a device instead of the CPU solver, when set (`stepAsync`). */
	device;
	step(dt) {
		const start = performance.now();
		this.lipImpacts.length = 0;
		this.solver.step(dt);
		this.afterWater(dt, start);
	}
	/** `step` with the water on the device when there is one; a failing device is dropped for the CPU solver. */
	async stepAsync(dt) {
		const { device } = this;
		if (!device) {
			this.step(dt);
			return;
		}
		const start = performance.now();
		this.lipImpacts.length = 0;
		try {
			await device.step(dt);
		} catch (error) {
			console.warn("Surf zone device step failed; stepping on the CPU from here.", error);
			device.dispose();
			this.device = void 0;
			this.solver.step(dt);
		}
		this.afterWater(dt, start);
	}
	/** Everything a step does once the water has moved: breaking, lip, foam. */
	afterWater(dt, start) {
		let phase = performance.now();
		this.stepCosts.water = phase - start;
		this.breaking.update(dt);
		this.markBreakingOnsets();
		let end = performance.now();
		this.stepCosts.breaking = end - phase;
		phase = end;
		this.advanceFront();
		end = performance.now();
		this.stepCosts.front = end - phase;
		phase = end;
		this.lip.step(dt);
		end = performance.now();
		this.stepCosts.lip = end - phase;
		phase = end;
		this.foam.update(dt, this.whitewaterStrength, this.advectionStencil);
		end = performance.now();
		this.stepCosts.foam = end - phase;
		phase = end;
		this.aerateBores(dt);
		end = performance.now();
		this.stepCosts.airSources = end - phase;
		phase = end;
		this.aeration.update(dt, this.advectionStencil);
		end = performance.now();
		this.stepCosts.aeration = end - phase;
		this.lastStepMs = end - start;
	}
	/** The swept barrel's front (Part B): the crests breaking in the fine zone, linked into lines, and their clocks. */
	advanceFront() {
		const { front, solver } = this;
		if (!front) return;
		const minHeight = FRONT_MIN_HEIGHT * edgeHeight(this.config, this.tank.edgeDepth);
		const count = columnCrests(solver, this.breaking, solver.rowBelow(this.frontFrom), minHeight, this.crestSamples);
		front.update(this.crestSamples, count, solver.time);
		this.frontPauses += advanceClocks(front.points, solver.time, this.onsetTiming);
		if (this.crash) {
			const { throws, volume } = this.crash.update(front.points, {
				solver,
				lip: this.lip,
				stillLevel: solver.restLevel,
				period: this.config.peakPeriod,
				strength: this.breaking.strength,
				whitewater: this.whitewater
			});
			this.lipLaunches += throws;
			this.lipJets += throws;
			this.lipVolume += volume;
		}
	}
	/**
	* The breaking the whitewater sees: the foam's bore source (and the spray and bubbles it drives), the bore's air and
	* turbulence, and the roar. At a swept spot with the crash it waits, over each open curl, for the barrel's touchdown
	* (PR 5); anywhere else it is the solver's own.
	*/
	get whitewaterStrength() {
		return this.whitewater ?? this.breaking.strength;
	}
	/** Still depth where the shoaled swell breaks, h_b = (Hs·D^¼/γ)^⅘, m. */
	breakerDepth() {
		return breakerDepthFor(edgeHeight(this.config, this.tank.edgeDepth), this.sea.depth);
	}
	/** Bore speed at the break, √(g h_b), m/s. */
	breakerCelerity() {
		return Math.sqrt(GRAVITY$1 * this.breakerDepth());
	}
	/** Breaker-point Iribarren number from the bed slope at the break line and H_b = γ h_b. */
	iribarren() {
		const point = this.breakPoint();
		const bed = (z) => tankDepth(this.spot, this.tank.edgeDepth, point.x, z, this.tank);
		const slope = Math.abs(bed(point.z - 2) - bed(point.z + 2)) / 4;
		const depth = this.breakerDepth();
		const overCrest = submergedCrest((ahead) => bed(point.z + ahead) + this.config.tide, depth, slope);
		const readout = describeSwell({
			height: BREAKER_INDEX * depth,
			period: this.config.peakPeriod,
			depth,
			bedSlope: slope,
			submergedCrest: overCrest
		});
		return {
			value: readout.iribarren,
			type: readout.breakerType
		};
	}
	peelEstimate() {
		return this.peel.estimate(this.solver.time, this.breakerCelerity());
	}
	/** Share of wet surf-zone cells breaking with B > 0.3. */
	breakingFraction() {
		const { solver } = this;
		let wet = 0;
		let breaking = 0;
		for (let iz = solver.rowBelow(this.tank.fineFrom); iz < solver.nz; iz += 1) for (let ix = 0; ix < solver.nx; ix += 1) {
			const i = iz * solver.nx + ix;
			if (solver.h[i] <= WET$3) continue;
			wet += 1;
			if (this.breaking.strength[i] > .3) breaking += 1;
		}
		return wet > 0 ? breaking / wet : 0;
	}
	/**
	* A new wave starts breaking in a column when its most offshore breaking cell
	* jumps seaward by more than 5 m. Bores still crossing the inner surf zone
	* therefore do not hide the next onset.
	*/
	markBreakingOnsets() {
		const { solver } = this;
		const firstRow = solver.rowBelow(this.tank.fineFrom);
		for (let column = 0; column < solver.nx; column += 1) {
			let outer = Infinity;
			let row = -1;
			for (let iz = firstRow; iz < solver.nz; iz += 1) if (this.breaking.strength[iz * solver.nx + column] > .3) {
				outer = solver.zCenters[iz];
				row = iz;
				break;
			}
			const previous = this.outerBreak[column];
			this.outerBreak[column] = outer;
			if (this.onsetsArmed && outer < previous - 5 && this.newBreaker(column, row)) {
				this.lastOnset[column] = solver.time;
				this.peel.markOnset(column, solver.time, outer);
				this.measureBreak(column, row);
				this.throwLip(column, row);
			}
		}
		this.onsetsArmed = true;
	}
	/** Where each column's outermost breaking cell lies across shore, z (Infinity when the column is not breaking). */
	outerBreakZ(column) {
		return this.outerBreak[column];
	}
	/**
	* Whether a column's break at `row` starts a new wave: at most one per
	* 0.7 Tp, and only where the still depth is at least 0.4 h_b. Shallower
	* first breaks are swash bores reaching the shore after a lull; counting
	* them read every spot's peel as mixed peaks.
	*/
	newBreaker(column, row) {
		const { solver } = this;
		if (solver.time - this.lastOnset[column] < .7 * this.config.peakPeriod) return false;
		return solver.restLevel - solver.bed[row * solver.nx + column] >= .4 * this.breakerDepth();
	}
	/**
	* Measure a wave starting to break in `column` (the wave-sizes spec): its crest is the highest surface up to
	* four cells seaward of the outermost breaking cell, as for the lip, and its face runs from that crest to the
	* lowest water within half a wavelength ahead (√(g h) Tp / 2 at the crest's still depth).
	*/
	measureBreak(column, row) {
		const { solver } = this;
		const { nx } = solver;
		let crest = row * nx + column;
		for (let iz = row - 1; iz >= Math.max(1, row - 4); iz -= 1) if (solver.surfaceAt(iz * nx + column) > solver.surfaceAt(crest)) crest = iz * nx + column;
		const stillDepth = Math.max(WET$3, solver.restLevel - solver.bed[crest]);
		const wave = {
			time: solver.time,
			x: solver.xCenters[column],
			z: solver.zCenters[Math.floor(crest / nx)],
			face: waveHeightAt(solver, crest, .5 * this.config.peakPeriod * Math.sqrt(GRAVITY$1 * stillDepth))
		};
		this.surf.add(wave);
		this.onBreak?.(wave);
	}
	/**
	* Throw a lip where a new wave starts breaking in `column`, if the local
	* breaker-point Iribarren number says plunging. The crest is the highest
	* surface up to four cells seaward of the outermost breaking cell; H_b = γ h
	* there, and the slope is the local bed gradient. A column throws at most once
	* per 0.7 Tp (one wave), and only where the still depth is at least 0.4 h_b:
	* shallower first breaks are swash bores reaching the shore after a lull, not
	* new breakers, and a lip there would carry almost no water (volume ∝ H²).
	*/
	throwLip(column, row) {
		if (this.crash) {
			this.crash.counts.onsets += 1;
			return;
		}
		const { solver } = this;
		const { nx, nz, bed, zCenters } = solver;
		if (solver.time - this.lastThrow[column] < .7 * this.config.peakPeriod) return;
		if (column < OPEN_EDGE_COLUMNS || column >= nx - OPEN_EDGE_COLUMNS) return;
		let crest = row * nx + column;
		for (let iz = row - 1; iz >= Math.max(1, row - 4); iz -= 1) if (solver.surfaceAt(iz * nx + column) > solver.surfaceAt(crest)) crest = iz * nx + column;
		const crestRow = Math.floor(crest / nx);
		const stillDepth = solver.restLevel - bed[crest];
		if (!(stillDepth >= .4 * this.breakerDepth()) || crestRow < 1 || crestRow > nz - 2) return;
		this.lastThrow[column] = solver.time;
		const slopeZ = (bed[crest + nx] - bed[crest - nx]) / (zCenters[crestRow + 1] - zCenters[crestRow - 1]);
		const slopeX = column > 0 && column < nx - 1 ? (bed[crest + 1] - bed[crest - 1]) / (2 * solver.dx) : 0;
		const breakerHeight = BREAKER_INDEX * stillDepth;
		const deepWavelength = GRAVITY$1 * this.config.peakPeriod ** 2 / (2 * Math.PI);
		const slope = Math.hypot(slopeX, slopeZ);
		const x = solver.xCenters[column];
		const overCrest = submergedCrest((ahead) => solver.restLevel - solver.sampleCentered(bed, x, zCenters[crestRow] + ahead), stillDepth, Math.abs(slopeZ));
		const iribarren = slope / Math.sqrt(breakerHeight / deepWavelength);
		let motion;
		let height = 0;
		let orthogonal;
		if (overCrest && iribarren >= .4) {
			motion = crestMotion(solver, crest);
			if (!motion) return;
			height = this.breakingWaveHeight(crest, motion);
			const gradient = this.orthogonalGradient(x, zCenters[crestRow], motion, height);
			if (reefOverturn(gradient, edgeHeight(this.config, this.tank.edgeDepth) / (this.tank.edgeDepth + this.config.tide))) orthogonal = gradient;
		}
		const form = orthogonal !== void 0 ? "jet" : breakerForm(iribarren);
		if (form === "roller") this.lipRollers += 1;
		if (form !== "jet") return;
		if (!motion) {
			motion = crestMotion(solver, crest);
			if (!motion) return;
			height = this.breakingWaveHeight(crest, motion);
		}
		const shape = lipThrow({
			iribarren,
			slope,
			nonlinearity: edgeHeight(this.config, this.tank.edgeDepth) / (this.tank.edgeDepth + this.config.tide),
			breakerHeight: height,
			windOverCelerity: (this.config.windSpeed ?? 0) / Math.sqrt(GRAVITY$1 * stillDepth),
			width: solver.dx,
			reef: orthogonal !== void 0 ? {
				orthogonalGradient: orthogonal,
				jetArea: LIP_JET[this.config.spot]?.jetArea
			} : void 0
		});
		if (!shape) return;
		const speed = motion.speed + shape.relativeSpeed;
		const along = motion.direction;
		const thrown = this.lip.launch(crest, {
			x: along.x * speed,
			z: along.z * speed
		}, solver.surfaceAt(crest), shape.volume, motion.speed, tubeGeometry(shape.shape, height), jetFlightTime(shape.shape, height), height);
		this.onThrow?.({
			asked: shape.volume,
			thrown,
			height,
			x,
			tube: tubeGeometry(shape.shape, height),
			vortexRatio: shape.reef?.vortexRatio,
			orthogonalGradient: orthogonal,
			speedOverCrest: speed / motion.speed
		});
		if (thrown > 0) {
			this.lipLaunches += 1;
			this.lipJets += 1;
			this.lipVolume += thrown;
		}
	}
	/** The overturn scales with the wave the solver has: its crest over the trough half a wavelength ahead. */
	breakingWaveHeight(crest, motion) {
		return waveHeightAt(this.solver, crest, .5 * motion.speed * this.config.peakPeriod);
	}
	/**
	* The gradient a breaking crest climbs, as Mead & Black (2001) measured it: along its travel, across the band
	* about its breaking depth (H / 0.78), over the window's own seabed (not the level strips at its open edges).
	*/
	orthogonalGradient(x, z, motion, height) {
		const { solver } = this;
		const { nx, nz, xCenters, zCenters, bed, dx } = solver;
		const [west, east] = [xCenters[2], xCenters[nx - 1 - 2]];
		const [south, north] = [zCenters[0], zCenters[nz - 1]];
		const { direction } = motion;
		const depthAhead = (s) => {
			const px = x + s * direction.x;
			const pz = z + s * direction.z;
			return px < west || px > east || pz < south || pz > north ? NaN : solver.restLevel - solver.sampleCentered(bed, px, pz);
		};
		return orthogonalGradient(depthAhead, height / BREAKER_INDEX, .5 * dx, REEF_PATH_REACH);
	}
	/** The flying tubes as a `tubeTable` (G9); returns how many. */
	writeTubes(into) {
		return this.lip.writeTubes(into, 256);
	}
	/** The width of the columns the lip throws in, m. */
	get tubeColumnWidth() {
		return this.solver.dx;
	}
	/** Water surface elevation, m; on dry land this is the bed. */
	heightAt(x, z) {
		return this.lip.carve(x, z, this.solver.sampleCentered(this.solver.h, x, z) + this.bedAt(x, z));
	}
	bedAt(x, z) {
		return this.solver.sampleCentered(this.solver.bed, x, z);
	}
	/** Uniform render grid covering the window and the whole tank. */
	renderGrid(spacing) {
		const width = this.solver.nx * this.solver.dx;
		return {
			xMin: this.windowXMin,
			zMin: this.tank.offshore,
			spacing,
			nx: Math.round(width / spacing) + 1,
			nz: Math.round((this.tank.shore - this.tank.offshore) / spacing) + 1
		};
	}
	/**
	* Resample the water to interleaved (height, foam) per render node. Dry nodes
	* sit 5 cm under the bed so the seabed mesh hides them. Foam is the foam
	* field's covered fraction. Under a flying lip the surface drops to its
	* void's floor, unless `carve` is false (the snapshot's raw heights, G9: the
	* page carves them from the tube table).
	*/
	writeUniformSurface(data, grid, carve = true) {
		this.writeUniformFields(grid, data);
		if (carve) carveGrid(data, grid, this.lip.tubeTable, this.lip.tubeCount, this.solver.dx);
	}
	/** The worker's three visual fields share the same interpolation and one pass over the render nodes. */
	writeUniformSnapshot(surface, flow, aeration, grid) {
		this.writeUniformFields(grid, surface, flow, aeration);
	}
	/** G9: every breaking bore drives air in by its dissipation, spilling shallower than a plunge. */
	aerateBores(dt) {
		const { h, bed, restLevel } = this.solver;
		const strength = this.whitewaterStrength;
		const { breakingCells, breakingCount, dissipation } = this.foam;
		for (let n = 0; n < breakingCount; n += 1) {
			const i = breakingCells[n];
			const still = restLevel - bed[i];
			if (dissipation[i] > 0) this.aeration.addBore(i, dissipation[i], h[i] - still, dt);
			this.aeration.stir(i, strength[i], dt);
		}
	}
	/** G9: resample the aeration to interleaved (void fraction, plume depth, m) per render node; 0 on dry nodes. */
	writeUniformAeration(data, grid) {
		this.writeUniformFields(grid, void 0, void 0, data);
	}
	/** Resample the depth-averaged current to interleaved (u, w) per render node, m/s; 0 on dry nodes. */
	writeUniformFlow(data, grid) {
		this.writeUniformFields(grid, void 0, data);
	}
	writeUniformFields(grid, surface, flow, aeration) {
		const { columns, columnWeights, rows, rowWeights } = this.mappingFor(grid);
		const { h, bed, qx, qz, nx } = this.solver;
		const { dense, residual } = this.foam;
		const plume = this.aeration.depth;
		if (flow && (!this.velocityX || this.velocityX.length !== h.length)) {
			this.velocityX = new Float64Array(h.length);
			this.velocityZ = new Float64Array(h.length);
		}
		if (aeration && (!this.voidFractions || this.voidFractions.length !== h.length)) this.voidFractions = new Float64Array(h.length);
		const u = this.velocityX;
		const w = this.velocityZ;
		const fraction = this.voidFractions;
		if (flow || aeration) for (let i = 0; i < h.length; i += 1) {
			if (flow) {
				const wet = h[i] > WET$3;
				u[i] = wet ? qx[i] / h[i] : 0;
				w[i] = wet ? qz[i] / h[i] : 0;
			}
			if (aeration) fraction[i] = this.aeration.voidFraction(i);
		}
		for (let r = 0; r < grid.nz; r += 1) {
			const row = rows[r] * nx;
			const tz = rowWeights[r];
			for (let c = 0; c < grid.nx; c += 1) {
				const i = row + columns[c];
				const tx = columnWeights[c];
				const w00 = (1 - tx) * (1 - tz);
				const w10 = tx * (1 - tz);
				const w01 = (1 - tx) * tz;
				const w11 = tx * tz;
				const o = (r * grid.nx + c) * 2;
				const depth = surface || flow ? h[i] * w00 + h[i + 1] * w10 + h[i + nx] * w01 + h[i + nx + 1] * w11 : 0;
				if (surface) {
					const bottom = bed[i] * w00 + bed[i + 1] * w10 + bed[i + nx] * w01 + bed[i + nx + 1] * w11;
					surface[o] = depth > WET$3 ? depth + bottom : bottom - .05;
					surface[o + 1] = depth > WET$3 ? (dense[i] + residual[i]) * w00 + (dense[i + 1] + residual[i + 1]) * w10 + (dense[i + nx] + residual[i + nx]) * w01 + (dense[i + nx + 1] + residual[i + nx + 1]) * w11 : 0;
				}
				if (flow) {
					flow[o] = depth > WET$3 ? u[i] * w00 + u[i + 1] * w10 + u[i + nx] * w01 + u[i + nx + 1] * w11 : 0;
					flow[o + 1] = depth > WET$3 ? w[i] * w00 + w[i + 1] * w10 + w[i + nx] * w01 + w[i + nx + 1] * w11 : 0;
				}
				if (aeration) {
					aeration[o] = w00 * fraction[i] + w10 * fraction[i + 1] + w01 * fraction[i + nx] + w11 * fraction[i + nx + 1];
					aeration[o + 1] = w00 * plume[i] + w10 * plume[i + 1] + w01 * plume[i + nx] + w11 * plume[i + nx + 1];
				}
			}
		}
	}
	/** Resample the bed elevation to one value per render node, with the same interpolation as `writeUniformSurface`. */
	writeUniformBed(data, grid) {
		const { columns, columnWeights, rows, rowWeights } = this.mappingFor(grid);
		const { bed, nx } = this.solver;
		for (let r = 0; r < grid.nz; r += 1) {
			const row = rows[r] * nx;
			const tz = rowWeights[r];
			for (let c = 0; c < grid.nx; c += 1) {
				const i = row + columns[c];
				const tx = columnWeights[c];
				data[r * grid.nx + c] = (bed[i] * (1 - tx) + bed[i + 1] * tx) * (1 - tz) + (bed[i + nx] * (1 - tx) + bed[i + nx + 1] * tx) * tz;
			}
		}
	}
	/** The take-off: where the break line crosses the spot's take-off transect (see `takeOffPoint`), the camera's break focus. */
	breakPoint() {
		this.takeOff ??= takeOffPoint(this.config);
		return { ...this.takeOff };
	}
	mappingFor(grid) {
		const { solver } = this;
		let mapping = this.mapping;
		if (!mapping || mapping.grid.nx !== grid.nx || mapping.grid.nz !== grid.nz || mapping.grid.spacing !== grid.spacing || mapping.grid.zMin !== grid.zMin) {
			const rows = new Int32Array(grid.nz);
			const rowWeights = new Float64Array(grid.nz);
			for (let r = 0; r < grid.nz; r += 1) {
				const z = grid.zMin + r * grid.spacing;
				const iz = solver.rowBelow(z);
				rows[r] = iz;
				rowWeights[r] = Math.min(1, Math.max(0, (z - solver.zCenters[iz]) / (solver.zCenters[iz + 1] - solver.zCenters[iz])));
			}
			mapping = {
				grid: { ...grid },
				xMin: NaN,
				columns: new Int32Array(grid.nx),
				columnWeights: new Float64Array(grid.nx),
				rows,
				rowWeights
			};
			this.mapping = mapping;
		}
		if (mapping.xMin !== grid.xMin) {
			for (let c = 0; c < grid.nx; c += 1) {
				const gx = Math.min(solver.nx - 1, Math.max(0, (grid.xMin + c * grid.spacing - solver.xCenters[0]) / solver.dx));
				const ix = Math.min(solver.nx - 2, Math.floor(gx));
				mapping.columns[c] = ix;
				mapping.columnWeights[c] = gx - ix;
			}
			mapping.xMin = grid.xMin;
		}
		return mapping;
	}
};
//#endregion
//#region ../../../../../private/tmp/coarse-foam-coverage-20261004/oracle/src/wave/surfZoneState.ts
const MAGIC = 1397052465;
function decodeSurfZoneState(bytes) {
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	if (bytes.byteLength < 8 || view.getUint32(0, true) !== MAGIC) throw new Error("Not a sea state");
	const length = view.getUint32(4, true);
	const header = JSON.parse(new TextDecoder().decode(bytes.subarray(8, 8 + length)));
	const start = 8 + Math.ceil(length / 4) * 4;
	const floats = new Float32Array(bytes.slice(start).buffer);
	const arrays = {};
	let offset = 0;
	for (const [name, count] of header.arrays) {
		if (offset + count > floats.length) throw new Error("A truncated sea state");
		arrays[name] = floats.subarray(offset, offset + count);
		offset += count;
	}
	return {
		...header,
		arrays
	};
}
//#endregion
//#region ../../../../../private/tmp/aeration-last-argument-cache-20261004/dispersion.ts
/** Linear (Airy) water-wave dispersion, ω² = g k tanh(kh), in SI units. */
const GRAVITY = 9.81;
//#endregion
//#region ../../../../../private/tmp/aeration-last-argument-cache-20261004/AerationField.original.ts
/**
* The air breaking drives into the water (G9), from `docs/research/whitewater-sources.md`:
* - `share` (β): share of the dissipated energy spent entraining air against buoyancy, 4–14 % in
*   surf-zone breakers (Blenkinsopp & Chaplin 2007);
* - `plungeDepth` (κ_p) and `boreDepth` (κ_s): plume depth per breaker or bore height (provisional);
* - `riseSpeed` (w_b): bubbles of radius above 0.5 mm rise at 0.2–0.3 m/s (Deane & Stokes 2002);
* - `peak` (α_max): the most air a surf-zone plume holds, about 20 % under plunging breakers
*   (Blenkinsopp & Chaplin 2007). Air driven in beyond it vents at once.
*/
const AERATION$1 = {
	share: .1,
	plungeDepth: .8,
	boreDepth: .3,
	riseSpeed: .25,
	peak: .2
};
/**
* The plume's turbulence (the wipeout spec, Part B), provisional:
* - under breaking of strength B in water h deep, the turbulent kinetic energy k
*   relaxes over `rise` s toward (ratio · √(g h))² · B: Ting & Kirby (1995,
*   1996) measured √k / √(g h) of about 0.1–0.2 under broken waves;
* - once the breaking has passed it fades with an e-folding time of
*   `decayShare` of the peak period, so it is all but gone within one period
*   (plunging breakers dissipate their turbulence within about one wave period);
* - it is carried by the current like the air.
*/
const TURBULENCE$1 = {
	ratio: .15,
	rise: .5,
	decayShare: 1 / 3
};
const DENSITY$1 = 1025;
const WET$2 = .01;
const TRACE$2 = 1e-7;
/** A plume spreads to the rows either side of where it lands. */
const ACROSS$1 = [-1, 1];
/** Plumes thinner than this still degas at this depth's rate, m (a numerical floor). */
const MIN_DEPTH$1 = .05;
/**
* Entrained air on the solver grid (G9): per cell, the air it holds per unit
* area (m³/m², its depth if it were one layer) and the plume's depth. Air
* enters where lip water lands (a share of the impact's energy spent against
* buoyancy, carried down to half the plunge's depth on average), where bores
* dissipate, and where trapped tubes break into bubbles. A plunge's or a
* tube's bubbles fill a plume as wide as it is deep (provisional). It is carried by the
* current semi-Lagrangian, like the foam, and degasses as its bubbles rise
* out of the plume. It never feeds back into the water.
*/
var AerationField$1 = class {
	solver;
	air;
	depth;
	/** The turbulent kinetic energy in each cell's water, m²/s² (`TURBULENCE`). */
	turbulence;
	nextAir;
	nextDepth;
	nextTurbulence;
	/** Cells breaking stirred since the latest update: they hold their turbulence rather than fade. */
	stirred;
	windowX;
	period;
	stirDt = NaN;
	stirGain = 0;
	/** `period`: the swell's peak period, s, which sets how fast the turbulence fades. */
	constructor(solver, options = {}) {
		this.solver = solver;
		const size = solver.h.length;
		this.air = new Float64Array(size);
		this.depth = new Float64Array(size);
		this.turbulence = new Float64Array(size);
		this.nextAir = new Float64Array(size);
		this.nextDepth = new Float64Array(size);
		this.nextTurbulence = new Float64Array(size);
		this.stirred = new Uint8Array(size);
		this.windowX = solver.xCenters[0];
		this.period = options.period ?? 10;
	}
	/** Breaking of strength `strength` (0–1) in `cell` for `dt` s stirs its water toward Ting & Kirby's intensity. */
	stir(cell, strength, dt) {
		this.followWindow();
		const depth = this.solver.h[cell];
		if (!(depth > WET$2) || !(strength > 0)) return;
		this.stirred[cell] = 1;
		const target = (TURBULENCE$1.ratio * Math.sqrt(GRAVITY * depth)) ** 2 * Math.min(1, strength);
		if (target > this.turbulence[cell]) {
			if (dt !== this.stirDt) {
				this.stirDt = dt;
				this.stirGain = 1 - Math.exp(-dt / TURBULENCE$1.rise);
			}
			this.turbulence[cell] += (target - this.turbulence[cell]) * this.stirGain;
		}
	}
	/** A plunge that dissipated `energy` J at (x, z), driving its bubbles `penetration` m down. */
	addPlunge(x, z, energy, penetration) {
		this.followWindow();
		const cell = this.solver.cellIndex(x, z);
		const reach = this.reach(cell, penetration);
		if (!(reach > 0) || !(energy > 0)) return;
		this.spread(x, z, AERATION$1.share * energy / (DENSITY$1 * GRAVITY * (reach / 2)), reach);
	}
	/**
	* A bore dissipating `dissipation` (energy per unit crest length over ρ,
	* m⁴/s³, `boreDissipation`) for `dt` s in `cell`, `height` m high: β of the
	* energy its cell's width of crest loses, as air held against buoyancy at
	* half the plume's depth (the cell holds it, where the bore dissipates).
	*/
	addBore(cell, dissipation, height, dt) {
		this.followWindow();
		const reach = this.reach(cell, AERATION$1.boreDepth * height);
		if (!(reach > 0) || !(dissipation > 0)) return;
		this.addTo(cell, AERATION$1.share * dissipation * dt * this.solver.dx / (GRAVITY * (reach / 2)), reach);
	}
	/** Trapped air of `volume` m³ broken into bubbles at (x, z), `penetration` m down. */
	addAir(x, z, volume, penetration) {
		this.followWindow();
		const cell = this.solver.cellIndex(x, z);
		const reach = this.reach(cell, penetration);
		if (!(reach > 0) || !(volume > 0)) return;
		this.spread(x, z, volume, reach);
	}
	/** The void fraction the plume holds: its air over its depth, 0 … 1. */
	voidFraction(cell) {
		const depth = this.depth[cell];
		return depth > 0 ? Math.min(1, this.air[cell] / depth) : 0;
	}
	/** Advance by `dt` s: carry with the current, and degas as the bubbles rise out of the plume. */
	update(dt, stencil) {
		if (!(dt > 0)) return;
		this.followWindow();
		this.advect(dt, stencil?.take(this.solver, dt));
		const { h } = this.solver;
		const fade = Math.exp(-dt / (TURBULENCE$1.decayShare * this.period));
		for (let i = 0; i < h.length; i += 1) {
			this.turbulence[i] = h[i] <= WET$2 || this.turbulence[i] < TRACE$2 ? 0 : this.turbulence[i] * (this.stirred[i] ? 1 : fade);
			this.stirred[i] = 0;
			if (h[i] <= WET$2 || this.air[i] === 0) {
				this.air[i] = 0;
				this.depth[i] = 0;
				continue;
			}
			const depth = Math.min(this.depth[i], h[i]);
			const air = this.air[i] * Math.exp(-AERATION$1.riseSpeed * dt / Math.max(MIN_DEPTH$1, depth));
			this.air[i] = air < TRACE$2 ? 0 : Math.min(air, AERATION$1.peak * depth);
			this.depth[i] = this.air[i] > 0 ? depth : 0;
		}
	}
	reach(cell, penetration) {
		return Math.min(penetration, this.solver.h[cell]);
	}
	/**
	* `volume` m³ of air over the wet cells whose centres lie within `radius` of
	* (x, z) (always the cell it lands in), evenly per square metre, each down to
	* `radius` or its water's depth. None from past an open edge: the plunge was
	* outside the window, and its cell would be the edge column's.
	*/
	spread(x, z, volume, radius) {
		if (this.solver.beyondOpenEdge(x)) return;
		const { nx, nz, xCenters, zCenters, dx, dz, h } = this.solver;
		const centre = this.solver.cellIndex(x, z);
		const column = centre % nx;
		const row = Math.floor(centre / nx);
		const span = Math.ceil(radius / dx);
		const cells = this.plume;
		cells.length = 0;
		let area = 0;
		for (const step of ACROSS$1) for (let iz = step < 0 ? row : row + 1; iz >= 0 && iz < nz; iz += step) {
			const across = zCenters[iz] - z;
			if (iz !== row && Math.abs(across) > radius) break;
			for (let ix = Math.max(0, column - span); ix <= Math.min(nx - 1, column + span); ix += 1) {
				const i = iz * nx + ix;
				if (!(i === centre || Math.hypot(xCenters[ix] - x, across) <= radius) || h[i] <= WET$2) continue;
				cells.push(i);
				area += dx * dz[iz];
			}
		}
		for (const i of cells) this.addTo(i, volume * dx * dz[Math.floor(i / nx)] / area, this.reach(i, radius));
	}
	plume = [];
	addTo(cell, volume, reach) {
		const { dx, dz, nx } = this.solver;
		const area = dx * dz[Math.floor(cell / nx)];
		this.depth[cell] = Math.max(this.depth[cell], reach);
		this.air[cell] = Math.min(AERATION$1.peak * this.depth[cell], this.air[cell] + volume / area);
	}
	/** Semi-Lagrangian step: each cell takes the air (and plume depth, and turbulence) found upstream at x − u·dt. */
	advect(dt, stencil) {
		if (stencil) {
			this.advectStencil(stencil);
			return;
		}
		const { nx, nz, h, qx, qz, xCenters, zCenters, dx } = this.solver;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const water = h[i];
			if (water <= WET$2) {
				this.nextAir[i] = 0;
				this.nextDepth[i] = 0;
				this.nextTurbulence[i] = 0;
				continue;
			}
			const x = xCenters[ix] - qx[i] / water * dt;
			const z = zCenters[iz] - qz[i] / water * dt;
			const gx = Math.min(nx - 1, Math.max(0, (x - xCenters[0]) / dx));
			const column = Math.min(nx - 2, Math.floor(gx));
			const tx = gx - column;
			let row = Math.min(iz, nz - 2);
			while (row > 0 && zCenters[row] > z) row -= 1;
			while (row < nz - 2 && zCenters[row + 1] <= z) row += 1;
			const tz = Math.min(1, Math.max(0, (z - zCenters[row]) / (zCenters[row + 1] - zCenters[row])));
			const k = row * nx + column;
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			this.nextAir[i] = this.air[k] * w00 + this.air[k + 1] * w10 + this.air[k + nx] * w01 + this.air[k + nx + 1] * w11;
			this.nextTurbulence[i] = this.turbulence[k] * w00 + this.turbulence[k + 1] * w10 + this.turbulence[k + nx] * w01 + this.turbulence[k + nx + 1] * w11;
			this.nextDepth[i] = Math.max(this.depth[k] * (w00 > 0 ? 1 : 0), this.depth[k + 1] * (w10 > 0 ? 1 : 0), this.depth[k + nx] * (w01 > 0 ? 1 : 0), this.depth[k + nx + 1] * (w11 > 0 ? 1 : 0));
		}
		this.air.set(this.nextAir);
		this.depth.set(this.nextDepth);
		this.turbulence.set(this.nextTurbulence);
	}
	/** Same interpolation as `advect`; foam has already found the departures on this step's water. */
	advectStencil(stencil) {
		const { h, nx } = this.solver;
		const { indices, values } = stencil;
		for (let i = 0; i < h.length; i += 1) {
			if (h[i] <= WET$2) {
				this.nextAir[i] = 0;
				this.nextDepth[i] = 0;
				this.nextTurbulence[i] = 0;
				continue;
			}
			const k = indices[i];
			const tx = values[i * 2];
			const tz = values[i * 2 + 1];
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			this.nextAir[i] = this.air[k] * w00 + this.air[k + 1] * w10 + this.air[k + nx] * w01 + this.air[k + nx + 1] * w11;
			this.nextTurbulence[i] = this.turbulence[k] * w00 + this.turbulence[k + 1] * w10 + this.turbulence[k + nx] * w01 + this.turbulence[k + nx + 1] * w11;
			this.nextDepth[i] = Math.max(this.depth[k] * (w00 > 0 ? 1 : 0), this.depth[k + 1] * (w10 > 0 ? 1 : 0), this.depth[k + nx] * (w01 > 0 ? 1 : 0), this.depth[k + nx + 1] * (w11 > 0 ? 1 : 0));
		}
		this.air.set(this.nextAir);
		this.depth.set(this.nextDepth);
		this.turbulence.set(this.nextTurbulence);
	}
	/**
	* Shift with the solver when its window slides, so air stays on the same
	* water; new columns start clear. Every add follows first, so air added in
	* the window it arrives in is not shifted again.
	*/
	followWindow() {
		const { nx, nz, dx, xCenters } = this.solver;
		const shift = Math.round((xCenters[0] - this.windowX) / dx);
		this.windowX = xCenters[0];
		if (shift === 0) return;
		for (const values of [
			this.air,
			this.depth,
			this.turbulence
		]) for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			if (Math.abs(shift) >= nx) values.fill(0, row, row + nx);
			else if (shift > 0) {
				values.copyWithin(row, row + shift, row + nx);
				values.fill(0, row + nx - shift, row + nx);
			} else {
				values.copyWithin(row - shift, row, row + nx + shift);
				values.fill(0, row, row - shift);
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/aeration-last-argument-cache-20261004/AerationField.candidate.ts
/**
* The air breaking drives into the water (G9), from `docs/research/whitewater-sources.md`:
* - `share` (β): share of the dissipated energy spent entraining air against buoyancy, 4–14 % in
*   surf-zone breakers (Blenkinsopp & Chaplin 2007);
* - `plungeDepth` (κ_p) and `boreDepth` (κ_s): plume depth per breaker or bore height (provisional);
* - `riseSpeed` (w_b): bubbles of radius above 0.5 mm rise at 0.2–0.3 m/s (Deane & Stokes 2002);
* - `peak` (α_max): the most air a surf-zone plume holds, about 20 % under plunging breakers
*   (Blenkinsopp & Chaplin 2007). Air driven in beyond it vents at once.
*/
const AERATION = {
	share: .1,
	plungeDepth: .8,
	boreDepth: .3,
	riseSpeed: .25,
	peak: .2
};
/**
* The plume's turbulence (the wipeout spec, Part B), provisional:
* - under breaking of strength B in water h deep, the turbulent kinetic energy k
*   relaxes over `rise` s toward (ratio · √(g h))² · B: Ting & Kirby (1995,
*   1996) measured √k / √(g h) of about 0.1–0.2 under broken waves;
* - once the breaking has passed it fades with an e-folding time of
*   `decayShare` of the peak period, so it is all but gone within one period
*   (plunging breakers dissipate their turbulence within about one wave period);
* - it is carried by the current like the air.
*/
const TURBULENCE = {
	ratio: .15,
	rise: .5,
	decayShare: 1 / 3
};
const DENSITY = 1025;
const WET$1 = .01;
const TRACE$1 = 1e-7;
/** A plume spreads to the rows either side of where it lands. */
const ACROSS = [-1, 1];
/** Plumes thinner than this still degas at this depth's rate, m (a numerical floor). */
const MIN_DEPTH = .05;
const INITIAL_EXP = Object.getOwnPropertyDescriptor(Math, "exp")?.value;
const CACHEABLE_EXP = typeof INITIAL_EXP === "function" && Function.prototype.toString.call(INITIAL_EXP) === "function exp() { [native code] }" ? INITIAL_EXP : void 0;
/**
* Entrained air on the solver grid (G9): per cell, the air it holds per unit
* area (m³/m², its depth if it were one layer) and the plume's depth. Air
* enters where lip water lands (a share of the impact's energy spent against
* buoyancy, carried down to half the plunge's depth on average), where bores
* dissipate, and where trapped tubes break into bubbles. A plunge's or a
* tube's bubbles fill a plume as wide as it is deep (provisional). It is carried by the
* current semi-Lagrangian, like the foam, and degasses as its bubbles rise
* out of the plume. It never feeds back into the water.
*/
var AerationField = class {
	solver;
	air;
	depth;
	/** The turbulent kinetic energy in each cell's water, m²/s² (`TURBULENCE`). */
	turbulence;
	nextAir;
	nextDepth;
	nextTurbulence;
	/** Cells breaking stirred since the latest update: they hold their turbulence rather than fade. */
	stirred;
	windowX;
	period;
	stirDt = NaN;
	stirGain = 0;
	/** `period`: the swell's peak period, s, which sets how fast the turbulence fades. */
	constructor(solver, options = {}) {
		this.solver = solver;
		const size = solver.h.length;
		this.air = new Float64Array(size);
		this.depth = new Float64Array(size);
		this.turbulence = new Float64Array(size);
		this.nextAir = new Float64Array(size);
		this.nextDepth = new Float64Array(size);
		this.nextTurbulence = new Float64Array(size);
		this.stirred = new Uint8Array(size);
		this.windowX = solver.xCenters[0];
		this.period = options.period ?? 10;
	}
	/** Breaking of strength `strength` (0–1) in `cell` for `dt` s stirs its water toward Ting & Kirby's intensity. */
	stir(cell, strength, dt) {
		this.followWindow();
		const depth = this.solver.h[cell];
		if (!(depth > WET$1) || !(strength > 0)) return;
		this.stirred[cell] = 1;
		const target = (TURBULENCE.ratio * Math.sqrt(GRAVITY * depth)) ** 2 * Math.min(1, strength);
		if (target > this.turbulence[cell]) {
			if (dt !== this.stirDt) {
				this.stirDt = dt;
				this.stirGain = 1 - Math.exp(-dt / TURBULENCE.rise);
			}
			this.turbulence[cell] += (target - this.turbulence[cell]) * this.stirGain;
		}
	}
	/** A plunge that dissipated `energy` J at (x, z), driving its bubbles `penetration` m down. */
	addPlunge(x, z, energy, penetration) {
		this.followWindow();
		const cell = this.solver.cellIndex(x, z);
		const reach = this.reach(cell, penetration);
		if (!(reach > 0) || !(energy > 0)) return;
		this.spread(x, z, AERATION.share * energy / (DENSITY * GRAVITY * (reach / 2)), reach);
	}
	/**
	* A bore dissipating `dissipation` (energy per unit crest length over ρ,
	* m⁴/s³, `boreDissipation`) for `dt` s in `cell`, `height` m high: β of the
	* energy its cell's width of crest loses, as air held against buoyancy at
	* half the plume's depth (the cell holds it, where the bore dissipates).
	*/
	addBore(cell, dissipation, height, dt) {
		this.followWindow();
		const reach = this.reach(cell, AERATION.boreDepth * height);
		if (!(reach > 0) || !(dissipation > 0)) return;
		this.addTo(cell, AERATION.share * dissipation * dt * this.solver.dx / (GRAVITY * (reach / 2)), reach);
	}
	/** Trapped air of `volume` m³ broken into bubbles at (x, z), `penetration` m down. */
	addAir(x, z, volume, penetration) {
		this.followWindow();
		const cell = this.solver.cellIndex(x, z);
		const reach = this.reach(cell, penetration);
		if (!(reach > 0) || !(volume > 0)) return;
		this.spread(x, z, volume, reach);
	}
	/** The void fraction the plume holds: its air over its depth, 0 … 1. */
	voidFraction(cell) {
		const depth = this.depth[cell];
		return depth > 0 ? Math.min(1, this.air[cell] / depth) : 0;
	}
	/** Advance by `dt` s: carry with the current, and degas as the bubbles rise out of the plume. */
	update(dt, stencil) {
		if (!(dt > 0)) return;
		this.followWindow();
		this.advect(dt, stencil?.take(this.solver, dt));
		const { h } = this.solver;
		const fade = Math.exp(-dt / (TURBULENCE.decayShare * this.period));
		const exp = CACHEABLE_EXP && Object.getOwnPropertyDescriptor(Math, "exp")?.value === CACHEABLE_EXP ? CACHEABLE_EXP : void 0;
		let lastArgument = NaN;
		let lastFactor = NaN;
		for (let i = 0; i < h.length; i += 1) {
			this.turbulence[i] = h[i] <= WET$1 || this.turbulence[i] < TRACE$1 ? 0 : this.turbulence[i] * (this.stirred[i] ? 1 : fade);
			this.stirred[i] = 0;
			if (h[i] <= WET$1 || this.air[i] === 0) {
				this.air[i] = 0;
				this.depth[i] = 0;
				continue;
			}
			const depth = Math.min(this.depth[i], h[i]);
			let air;
			if (exp) {
				const heldAir = this.air[i];
				const argument = -AERATION.riseSpeed * dt / Math.max(MIN_DEPTH, depth);
				const factor = argument === lastArgument ? lastFactor : exp(argument);
				lastArgument = argument;
				lastFactor = factor;
				air = heldAir * factor;
			} else air = this.air[i] * Math.exp(-AERATION.riseSpeed * dt / Math.max(MIN_DEPTH, depth));
			this.air[i] = air < TRACE$1 ? 0 : Math.min(air, AERATION.peak * depth);
			this.depth[i] = this.air[i] > 0 ? depth : 0;
		}
	}
	reach(cell, penetration) {
		return Math.min(penetration, this.solver.h[cell]);
	}
	/**
	* `volume` m³ of air over the wet cells whose centres lie within `radius` of
	* (x, z) (always the cell it lands in), evenly per square metre, each down to
	* `radius` or its water's depth. None from past an open edge: the plunge was
	* outside the window, and its cell would be the edge column's.
	*/
	spread(x, z, volume, radius) {
		if (this.solver.beyondOpenEdge(x)) return;
		const { nx, nz, xCenters, zCenters, dx, dz, h } = this.solver;
		const centre = this.solver.cellIndex(x, z);
		const column = centre % nx;
		const row = Math.floor(centre / nx);
		const span = Math.ceil(radius / dx);
		const cells = this.plume;
		cells.length = 0;
		let area = 0;
		for (const step of ACROSS) for (let iz = step < 0 ? row : row + 1; iz >= 0 && iz < nz; iz += step) {
			const across = zCenters[iz] - z;
			if (iz !== row && Math.abs(across) > radius) break;
			for (let ix = Math.max(0, column - span); ix <= Math.min(nx - 1, column + span); ix += 1) {
				const i = iz * nx + ix;
				if (!(i === centre || Math.hypot(xCenters[ix] - x, across) <= radius) || h[i] <= WET$1) continue;
				cells.push(i);
				area += dx * dz[iz];
			}
		}
		for (const i of cells) this.addTo(i, volume * dx * dz[Math.floor(i / nx)] / area, this.reach(i, radius));
	}
	plume = [];
	addTo(cell, volume, reach) {
		const { dx, dz, nx } = this.solver;
		const area = dx * dz[Math.floor(cell / nx)];
		this.depth[cell] = Math.max(this.depth[cell], reach);
		this.air[cell] = Math.min(AERATION.peak * this.depth[cell], this.air[cell] + volume / area);
	}
	/** Semi-Lagrangian step: each cell takes the air (and plume depth, and turbulence) found upstream at x − u·dt. */
	advect(dt, stencil) {
		if (stencil) {
			this.advectStencil(stencil);
			return;
		}
		const { nx, nz, h, qx, qz, xCenters, zCenters, dx } = this.solver;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const water = h[i];
			if (water <= WET$1) {
				this.nextAir[i] = 0;
				this.nextDepth[i] = 0;
				this.nextTurbulence[i] = 0;
				continue;
			}
			const x = xCenters[ix] - qx[i] / water * dt;
			const z = zCenters[iz] - qz[i] / water * dt;
			const gx = Math.min(nx - 1, Math.max(0, (x - xCenters[0]) / dx));
			const column = Math.min(nx - 2, Math.floor(gx));
			const tx = gx - column;
			let row = Math.min(iz, nz - 2);
			while (row > 0 && zCenters[row] > z) row -= 1;
			while (row < nz - 2 && zCenters[row + 1] <= z) row += 1;
			const tz = Math.min(1, Math.max(0, (z - zCenters[row]) / (zCenters[row + 1] - zCenters[row])));
			const k = row * nx + column;
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			this.nextAir[i] = this.air[k] * w00 + this.air[k + 1] * w10 + this.air[k + nx] * w01 + this.air[k + nx + 1] * w11;
			this.nextTurbulence[i] = this.turbulence[k] * w00 + this.turbulence[k + 1] * w10 + this.turbulence[k + nx] * w01 + this.turbulence[k + nx + 1] * w11;
			this.nextDepth[i] = Math.max(this.depth[k] * (w00 > 0 ? 1 : 0), this.depth[k + 1] * (w10 > 0 ? 1 : 0), this.depth[k + nx] * (w01 > 0 ? 1 : 0), this.depth[k + nx + 1] * (w11 > 0 ? 1 : 0));
		}
		this.air.set(this.nextAir);
		this.depth.set(this.nextDepth);
		this.turbulence.set(this.nextTurbulence);
	}
	/** Same interpolation as `advect`; foam has already found the departures on this step's water. */
	advectStencil(stencil) {
		const { h, nx } = this.solver;
		const { indices, values } = stencil;
		for (let i = 0; i < h.length; i += 1) {
			if (h[i] <= WET$1) {
				this.nextAir[i] = 0;
				this.nextDepth[i] = 0;
				this.nextTurbulence[i] = 0;
				continue;
			}
			const k = indices[i];
			const tx = values[i * 2];
			const tz = values[i * 2 + 1];
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			this.nextAir[i] = this.air[k] * w00 + this.air[k + 1] * w10 + this.air[k + nx] * w01 + this.air[k + nx + 1] * w11;
			this.nextTurbulence[i] = this.turbulence[k] * w00 + this.turbulence[k + 1] * w10 + this.turbulence[k + nx] * w01 + this.turbulence[k + nx + 1] * w11;
			this.nextDepth[i] = Math.max(this.depth[k] * (w00 > 0 ? 1 : 0), this.depth[k + 1] * (w10 > 0 ? 1 : 0), this.depth[k + nx] * (w01 > 0 ? 1 : 0), this.depth[k + nx + 1] * (w11 > 0 ? 1 : 0));
		}
		this.air.set(this.nextAir);
		this.depth.set(this.nextDepth);
		this.turbulence.set(this.nextTurbulence);
	}
	/**
	* Shift with the solver when its window slides, so air stays on the same
	* water; new columns start clear. Every add follows first, so air added in
	* the window it arrives in is not shifted again.
	*/
	followWindow() {
		const { nx, nz, dx, xCenters } = this.solver;
		const shift = Math.round((xCenters[0] - this.windowX) / dx);
		this.windowX = xCenters[0];
		if (shift === 0) return;
		for (const values of [
			this.air,
			this.depth,
			this.turbulence
		]) for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			if (Math.abs(shift) >= nx) values.fill(0, row, row + nx);
			else if (shift > 0) {
				values.copyWithin(row, row + shift, row + nx);
				values.fill(0, row + nx - shift, row + nx);
			} else {
				values.copyWithin(row - shift, row, row + nx + shift);
				values.fill(0, row, row - shift);
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/aeration-last-argument-cache-20261004/AdvectionStencil.ts
/** A same-step departure lookup shared by fields carried on unchanged water. */
var AdvectionStencil = class {
	indices = /* @__PURE__ */ new Uint32Array(0);
	/** The original tx/tz fractions, in double precision. */
	values = /* @__PURE__ */ new Float64Array(0);
	solver;
	xCenters;
	zCenters;
	dt = NaN;
	time = NaN;
	xMin = NaN;
	zMin = NaN;
	dx = NaN;
	nx = 0;
	nz = 0;
	ready = false;
	/** Foam records a fresh lookup every update: h/q are mutable, even without a clock or window change. */
	begin(solver, dt) {
		this.ready = false;
		const size = solver.h.length;
		if (this.indices.length !== size) {
			this.indices = new Uint32Array(size);
			this.values = new Float64Array(size * 2);
		}
		this.solver = solver;
		this.xCenters = solver.xCenters;
		this.zCenters = solver.zCenters;
		this.dt = dt;
		this.time = solver.time;
		this.xMin = solver.xCenters[0];
		this.zMin = solver.zCenters[0];
		this.dx = solver.dx;
		this.nx = solver.nx;
		this.nz = solver.nz;
	}
	/** The whole lookup has been written; dry cells need no entry because both fields clear them. */
	commit() {
		this.ready = true;
	}
	/** Discard it when a caller changes h/q between the two field updates. */
	invalidate() {
		this.ready = false;
	}
	/**
	* Aeration may reuse it once, immediately after foam, while h/q stay unchanged.
	* A changed dt, grid, window or clock falls back to computing departures itself.
	* Consuming it prevents an unrelated later call at the same solver time from reusing mutable-water state.
	*/
	take(solver, dt) {
		const matches = this.ready && this.solver === solver && this.dt === dt && this.time === solver.time && this.xCenters === solver.xCenters && this.zCenters === solver.zCenters && this.xMin === solver.xCenters[0] && this.zMin === solver.zCenters[0] && this.dx === solver.dx && this.nx === solver.nx && this.nz === solver.nz;
		this.ready = false;
		return matches ? this : void 0;
	}
};
/** A modest surf bore: 0.25 m running onto 1 m of still water. */
const REFERENCE_BORE = {
	stillDepth: 1,
	depth: 1.25
};
/** Share of the dense foam that decays into residual lace instead of vanishing (a game value). */
const LACE_SHARE = .3;
/** Depth of landed lip water that covers a cell with foam, m. */
const SPLASH_DEPTH = .05;
const WET = .01;
const TRACE = 1e-6;
/**
* Energy a bore dissipates per unit crest length, divided by ρ, m³/s³: g q ΔH,
* with the hydraulic-jump head loss ΔH = (h₂ − h₁)³/(4 h₁ h₂), the bore speed
* c = √(g h₂ (h₁ + h₂)/(2 h₁)) and the discharge through it q = c h₁ (e.g. Chow 1959).
* The still depth ahead is h₁ and the local depth behind the front h₂.
*/
function boreDissipation(stillDepth, depth) {
	if (!(stillDepth > 0) || !(depth > stillDepth)) return 0;
	const headLoss = (depth - stillDepth) ** 3 / (4 * stillDepth * depth);
	const speed = Math.sqrt(GRAVITY * depth * (stillDepth + depth) / (2 * stillDepth));
	return GRAVITY * speed * stillDepth * headLoss;
}
const REFERENCE_DISSIPATION = boreDissipation(REFERENCE_BORE.stillDepth, REFERENCE_BORE.depth);
/**
* Foam carried by the flow on the solver grid (plan §2.4, G4): ∂F/∂t + u·∇F = S − F/τ.
* F is the fraction of the surface covered by foam, split into dense whitewater
* and the residual lace it decays into, which lasts longer (the two regimes of
* Callaghan et al. 2013). Each update advects both semi-Lagrangian with the
* solver's depth-averaged velocity, decays them exactly, and adds the breaking
* strength times the bore's dissipation. Lip splashes add foam where they land.
* The foam never feeds back into the water.
*/
var FoamField = class {
	solver;
	decay;
	dense;
	residual;
	/** Dense foam bores made per second in each cell at the last update (it also drives the bubbles). */
	source;
	/** Positive bore sources, sorted by cell: the visual clouds skip the rest of the grid. */
	sourceCells;
	sourceCount = 0;
	/** Wet breaking cells and their dissipated power: aeration reads the same bore measurement. */
	breakingCells;
	dissipation;
	breakingCount = 0;
	nextDense;
	nextResidual;
	windowX;
	constructor(solver, decay) {
		this.solver = solver;
		this.decay = decay;
		const size = solver.nx * solver.nz;
		this.dense = new Float64Array(size);
		this.residual = new Float64Array(size);
		this.source = new Float64Array(size);
		this.sourceCells = new Uint32Array(size);
		this.breakingCells = new Uint32Array(size);
		this.dissipation = new Float64Array(size);
		this.nextDense = new Float64Array(size);
		this.nextResidual = new Float64Array(size);
		this.windowX = solver.xCenters[0];
	}
	totalAt(index) {
		return this.dense[index] + this.residual[index];
	}
	/** Cover the cell a lip parcel of `volume` m³ lands in; none past an open edge, where it has left the window. */
	addSplash(x, z, volume) {
		const { solver } = this;
		if (solver.beyondOpenEdge(x)) return;
		const cell = solver.cellIndex(x, z);
		const area = solver.dx * solver.dz[Math.floor(cell / solver.nx)];
		this.dense[cell] = Math.min(1, this.dense[cell] + volume / (area * SPLASH_DEPTH));
		this.residual[cell] = Math.min(this.residual[cell], 1 - this.dense[cell]);
	}
	/** Advance by `dt` seconds with the breaking strength B per cell. */
	update(dt, breaking, stencil) {
		if (!(dt > 0)) return;
		this.followWindow();
		this.advect(dt, stencil);
		const { h, bed, restLevel } = this.solver;
		const keepDense = Math.exp(-dt / this.decay.dense);
		const keepLace = Math.exp(-dt / this.decay.residual);
		this.sourceCount = 0;
		this.breakingCount = 0;
		for (let i = 0; i < h.length; i += 1) {
			if (h[i] <= WET) {
				this.dense[i] = 0;
				this.residual[i] = 0;
				this.source[i] = 0;
				continue;
			}
			const previous = this.dense[i];
			let dense = previous * keepDense;
			const lace = this.residual[i] * keepLace + LACE_SHARE * (previous - dense);
			const strength = breaking[i];
			let bore = 0;
			if (strength > 0) {
				bore = boreDissipation(restLevel - bed[i], h[i]);
				this.breakingCells[this.breakingCount++] = i;
				this.dissipation[i] = strength * bore;
			}
			const rate = strength > 0 ? strength * 4 * bore / REFERENCE_DISSIPATION : 0;
			this.source[i] = rate;
			if (rate > 0) this.sourceCells[this.sourceCount++] = i;
			dense += rate * dt;
			this.dense[i] = dense < TRACE ? 0 : Math.min(1, dense);
			this.residual[i] = lace < TRACE ? 0 : Math.min(lace, 1 - this.dense[i]);
		}
	}
	/** Rebuild the derived index after a tool or test directly edits `source`; normal updates build it as they go. */
	reindexSources() {
		this.sourceCount = 0;
		for (let i = 0; i < this.source.length; i += 1) if (this.source[i] > 0) this.sourceCells[this.sourceCount++] = i;
	}
	/** Semi-Lagrangian step: each cell takes the foam found upstream at x − u·dt. */
	advect(dt, stencil) {
		const { nx, nz, h, qx, qz, xCenters, zCenters, dx } = this.solver;
		stencil?.begin(this.solver, dt);
		const indices = stencil?.indices;
		const values = stencil?.values;
		for (let iz = 0; iz < nz; iz += 1) for (let ix = 0; ix < nx; ix += 1) {
			const i = iz * nx + ix;
			const depth = h[i];
			if (depth <= WET) {
				this.nextDense[i] = 0;
				this.nextResidual[i] = 0;
				continue;
			}
			const x = xCenters[ix] - qx[i] / depth * dt;
			const z = zCenters[iz] - qz[i] / depth * dt;
			const gx = Math.min(nx - 1, Math.max(0, (x - xCenters[0]) / dx));
			const column = Math.min(nx - 2, Math.floor(gx));
			const tx = gx - column;
			let row = Math.min(iz, nz - 2);
			while (row > 0 && zCenters[row] > z) row -= 1;
			while (row < nz - 2 && zCenters[row + 1] <= z) row += 1;
			const tz = Math.min(1, Math.max(0, (z - zCenters[row]) / (zCenters[row + 1] - zCenters[row])));
			const k = row * nx + column;
			const w00 = (1 - tx) * (1 - tz);
			const w10 = tx * (1 - tz);
			const w01 = (1 - tx) * tz;
			const w11 = tx * tz;
			if (indices && values) {
				indices[i] = k;
				values[i * 2] = tx;
				values[i * 2 + 1] = tz;
			}
			this.nextDense[i] = this.dense[k] * w00 + this.dense[k + 1] * w10 + this.dense[k + nx] * w01 + this.dense[k + nx + 1] * w11;
			this.nextResidual[i] = this.residual[k] * w00 + this.residual[k + 1] * w10 + this.residual[k + nx] * w01 + this.residual[k + nx + 1] * w11;
		}
		this.dense.set(this.nextDense);
		this.residual.set(this.nextResidual);
		stencil?.commit();
	}
	/** Shift with the solver when its window slides, so foam stays on the same water; new columns start clean. */
	followWindow() {
		const { nx, nz, dx, xCenters } = this.solver;
		const shift = Math.round((xCenters[0] - this.windowX) / dx);
		this.windowX = xCenters[0];
		if (shift === 0) return;
		for (const values of [this.dense, this.residual]) for (let iz = 0; iz < nz; iz += 1) {
			const row = iz * nx;
			if (Math.abs(shift) >= nx) values.fill(0, row, row + nx);
			else if (shift > 0) {
				values.copyWithin(row, row + shift, row + nx);
				values.fill(0, row + nx - shift, row + nx);
			} else {
				values.copyWithin(row - shift, row, row + nx + shift);
				values.fill(0, row, row - shift);
			}
		}
	}
};
//#endregion
//#region ../../../../../private/tmp/aeration-last-argument-cache-20261004/cost.ts
const INPUT = "/Users/regina/Desktop/Projects/surfing-game/docs/research/performance-2026-10-03/render-scale/baseline-held-source.json.gz";
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const args = Object.fromEntries(process.argv.slice(2).map((a) => {
	const at = a.indexOf("=");
	if (at < 0 || !a.startsWith("--")) throw Error("Use --name=value");
	return [a.slice(2, at), a.slice(at + 1)];
}));
if (Object.keys(args).some((k) => !["run", "out"].includes(k))) throw Error("Only run/out allowed");
if (args.run !== "true") {
	console.log(JSON.stringify({
		prepared: true,
		method: "one bounded CPU paired full-update cost, not FPS",
		fixture: INPUT,
		paths: ["shared-stencil", "full-advection"],
		warmPairs: 12,
		measuredPairs: 30,
		rotatingOrder: "AB then BA",
		secondsBound: 20
	}));
	process.exit(0);
}
const out = args.out ?? "/private/tmp/aeration-last-argument-cache-20261004/cost-report.json";
if (existsSync(out)) throw Error("Refusing to overwrite prior cost report");
const allStart = performance.now();
const input = readFileSync(INPUT);
if (sha(input) !== "95f3937160eff73a9c751fcbdc2246a811978b49be7dbbda0e56ed9dea69e584") throw Error("Fixture compressed hash differs");
const json = gunzipSync(input);
if (sha(json) !== "8e73b4d10d268081891d0bf89b93c6706b37617a6bea5543af443d6963443587") throw Error("Fixture JSON hash differs");
const capture = JSON.parse(json.toString("utf8"));
const compressed = Buffer.from(capture.serialized.compressed.base64, "base64");
if (sha(compressed) !== capture.serialized.compressed.sha256) throw Error("Serialized compressed hash differs");
const raw = capture.serialized.deflated ? inflateSync(compressed) : compressed;
if (sha(raw) !== "38b63fbe297eeb143c6449902855be39802455d4f14d540a07d152ead7ec32e0" || sha(raw) !== capture.serialized.rawSha256) throw Error("SET1 raw hash differs");
const stateBytes = new Uint8Array(raw);
const state = decodeSurfZoneState(stateBytes);
const view = new DataView(stateBytes.buffer);
const headerBytes = view.getUint32(4, true);
const header = JSON.parse(new TextDecoder().decode(stateBytes.subarray(8, 8 + headerBytes)));
let offset = 8 + Math.ceil(headerBytes / 4) * 4;
for (const [name, count] of header.arrays) {
	const values = state.arrays[name];
	if (!values || values.length !== count) throw Error("Decoded count differs:" + name);
	const words = new Uint32Array(values.buffer, values.byteOffset, values.length);
	for (let i = 0; i < count; i++) if (words[i] !== view.getUint32(offset + i * 4, true)) throw Error("Raw offset/word differs:" + name);
	offset += count * 4;
}
if (offset !== raw.length) throw Error("Trailing/truncated SET1 data");
for (const [name, values] of Object.entries(state.arrays)) if (!values.every(Number.isFinite)) throw Error("Nonfinite retained input:" + name);
const scene = new SurfZoneSimulation(capture.scalars.config, "warm");
scene.importState(state);
const solver = scene.solver;
if (solver.nx !== 160 || solver.nz !== 725 || solver.h.length !== 116e3) throw Error("Actual fixture grid differs");
const dt = 1 / 60;
const period = capture.scalars.config.peakPeriod;
const names = [
	"air",
	"depth",
	"turbulence",
	"nextAir",
	"nextDepth",
	"nextTurbulence",
	"stirred"
];
const initialAir = scene.aeration.air.slice();
const initialDepth = scene.aeration.depth.slice();
const native = Math.exp;
if (Function.prototype.toString.call(native) !== "function exp() { [native code] }" || Object.getOwnPropertyDescriptor(Math, "exp")?.value !== native) throw Error("Expected native data Math.exp");
const stencil = new AdvectionStencil();
new FoamField(solver, {
	dense: 9,
	residual: 18
}).update(dt, new Float64Array(solver.h.length), stencil);
const solverNames = [
	"h",
	"bed",
	"qx",
	"qz",
	"xCenters",
	"zCenters"
];
const solverRefs = solverNames.map((n) => solver[n]);
const solverHashes = solverRefs.map((a) => sha(new Uint8Array(a.buffer, a.byteOffset, a.byteLength)));
const solverTime = solver.time;
const departureIndicesSha = sha(new Uint8Array(stencil.indices.buffer));
const departureFractionsSha = sha(new Uint8Array(stencil.values.buffer));
const byte = (a) => new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
const variants = [{
	name: "original",
	field: new AerationField$1(solver, { period })
}, {
	name: "candidate",
	field: new AerationField(solver, { period })
}].map((v) => ({
	...v,
	refs: names.map((n) => v.field[n])
}));
const reset = (field) => {
	field.air.set(initialAir);
	field.depth.set(initialDepth);
	field.turbulence.fill(0);
	field.stirred.fill(0);
};
const armStencil = () => {
	stencil.begin(solver, dt);
	stencil.commit();
};
const update = (field, shared) => {
	if (shared) armStencil();
	field.update(dt, shared ? stencil : void 0);
};
const check = () => {
	for (const n of names) {
		const a = variants[0].field[n], b = variants[1].field[n];
		if (Buffer.compare(byte(a), byte(b)) !== 0) throw Error("Full field byte parity failed:" + n);
	}
	variants.forEach((v) => names.forEach((n, i) => {
		if (v.refs[i] !== v.field[n]) throw Error("Array identity changed:" + n);
	}));
};
const outputs = {};
for (const shared of [true, false]) {
	const path = shared ? "shared-stencil" : "full-advection";
	for (const v of variants) {
		reset(v.field);
		update(v.field, shared);
	}
	check();
	for (let r = 0; r < 12; r++) for (const ix of r % 2 ? [1, 0] : [0, 1]) {
		reset(variants[ix].field);
		update(variants[ix].field, shared);
	}
	const rows = [];
	for (let r = 0; r < 30; r++) {
		if (performance.now() - allStart > 2e4) throw Error("Predeclared20s CPU bound");
		const values = {};
		const order = r % 2 ? [1, 0] : [0, 1];
		for (const ix of order) {
			const v = variants[ix];
			reset(v.field);
			if (shared) armStencil();
			const start = performance.now();
			v.field.update(dt, shared ? stencil : void 0);
			values[v.name] = performance.now() - start;
		}
		check();
		rows.push({
			pair: r,
			order: order.map((i) => variants[i].name),
			original: values.original,
			candidate: values.candidate,
			savingMs: values.original - values.candidate
		});
	}
	const stats = (a) => {
		const s = a.toSorted((x, y) => x - y);
		return {
			median: (s[s.length - 1 >> 1] + s[s.length >> 1]) / 2,
			mean: a.reduce((x, y) => x + y, 0) / a.length,
			p95: s[Math.ceil(s.length * .95) - 1],
			min: s[0],
			max: s.at(-1)
		};
	};
	outputs[path] = {
		rows,
		originalMs: stats(rows.map((r) => r.original)),
		candidateMs: stats(rows.map((r) => r.candidate)),
		pairedSavingMs: stats(rows.map((r) => r.savingMs)),
		allPairsBitExact: true
	};
}
if (Math.exp !== native) throw Error("Math.exp changed during measurement");
solverNames.forEach((n, i) => {
	const a = solver[n];
	if (a !== solverRefs[i] || sha(new Uint8Array(a.buffer, a.byteOffset, a.byteLength)) !== solverHashes[i]) throw Error("Held solver identity/bytes changed:" + n);
});
if (solver.time !== solverTime) throw Error("Held solver clock changed");
if (departureIndicesSha !== sha(new Uint8Array(stencil.indices.buffer)) || departureFractionsSha !== sha(new Uint8Array(stencil.values.buffer))) throw Error("Held stencil bytes changed");
const report = {
	valid: true,
	kind: "bounded CPU full AerationField.update paired cost; no water advance/browser/FPS",
	base: "58ceb6a29617c00f93fb3b21eff3058d824319d5",
	fixture: INPUT,
	compressedSha256: sha(input),
	jsonSha256: sha(json),
	rawSet1Sha256: sha(raw),
	rawStateWordsAndOffsetsVerified: true,
	newControlledPostStateInput: true,
	historicalCountedArguments: false,
	turbulenceInitialization: "original importState handover sets zero; same zero stirred on both variants",
	sourceInjection: "none added before this controlled update; separate parity tests cover sources/stir/window",
	solverTime: solver.time,
	nx: solver.nx,
	nz: solver.nz,
	dt,
	period,
	cells: solver.h.length,
	warmPairs: 12,
	pairs: 30,
	order: "AB/BA adjacent alternating",
	nativeDataExpAtModuleInitialization: true,
	fullUpdateDescriptorBranchAdvectionFinishIncluded: true,
	stencilPreparedUntimedFromOriginalFoam: true,
	departureIndicesSha,
	departureFractionsSha,
	unchangedSolverIdentitiesBytesAndClock: true,
	solverArraySha256: Object.fromEntries(solverNames.map((n, i) => [n, solverHashes[i]])),
	outputs,
	elapsedCpuMs: performance.now() - allStart,
	performanceOrAdoptionClaim: false
};
writeFileSync(out, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify({
	path: out,
	valid: report.valid,
	outputs: Object.fromEntries(Object.entries(outputs).map(([k, v]) => [k, v.pairedSavingMs])),
	elapsedCpuMs: report.elapsedCpuMs
}));
//#endregion
export {};
