# Dedicated full snapshot writer: source preparation only

The only runtime change is `SurfZoneSimulation.writeUniformSnapshot`, based on accepted `e3e630bc45339e0f7564e59cfdd556275c06de92`. The original optional `writeUniformFields` and all other runtime bytes stay unchanged. The unconditional method uses the same mapping, reusable Float64 velocity/void arrays, ascending preprocessing and row/column traversal, wet/dry tests, coefficient arithmetic and Float32 store order. Every `this.aeration.voidFraction(i)` remains a dynamic call after that cell's velocity stores and before the output pass. No bed cache, aeration candidate, private owner, source evolution, physics, transport, graphics or publication-cadence change is included.

The ordinary worker already calls the generic helper with stable full arguments. No mixed-argument training or deoptimization has been observed. This candidate removes dispatch checks in source; an optimizing runtime may already remove them. The duplicated full loop is justified only if the complete field-fill gate shows a useful saving.

The declared API scope is the existing TypeScript signature: all three `Float32Array` output arguments are required. Calls that bypass it with missing, null or undefined outputs are outside this candidate's equivalence claim. The three public separate writers and the generic optional writer remain unchanged.

## Source and intake authority

`baseline/src/wave/SurfZoneSimulation.ts` is exact accepted source, also matching the previously reviewed air experiment's **original** source. `candidate.patch` contains only the full-method edit. `qa/{baseline,candidate}.ts` differ from their respective runtime files only by rebinding relative imports to the same canonical absolute modules; this prevents duplicate solver identities in strict checks and cost bundles. No candidate air module is imported. Canonical dependencies are hash-bound metadata, not copied trees.

The intake retains the reviewed plain owning `new Uint8Array(raw)` decoder boundary, exact SET1 offsets/counts/raw 32-bit words, and finite guards from the rejected air gate. Its QA imports point to canonical codec/types, and its descriptive source-proxy text now truthfully states that this workload does **not** call `BreakingModel.update(0)` or evolve materials. The fixture is the existing `render-scale/baseline-held-source.json.gz`, a saved 1bcc F32 poststate imported into accepted F64 constructors: 160 × 725 = 116,000 cells, 161 × 633 = 101,913 render nodes, 611,478 Float32 output words. It is not historical F64/pre-degas/late-game state. Bed/geometry are regenerated from the identical recorded config. Import's original omitted-turbulence reset is retained on both arms.

## Proposed sequential CPU checks — not executed

Set `FULL_SNAPSHOT_READY_SHA256` to the reviewed hash of `ready.json`; CWD is this directory. Preserve actual argv, start/end/exit and first logs plus before/after pins. Stop on the first failure, without automatic repair or retry.

1. `node --test source-contract.test.mjs` — two literal scope/order gates; no numerical import.
2. `/Users/regina/Desktop/Projects/surfing-game/node_modules/.bin/tsc -p tsconfig.qa.json --pretty false`
3. `/Users/regina/Desktop/Projects/surfing-game/node_modules/.bin/vitest run --config vitest.config.ts --maxWorkers=1 --reporter=json --outputFile=checks/vitest.json`
4. `node --check build-cost.mjs`
5. `node --check run-cost.mjs`
6. `node build-cost.mjs` — one standalone Node bundle, not an app/browser build.
7. `node run-cost.mjs --run=false` — verifies source/compiled authority and prints an unarmed plan; no numerical module import.

Five new numerical tests cover exact mixed wet/dry (including both sides of the actual 0.01 threshold) and boundary/layout outputs, nonfinite/signed-zero behavior, dynamic void-method replacement/receiver/input mutation/preprocess-before-output chronology, overlapping output views and output/input aliases, plus the exact retained full workload, first-allocation sizes and reusable scratch identities. The sixth test retains the existing full-versus-separate regression body unchanged, with candidate/class imports rebound for QA. The generic writer remains literal and its normal public behavior is exercised rather than weakened.

## Proposed separate cost lease — not executed

Only after all checks pass and root grants a quiet CPU lease: `FULL_SNAPSHOT_READY_SHA256=<reviewed> node run-cost.mjs --run=true --out=/private/tmp/surf-full-snapshot-writer-20261004/cost/report.json`, one operation, fresh output, 20 s whole-operation bound and no retry. Root's command wrapper should enforce the hard wall bound as well as the cooperative checks inside the workload.

Both arms import the same pinned F32 poststate once and retain all solver/material fields and clocks unchanged. Each has persistent original scratch arrays and three reused final buffers. One preflight fill, eight warm pairs and 24 adjacent measured pairs follow balanced `AB, BA, BA, AB` blocks. Timers cover the **complete three-field writer** including all velocity/void preprocessing and all node interpolation/stores. Output/scratch equality and unchanged input bytes/identities/clocks are checked outside timers after each pair; messages are constructed only on failure. Report raw samples, paired median, marginal p95 and AB/BA strata, not sums of independent quantiles.

This deliberately excludes unchanged Runner pose/event/particle/front packing, materials/source steps, water/contact/body/lip/front stepping, transport and page/GPU rendering. It is neither a whole-worker result nor an ordinary FPS or visual acceptance. No further hardware trial or production adoption follows automatically from the CPU result.
