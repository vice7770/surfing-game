# Proposed gates — unexecuted

All commands run from this directory. Root first reviews `ready.json`, `checks-driver-ready.json` and the source/runtime/build reuse pins. No checks are authorized by their existence.

One future CPU operation uses mandatory `FULL_WRITER_FPS_READY_SHA256` and `FULL_WRITER_CHECKS_DRIVER_READY_SHA256` bindings:

```text
python3 checks-driver.py --run=true
```

It preserves actual command/PID/start/end/exit, original stdout/stderr and before/after source, dependency, public and reused-build hashes. The declared 120-second command budget stops at the first failure, with owned process-group timeout cleanup and no automatic source repair or retry. The exact eight commands are:

1. `node candidate/node_modules/typescript/bin/tsc --project candidate/tsconfig.json --noEmit --incremental false`
2. `node build-only.mjs` — candidate only, literal `BUILD_ID=306258296`, private Vite cache, `configLoader=runner`, `copyPublicDir=false`, `emptyOutDir=false`; baseline's eleven outputs are reused unchanged.
3. `python3 bind-launch.py` — local successful-build metadata only, no network.
4. `node --check native-owned.mjs`
5. `node --check passive-guard.mjs`
6. `node --check survey.mjs`
7. `node --check pair.mjs`
8. `node pair.mjs --run=false` — verifies completed bindings and prints the unarmed plan, no game import, server or browser.

There is no Vitest operation in this FPS gate. It reuses the six numerical/two literal full-writer checks and the production renderer's 46 tests. No default/shared Vitest cache operation is proposed. The baseline wrapper manifest is written only to this directory's `baseline/`, while its `outputRoot` points directly at the immutable root-final alternative dist.

Only after all eight pass and root independently reviews compiled hashes and grants sole hardware lease:

```text
FULL_WRITER_FPS_READY_SHA256=<reviewed>
FULL_WRITER_FPS_BINDINGS_SHA256=<reviewed>
node pair.mjs --run=true --out=/private/tmp/surf-full-writer-fps-20261004/run
```

This proposed pair has no resizing/emulation, worker-RNG override, profiler, GPU timers, batching intervention, contact observer, forced Y drain, foam/air candidate, publication cadence change or shader prewarm. The original page-only `Math.random` bootstrap is retained and declared. Every served compiled output and the shared public whitelist are hash verified. Actual Ride worker URL/start/idle one-step metadata, native dimensions, graphics and config are guarded; the practice worker is excluded.

The evidence must distinguish display rate, fresh snapshots, simulation-wall progress and per-stage telemetry. Complete late bins are wall-time only. Fixed pair order and ordinary phase drift limit attribution; quantiles are not additive request latency. No further run, adoption or visual acceptance follows automatically.
