"""Source-byte preparation only; never imports runtime/transform modules or runs checks."""
from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json

ROOT = Path('/Users/regina/Desktop/Projects/surfing-game')
WORK = Path('/private/tmp/surf-feed-indexed-fps-20261004')
PARENT = Path('/private/tmp/surf-feed-components-fps-20261004')
CANDIDATE = Path('/private/tmp/surf-feed-indexed-scan-20261004')
ADOPTION = Path('/private/tmp/surf-full-writer-adoption-20261004')
BASELINE = 'b0e003b8670c9d0be83bc9bb24c30b5382a54499'
H = lambda b: hashlib.sha256(b).hexdigest()

def record(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': H(b)}

def save(name, value):
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')

def rename(text):
    return (text.replace(str(PARENT), str(WORK))
            .replace('FEED_COMPONENTS_FPS', 'FEED_INDEXED_FPS')
            .replace('feed-components', 'feed-indexed')
            .replace('port: 4241, cdp: 9651', 'port: 4243, cdp: 9653')
            .replace('port: 4242, cdp: 9652', 'port: 4244, cdp: 9654'))

for name in ['survey.mjs', 'native-owned.mjs', 'passive-guard.mjs', 'public-assets.json']:
    (WORK / name).write_bytes((PARENT / name).read_bytes())

prior_ready = json.loads((PARENT / 'ready.json').read_text())
assert record(PARENT / 'ready.json')['sha256'] == '3a60b4eba4503a84eaa981294e92bfa6f98be9ecb95427a44a40aa8243a54c99'
prior_source = json.loads((PARENT / 'source-manifest.json').read_text())
files = prior_source['arms'][0]['files']
assert len(files) == 554
for pin in files:
    actual = record(ROOT / pin['path'])
    assert (actual['bytes'], actual['sha256']) == (pin['bytes'], pin['sha256']), pin['path']

target = ROOT / 'src/wave/SideFeed.ts'
original = target.read_text()
before = '    for (const weight of this.weights) if (weight > 0) slots += 1;'
after = '    const weights = this.weights;\n    for (let i = 0; i < weights.length; i += 1) if (weights[i] > 0) slots += 1;'
assert original.count(before) == 1
virtual = original.replace(before, after)
assert (len(virtual.encode()), H(virtual.encode())) == (10085, 'ac2b896d945ebdaf8b0530bd3ed515a7701d16c078991d93ca3a5870b3687dd2')
parent_candidate = json.loads((CANDIDATE / 'ready.json').read_text())
assert parent_candidate['sourceCheckpoint'] == BASELINE
assert parent_candidate['priorComponentCacheUnadoptedAndExcluded'] is True
assert parent_candidate['candidateSource']['sha256'] == H(virtual.encode())
gpu = record(ROOT / 'src/wave/gpu/GpuBoussinesq.ts')
assert gpu['sha256'] == '41e212604f0d7b889445edb17a05f38edf5044f66dceaa9eddaee4ebf69d8094'
spec = {'path': str(target), 'relativePath': 'src/wave/SideFeed.ts',
        'original': record(target), 'transform': record(CANDIDATE / 'patch-source.mjs'),
        'virtualCandidate': {'bytes': len(virtual.encode()), 'sha256': H(virtual.encode())},
        'editCount': 1,
        'mode': 'canonical original path; one source load/readFile substitution; no changed source file or clone',
        'ascendingNativeFloat64WeightScan': True,
        'noNewCacheOrGenerationState': True,
        'componentCacheExcluded': True,
        'canonicalGpuUnchanged': gpu,
        'exportedHelpersAndClassPrefixStayLiteral': True}
save('source-manifest.json', {
    'schema': 'feed-indexed-fps-source/v1', 'baseline': BASELINE,
    'commonBuildId': '306258296', 'sourceCheckpointAuthority': record(ADOPTION / 'source-after.json'),
    'sourceManifestParent': record(PARENT / 'source-manifest.json'),
    'documentationHeadReportedByRoot': '4a2657bea',
    'arms': [{'arm': name, 'root': str(ROOT), 'fileCount': len(files), 'files': files,
              'effectiveSourceMode': 'literal canonical' if name == 'baseline' else 'same canonical closure plus one pinned virtual SideFeed source transformation'}
             for name in ['baseline', 'candidate']],
    'onlyRuntimeDifference': spec, 'sourceBytePreparationOnly': True, 'noSourceClones': True})

reuse = json.loads((PARENT / 'baseline-reuse.json').read_text())
reuse['schema'] = 'feed-indexed-fps-baseline-reuse/v1'
save('baseline-reuse.json', reuse)
dep = json.loads((PARENT / 'dependency-authority.json').read_text())
dep['schema'] = 'feed-indexed-fps-dependencies/v1'
dep['sourceOnlyBorrow'] = record(PARENT / 'dependency-authority.json')
save('dependency-authority.json', dep)

borrow = [record(PARENT / name) for name in [
    'ready.json', 'freeze.json', 'source-manifest.json', 'baseline-reuse.json',
    'dependency-authority.json', 'survey.mjs', 'native-owned.mjs', 'passive-guard.mjs',
    'public-assets.json', 'pair.mjs', 'authority.mjs', 'strict.mjs', 'build-only.mjs',
    'checks-driver.py', 'bind-launch.py', 'checks/terminal.json', 'build-terminal.json',
    'bindings.json', 'root-run/report.json']]
borrow += [record(ADOPTION / name) for name in ['source-after.json', 'build-manifest.json', 'terminal.json', 'build.mjs']]
borrow += [record(CANDIDATE / name) for name in ['ready.json', 'inputs.json', 'patch-source.mjs', 'proposal.md']]
save('borrowed-authorities.json', {
    'schema': 'feed-indexed-fps-borrowed/v1', 'records': borrow,
    'indexedProofAndCost': 'Separate root-controlled gates remain pending at this source preparation; no assumed outcome or mutable run authority is borrowed.',
    'priorCacheNativePair': 'Closed valid, unadopted; its exact harness is a derivation parent, not a composed runtime candidate.',
    'physicalCaptureNotNeeded': 'Ordinary native gameplay; no fixture, public asset, compiled baseline or source tree copied.'})

for name in ['pair.mjs', 'checks-driver.py', 'bind-launch.py', 'authority.mjs']:
    text = rename((PARENT / name).read_text())
    (WORK / name).write_text(text)
    if name != 'authority.mjs':
        (WORK / (name + '.diff')).write_text(''.join(difflib.unified_diff(
            (PARENT / name).read_text().splitlines(True), text.splitlines(True),
            fromfile=str(PARENT / name), tofile=str(WORK / name))))

for name in ['strict.mjs', 'build-only.mjs']:
    text = rename((PARENT / name).read_text())
    text = (text.replace('/private/tmp/surf-feed-indexed-cache-20261004/patch-source.mjs',
                         str(CANDIDATE / 'patch-source.mjs'))
            .replace('export class GpuBoussinesq', 'export class SideFeed')
            .replace('single-reviewed-feed-component-source-', 'single-reviewed-indexed-side-feed-source-')
            .replace('Canonical GPU candidate was not substituted', 'Canonical SideFeed candidate was not substituted'))
    (WORK / name).write_text(text)
    (WORK / (name + '.diff')).write_text(''.join(difflib.unified_diff(
        (PARENT / name).read_text().splitlines(True), text.splitlines(True),
        fromfile=str(PARENT / name), tofile=str(WORK / name))))

commands = json.loads(rename((PARENT / 'commands.json').read_text()))
save('commands.json', commands)
plan = json.loads(rename((PARENT / 'plan.json').read_text()))
plan['purpose'] = 'One future unchanged b0 versus exact ascending indexed SideFeed weight scan ordinary native pair; no component cache, numerical/shader/geometry/grid change'
for arm in plan['arms']:
    arm['port'] += 2
    arm['cdp'] += 2
    arm['url'] = 'http://127.0.0.1:' + str(arm['port']) + '/?diagnostics'
plan['failure'] = plan['failure'].replace('4241/9651 then4242/9652', '4243/9653 then4244/9654')
plan['proposedChecksBeforeHardware'][0] = 'Whole-project candidate TypeScript compiler-host check; separate root-controlled indexed protocol proof and complete mock-host cost must be reviewed, not rerun by this native gate'
plan['limits'] = [
    'One fixed-order pair, five warm seconds then 90 passive; wall bins are not matched phases, no temperature/causal claim',
    'Only canonical SideFeed virtual source changes; GpuBoussinesq, component-cache state, shaders, grid, control timing, prefetch, writer, renderer and RNG remain b0',
    'Separate memory mock-host protocol/cost evidence is not a real GPU replay or native FPS result; outcomes pending root review',
    'No Vitest/default shared cache; Vite private cache/configLoader runner',
    'No source imports, checks, builds, network or browser executed by source preparer']
plan['proposedBuild']['sourceStrategy'] = 'Pinned pre-load exact candidateSource on canonical SideFeed.ts only in main/worker plugin instances; canonical imports retained and GpuBoussinesq unchanged'
plan.pop('componentCacheScope')
plan['indexedSideFeedScope'] = {
    'runtimeSource': spec, 'parentReady': record(CANDIDATE / 'ready.json'),
    'proofAndCost': 'Root-controlled separate CPU gates pending, no outcome assumed',
    'priorComponentCacheExcluded': True, 'nativeResultPending': True}
save('plan.json', plan)
save('derivation.json', {
    'schema': 'feed-indexed-fps-derivation/v1', 'sourceOnly': True,
    'parentReady': record(PARENT / 'ready.json'),
    'exactCopies': [{'borrowed': record(PARENT / name), 'owned': record(WORK / name), 'byteIdentical': True}
                    for name in ['survey.mjs', 'native-owned.mjs', 'passive-guard.mjs', 'public-assets.json']],
    'derivedSourceDiffs': [record(WORK / (name + '.diff')) for name in ['pair.mjs', 'checks-driver.py', 'bind-launch.py', 'strict.mjs', 'build-only.mjs']],
    'singleRuntimeTransform': spec,
    'inheritedInternalEnvironmentKeys': ['FULL_WRITER_FPS_LAUNCHER_REPORT', 'FULL_WRITER_FPS_EXPECTED_WORKER', 'FULL_WRITER_FPS_EXPECTED_SOLO_ONE_STEP'],
    'noRuntimeComposition': True})

readme = '''# Proposed indexed SideFeed ordinary FPS gate — source only

No source imports, checks, builds, bindings, network, browser or numerical operations have been executed during preparation. Root reviews this readiness, grants CPU compilation, verifies compiled outputs/bindings and grants a separate sole native lease. Root-controlled indexed proof/cost are separate pending evidence; no success or FPS gain is assumed.

Baseline is literal b0e003b8670c9d0be83bc9bb24c30b5382a54499, directly served from /private/tmp/surf-full-writer-adoption-20261004/dist: eleven pinned original outputs and worker b711e16b… (448,078 bytes). Common literal BUILD_ID=306258296. No source tree, public assets, compiled baseline or source symlinks are copied.

Candidate calls only the exact /private/tmp/surf-feed-indexed-scan-20261004/patch-source.mjs on canonical src/wave/SideFeed.ts. Original source is 10,038 bytes/ebdfb692…; the virtual candidate is 10,085 bytes/ac2b896d… . Only deviceShape's for-of weight scan becomes an ascending indexed scan over the same native Float64Array. GpuBoussinesq remains literal 41e21260…; the previous component-cache candidate is excluded. There is no new cache/state/cadence, shader, field, grid, physics or rendering change.

TypeScript parses the original whole-project tsconfig/include and uses CompilerHost.readFile substitution for this one canonical path, no emit/incremental state. Candidate-only Vite uses the identical root/config/BUILD_ID with configLoader=runner, owned cache/outDir, copyPublicDir=false and emptyOutDir=false. Source-pinned pre-load hooks run in fresh normal and worker plugin instances; the real worker SideFeed substitution is mandatory. Relative import paths remain canonical. Original/virtual source SHA and realm are recorded; all other canonical src loads require their frozen pins. Compilation and typing both assert the prefix before export class SideFeed stays literal. Installed TypeScript/Vite implementation/type boundaries are borrowed unchanged from the proven parent gate.

survey.mjs, native-owned.mjs, passive-guard.mjs and public-assets.json are byte-identical to the completed component-cache gate and its successful full-writer ancestor. The same High/Rich/High menu→Surf→Padang→Big→Paddle out route idles five warm seconds then samples exactly 90 seconds: numeric60 cap, 116,000 cells/dx2/fine1/stage2/64 components/render2/mask1/four cases, ordinary rider and actual soloOneStep=true. The initial 1708×966 window at60,60 must yield CSS1708×879/DPR2/canvas2989×1538; abort mismatch without resizing or emulation. Original page-only INSTRUMENT Mulberry32 seed0x5eed remains unchanged; worker RNG is not overridden. No lowered resolution, diagnostic GPU timer/profiler, synthetic stepping, keyboard/autopilot rider input or candidate composition.

New outer keys are FEED_INDEXED_FPS_READY_SHA256, FEED_INDEXED_FPS_CHECKS_READY_SHA256 and FEED_INDEXED_FPS_BINDINGS_SHA256. Existing native/guard internal FULL_WRITER_FPS_LAUNCHER_REPORT / EXPECTED_WORKER / EXPECTED_SOLO_ONE_STEP keys stay unchanged. The future CPU driver has 120 seconds plus5 seconds timeout cleanup, sequential first-failure stop: node strict.mjs → node build-only.mjs → python3 bind-launch.py → node --check for native/guard/survey/pair → node pair.mjs --run=false. Exact commands are recorded in commands.json. No Vitest/shared cache operation is introduced.

After reviewed compilation/bindings, the separate native command is env FEED_INDEXED_FPS_READY_SHA256=<reviewed> FEED_INDEXED_FPS_BINDINGS_SHA256=<reviewed> node pair.mjs --run=true --out=<fresh owned path>. Baseline4243/9653 must be valid and fully closed before candidate4244/9654. Occupied owned ports or4200 abort;4200 stays closed and5173 is untouched. Each arm retains175 seconds command abort plus5 seconds owned cleanup, no retries. Public38 read-only whitelist, pre-Chrome served-output hashing, source/public/compiled/helper authority before/after, fresh Chrome profiles, sole-page selection, owned-PID-only cleanup and real ECONNREFUSED proofs remain unchanged. Sandboxed EPERM is not closure evidence.

The derivative's two source arms each reference the same554 original canonical files with a separately declared one-file virtual transform; no fake patched filesystem hash is asserted. Separate exact candidate TS/Vite substitution metadata, baseline reuse metadata and later compiled arm manifests establish effective source identity. Old parent ready/bindings do not authorize this gate. All original failed/partial outputs must remain; stop the first failure without repair/retry/deletion.

Display cadence, fresh snapshots, simulation-wall progress, live telemetry and late bins are distinct measurements. Stage quantiles are not additive. One fixed-order native pair cannot establish phase matching, thermal cause, visual acceptance, general coverage or sustained60 physics. This source preparation establishes no numerical or native pass and makes no adoption claim.
'''
(WORK / 'README.md').write_text(readme)

artifacts = [record(p) for p in sorted(WORK.iterdir()) if p.is_file() and p.name not in ['ready.json', 'checks-driver-ready.json', 'freeze.json']]
dep_pins = [*dep['packageRecords'], dep['cdpHelper'], *dep['lockFiles'], dep['compilerImplementation'], dep['viteImplementation'], dep['viteWorkerConfigurationTypes'], dep['viteWorkerImplementation']]
direct = {p['path']: p for p in [*borrow, *dep_pins]}
save('ready.json', {
    'schema': 'feed-indexed-native-fps-ready/v1',
    'stage': 'source-ready; checks/build/hardware unexecuted',
    'preparedAt': datetime.now(timezone.utc).isoformat(), 'directory': str(WORK),
    'runtimeBaseline': BASELINE, 'documentationHeadReportedByRoot': '4a2657bea',
    'sourceAuthority': record(WORK / 'source-manifest.json'), 'sourceFileCounts': [554, 554],
    'runtimeDifference': spec, 'artifacts': artifacts,
    'borrowedSourceAuthorities': list(direct.values()),
    'baselineDirectDistReuse': True, 'baselineOutputFiles': 11,
    'publicAssets': record(WORK / 'public-assets.json'), 'noSourceTreeCopy': True,
    'noPrivateSourceSymlinks': True, 'noPublicAssetCopies': True,
    'wholeProjectCandidateStrict': 'TypeScript compilerHost.readFile substitution only; original tsconfig/src-only roots/noEmit/incrementalfalse',
    'candidateBundling': 'Source-pinned Vite pre-load transform on canonical SideFeed only, normal+freshworkerpluginfactory',
    'canonicalGpuAndComponentCacheExcluded': gpu,
    'proposedCpuCommands': commands['cpu'], 'executedChecksOrNumericalImports': False,
    'executedBuildServerBrowserHardware': False,
    'separateCpuAndHardwareApprovalRequired': True, 'nativePorts': [4243,9653,4244,9654],
    'port4200MustStayClosed': True, 'port5173Untouched': True})
save('checks-driver-ready.json', {
    'schema': 'feed-indexed-fps-checks-driver-ready/v1',
    'driver': record(WORK / 'checks-driver.py'), 'sourceReady': record(WORK / 'ready.json'),
    'commands': commands['cpu'], 'executed': False,
    'readOnlyUseLinks': [], 'noSourceClonesOrLinkRealpathImports': True})
save('freeze.json', {
    'schema': 'feed-indexed-fps-source-freeze/v1',
    'records': [record(p) for p in sorted(WORK.iterdir()) if p.is_file() and p.name != 'freeze.json'],
    'sourceOnly': True, 'ready': record(WORK / 'ready.json'),
    'driverReady': record(WORK / 'checks-driver-ready.json')})
print(json.dumps({'sourceOnly': True, 'ready': record(WORK / 'ready.json'),
                  'checksReady': record(WORK / 'checks-driver-ready.json'),
                  'freeze': record(WORK / 'freeze.json'),
                  'ownedRecords': len(json.loads((WORK / 'freeze.json').read_text())['records']),
                  'borrowedPins': len(direct), 'canonicalPerArm': len(files), 'virtual': spec['virtualCandidate']}, indent=2))
