# Proposed component-count cache ordinary FPS gate — source only

No imports/checks/build/network/browser operation has been executed during this preparation. Root must review the new readiness and CPU driver binding, grant CPU checks, independently verify the built candidate, and separately grant the native lease. This is not an adoption or FPS claim from the prior mock-host cost.

Baseline is unchanged b0e003b8670c9d0be83bc9bb24c30b5382a54499 runtime, served directly from /private/tmp/surf-full-writer-adoption-20261004/dist. Its eleven original outputs are independently pinned; worker b711e16b… is 448,078 bytes. Candidate uses only the exact parent patch-source.mjs at /private/tmp/surf-feed-components-cache-20261004, bound to ready a090e34a… . Literal BUILD_ID=306258296 is common. No source tree, public assets or baseline compiled outputs are copied.

The source strategy keeps canonical identities: a pre-load Vite hook calls the exact reviewed candidateSource only for canonical src/wave/gpu/GpuBoussinesq.ts, in fresh normal and worker plugin instances. Its original SHA is 41e21260…; the one virtual candidate SHA is c3fd4e6c… (24,025 bytes). Both compilation realms record the exact original/virtual identities; successful worker substitution is mandatory. Other canonical src loads require the frozen full-source pin. All relative imports and real paths remain original. Whole-project candidate typing parses the original tsconfig/include and substitutes only that file through CompilerHost.readFile, with no emit/incremental state. The installed TS implementation calls the host readFile for getSourceFile; installed Vite explicitly requires worker.plugins to return fresh instances. Those local implementation/type files are pinned, not imported during preparation.

survey.mjs, native-owned.mjs, passive-guard.mjs and public-assets.json are exact bytes from the successful full-writer ordinary gate. The page-only original INSTRUMENT Mulberry32 bootstrap starts at0x5eed; worker RNG is unchanged. Native/guard internal FULL_WRITER_FPS_LAUNCHER_REPORT / EXPECTED_WORKER / EXPECTED_SOLO_ONE_STEP keys remain byte-identical and are populated by the new pair driver. New outer authorization keys are FEED_COMPONENTS_FPS_READY_SHA256, FEED_COMPONENTS_FPS_CHECKS_READY_SHA256, and FEED_COMPONENTS_FPS_BINDINGS_SHA256.

The unchanged High/Rich/High menu→Surf→Padang→Big→Paddle out route idles five warm seconds then samples90 seconds, numeric60 cap, actual116,000cells/dx2/fine1/stage2/components64/render2/mask1/four cases, ordinary rider and solo one-step requests. Original1708×966 window launch must yield observed1708×879 CSS/DPR2/2989×1538 backing; abort on mismatch, never resize. No diagnostic GPU profiler, timer query, worker command, seed override, lowered resolution, keyboard/autopilot ride input, batching or contact drain. The original ?diagnostics page exposes unchanged telemetry only.

Baseline4241/9651 must be valid and fully closed before candidate4242/9652. The public38 whitelist is shared read-only. Every compiled output is fetched and hash-compared before Chrome, source/public/build authority is verified before/after each arm, and the caller preserves a whole-gate before/after inventory. Occupied owned ports/4200 abort. 4200 remains closed;5173 is untouched. Each arm has175s command abort plus5s cleanup; no retry/port cleanup of unrelated processes. Fresh owned Chrome profiles, sole-page selection, owned PID-only termination and actual ECONNREFUSED closure remain inherited. Native execution requires the real approved local TCP/Chrome environment; sandbox EPERM is not closure proof.

Proposed CPU commands, only after separate approval (120s sequence/5s timeout cleanup):

1. node strict.mjs
2. node build-only.mjs
3. python3 bind-launch.py
4. node --check native-owned.mjs
5. node --check passive-guard.mjs
6. node --check survey.mjs
7. node --check pair.mjs
8. node pair.mjs --run=false

Driver operation is env FEED_COMPONENTS_FPS_READY_SHA256=<new ready> FEED_COMPONENTS_FPS_CHECKS_READY_SHA256=<new checks-driver-ready> python3 checks-driver.py --run=true. The driver sets BUILD_ID306258296. Candidate Vite output/cache are inside this owned gate, configLoader=runner/copyPublicDir=false/emptyOutDir=false; no shared Vitest operation is present. Original failures/partial outputs are retained; first failure stops, no repair/retry/deletion. Only after root's compiled review: env FEED_COMPONENTS_FPS_READY_SHA256=<new ready> FEED_COMPONENTS_FPS_BINDINGS_SHA256=<new bindings> node pair.mjs --run=true --out=<fresh owned path>.

Old full-writer source-ready/build bindings cannot serve as new authorization: they describe the pre-writer e084 baseline. The derivative baseline wrappers now bind b0/b711 and the original ALT manifest. Candidate worker may change chunk names; its exact filename/hash is bound after build. Harness diffs change authority/paths/ports only. No fake matching-worker or unchanged rendered-chunk assumption is made.

Keep display cadence, fresh publications, simulation-wall progress, telemetry and late wall bins distinct. Stage quantiles are not additive request latency. One fixed-order pair cannot establish general coverage, phase matching, heat causation, visual acceptance or sustained60 physics. The prior exact nine-case protocol proof and32-pair mock-host cost are borrowed as separate evidence, not relabeled as native results or rerun by this gate.
