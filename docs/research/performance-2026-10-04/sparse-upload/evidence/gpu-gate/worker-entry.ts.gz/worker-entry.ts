import { SurfZoneRunner as OriginalRunner } from '../original/src/wave/SurfZoneRunner';
import { SurfZoneRunner as CandidateRunner } from '../candidate/src/wave/SurfZoneRunner';
import { BoussinesqSolver as OriginalSolver } from '../original/src/wave/BoussinesqSolver';
import { BoussinesqSolver as CandidateSolver } from '../candidate/src/wave/BoussinesqSolver';
import { GpuBoussinesq as OriginalGpu, DEVICE_READBACK, readbackTarget as originalTarget } from '../original/src/wave/gpu/GpuBoussinesq';
import { GpuBoussinesq as CandidateGpu, readbackTarget as candidateTarget } from '../candidate/src/wave/gpu/GpuBoussinesq';
import { PhysicalSurfWater as OriginalWater } from '../original/src/physics/PhysicalSurfWater';
import { PhysicalSurfWater as CandidateWater } from '../candidate/src/physics/PhysicalSurfWater';
import { PlungingLip as OriginalLip } from '../original/src/wave/PlungingLip';
import { PlungingLip as CandidateLip } from '../candidate/src/wave/PlungingLip';
import { decodeSurfZoneState as originalDecode, type SurfZoneState } from '../original/src/wave/surfZoneState';
import { decodeSurfZoneState as candidateDecode } from '../candidate/src/wave/surfZoneState';
import { barrelCasesFor as originalCases } from '../original/src/wave/barrel/barrelLibrary';
import { barrelCasesFor as candidateCases } from '../candidate/src/wave/barrel/barrelLibrary';
import { uniformEdges } from '../original/src/wave/ShallowWaterSolver';
import type { SurfZoneConfig } from '../original/src/wave/SurfZoneSimulation';
import { bytePair, comparePairs, directArrays, exactScalar, exactTree, stats, verifyStateWords, type BytePair } from './numeric';

const DT = 1 / 60;
const EXPECTED = { spot: 'padang', seed: 8761, significantHeight: 3.8, peakPeriod: 18, directionDegrees: 0, spreading: 150,
  tide: 0, windSpeed: 0, stage: 2, compute: 'auto', dx: 2, fineSpacing: 1, componentCount: 64 } as const;
const FIXTURE_SHA = '10b2651ef6b7f2a6a701ec98f0e266fe411a3c2e2e3ada8190ddd1fea1ca2783';
const FIXTURE_JSON_SHA = 'c4e6987fdeb7a53aad9316efe299aa56b0118d297390ee3981c727bec04c0d4c';
const CASES = [
  ['barrels/pad19-a20-l12.bin', 'a89e1a6fed766fa881aa6a057df39e619e2f6fa3801d3715892f0f88e3769b37', 149848],
  ['barrels/pad19-a30-l12.bin', '7a6acf5a5ca0186ec39587c83b52a25cec684078c9f848d63249ad333ef2f041', 163264],
  ['barrels/pad19-a45-l12.bin', '4e4a15298f2f2424d49a357a05f4e12f271f62b170d7887b825ac988cbe403af', 168424],
  ['barrels/periodic-padang19s-l12.bin', '8492f8fe051902e4053f0d4f98194b736fc3f0be0a32c60b070d53fa6ad2d3ab', 181852],
] as const;
type Device = OriginalGpu | CandidateGpu;
const devices: Device[] = [];
const finishedDevices = new Set<Device>();
const errors: string[] = [];
let closing = false;
const scope = globalThis as unknown as { postMessage(message: unknown): void; onmessage: ((event: MessageEvent) => void) | null };
const stage = (name: string, detail: unknown = null) => scope.postMessage({ kind: 'stage', sparseStage: name, detail, utc: new Date().toISOString() });
async function bounded<T>(promise: Promise<T>, ms: number, name: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try { return await Promise.race([promise, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(Error(name)), ms); })]); }
  finally { clearTimeout(timer); }
}
async function sha(bytes: Uint8Array): Promise<string> {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes as BufferSource));
  return Array.from(digest, x => x.toString(16).padStart(2, '0')).join('');
}
async function fetched(path: string): Promise<Uint8Array> {
  const response = await fetch(path); if (!response.ok) throw Error(`Asset ${path}: ${response.status}`);
  return new Uint8Array(await response.arrayBuffer());
}
async function decompress(bytes: Uint8Array, format: 'gzip' | 'deflate'): Promise<Uint8Array> {
  return new Uint8Array(await new Response(new Blob([bytes as BlobPart]).stream().pipeThrough(new DecompressionStream(format))).arrayBuffer());
}
async function fixture() {
  const compressed = await fetched('/fixture.json.gz'); if (await sha(compressed) !== FIXTURE_SHA) throw Error('Fixture gzip SHA');
  const json = await decompress(compressed, 'gzip'); if (await sha(json) !== FIXTURE_JSON_SHA) throw Error('Fixture JSON SHA');
  const capture = JSON.parse(new TextDecoder().decode(json)) as { scalars: { config: SurfZoneConfig; status: { seaTime: number } };
    serialized: { deflated: boolean; rawSha256: string; compressed: { base64: string; sha256: string } } };
  const config = capture.scalars.config;
  const keys = Object.keys(config); if (keys.length !== Object.keys(EXPECTED).length) throw Error('Unexpected complete ordinary config key count');
  for (const [key, value] of Object.entries(EXPECTED)) exactScalar((config as unknown as Record<string, unknown>)[key], value, `config.${key}`);
  const packed = Uint8Array.from(atob(capture.serialized.compressed.base64), c => c.charCodeAt(0));
  if (await sha(packed) !== capture.serialized.compressed.sha256) throw Error('SET1 compressed SHA');
  const raw = capture.serialized.deflated ? await decompress(packed, 'deflate') : packed;
  if (await sha(raw) !== capture.serialized.rawSha256) throw Error('SET1 raw SHA');
  const a = originalDecode(raw), b = candidateDecode(raw);
  verifyStateWords(raw, a.arrays); verifyStateWords(raw, b.arrays); exactTree(a, b, 'decoded fixture');
  if (!(a.solverTime >= (config.spinUpPeriods ?? 2) * config.peakPeriod)) throw Error('Fixture would execute water spin-up');
  for (const key of ['h', 'qx', 'qz', 'foam.dense', 'foam.residual', 'aeration.air', 'aeration.depth']) {
    if (!a.arrays[key] || !a.arrays[key].every(Number.isFinite)) throw Error(`Consumed nonfinite fixture ${key}`);
  }
  const seaTime = a.solverTime + a.seaTimeOffset;
  if (!(Math.abs(seaTime - capture.scalars.status.seaTime) < 1e-9)) throw Error('Fixture saved/source sea clock mismatch');
  const cases: Uint8Array[] = [];
  exactTree(originalCases('padang'), candidateCases('padang'), 'default cases');
  for (let i = 0; i < CASES.length; i += 1) {
    if (originalCases('padang')[i]?.asset !== CASES[i][0]) throw Error('Default case source order');
    const bytes = await fetched(`/${CASES[i][0]}`);
    if (bytes.length !== CASES[i][2] || await sha(bytes) !== CASES[i][1]) throw Error(`Case byte pin ${i}`);
    cases.push(bytes);
  }
  return { config, raw, a, b, cases, authority: { gzipSha: FIXTURE_SHA, jsonSha: FIXTURE_JSON_SHA, rawSha: capture.serialized.rawSha256,
    captureRef: '1bcc7c0c9', captureWorkerSha: 'eb1a337b66c0eea19035241aee1c46a129a039548e21916d428a6a1a50d2d3c5',
    config, solverTime: a.solverTime, seaTimeOffset: a.seaTimeOffset, seaTime, cells: a.nx * a.nz, nx: a.nx, nz: a.nz,
    counters: a.counters, casePins: CASES, limitation: 'Controlled F32 handover into accepted6f3; RATEH/NU constructor defaults, turbulence import reset, fresh rider and particle RNG; not historical replay.' } };
}
function ownedDevice<T extends Device>(device: T | undefined): T {
  if (!device) throw Error('Real GPU device unavailable');
  devices.push(device); device.device.pushErrorScope('validation');
  device.device.addEventListener('uncapturederror', (event) => errors.push(event.error.message));
  void device.device.lost.then(info => { if (!closing && !finishedDevices.has(device)) errors.push(`Device lost: ${info.reason} ${info.message}`); });
  return device;
}
async function finishDevice(device: Device): Promise<void> {
  if (finishedDevices.has(device)) return;
  const error = await device.device.popErrorScope(); finishedDevices.add(device); device.dispose();
  if (error) throw Error(`Device validation: ${error.message}`);
}
function healthy(): void { if (errors.length) throw Error(errors.join('\n')); }
/** Exact observed native staging copy, present only in parity/setup. Removed before timed pairs. */
function captureMapped(device: Device, n: number) {
  const staging = (device as unknown as { staging: GPUBuffer }).staging;
  const descriptor = Object.getOwnPropertyDescriptor(staging, 'getMappedRange');
  const original = staging.getMappedRange, words = new Uint32Array(9 * n); let calls = 0;
  Object.defineProperty(staging, 'getMappedRange', { configurable: true, writable: true, value: function(this: GPUBuffer, offset?: number, size?: number) {
    const result = original.call(this, offset, size);
    if (this !== staging || result.byteLength !== words.byteLength || (offset ?? 0) !== 0) throw Error('Observed staging method/range changed');
    words.set(new Uint32Array(result)); calls += 1; return result;
  } });
  return { words, calls: () => calls, restore: () => {
    if (descriptor) Object.defineProperty(staging, 'getMappedRange', descriptor); else delete (staging as unknown as { getMappedRange?: GPUBuffer['getMappedRange'] }).getMappedRange;
    if (staging.getMappedRange !== original) throw Error('Native staging method restoration failed');
  } };
}
function arraysTogether(a: object, b: object, prefix: string, skip: readonly string[] = []): BytePair[] {
  const aa = directArrays(a), bb = directArrays(b), result: BytePair[] = [];
  exactTree(Object.keys(aa), Object.keys(bb), `${prefix} keys`);
  for (const key of Object.keys(aa)) {
    if (skip.includes(key)) continue;
    const pair = bytePair(aa[key], bb[key], `${prefix}.${key}`);
    pair.currentA = () => (a as Record<string, unknown>)[key]; pair.currentB = () => (b as Record<string, unknown>)[key]; result.push(pair);
  }
  return result;
}
function rngCounter(object: object, seed: number, salt: number) {
  const holder = object as { random: () => number }, original = holder.random;
  if (typeof original !== 'function') throw Error('Expected source-pinned private particle stream');
  let calls = 0;
  holder.random = () => { calls += 1; return original(); };
  return { calls: () => calls, state: () => ((seed ^ salt) + Math.imul(0x6d2b79f5, calls)) >>> 0 };
}
async function smallFixture(boundary: 'open' | 'wall') {
  const grid = { nx: 32, xMin: 0, dx: 1, zEdges: uniformEdges(0, 40, 40), xBoundary: boundary };
  const a = new OriginalSolver(grid, () => 2, { manning: 0 }), b = new CandidateSolver(grid, () => 2, { manning: 0 });
  for (const s of [a, b]) {
    for (let row = 10; row < 14; row += 1) for (let x = 0; x < s.nx; x += 1) {
      const i = row * s.nx + x; s.h[i] += .8; s.qx[i] = .75 * s.h[i]; s.qz[i] = 1.5 * s.h[i];
    }
    s.h[0] = 0;
  }
  const ga = ownedDevice(await bounded(OriginalGpu.create(a), 10000, 'Original small device deadline'));
  const gb = ownedDevice(await bounded(CandidateGpu.createForWorker(b), 10000, 'Candidate small device deadline'));
  const wa = new OriginalWater(a, { peakPeriod: 10 }), wb = new CandidateWater(b, { peakPeriod: 10 });
  const la = new OriginalLip(a, 256), lb = new CandidateLip(b, 256);
  const ca = captureMapped(ga, a.h.length), cb = captureMapped(gb, b.h.length);
  const mapped = [bytePair(ca.words, cb.words, 'actual mapped 9 fields')];
  const fields = DEVICE_READBACK.map(index => bytePair(originalTarget(a, index), candidateTarget(b, index), `small field ${index}`));
  fields.push(bytePair(a.plungeHold, b.plungeHold, 'small plunge'));
  const ids = [a.h, a.qx, a.qz, b.h, b.qx, b.qz];
  let normalThrown = 0, heldThrown = 0;
  try {
    const jetA = { cell: a.cellIndex(8.5, 12.5), velocityX: 2, velocityZ: 4, volume: .3, waveHeight: 2.8,
      launchX: 8.5, launchY: 3, launchZ: 12.5, pourX: 9, pourY: 2, pourZ: 15, pourSpacing: .01, pourVY: -1,
      voidLength: 1, axisX: 1, axisY: -.1, voidHeight: .5, voidArea: .2, span: 1, dirX: 0, dirZ: 1, crestSpeed: 3, relativeSpeed: 1 };
    let heldA: ReturnType<OriginalLip['holdJet']> | undefined, heldB: ReturnType<CandidateLip['holdJet']> | undefined;
    for (let frame = 0; frame < 180; frame += 1) {
      if (frame >= 2 && frame <= 5) {
        wa.addReaction(8.25, 12.5, 113.37, -7, -67.91); wb.addReaction(8.25, 12.5, 113.37, -7, -67.91);
        wa.applyRemoteReaction(8.25, 12.5, .031, -.047); wb.applyRemoteReaction(8.25, 12.5, .031, -.047);
        wa.addReaction(.5, .5, 1, 2, 3); wb.addReaction(.5, .5, 1, 2, 3);
      }
      if (frame === 2) {
        normalThrown = la.launch(a.cellIndex(30.5, 12.5), { x: 5, z: 4 }, 3, .3, 3, undefined, undefined, 2.8);
        exactScalar(normalThrown, lb.launch(b.cellIndex(30.5, 12.5), { x: 5, z: 4 }, 3, .3, 3, undefined, undefined, 2.8), 'normal withdrawal');
        heldA = la.holdJet(jetA); heldB = lb.holdJet({ ...jetA, cell: b.cellIndex(8.5, 12.5) });
        exactTree(heldA, heldB, 'held withdrawal'); heldThrown = heldA.thrown;
        if (!(normalThrown > 0 && heldThrown > 0)) throw Error('Actual withdrawals were empty');
      }
      if (frame === 4 && heldA && heldB) exactScalar(la.crashJet(heldA.strip, { x: 9, y: 2, z: 15, spacing: .01, vy: -1 }, { x: 8.5, y: 3, z: 12.5 }),
        lb.crashJet(heldB.strip, { x: 9, y: 2, z: 15, spacing: .01, vy: -1 }, { x: 8.5, y: 3, z: 12.5 }), 'crash pour');
      if (frame === 6) for (let row = 3; row < 24; row += 1) for (let x = 1; x < 31; x += 2) {
        wa.applyRemoteReaction(x + .6, row + .6, .031, -.047); wb.applyRemoteReaction(x + .6, row + .6, .031, -.047);
      }
      if (frame === 7) { a.step(DT / 2); b.step(DT / 2); }
      if (frame === 8) { a.shiftAlongShore(3); b.shiftAlongShore(3); a.shiftAlongShore(-2); b.shiftAlongShore(-2); }
      await ga.step(DT); await gb.step(DT); healthy(); comparePairs(mapped); comparePairs(fields);
      exactScalar(ca.calls(), frame + 1, 'mapped A calls'); exactScalar(cb.calls(), frame + 1, 'mapped B calls');
      la.step(DT); lb.step(DT); comparePairs(fields); exactTree(la.exportState(), lb.exportState(), 'actual lip lifecycle');
      exactScalar(a.time, b.time, 'small solver time');
      const current = [a.h, a.qx, a.qz, b.h, b.qx, b.qz]; for (let i = 0; i < ids.length; i += 1) if (ids[i] !== current[i]) throw Error('Small public array replaced');
    }
    if (!(la.landings > 0)) throw Error('No actual landing within fixed 180 steps');
    exactScalar(la.landings, lb.landings, 'landings'); exactScalar(la.escapedVolume, lb.escapedVolume, 'escaped water');
    return { boundary, pairedSteps: 180, dt: DT, rawMappedFields: 9, normalThrown, heldThrown, landings: la.landings, escapedVolume: la.escapedVolume, solverTime: a.time };
  } finally { ca.restore(); cb.restore(); await finishDevice(ga); await finishDevice(gb); }
}

async function makeOriginal(config: SurfZoneConfig, state: SurfZoneState, cases: Uint8Array[]) {
  const runner = OriginalRunner.forWorker(config, { rider: true, renderSpacing: undefined, stance: 'regular', barrelCases: cases }, 'warm');
  const solver = runner.simulation.solver; if (!(solver instanceof OriginalSolver)) throw Error('Original expected own Boussinesq');
  runner.simulation.importState(state);
  const gpu = ownedDevice(await bounded(OriginalGpu.create(solver), 10000, 'Original ordinary device deadline'));
  runner.simulation.device = gpu; runner.setParticleLevel('high'); runner.setSprayLook('rich'); runner.setSprayEnabled(true);
  const bubbles = rngCounter(runner.bubbles, config.seed, 0xb0bb1e), spray = rngCounter(runner.spray, config.seed, 0x5b1a54);
  let steps = 0; const step = gpu.step; gpu.step = async dt => { steps += 1; return step.call(gpu, dt); };
  await runner.spinUp(); exactScalar(steps, 0, 'original spinUp water calls'); gpu.step = step;
  return { runner, solver, gpu, bubbles, spray, buffers: runner.createBuffers(), fields: DEVICE_READBACK.map(index => originalTarget(solver, index)) };
}
async function makeCandidate(config: SurfZoneConfig, state: SurfZoneState, cases: Uint8Array[]) {
  const runner = CandidateRunner.forWorker(config, { rider: true, renderSpacing: undefined, stance: 'regular', barrelCases: cases }, 'warm');
  const solver = runner.simulation.solver; if (!(solver instanceof CandidateSolver)) throw Error('Candidate expected own Boussinesq');
  runner.simulation.importState(state);
  const gpu = ownedDevice(await bounded(CandidateGpu.createForWorker(solver), 10000, 'Candidate ordinary device deadline'));
  runner.simulation.device = gpu; runner.setParticleLevel('high'); runner.setSprayLook('rich'); runner.setSprayEnabled(true);
  const bubbles = rngCounter(runner.bubbles, config.seed, 0xb0bb1e), spray = rngCounter(runner.spray, config.seed, 0x5b1a54);
  let steps = 0; const step = gpu.step; gpu.step = async dt => { steps += 1; return step.call(gpu, dt); };
  await runner.spinUp(); exactScalar(steps, 0, 'candidate spinUp water calls'); gpu.step = step;
  return { runner, solver, gpu, bubbles, spray, buffers: runner.createBuffers(), fields: DEVICE_READBACK.map(index => candidateTarget(solver, index)) };
}
type Ordinary = Awaited<ReturnType<typeof makeOriginal>> | Awaited<ReturnType<typeof makeCandidate>>;
function sourceContact(arm: Ordinary): void {
  const privateContact = arm.runner as unknown as { ordinaryContactOwner?: object; contactQueries?: object };
  if (!privateContact.ordinaryContactOwner || !privateContact.contactQueries || !arm.runner.session || !arm.runner.simulation.front) throw Error('Ordinary worker contact/rider/front missing');
  if (arm.runner.grid.spacing !== 2 || arm.solver.h.length !== 116000) throw Error('Ordinary grid/default render spacing changed');
}
function pairsFor(a: Ordinary, b: Ordinary): BytePair[] {
  const pairs = a.fields.map((array, i) => bytePair(array, b.fields[i], `ordinary9.${i}`));
  pairs.push(...arraysTogether(a.solver, b.solver, 'solver'), ...arraysTogether(a.runner.simulation, b.runner.simulation, 'simulation'),
    ...arraysTogether(a.runner.simulation.foam, b.runner.simulation.foam, 'foam'), ...arraysTogether(a.runner.simulation.aeration, b.runner.simulation.aeration, 'air'),
    ...arraysTogether(a.runner.bubbles, b.runner.bubbles, 'bubbles'), ...arraysTogether(a.runner.spray, b.runner.spray, 'spray'),
    // The lip's private presentation tube scratch can legitimately grow; fixed public snapshot capacity is checked instead.
    ...arraysTogether(a.runner.simulation.lip, b.runner.simulation.lip, 'lip', ['tubes']), ...arraysTogether(a.buffers, b.buffers, 'snapshot'),
    ...arraysTogether(a.runner.board!, b.runner.board!, 'board'), ...arraysTogether(a.runner.session!.rider, b.runner.session!.rider, 'rider'));
  const sa = (a.runner.simulation as unknown as { advectionStencil: object }).advectionStencil;
  const sb = (b.runner.simulation as unknown as { advectionStencil: object }).advectionStencil;
  pairs.push(...arraysTogether(sa, sb, 'sharedStencil'));
  return pairs;
}
const FRONT_KEYS = ['id', 'front', 'column', 'sigma', 'x', 'z', 'b', 'height', 'joined', 'depth', 'throwDepth', 'crestDepth', 'thrown', 'throwZ', 'footHeight', 'footDepth', 'broke', 'tau', 'fresh', 'jumped', 'seen', 'jetStrip', 'crashedAt', 'jetWindow', 'jetPace', 'jetBase', 'jetUntil', 'jetAt', 'crestZ', 'crestSpeed'];
const COUNTS = ['lipCount', 'tubeCount', 'bubbleCount', 'sprayCount', 'lipHitCount', 'strokeHitCount', 'frontCount'] as const;
function samePose(a: object, b: object, name: string): void {
  const aa = a as Record<string, unknown>, bb = b as Record<string, unknown>;
  for (const key of ['position', 'velocity', 'orientation', 'angularVelocity']) {
    const av = aa[key] as Record<string, number>, bv = bb[key] as Record<string, number>;
    for (const axis of ['x', 'y', 'z', 'w']) if (!Object.is(av[axis], bv[axis])) throw Error(`${name}.${key}.${axis}`);
  }
}
function assertOrdinary(a: Ordinary, b: Ordinary, pairs: readonly BytePair[]): void {
  healthy(); if (a.runner.simulation.device !== a.gpu || b.runner.simulation.device !== b.gpu) throw Error('Unexpected CPU/device fallback');
  comparePairs(pairs);
  for (let field = 0; field < a.fields.length; field += 1) for (let i = 0; i < a.fields[field].length; i += 1) {
    if (!Number.isFinite(a.fields[field][i])) throw Error(`Nonfinite ordinary device field ${field}[${i}]`);
  }
  samePose(a.runner.board!, b.runner.board!, 'board'); samePose(a.runner.session!.rider, b.runner.session!.rider, 'rider');
  exactScalar(a.runner.session!.phase, b.runner.session!.phase, 'ride phase');
  exactScalar(a.runner.session!.rider.attached, b.runner.session!.rider.attached, 'rider attached');
  exactScalar(a.solver.time, b.solver.time, 'ordinary solver time'); exactScalar(a.runner.simulation.seaTime, b.runner.simulation.seaTime, 'ordinary sea time');
  exactScalar(a.gpu.lastSubsteps, b.gpu.lastSubsteps, 'device CFL substeps');
  for (const key of COUNTS) exactScalar(a.buffers[key], b.buffers[key], key);
  for (const key of ['lipLaunches', 'lipVolume', 'lipJets', 'lipRollers'] as const) exactScalar(a.runner.simulation[key], b.runner.simulation[key], key);
  for (const key of ['sourceCount', 'breakingCount'] as const) exactScalar(a.runner.simulation.foam[key], b.runner.simulation.foam[key], `foam.${key}`);
  const sa = (a.runner.simulation as unknown as { advectionStencil: Record<string, unknown> }).advectionStencil;
  const sb = (b.runner.simulation as unknown as { advectionStencil: Record<string, unknown> }).advectionStencil;
  for (const key of ['dt', 'time', 'xMin', 'zMin', 'dx', 'nx', 'nz', 'ready']) if (!Object.is(sa[key], sb[key])) throw Error(`Shared stencil descriptor ${key}`);
  exactScalar(a.runner.simulation.lip.time, b.runner.simulation.lip.time, 'lip time'); exactScalar(a.runner.simulation.lip.landings, b.runner.simulation.lip.landings, 'lip landings');
  exactScalar(a.bubbles.calls(), b.bubbles.calls(), 'bubble random draws'); exactScalar(a.bubbles.state(), b.bubbles.state(), 'bubble RNG state');
  exactScalar(a.spray.calls(), b.spray.calls(), 'spray random draws'); exactScalar(a.spray.state(), b.spray.state(), 'spray RNG state');
  const pa = a.runner.simulation.front!.points, pb = b.runner.simulation.front!.points;
  exactScalar(pa.length, pb.length, 'F64 front count');
  for (let i = 0; i < pa.length; i += 1) for (let k = 0; k < FRONT_KEYS.length; k += 1) {
    const key = FRONT_KEYS[k]; const av = (pa[i] as unknown as Record<string, unknown>)[key], bv = (pb[i] as unknown as Record<string, unknown>)[key];
    if (!Object.is(av, bv)) throw Error(`F64 front[${i}].${key}: ${String(av)}/${String(bv)}`);
  }
}
async function compute(arm: Ordinary): Promise<number> {
  const start = performance.now(); await arm.runner.advanceAsync(1); arm.runner.fill(arm.buffers); return performance.now() - start;
}
async function ordinaryCost(input: Awaited<ReturnType<typeof fixture>>) {
  const a = await makeOriginal(input.config, input.a, input.cases), b = await makeCandidate(input.config, input.b, input.cases);
  sourceContact(a); sourceContact(b);
  const initialSolverTime = a.solver.time, initialSeaTime = a.runner.simulation.seaTime;
  exactTree(a.runner.simulation.exportState(), b.runner.simulation.exportState(), 'ordinary imported full state');
  const ca = captureMapped(a.gpu, a.solver.h.length), cb = captureMapped(b.gpu, b.solver.h.length);
  const rawPairs = [bytePair(ca.words, cb.words, 'ordinary actual mapped9')];
  // One genuine device step establishes residency; then actual material restore invalidates it.
  await compute(a); await compute(b); comparePairs(rawPairs);
  const restoreA = a.runner.simulation.exportState(), restoreB = b.runner.simulation.exportState(); exactTree(restoreA, restoreB, 'ordinary full restore');
  a.runner.simulation.importState(restoreA); b.runner.simulation.importState(restoreB);
  await compute(a); await compute(b); comparePairs(rawPairs);
  exactScalar(ca.calls(), 2, 'ordinary mapped A calls'); exactScalar(cb.calls(), 2, 'ordinary mapped B calls'); ca.restore(); cb.restore();
  exactTree(a.runner.simulation.exportState(), b.runner.simulation.exportState(), 'ordinary detailed pre-cost state');
  const costStart = performance.now();
  for (let warm = 0; warm < 4; warm += 1) { if (warm % 2) { await compute(b); await compute(a); } else { await compute(a); await compute(b); } }
  const pairs = pairsFor(a, b); assertOrdinary(a, b, pairs);
  const identityReaders = [() => a.solver.h, () => b.solver.h, () => a.solver.qx, () => b.solver.qx, () => a.solver.qz, () => b.solver.qz,
    () => a.runner.simulation.foam.dense, () => b.runner.simulation.foam.dense, () => a.runner.simulation.aeration.air, () => b.runner.simulation.aeration.air];
  const identities = identityReaders.map(read => read());
  const fromTime = a.solver.time, fromSea = a.runner.simulation.seaTime;
  const rows: { pair: number; order: 'AB' | 'BA'; originalMs: number; candidateMs: number; savingMs: number; solverTime: number; seaTime: number; originalPackMs: number; candidatePackMs: number; originalMapMs: number; candidateMapMs: number; substeps: number }[] = [];
  for (let pair = 0; pair < 24; pair += 1) {
    if (performance.now() - costStart > 20000) throw Error('20 s cost cutoff');
    let am: number, bm: number; const order = pair % 2 ? 'BA' : 'AB';
    if (order === 'AB') { am = await compute(a); bm = await compute(b); } else { bm = await compute(b); am = await compute(a); }
    assertOrdinary(a, b, pairs);
    for (let i = 0; i < identityReaders.length; i += 1) if (identityReaders[i]() !== identities[i]) throw Error('Public array identity replaced');
    rows.push({ pair, order, originalMs: am, candidateMs: bm, savingMs: am - bm, solverTime: a.solver.time, seaTime: a.runner.simulation.seaTime,
      originalPackMs: a.gpu.diagnostics.pack, candidatePackMs: b.gpu.diagnostics.pack, originalMapMs: a.gpu.diagnostics.map, candidateMapMs: b.gpu.diagnostics.map, substeps: a.gpu.lastSubsteps });
  }
  if (performance.now() - costStart > 20000) throw Error('20 s terminal cost cutoff');
  const expected = initialSolverTime + DT * 30; if (Math.abs(a.solver.time - expected) > 1e-10 || Math.abs(a.runner.simulation.seaTime - (initialSeaTime + DT * 30)) > 1e-10) throw Error('Exact 30 fixed-step phase bound');
  return { valid: true, scope: 'advanceAsync(1)+fill(reused buffers): complete worker computation/publication prep; excludes postMessage/renderer/status/after-pair validation',
    dt: DT, setupParitySteps: 2, warmupPairedSteps: 4, costPairs: 24, AB: 12, BA: 12, cells: a.solver.h.length, fieldsCompared: 9,
    fromTime, fromSea, toTime: a.solver.time, toSea: a.runner.simulation.seaTime, costPhaseMs: performance.now() - costStart,
    original: stats(rows.map(r => r.originalMs)), candidate: stats(rows.map(r => r.candidateMs)), pairedSaving: stats(rows.map(r => r.savingMs)),
    fullRestoredStateAndLifecycleParityBeforeCost: true, mappedNineBytesParityBeforeCost: true, allDirectNineFieldSnapshotSourceStencilBytesEveryPair: true,
    nativeCaptureRemovedDuringCost: true, particles: { level: 'high', look: 'rich', bubbleDraws: a.bubbles.calls(), bubbleState: a.bubbles.state(), sprayDraws: a.spray.calls(), sprayState: a.spray.state(), qaCounterOverheadIncluded: true }, rows };
}
let started = false;
scope.onmessage = async () => {
  if (started) { scope.postMessage({ kind: 'result', valid: false, failure: 'Single-use worker already started' }); return; }
  started = true;
  const report: { valid: boolean; stages: unknown[]; fixture?: unknown; parity?: unknown[]; cost?: unknown; failure?: unknown; cleanup?: unknown } = { valid: false, stages: [], parity: [] };
  try {
    if (!navigator.gpu || !isSecureContext) throw Error('Secure worker WebGPU unavailable');
    stage('FIXTURE_INTAKE'); const input = await fixture(); report.fixture = input.authority; stage('FIXTURE_PINNED', input.authority);
    for (const boundary of ['open', 'wall'] as const) { stage(`PARITY_${boundary}`); const result = await smallFixture(boundary); report.parity!.push(result); stage(`PARITY_${boundary}_PASSED`, result); }
    stage('ORDINARY_MATCHED_STATE_COST'); report.cost = await ordinaryCost(input); healthy();
    for (const device of devices) { if (finishedDevices.has(device)) continue; const error = await device.device.popErrorScope(); if (error) throw Error(`Device validation: ${error.message}`); }
    report.valid = true; stage('PASSED');
  } catch (error) { report.failure = { name: error instanceof Error ? error.name : 'unknown', message: String(error), stack: error instanceof Error ? error.stack : null }; stage('FIRST_FAILURE', report.failure); }
  finally { closing = true; for (const device of devices) device.dispose(); report.cleanup = { devicesDisposed: devices.length, ownedWorker: true, noRAFOrDrawing: true }; scope.postMessage({ kind: 'result', ...report }); }
};
