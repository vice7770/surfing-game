# Descending structural Hermite/facet trial — offline evidence

The frozen one-recipe trial is complete. This candidate improves the captured descending curl but is **not consumer-ready or adopted**: early ordinary surfaces, tight formation attachment and old terminal lifecycle remain unresolved. No tuning or per-frame exceptions were added.

Read `causal-analysis-and-next-scope.md` for the causal result and one proposed broader analytic crest-to-toe model. `recipe.md`, `prototype.py`, `evaluate.py` and `evaluation-start.json` preserve the pre-evaluation specification/code hashes. `report.json` is the complete raw result; `report.json.gz` is its deterministic lossless copy. `summary.json` and `causal-diagnostics.json` preserve both failures and classification. The six selected contours in `failure-profiles.json` are reconstructed by the unchanged frozen prototype for explanation only.

| Scope | Finite / attempted | Clean → crossed | Increased inherited pair count |
| --- | ---: | ---: | ---: |
| Actual captured outlines | 5 / 5 | 0 | 0 |
| Raw frames, all eight cases | 1,224 / 1,224 | 0 | 1 |
| Joint construction after raw F32 interpolation | 3,648 / 3,648 | 0 | 2 |
| Pretransform then F32 interpolation diagnostic | 3,648 / 3,648 | 12 | 16 |

Captured 1.13 m continuous widths are 1.215, 1.341, 1.410, 1.436 and 1.454 m. First row fails the 1.25 m target. All five fail 1.6 m clearance over 1.25 m width. Captured turns remain 45–55°; global formation introduces 27 frames with new turns above 90°. All 876 zero-reach ordinary roofs change, maximum 0.42244 h0. One already-contacting terminal interpolation remains in cap-floor contact. No new zero edge or invalid domain occurred.

The original live-source end hashes match their start hashes because evaluation completed before the root restored rejected production WIP. `immutable-source-baseline.json` independently verifies all twelve original candidate files against `/private/tmp/tube-rejected-live-source-verification-20261004/src/`, and links the parent's intentional restoration receipt. Subsequent baseline comparison uses those immutable files, not the restored live source. Neither restored code nor the twelve rejected files was modified by this offline task.

`captured-profile-comparison.png` compares actual outlines in metres against raw and rejected 0.25H geometry. `failure-profile-comparison.png` illustrates causal failures at illustrative h0×7 scaling. Static plots are numeric figures, not edited native imagery. Incoming crest31 is absent from the five captures; its outgoing tangent substitute is labeled. Proper crossings exclude endpoint/collinear and 3D-volume cases. Adjacent-time samples do not prove arbitrary cross-case/alongshore continuity, rider clearance, FPS or moving native appearance.

Current scope is scratch only. No production/build/native/browser/port/Git action and no further candidate evaluation took place. Native moving proof and actual tube entry remain required.
