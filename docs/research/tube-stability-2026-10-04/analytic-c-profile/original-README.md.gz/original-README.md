# Frozen analytic C-profile — first complete trial

This is one offline candidate, frozen before its single predeclared evaluation. It owns32..112 with free64/88 semantics, a paired roof, rolled cap, broad circular root and analytic floor. The captured shapes meet both declared opening targets and visibly descend, but **the global candidate is not safe/continuous enough to port or adopt**. No tuning or silent repair occurred.

| Scope | Attempted | Valid | New clean→crossed |
| --- | ---: | ---: | ---: |
| Actual captured outlines | 5 | 5 | 0 |
| All source frames | 1,224 | 1,219 | 39 |
| Adjacent F32 parameter interpolation | 3,648 | 3,632 | 116 |
| Predeclared lifecycle grid | 376 | 367 | 15 |
| Predeclared parameter/case grid | 672 | 672 | 23 |

The39 raw/116 interpolated new crossings are real Reef geometry failures. Its narrow steep domain makes the root circle intersect both the owned roof and preserved bulk. The15 phase/23 cross-case flags are different: intended cap/plateau contact stored a few F32 ULP below the shared plane (<=3e-8h0), creating two tiny proper crossings. All are retained in `report.json` and classified separately in `causal-diagnostics.json`.

Captured continuous widths are **1.597–1.840m at1.13m clearance** and **1.335–1.565m at1.6m clearance**; all exceed1.25m. Maximum stored turn22.91°, nominal sheet0.139–0.150m, useful crouched-interval vertical separation0.149–0.327m. These are actual saved outline measurements, not native/body/board/path proof. Captures begin at32 and cannot establish earlier preserved-bulk compatibility. Their authoredTD was inferred from tau/life and labeled.

Strict precision failures are five raw frames,16 adjacent samples andnine phase samples. Three raw failures have tau≈1e-13 and intended thickness≈1e-50h0 (mathematical ordinary limit). Two raw failures have positive formation0.001033/0.003432 and thickness below the declared8ULP floor. Phase failures include eight near retirement−1e-6TD andone still-retiring Reef sample. A precision-aware collapse cannot be adopted without repairing the separately found zero-state floor limits: eight held-input algebraic audits have maximum formation jump0.01240h0 and retirement jump0.01759h0 (8.68/12.31cm at illustrative7m).

Impact itself is continuous in the declared ±1e-6TD samples (largest displacement1.08e-6h0). Actual impact is1.149TD for seven held inputs and1.169TD Reef; authoredTD initiates sealing. No materially significant cap-floor penetration occurs in the valid grid, but the small F32 contact residuals are not marked exact contact passes. Original64 material semantics/velocities are intentionally replaced; no consumer uses this model yet.

See `integration-and-next-scope.md` for the concrete shared-provider route, remaining lifecycle/landmark/cache requirements and one minimum bounded-root structural option. This is a port plan, not a production-ready declaration. `recipe.md`, `prototype.py`, `evaluate.py` and `evaluation-start.json` retain exact pre-evaluation hashes. `report.json.gz` is a deterministic lossless copy of the complete result. Static numeric figures: `captured-profile-comparison.png`, `failure-profile-comparison.png`. Selected failure contours are in `failure-profiles.json`.

No production/source/docs edits, native/build/browser/server/port/Git actions or new candidate evaluation were performed. All previous trials and user builds remain untouched. The tube goal remains open.
