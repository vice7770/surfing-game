import { Vector3 } from 'three';
import { writeFileSync } from 'node:fs';
import { afterAll, describe, expect, it } from 'vitest';
import { AttachedRider, MAX_FLIGHT, RECOVERABLE_ERROR } from './AttachedRider';
import { BoardBody } from './BoardBody';
import { PlaneWater } from './PlaneWater';
import { AttachedRider as BaselineRider } from '../../../baseline/src/physics/AttachedRider';
import { BoardBody as BaselineBoard } from '../../../baseline/src/physics/BoardBody';
import { SurfZoneRunner } from '../wave/SurfZoneRunner';
import { SurfZoneRunner as BaselineRunner } from '../../../baseline/src/wave/SurfZoneRunner';

const DT = 1 / 60;
const ownerFixtures: unknown[] = [];
afterAll(() => writeFileSync('/private/tmp/tube-rider-support-trace-20261004/support-fixtures.json', JSON.stringify({
  scope: 'Actual CPU getter/status fixture data only; no native trajectory', rows: ownerFixtures,
}, null, 2) + '\n'));

function ownerRow(board: BoardBody, rider: AttachedRider) {
  const vec = (v: { x: number; y: number; z: number }) => ({ x: v.x, y: v.y, z: v.z });
  const q = board.orientation;
  return { boardPose: [...board.position.toArray(), ...q.toArray(), 1], ride: { supportDiagnostics: {
    ...rider.supportDiagnostics, board: {
      position: vec(board.position), centerOfMass: vec(board.centerOfMass), velocity: vec(board.velocity), angularVelocity: vec(board.angularVelocity),
      quaternion: { x: q.x, y: q.y, z: q.z, w: q.w },
      forces: Object.fromEntries(Object.entries(board.forces).map(([key, value]) => [key, vec(value)])),
      wettedArea: board.wettedArea, submergedVolume: board.submergedVolume, outsidePatches: board.outsidePatches, substepsTaken: board.substepsTaken,
    },
  } } };
}

// All enumerable public/private state, including work ledgers, solver scratch,
// parts and contact. Only the isolated diagnostic records are excluded for the
// baseline comparison. Getter-purity comparisons exclude nothing.
function data(value: unknown, omitDiagnostics = false): string {
  return JSON.stringify(value, (key, item) => {
    if (omitDiagnostics && /^support[A-Z]/.test(key)) return undefined;
    if (item instanceof Set) return [...item];
    if (ArrayBuffer.isView(item)) return Array.from(item as unknown as ArrayLike<number>);
    return item;
  });
}

function mounted(phase: 'prone' | 'standing' = 'standing', baseline = false) {
  // The independently imported baseline has distinct TS private-field identities;
  // only this comparison fixture bridges them. Runtime objects remain original.
  const board = (baseline ? new BaselineBoard() : new BoardBody()) as unknown as BoardBody;
  board.place(new Vector3(0, board.shape.centerOfMass.y, 0));
  const rider = (baseline ? new BaselineRider(board.shape, { phase }) : new AttachedRider(board.shape, { phase })) as unknown as AttachedRider;
  board.attach(rider);
  return { board, rider };
}

function countedWater() {
  const water = new PlaneWater();
  let queries = 0;
  const sample = water.sampleAt.bind(water);
  water.sampleAt = (...args) => { queries += 1; return sample(...args); };
  return { water, queries: () => queries };
}

describe('isolated support diagnostics', () => {
  it('is a pure getter with independent current and last-separation copies', () => {
    const { board, rider } = mounted();
    const r = rider as AttachedRider;
    const { water, queries } = countedWater();
    for (let i = 0; i < 360 && rider.attached; i++) board.step(DT, water);
    expect(rider.attached).toBe(false);
    const before = data({ board, rider });
    const count = queries();
    const first = r.supportDiagnostics;
    expect(first.lastSeparation).not.toBeNull();
    expect(first.lastSeparation!.state.attached).toBe(true);
    const second = r.supportDiagnostics;
    first.current.sway.x = 999;
    first.current.leg.extension = 999;
    first.current.cop.support.xMin = 999;
    first.current.limitTime.tip = 999;
    first.lastSeparation!.state.position.x = 999;
    first.lastSeparation!.thresholds.recoverableErrorMetres = 999;
    expect(r.supportDiagnostics).toEqual(second);
    expect(data({ board, rider })).toBe(before);
    expect(queries()).toBe(count);
    rider.mount(board);
    expect(r.supportDiagnostics.lastSeparation).toBeNull();
    expect(r.supportDiagnostics.current.finishSubsteps).toBe(0);
  });

  it.each(['prone-popup', 'standing-crouch-towed', 'standing-unpowered'] as const)(
    'keeps every ordinary physical state and water-query count byte equal to accepted source: %s', (mode) => {
      const a = mounted(mode === 'prone-popup' ? 'prone' : 'standing');
      const b = mounted(mode === 'prone-popup' ? 'prone' : 'standing', true);
      const aw = countedWater(); const bw = countedWater();
      let sawStanding = false; let sawSeparation = false;
      for (let step = 1; step <= 360; step++) {
        for (const { board, rider } of [a, b]) {
          rider.paddle = true;
          rider.steer = 0; rider.trim = 0; rider.compress = 0;
          if (mode === 'prone-popup' && step === 11) rider.popUp();
          if (rider.phase === 'standing') rider.crouch = 1;
          if (mode === 'standing-crouch-towed' && step <= 240) { board.velocity.z = 6; rider.velocity.z = 6; }
        }
        const before = data(a);
        (a.rider as AttachedRider).supportDiagnostics;
        expect(data(a)).toBe(before);
        a.board.step(DT, aw.water); b.board.step(DT, bw.water);
        (a.rider as AttachedRider).supportDiagnostics;
        expect(data(a, true), `physical state at ${mode} step ${step}`).toBe(data(b, true));
        expect(aw.queries()).toBe(bw.queries());
        sawStanding ||= a.rider.phase === 'standing';
        sawSeparation ||= !a.rider.attached;
      }
      expect(sawStanding).toBe(true);
      if (mode === 'standing-unpowered') expect(sawSeparation).toBe(true);
    });

  it('copies status telemetry without adding a water/contact query or changing existing status fields', () => {
    const a = mounted(); const b = mounted('standing', true);
    const water = new PlaneWater();
    a.board.velocity.z = b.board.velocity.z = 6;
    a.rider.velocity.z = b.rider.velocity.z = 6;
    a.board.step(DT, water); b.board.step(DT, water);
    // Mock only the runner's already-populated scalar/status dependencies. Do
    // not construct a sea, advance physics, create a GPU, or call its gauge.
    const fields = (pair: typeof a) => ({
      simulation: { seaTime: 1, timeToSet: 2, lastStepMs: 0, device: null, solver: { nx: 1, nz: 1, time: 1 },
        breakingFraction: () => 0, surf: { reading: () => null }, peelEstimate: () => null,
        lipLaunches: 0, lipVolume: 0, lipJets: 0, lipRollers: 0, lip: { airborneVolume: () => 0 }, breaking: { onsetScale: 1 }, stepCosts: {} },
      focus: { x: 0, z: 0 }, breaker: {}, breakDepth: 1, spray: { count: 0 }, board: pair.board,
      session: { board: pair.board, rider: pair.rider, phase: pair.rider.phase, separation: undefined,
        leash: { snapped: false, tension: 0, distance: 0, reeling: false }, surfer: { active: false },
        recovery: { state: 'free' }, breath: { level: 1 } },
      wave: { valid: false }, rideResets: 0, rescues: 0, snapshotKnock: 0,
      boardMs: 0, contactMs: 0, bubbleMs: 0, sprayMs: 0, soundMs: 0, pipelineStepMs: 0,
      snapshotFieldsMs: 0, fillMs: 0, batchMs: 0, batchSteps: 0,
    });
    const runner = Object.assign(Object.create(SurfZoneRunner.prototype), fields(a)) as SurfZoneRunner;
    const baseline = Object.assign(Object.create(BaselineRunner.prototype), fields(b)) as BaselineRunner;
    Object.defineProperty(runner, 'cue', { value: false });
    Object.defineProperty(baseline, 'cue', { value: false });
    const before = data(a);
    const result = runner.status();
    expect(data(a)).toBe(before);
    const diagnostic = result.ride!.supportDiagnostics!;
    ownerFixtures.push({ boardPose: [...a.board.position.toArray(), ...a.board.orientation.toArray(), 1], ride: { supportDiagnostics: diagnostic } });
    expect(diagnostic.current).toEqual((a.rider as AttachedRider).supportDiagnostics.current);
    expect(diagnostic.board.submergedVolume).toBe(a.board.submergedVolume);
    expect(diagnostic.board.forces.pressure).toEqual({ x: a.board.forces.pressure.x, y: a.board.forces.pressure.y, z: a.board.forces.pressure.z });
    const old = baseline.status();
    delete result.ride!.supportDiagnostics;
    delete result.pipelineMs; delete old.pipelineMs;
    expect(result).toEqual(old);
  });

  it.each(['flight-time', 'sway', 'posture-error'] as const)('records the exact existing %s release branch before detach', (branch) => {
    const { board, rider } = mounted();
    const r = rider as AttachedRider;
    // This fixture isolates only finish()'s existing branch precedence. It
    // deliberately prepares private state; the actual native trial never does.
    const internal = r as unknown as { feasible: boolean; sway: Vector3; limit: string; limitTime: { tip: number }; frame: () => void; target: Vector3 };
    internal.feasible = false;
    internal.frame = () => {};
    internal.target.copy(r.position);
    r.velocity.set(0, 0, 0); board.velocity.set(0, 0, 0);
    r.leg.extension = 1;
    if (branch === 'flight-time') r.flightTime = MAX_FLIGHT + 0.01;
    if (branch === 'sway') internal.sway.x = RECOVERABLE_ERROR + 0.01;
    if (branch === 'posture-error') { r.position.x += RECOVERABLE_ERROR + 0.01; internal.limit = 'tip'; internal.limitTime.tip = 0.2; }
    r.finish(DT, board);
    const last = r.supportDiagnostics.lastSeparation!;
    expect(r.attached).toBe(false);
    expect(last.branch).toBe(branch);
    expect(last.state.attached).toBe(true);
    expect(last.state.finishSubsteps).toBe(1);
    expect(last.state.lastSubstepSeconds).toBe(DT);
    expect(last.cause).toBe(branch === 'flight-time' ? 'lost board' : 'balance');
    expect(last.dominantLimit).toBe(branch === 'posture-error' ? 'tip' : null);
    ownerFixtures.push(ownerRow(board, r));
  });
});
