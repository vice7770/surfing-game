"""Run only after root confirms terminal closure. Offline reads; writes only new analysis scratch."""
from pathlib import Path
import ast, collections, hashlib, json, math

BASE=Path('/private/tmp/tube-rider-support-trace-20261004')
OUT=Path('/private/tmp/tube-rider-support-analysis-20261004')
PRIOR=Path('/private/tmp/tube-prepared-ordinary-entry-20261004')
def receipt(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def extract(row):
    d=row['ride']['supportDiagnostics'];s=d['current'];b=d['board'];q=b['quaternion'];x,y,z,w=[q[k] for k in ('x','y','z','w')]
    up=[2*(x*y-w*z),1-2*(x*x+z*z),2*(y*z+w*x)]
    forward=[2*(x*z+w*y),2*(y*z-w*x),1-2*(x*x+y*y)];heading=math.atan2(forward[0],forward[2])
    roll=math.atan2(up[0]*math.cos(heading)-up[2]*math.sin(heading),up[1])
    return {'step':row.get('step',0),'physicalSeconds':row.get('physicalSeconds',0),'seaTime':row['seaTime'],'phase':row['ride']['phase'],
      'boardPose':row['boardPose'],'riderPoints':row['riderPoints'],'balance':row['ride']['balance'],'publishedBank':row['ride']['bank'],
      'boardTiltDegrees':math.degrees(math.acos(max(-1,min(1,up[1])))),'boardHeadingDegrees':math.degrees(heading),'boardHeadingRelativeRollDegrees':math.degrees(roll),
      'headTopAboveBoardY':row['riderPoints'][7]+HEAD_RADIUS-row['boardPose'][1],
      'postureError':s['postureError'],'swayMagnitude':math.hypot(s['sway']['x'],s['sway']['z']),'flightTime':s['flightTime'],
      'flags':{k:s[k] for k in ('attached','inContact','upright','planing','banked','banking','feasible','contactFeasible','loaded')},
      'lastContactLimit':s['lastContactLimit'],'limitTime':s['limitTime'],'rawMargin':s['rawMargin'],'smoothedMargin':s['balanceMargin'],
      'planingSample':s['planingSample'],'leg':s['leg'],'bank':s['bank'],'sway':s['sway'],'swayRate':s['swayRate'],'cop':s['cop'],
      'finishSubsteps':s['finishSubsteps'],'lastSubstepSeconds':s['lastSubstepSeconds'],'riderPosition':s['position'],'riderVelocity':s['velocity'],
      'board':b,'wave':row['ride']['wave'],'nearestRaw':row['frontEvidence']['closestAny'],'nearestDrawn':row['frontEvidence']['nearestDrawnCrestAnyPhase'],
      'near40Count':row['frontEvidence']['nearBoardCount'],'targetStatus':row['tubeTarget']['status'],'witnessClassification':(row.get('witness') or {}).get('classification')}

INPUTS=[BASE/'native-first/report.json',BASE/'native-first/steps.ndjson',BASE/'native-first-owner.json',BASE/'native-first/launcher.json',
        BASE/'preparation.json',BASE/'policy.json',BASE/'run.py',BASE/'root-build-seal.json',BASE/'support-patch-receipt.json',PRIOR/'native-first/report.json']
before={str(p):receipt(p) for p in INPUTS}
report=json.loads(INPUTS[0].read_text());owner=json.loads(INPUTS[2].read_text());launcher=json.loads(INPUTS[3].read_text());prep=json.loads(INPUTS[4].read_text());steps=report['steps']
assert owner['complete'] is True and owner['exitCode']==0 and owner['firstFailure'] is None and owner['failures']==[],'Only a completed successful terminal owner may be analyzed'
assert report['complete'] is True and report['firstFailure'] is None and report['chromeClosed'] is True and report['browserErrors']==[]
assert owner['remainingOwnedPids']==[] and owner['independentClosureValid'] is True and owner['closedPorts']=={'4296':True,'9706':True}
assert all(owner['userPortsOpenBefore'][str(p)] and owner['userPortsOpenAfter'][str(p)] for p in (4310,4311,4312))
assert all(owner[k] is True for k in ('userServersStayedOpen','copiedDistUnchanged','diagnosticSourcesUnchanged','candidateProductionInputsUnchanged'))
assert owner['elapsedSeconds']<=180 and owner['cleanupElapsedSeconds']<=7 and report['source']==prep and prep['launchReady'] is True
assert [json.loads(line) for line in INPUTS[1].read_text().splitlines()]==steps and len(steps)==report['stepCount']==owner['captureValidation']['stepCount']

# Extract pure validators only; never execute owner top-level code or networking.
names={'bounded_file','integer','clock_equal','finite_number','steering_check','movie_gate','artifact_names_check','png_caps_check','sea_counters_check','front_evidence_check','popup_check','support_diagnostics_check','validate_capture','verify_copy','verify_production_inputs','verify_sources'}
nodes=[n for n in ast.parse((BASE/'run.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(nodes)==len(names)
scope={'Path':Path,'hashlib':hashlib,'json':json,'math':math,'MIB':1024*1024,'preparation':prep,'DIST':BASE/'dist','expected_assets':{**prep['assets'],**prep['diagnosticAssets']}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'pure-completed-support-owner-validators','exec'),scope)
capture=scope['validate_capture'](report,BASE/'native-first','candidate');assert capture==owner['captureValidation']
assert all(scope[n]() for n in ('verify_copy','verify_sources','verify_production_inputs'))
HEAD_RADIUS=report['referenceSphereRadii'][2]
rows=[extract(r) for r in steps];standing=[r for r in rows if r['phase']=='standing'];initial=extract(report['initialBody'])
def first(predicate):return next((r for r in rows if predicate(r)),None)
def first_standing(predicate):return next((r for r in standing if predicate(r)),None)
events={'firstStanding':standing[0] if standing else None,'firstActualHeadTopAtMostNominal1_13':first_standing(lambda r:r['headTopAboveBoardY']<=1.13),
        'firstStandingOffPlaning':first_standing(lambda r:not r['flags']['planing']),
        'firstStandingNotBanking':first_standing(lambda r:not r['flags']['banking']),
        'firstStandingInfeasible':first_standing(lambda r:not r['flags']['feasible']),
        'firstStandingTipLimit':first_standing(lambda r:r['lastContactLimit']=='tip'),
        'firstStandingRawMarginZero':first_standing(lambda r:r['rawMargin']==0),
        'firstStandingBalanceBelowHalf':first_standing(lambda r:r['balance']<.5),
        'firstStandingBalanceBelowOneTenth':first_standing(lambda r:r['balance']<.1),
        'firstPostureErrorBeyondRecovery':first(lambda r:r['postureError']>.25),
        'firstSwayBeyondRecovery':first(lambda r:r['swayMagnitude']>.25),
        'firstFlightBeyondRecovery':first(lambda r:r['flightTime']>.4),
        'firstLocalJoinedFrontObserved':first(lambda r:r['near40Count']>0),
        'lastStanding':standing[-1] if standing else None,'terminal':rows[-1]}
transitions=[]
previous=initial
for r in rows:
    changed={k:[previous['flags'][k],r['flags'][k]] for k in r['flags'] if previous['flags'][k]!=r['flags'][k]}
    if changed or previous['lastContactLimit']!=r['lastContactLimit']:
        transitions.append({'step':r['step'],'physicalSeconds':r['physicalSeconds'],'phase':r['phase'],'flags':changed,
                            'limit':[previous['lastContactLimit'],r['lastContactLimit']],'row':r})
    previous=r
lasts=[(r,r['ride']['supportDiagnostics']['lastSeparation']) for r in steps if r['ride']['supportDiagnostics']['lastSeparation'] is not None]
release=None
if lasts:
    rr,record=lasts[0]
    release={'firstObservedOrdinaryStep':rr['step'],'physicalSeconds':rr['physicalSeconds'],'seaTime':rr['seaTime'],'record':record,
      'preDetachScope':'Exact existing finish branch after posture error and cause-memory update, before separate(); enclosing row supplies ordinary clock. Public contact force/load are latest completed step ledgers, not newly resampled force at the branch.'}
minima={}
for key,get in {'any':lambda r:r['frontEvidence']['closestAny'],'pre':lambda r:r['frontEvidence']['closestByPhase']['pre'],
 'open':lambda r:r['frontEvidence']['closestByPhase']['open'],'post':lambda r:r['frontEvidence']['closestByPhase']['post'],
 'drawnAny':lambda r:r['frontEvidence']['nearestDrawnCrestAnyPhase']}.items():
    available=[r for r in steps if get(r) is not None]
    if available:
        r=min(available,key=lambda r:get(r)['horizontalDistance']);minima[key]={'step':r['step'],'physicalSeconds':r['physicalSeconds'],'record':get(r)}
prior=json.loads((PRIOR/'native-first/report.json').read_text());n=min(len(steps),len(prior['steps']))
input_differences=[r['step'] for r,p in zip(steps,prior['steps']) if r['input']!=p['input']]
delta_board=max((abs(a-b) for r,p in zip(steps,prior['steps']) for a,b in zip(r['boardPose'],p['boardPose'])),default=0)
delta_rider=max((abs(a-b) for r,p in zip(steps,prior['steps']) for a,b in zip(r['riderPoints'],p['riderPoints'])),default=0)
comparison={'priorSteps':len(prior['steps']),'newSteps':len(steps),'comparedPrefix':n,'inputDifferenceSteps':input_differences,
 'publishedBoardPoseMaximumAbsoluteDifference':delta_board,'publishedRiderPointsMaximumAbsoluteDifference':delta_rider,
 'exactPriorStepCount':len(steps)==len(prior['steps']),'exactInputSequence':not input_differences and len(steps)==len(prior['steps']),
 'exactPublishedBodyBoardGeometry':delta_board==0 and delta_rider==0 and len(steps)==len(prior['steps'])}
result={'schema':'rider-support-read-only-analysis/v1','resourcesStarted':False,'originalsModified':False,'inputReceipts':before,
 'ownerClosureVerified':True,'actualOwnerValidatorsReexecuted':True,'savedClosure':{'ownerComplete':True,'terminalExitCode':0,'elapsedSeconds':owner['elapsedSeconds'],
 'cleanupSeconds':owner['cleanupElapsedSeconds'],'closedPorts':owner['closedPorts'],'remainingOwnedPids':owner['remainingOwnedPids'],'allThreeUserPortsPreserved':True,'scope':'Saved terminal proof only; no live port probe'},
 'ordinaryTrial':{'steps':len(steps),'physicalSeconds':steps[-1]['physicalSeconds'],'stop':report['stop'],'phaseCounts':dict(collections.Counter(r['ride']['phase'] for r in steps)),
 'popup':capture['popupControl'],'steering':capture['steeringControl'],'targetCounts':dict(collections.Counter(r['tubeTarget']['status'] for r in steps)),
 'witnessCounts':dict(collections.Counter((r['witness'] or {}).get('classification','not measured') for r in steps)),
 'videoTrigger':report['videoTrigger'],'entry':report['entry'],'near40Counts':dict(collections.Counter(r['near40Count'] for r in rows))},
 'priorOrdinaryComparison':comparison,'initial':initial,'events':events,'flagOrLimitTransitions':transitions,'exactRelease':release,'frontMinima':minima,
 'standingFlagCounts':{k:dict(collections.Counter(r['flags'][k] for r in standing)) for k in ('planing','banked','banking','feasible','inContact','loaded')},
 'standingLimitCounts':dict(collections.Counter(r['lastContactLimit'] for r in standing)),
 'precursorTrajectory':rows[max(0,(release['firstObservedOrdinaryStep'] if release else len(rows))-130):],
 'interpretationLimits':['This observation records branch cause and support states, not an independent hydraulic-force validity proof.',
 'No new water/contact queries are made. Planing speed is the existing prepare-time sample; board force vectors are mean ledgers of the published ordinary step.',
 'No current indexed body cavity witness or roof collision can be inferred from a balance/status label.',
 'A preformed/raw-front library clock forecasts shape, not a guaranteed future ordinary arrival or body-fit passage.',
 'Post-step state retains only the final rider substep, plus exact release state; any within-step transient with recovery is not fully reconstructed.']}
after={str(p):receipt(p) for p in INPUTS};assert after==before;result['inputReceiptsUnchangedAfterAnalysis']=True
(OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
summary={k:result[k] for k in ('schema','resourcesStarted','originalsModified','ownerClosureVerified','savedClosure','ordinaryTrial','priorOrdinaryComparison','exactRelease','standingFlagCounts','standingLimitCounts','frontMinima','interpretationLimits')}
summary['events']={k:({'step':r['step'],'physicalSeconds':r['physicalSeconds'],'phase':r['phase'],'flags':r['flags'],'planingSample':r['planingSample'],'boardRollDegrees':r['boardHeadingRelativeRollDegrees'],'postureError':r['postureError'],'swayMagnitude':r['swayMagnitude'],'flightTime':r['flightTime'],'limit':r['lastContactLimit'],'rawMargin':r['rawMargin'],'balance':r['balance']} if r else None) for k,r in events.items()}
summary['analysis']=receipt(OUT/'analysis.json');(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'steps':len(steps),'ownerVerified':True,'releaseBranch':release['record']['branch'] if release else None,'releaseCause':release['record']['cause'] if release else None,'releaseStep':release['firstObservedOrdinaryStep'] if release else None,'priorComparison':comparison,'output':str(OUT/'summary.json')}))
