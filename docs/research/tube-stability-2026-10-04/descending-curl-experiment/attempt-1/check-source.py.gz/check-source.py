#!/usr/bin/env python3
"""Offline source-only checks: never import/execute the native launcher."""
from pathlib import Path
import ast, datetime, hashlib, json, re, shutil, subprocess
WORK=Path('/private/tmp/tube-whole-curl-native-20261004')
BASE=Path('/private/tmp/tube-no-foam-balls-20261004')
checks=[]
def check(name, condition):
    checks.append({'name':name,'passed':bool(condition)})
    assert condition,name
node=shutil.which('node');check('Installed Node for syntax-only --check',bool(node))
for name in ('native.mjs','native-owned.mjs','ray-faces.mjs'):
    result=subprocess.run([node,'--check',str(WORK/name)],capture_output=True,text=True,check=False,timeout=10)
    checks.append({'name':name+' syntax','passed':result.returncode==0,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    assert result.returncode==0,result.stderr
for name in ('run.py','check-source.py'):
    ast.parse((WORK/name).read_text());check(name+' AST syntax',True)
source=(WORK/'native.mjs').read_text();baseline=(BASE/'native.mjs').read_text()
for name in ('SETTINGS','OVERRIDES','GRAPHICS'):
    pattern=rf'const {name} = .*?;' 
    ours=re.search(pattern,source,re.S).group();old=re.search(pattern,baseline,re.S).group()
    check(name+' exact baseline source',ours==old)
for exact in (
    'const eye=[155.32094597816467,4.819468761980533,-.038138747215270996];',
    'const target=[150.3824691772461,.8194687619805336,-6.938243746757507];',
    'const candidates=[],targetSigma=32.379207311;',
    'await d.start(${JSON.stringify(SETTINGS)},${JSON.stringify(OVERRIDES)},{rider:false,lab:true});',
    'await d.mode.sweptBarrel.ready;d.setWaterLook(\'rich\');await d.setTimeOfDay(\'midday\');',
    'd.resize(1708,879);'):
    check('Preserved baseline '+exact,exact in source and exact in baseline)
check('Exact 1047 settle',"__wholeCurl.steps(1047)" in source)
check('Choose exactly once after fixed settle',source.count('__wholeCurl.choose()')==1)
check('Three fixed PNG indices', 'const pngIndices=[18,30,60];' in source)
check('60 sequential ordinary step calls', 'physicalStepIndex<=60' in source)
check('No material opacity assignments',not re.search(r'\.opacity\s*=(?!=)',source))
check('No mesh visibility assignments',not re.search(r'\.visible\s*=(?!=)',source))
check('No legacy visibility/opacity inspection functions',not any(s in source for s in ('setFoamInspection','setRollerInspection','no-rollers-','hidden-water-')))
check('Ray helper exact unchanged baseline',(WORK/'ray-faces.mjs').read_bytes()==(BASE/'ray-faces.mjs').read_bytes())
check('Baseline owner receipt exact unchanged',(WORK/'baseline-native-first-owner.json').read_bytes()==(BASE/'native-first-owner.json').read_bytes())
result=subprocess.run(['python3',str(WORK/'run.py'),'--arm','candidate'],capture_output=True,text=True,check=False,timeout=10)
check('Source-only owner plan exit',result.returncode==0)
plan=json.loads(result.stdout)
check('Plan starts no resources',plan['sourceOnlyPlan'] and plan['resourcesStarted'] is False)
check('Only fresh owned ports',plan['ports']==[4290,9700])
check('User servers retained',plan['untouchedUserPorts']==[4310,4311])
check('Whole/command/cleanup deadlines', [plan[k] for k in ('wholeSeconds','commandSeconds','cleanupSeconds')]==[180,168,7])
check('Capture byte caps',plan['singleClipMaximumBytes']==16*1024*1024 and plan['reportMaximumBytes']==2*1024*1024)
receipt={'schema':'tube-whole-curl-source-checks/v1','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceOnly':True,'resourcesStarted':False,'complete':True,'checks':checks,'sourceOnlyPlan':plan,
    'limitations':'Syntax/static preserved-input checks only. No built artifact, MediaRecorder capability, pixels, timing, cleanup runtime or tube quality verified.'}
(WORK/'source-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
def file_receipt(path):
    body=path.read_bytes();return {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
manifest={'schema':'tube-whole-curl-source-manifest/v1','sourceOnly':True,'baselinePath':str(BASE),
    'ownedSources':[file_receipt(WORK/name) for name in ('native.mjs','native-owned.mjs','ray-faces.mjs','run.py','check-source.py','README.md','baseline-native-first-owner.json')],
    'baselineReferences':[file_receipt(BASE/name) for name in ('native.mjs','native-owned.mjs','ray-faces.mjs','run.py','native-first-owner.json','native-first/report.json')],
    'sharedCdpHelper':file_receipt(Path('/Users/regina/Desktop/Projects/surfing-game/scripts/browser/cdp.mjs')),
    'checksReceipt':file_receipt(WORK/'source-checks.json'),'builtDist':None,'captureOutputs':None}
(WORK/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'complete':True,'sourceOnly':True,'resourcesStarted':False,'checks':len(checks),
    'receipt':str(WORK/'source-checks.json'),'manifest':str(WORK/'source-manifest.json')}))
