from pathlib import Path
work=Path('/private/tmp/tube-directed-entry-20261004');p=work/'native.mjs';s=p.read_text()
s=s.replace("import { createWitnessSampler } from './body-witnesses.mjs';", "import { createWitnessSampler } from './body-witnesses.mjs';\nimport { createTubeTargetSelector } from './tube-target.mjs';")
s=s.replace('/private/tmp/tube-coherent-warmup-native-20261004','/private/tmp/tube-directed-entry-20261004').replace('PORT=4292,CDP=9702','PORT=4293,CDP=9703')
s=s.replace("const POLICY={style:'line',waitOutside:5,rise:1,lineDegrees:60,giveUp:30,stall:false};", "const FIXED_POLICY=JSON.parse(readFileSync(join(WORK,'policy.json'))),POLICY=FIXED_POLICY.pilot;")
s=s.replace("schema:'tube-coherent-warmup-entry-native/v1'", "schema:'tube-directed-entry-native/v1'")
a=s.index(' graphics:GRAPHICS,policy:');b=s.index('\n source:',a);s=s[:a]+" graphics:GRAPHICS,policy:FIXED_POLICY,"+s[b:]
s=s.replace("First published fall/separation/reset increase or pilot done;", "First published fall/separation/reset increase, locked target loss, detector budget or pilot done;")
s=s.replace("first eligible actual standing row: drawn loft indices>0 and finite abs(curlDistance)<=15 or witness partial/contained", "first eligible actual standing row: drawn loft indices>0 and qualified actual mouth within15m or witness partial/contained")
s=s.replace("function install(Autopilot,autopilotView,riderPartVolumes,createWitnessSampler,policy){", "function install(Autopilot,autopilotView,riderPartVolumes,createWitnessSampler,createTubeTargetSelector,fixedPolicy){\n const policy=fixedPolicy.pilot;")
s=s.replace("const pilot=new Autopilot(policy),measure=createWitnessSampler(),radii=", "const pilot=new Autopilot(policy),measure=createWitnessSampler(),selector=createTubeTargetSelector(fixedPolicy.target),radii=")
s=s.replace('standingSteerStarted=false,gentleSteer=0;', 'targetState=null;')
s=s.replace("   pilot:{state:pilot.state", "   tubeTarget:clone(targetState),pilot:{state:pilot.state")
a=s.index(' async function step(){');b=s.index('  const w=view.ride.wave',a)
s=s[:a]+''' function refreshTarget(){
  if(detectorFailure||detectorMs>=fixedPolicy.finite.detectorMilliseconds){targetState={status:'detector-budget-or-failure',target:null,disabledReason:detectorFailure??'20s cumulative detector budget'};return;}
  const snap=mode.host.snapshot,begin=performance.now();
  try{targetState=selector.select(mode.barrelLoft,Array.from(snap.board.subarray(0,3)),snap.status.ride,Array.from(snap.rider.subarray(0,21)),radii[2],measure.columns);}
  catch(error){detectorFailure=String(error?.stack??error);targetState={status:'detector-failure',target:null,disabledReason:detectorFailure};}
  detectorMs+=performance.now()-begin;
 }
 async function step(){must(lab.clock.paused&&mode.host.outstandingSteps===0,'Paused drained ordinary step required');
  if(targetState.status==='target-lost'||targetState.status.startsWith('detector-'))return{noStep:true,stopKind:targetState.status,tubeTarget:clone(targetState)};
  const before=mode.host.snapshot.status.seaTime,view=autopilotView(mode.host,mode.focus.z,0);must(view,'Actual production pilot view required');
  const input=pilot.next(view,DT),requestedPilotSteer=input.steer;
  const target=targetState.target?{...targetState.target,boardX:view.board.x,boardZ:view.board.z}:null;
  const steeringControl={...selector.steer(target,view.board.heading,DT),requestedPilotSteer,standing:view.ride.phase==='standing',
   inputTarget:target?{front:target.front,x:target.x,z:target.z,rowBracket:target.rowBracket,sigmaBracket:target.sigmaBracket,distance:target.distance}:null};
  input.steer=steeringControl.actualInputSteer;
''' +s[b:]
s=s.replace("if(!popupIssued&&firstGo&&prone&&(view.ride.cue||manualGate)){", "if(!popupIssued&&firstGo&&prone&&target&&(view.ride.cue||manualGate)){")
s=s.replace("  const row=current();row.step=++steps;", "  refreshTarget();\n  const row=current();row.step=++steps;")
s=s.replace("scope:'Read-only raw snapshot front records grouped separately from actual drawn loft rows; no geometry/source replacement or target selection'", "scope:'Read-only raw snapshot front records grouped separately from actual drawn loft rows; candidate target is separately derived from active indexed geometry'")
s=s.replace("frontInventory:frontInventory(),visibleHeadExtents", "frontInventory:frontInventory(),tubeTarget:clone(targetState),visibleHeadExtents")
s=s.replace("window.__naturalEntry={step,current,checkpoint", "refreshTarget();\n window.__naturalEntry={step,current,checkpoint")
s=s.replace("(${createWitnessSampler.toString()}),${JSON.stringify(POLICY)}", "(${createWitnessSampler.toString()}),(${createTubeTargetSelector.toString()}),${JSON.stringify(FIXED_POLICY)}")
s=s.replace("report.stop={kind:'pilot-done-before-step',...row}", "report.stop={kind:row.stopKind??'pilot-done-before-step',...row}")
a=s.index('  const curlDistance=row.ride.wave.curlDistance');b=s.index('    const videoStart=await page.eval',a)
s=s[:a]+'''  const mouth=row.tubeTarget?.target,qualifiedMouthDistance=mouth?.qualified&&Number.isFinite(mouth.distance)?mouth.distance:null;
  const mouthNear=qualifiedMouthDistance!==null&&qualifiedMouthDistance<=15;
  const witnessClassification=row.witness?.classification??null,witnessQualifies=witnessClassification==='partial'||witnessClassification==='contained';
  if(videoStartStep===null&&row.ride.phase==='standing'&&(row.loft?.indices??0)>0&&(mouthNear||witnessQualifies)){
    report.videoTrigger={triggered:true,step:row.step,seaTime:row.seaTime,physicalSeconds:row.physicalSeconds,loftIndexCount:row.loft.indices,
      qualifiedMouthDistance,mouthNear,targetFront:mouth?.front??null,witnessClassification,witnessQualifies};
''' +s[b:]
s=s.replace("  if(row.pilot.state==='done'){", "  if(row.tubeTarget.status==='target-lost'||row.tubeTarget.status.startsWith('detector-')){report.stop={kind:row.tubeTarget.status,step:row.step,tubeTarget:row.tubeTarget};break;}\n  if(row.pilot.state==='done'){")
s=s.replace("entry:!!report.entry.firstConnectedWitnessEntry,detectorMs", "entry:!!report.entry.firstConnectedWitnessEntry,target:row.tubeTarget.status,targetFront:row.tubeTarget.lockedFront,detectorMs")
s=s.replace("Root-frozen accepted raw/held roof plus coherent startup candidate;", "Root-frozen accepted raw/held roof plus accepted coherent startup;")
p.write_text(s)
