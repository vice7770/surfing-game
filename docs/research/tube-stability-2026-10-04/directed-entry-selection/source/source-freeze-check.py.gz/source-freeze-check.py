"""Hash/copy and source-structure checks only; no runtime launch or networking."""
from pathlib import Path
import ast, hashlib, json, subprocess, datetime
W=Path('/private/tmp/tube-directed-entry-20261004');B=Path('/private/tmp/tube-coherent-warmup-native-20261004')
def sha(body):return hashlib.sha256(body).hexdigest()
def receipt(p):
    body=p.read_bytes();return {'file':str(p),'bytes':len(body),'sha256':sha(body)}
old=json.loads((B/'candidate-source-frozen.json').read_text());new=json.loads((W/'candidate-source-frozen.json').read_text())
assert len(old)==len(new)==327 and set(old)==set(new)
for key,value in new.items():
    body=Path(value['path']).read_bytes();assert len(body)==old[key]['bytes']==value['bytes'] and sha(body)==old[key]['sha256']==value['sha256']
base=json.loads((B/'preparation.json').read_text());assets={**base['assets'],**base['diagnosticAssets']}
assert len(assets)==50 and {str(p.relative_to(W/'dist')) for p in (W/'dist').rglob('*') if p.is_file()}==set(assets)
for key,value in assets.items():
    body=(W/'dist'/key).read_bytes();assert len(body)==value['bytes'] and sha(body)==value['sha256'] and body==(B/'dist'/key).read_bytes()
for path in base['productionInputs']['extraCandidateChangedFiles']:
    assert sha((W/'candidate'/path['path']).read_bytes())==path['candidateSha256']
assert (W/'candidate.patch').read_bytes()==(B/'candidate.patch').read_bytes()
assert (W/'native-owned.mjs').read_bytes()==(B/'native-owned.mjs').read_bytes()
body=(W/'body-witnesses.mjs').read_text();prior=(B/'body-witnesses.mjs').read_text()
assert body[:body.index(' function measure(')]==prior[:prior.index(' return function measure(')]
original_measure=prior[prior.index(' return function measure('):].replace(' return function measure(', ' function measure(',1)
original_measure=original_measure[:-len(' };\n}\n')]+' }\n'
assert body[body.index(' function measure('):body.index(' // The directed-entry selector')]==original_measure
driver=(W/'native.mjs').read_text();install=driver[driver.index('function install('):driver.index('\nlet page,exitCode=')]
assert install.count('d.step(input)')==1 and install.count('mode.update(DT)')==1 and 'pilot.next(view,DT)' in install
for forbidden in ('pilot.go(','.reset(','.prepare(','.setState(','.place(','.teleport(','.setRide(','.setCue(','.applyForce('):assert forbidden not in install
assert 'input.steer=steeringControl.actualInputSteer' in install and 'prone&&target&&(view.ride.cue||manualGate)' in install
assert "if(view.ride.phase==='standing')Object.assign(input,{crouch:1,compress:0})" in install
assert driver.index('video.track.requestFrame()')>driver.index('recorder.start(500)')
prior_driver=(B/'native.mjs').read_text()
media_start=' async function beginVideo()';media_end=' function videoFrame()'
assert driver[driver.index(media_start):driver.index(media_end)]==prior_driver[prior_driver.index(media_start):prior_driver.index(media_end)]
# The recorder start callback is declared before starting; request occurs within the same synchronous try block.
start_block=driver[driver.index('recorder.start(500)'):driver.index('  }catch',driver.index('recorder.start(500)'))] if '  }catch' in driver[driver.index('recorder.start(500)'):] else driver[driver.index('recorder.start(500)'):]
assert 'video.track.requestFrame()' in start_block and 'requestedBeforeRecorderStartEvent:true' in start_block
target=(W/'tube-target.mjs').read_text();assert 'timeBudgetMilliseconds' in target and 'performance.now()-scanStarted' in target
assert 'covering.length!==1' in target and 'h.length!==3' in target and 'lockedFront!==null&&front!==lockedFront' in target
owner=(W/'run.py').read_text();ast.parse(owner)
assert 'USER_PORTS=(4310,4311,4312)' in owner and 'PORTS=(4293,9703)' in owner
assert 'start_new_session=True' in owner and 'os.killpg(proc.pid,sig)' in owner and 'os.killpg(' not in owner.replace('os.killpg(proc.pid,sig)','')
assert 'server.shutdown' in owner and "key in expected_assets" in owner and 'len(records)!=327' in owner
checks={}
for name in ['helper-fixtures.json','installed-driver-fixtures.json','owner-source-checks.json']:
    x=json.loads((W/name).read_text());assert x['failed']==0 and x['resourcesStarted'] is False;checks[name]={'passed':x['passed'],'receipt':receipt(W/name)}
ports=json.loads((W/'read-only-ports-escalated.json').read_text())['ports'];assert all(ports[str(p)]['closed'] is True for p in [4293,9703]);assert all(ports[str(p)]['closed'] is False for p in [4310,4311,4312])
for name in ['native.mjs','native-owned.mjs','body-witnesses.mjs','tube-target.mjs','helper-fixtures.mjs','installed-driver-fixtures.mjs']:
    r=subprocess.run(['node','--check',str(W/name)],capture_output=True,text=True,check=True);assert not r.stderr
plan=subprocess.run(['python3',str(W/'run.py'),'--arm','candidate'],capture_output=True,text=True,check=True);x=json.loads(plan.stdout);assert x['resourcesStarted'] is False and x['ports']==[4293,9703] and x['userPorts']==[4310,4311,4312]
(W/'dry-plan.json').write_text(json.dumps(x,indent=2)+'\n')
result={'complete':True,'frozenPreparationOnly':True,'resourcesStarted':False,'productionInputs':327,'copiedAssets':50,'sourceContentsUnchanged':True,'builtAssetsUnchanged':True,'originalBodyWitnessLogicUnchanged':True,'helperMockPassed':sum(v['passed'] for v in checks.values()),'checks':checks,'finitePlan':receipt(W/'dry-plan.json'),'readOnlyPorts':receipt(W/'read-only-ports-escalated.json'),'diagnosticInputSourceChecksPassed':True,'originalLauncherUnchanged':True,'allThreeUserPortsPreservedByContract':True,'goalComplete':False}
(W/'source-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['checks','finitePlan','readOnlyPorts']}))
