import datetime, json, socket
from pathlib import Path
results={}
for port in [4293,9703,4310,4311,4312]:
    sock=socket.socket();sock.settimeout(.3)
    try:sock.connect(('127.0.0.1',port));results[str(port)]={'closed':False,'reason':'TCP accepted'}
    except ConnectionRefusedError:results[str(port)]={'closed':True,'reason':'ECONNREFUSED'}
    except OSError as e:results[str(port)]={'closed':None,'reason':str(e)}
    finally:sock.close()
receipt={'resourcesStarted':False,'readOnlyTcpOnly':True,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ports':results}
Path('/private/tmp/tube-directed-entry-20261004/read-only-ports-escalated.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
