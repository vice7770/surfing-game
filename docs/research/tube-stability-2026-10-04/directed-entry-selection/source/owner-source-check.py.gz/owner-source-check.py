"""Execute extracted pure checks only. Never execute owner top-level launch or networking."""
import ast, copy, hashlib, json, math
from pathlib import Path
W=Path('/private/tmp/tube-directed-entry-20261004')
source=(W/'run.py').read_text()
names={'integer','clock_equal','finite_number','steering_check','movie_gate','artifact_names_check','png_caps_check','sea_counters_check'}
nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(nodes)==len(names)
scope={'MIB':1024*1024,'math':math}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'pure-owner-checks','exec'),scope)
def rejected(fn,*args):
    try:fn(*args)
    except AssertionError:return
    raise AssertionError('Invalid mock accepted')
fixtures=json.loads((W/'installed-driver-fixtures.json').read_text());rows=fixtures['steps']
steering=scope['steering_check'](rows);assert steering['lockedFront']==7 and steering['targetedInputs']==3
bad=copy.deepcopy(rows);bad[0]['input']['steer']=.21;rejected(scope['steering_check'],bad)
bad=copy.deepcopy(rows);bad[1]['steeringControl']['inputTarget']['front']=8;rejected(scope['steering_check'],bad)
bad=copy.deepcopy(rows);bad[1]['tubeTarget']['target']['crossings']=[0,1,1];rejected(scope['steering_check'],bad)
assert scope['movie_gate'](rows[0])['eligible'] is True
bad=copy.deepcopy(rows[0]);bad['tubeTarget']['target']=None;bad['ride']['wave']['curlDistance']=0;bad['witness']=None
assert scope['movie_gate'](bad)['eligible'] is False # Proxy curlDistance is deliberately irrelevant.
bad['witness']={'classification':'partial'};assert scope['movie_gate'](bad)['eligible'] is True
bad['ride']['phase']='prone';assert scope['movie_gate'](bad)['eligible'] is False
names_list=['initial.png','standing.png','entry.png','final.png','steps.ndjson','standing-motion.webm'];scope['artifact_names_check'](names_list)
rejected(scope['artifact_names_check'],names_list+['extra.png']);rejected(scope['artifact_names_check'],names_list[:-1]+['initial.png'])
scope['png_caps_check'](4,4,48*1024*1024);rejected(scope['png_caps_check'],5,5,100);rejected(scope['png_caps_check'],4,4,48*1024*1024+1)
for row in rows:scope['sea_counters_check'](row)
bad=copy.deepcopy(rows[0]);bad['seaCounters']['rawFrontCount']=.5;rejected(scope['sea_counters_check'],bad)
receipt={'passed':5,'failed':0,'resourcesStarted':False,'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'checks':['all-phase steering bounds and locked front','invalid steering/front/crossing rejection','actual-column movie gate excludes curl proxy','artifact count and byte bounds','published sea counter checks'],'steering':steering,'extractedFunctions':sorted(names),'scope':'Pure mocked owner checks only; no actual trajectory, TCP connection, native process, cleanup or body passage proof'}
(W/'owner-source-checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'passed':5,'failed':0,'resourcesStarted':False}))
