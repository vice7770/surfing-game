// Execute only the extracted browser installer against in-memory mocks; no game, network or browser.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import vm from 'node:vm';
import { createWitnessSampler } from './body-witnesses.mjs';
import { createTubeTargetSelector } from './tube-target.mjs';
const W='/private/tmp/tube-directed-entry-20261004',source=readFileSync(W+'/native.mjs','utf8'),policy=JSON.parse(readFileSync(W+'/policy.json'));
const begin=source.indexOf('function install('),end=source.indexOf('\nlet page,exitCode=',begin);assert(begin>0&&end>begin);
const l={sliceCount:2,vertexCount:268,indexCount:798,positions:new Float32Array(804),indices:new Uint32Array(798),
 sliceFront:new Int32Array([7,7]),sliceSigma:new Float32Array([0,1]),sliceTau:new Float32Array([1,1]),sliceJoined:new Uint8Array([1,0]),
 slicePhase:new Uint8Array([1,1]),sliceFormed:new Float32Array([1,1]),sliceWeight:new Float32Array([1,1]),sliceLife:new Float32Array([.865,.865]),
 sliceFade:new Float32Array([1,1]),sliceRayX:new Float32Array([1,1]),sliceRayZ:new Float32Array([0,0])};
const knots=[[0,-1,0],[3,-1,0],[35,0,3],[67,2,3],[91,0,2],[115,2,0],[130,3,0],[133,3,0]];
for(let row=0;row<2;row++)for(let j=0;j<134;j++){
 let k=0;while(k+1<knots.length&&j>knots[k+1][0])k++;
 const a=knots[k],b=knots[Math.min(k+1,knots.length-1)],t=b[0]>a[0]?(j-a[0])/(b[0]-a[0]):0,o=3*(row*134+j);
 l.positions[o]=a[1]+(b[1]-a[1])*t;l.positions[o+1]=a[2]+(b[2]-a[2])*t;l.positions[o+2]=row-.5;
}
for(let j=0;j<133;j++)l.indices.set([j,j+134,j+1,j+1,j+134,j+135],6*j);
const ride={phase:'prone',resets:0,cue:false,balance:1,wave:{valid:true,directionX:1,directionZ:0,aheadOfCrest:3,faceFraction:.5,speedShoreward:3}};
const snap={frontCount:2,front:new Float32Array(18),board:new Float64Array([.5,0,0,0,0,0,1,0]),rider:new Float64Array(33),status:{seaTime:10,ride,compute:'mock',stepMs:0,lipLaunches:1,lipVolume:1,lipJets:1,lipRollers:0,lipAirborne:1}};
for(let i=0;i<7;i++){snap.rider[3*i]=.5;snap.rider[3*i+1]=i===2?1.5:1;snap.rider[3*i+2]=0;}
const vector={toArray:()=>[0,0,0]},mode={host:{snapshot:snap,outstandingSteps:0},focus:{z:0},barrelLoft:l,board:{position:vector,quaternion:{toArray:()=>[0,0,0,1]}},
 drawnRider:snap.rider,riderState:{clock:10},sweptBarrel:{holdsClearDrawing:true,waterAt:()=>false},camera:{camera:{}},surfer:{skinned:null},update:()=>{mode.riderState.clock=snap.status.seaTime;}};
const recorded=[],d={mode,water:{materialUniforms:{waterTime:{value:10}},surfaceRevision:1},renderView:()=>{},step:input=>{
 recorded.push({...input});snap.status.seaTime+=1/60;ride.phase='standing';d.water.materialUniforms.waterTime.value=snap.status.seaTime;
}};
class Pilot {state='go';attempts=1;rideTime=0;phase='';next(){return {paddle:true,popUp:true,steer:-.8};}}
const context=vm.createContext({window:{breaklineDiagnostics:d,breaklineLab:{clock:{paused:true}}},performance,console,setTimeout,Float32Array,Uint32Array,Map,Set});
const installer=vm.runInContext('('+source.slice(begin,end)+')',context);
const view=()=>({ride:{...ride,wave:{...ride.wave}},board:{x:.5,z:0,heading:0}});
installer(Pilot,view,()=>Array(7).fill(4*Math.PI*.1**3/3),createWitnessSampler,createTubeTargetSelector,policy);
const initial=context.window.__naturalEntry.current();assert.equal(initial.tubeTarget.status,'qualified');assert.equal(initial.tubeTarget.lockedFront,7);
const rows=[];for(let i=0;i<3;i++)rows.push(await context.window.__naturalEntry.step());
assert.equal(rows[0].input.paddle,true);assert.equal(rows[0].input.popUp,true);assert(rows[0].input.steer>0);assert(Math.abs(rows[0].input.steer-.4/60)<1e-12);
assert.equal(rows[1].input.popUp,false);assert.equal(rows[2].input.popUp,false);
assert.equal(rows[1].input.crouch,1);assert.equal(rows[1].input.compress,0);assert.equal(rows[1].input.trim,0);assert.equal(rows[1].input.pocketReflex,false);
assert(Math.abs(rows[1].input.steer-2*.4/60)<1e-12);assert.equal(rows[1].tubeTarget.status,'qualified');assert.equal(rows[1].tubeTarget.headHeightDemand.preparedPose,false);
assert(rows.every(r=>r.tubeTarget.lockedFront===7));assert(rows.every(r=>r.steeringControl.requestedPilotSteer===-.8));
assert(Math.abs(snap.status.seaTime-(10+3/60))<1e-12);assert.equal(recorded.length,3);
const output={passed:6,failed:0,resourcesStarted:false,scope:'Extracted installer executed against mocks only; no game/browser/trajectory evidence',checks:['production paddle retained','geometric target overrides away-from-curl steer','prone initial cap/slew','one valid manual popup only','earliest standing crouch no zero-reset steer','same-front target while body prepares'],initial,steps:rows};
writeFileSync(W+'/installed-driver-fixtures.json',JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify({passed:6,failed:0,resourcesStarted:false}));
