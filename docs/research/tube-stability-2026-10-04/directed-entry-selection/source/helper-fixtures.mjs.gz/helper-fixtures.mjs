import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createWitnessSampler } from './body-witnesses.mjs';
import { createTubeTargetSelector } from './tube-target.mjs';
const W='/private/tmp/tube-directed-entry-20261004',policy=JSON.parse(readFileSync(W+'/policy.json')).target;
const checks=[];
function check(name,f){f();checks.push({name,passed:true});}
function strip(path,front=7,life=.865){
 const count=134,p=new Float32Array(count*2*3),indices=[];
 for(let row=0;row<2;row++)for(let j=0;j<count;j++){
  const c=path[Math.min(j,path.length-1)],o=3*(row*count+j);p[o]=c[0];p[o+1]=c[1];p[o+2]=row-.5;
 }
 for(let j=0;j+1<count;j++){const a=j,b=a+count;indices.push(a,b,a+1,a+1,b,b+1);}
 return {positions:p,indices:new Uint32Array(indices),vertexCount:268,indexCount:indices.length,sliceCount:2,
  sliceFront:new Int32Array([front,front]),sliceSigma:new Float32Array([0,1]),sliceTau:new Float32Array([1,1]),
  sliceJoined:new Uint8Array([1,0]),slicePhase:new Uint8Array([1,1]),sliceFormed:new Float32Array([1,1]),
  sliceWeight:new Float32Array([1,1]),sliceLife:new Float32Array([life,life]),sliceFade:new Float32Array([1,1]),
  sliceRayX:new Float32Array([1,1]),sliceRayZ:new Float32Array([0,0])};
}
function profile(){
 const knots=[[0,-1,0],[3,-1,0],[35,0,3],[67,2,3],[91,0,2],[115,2,0],[130,3,0],[133,3,0]],out=[];
 for(let i=0;i<134;i++){
  let k=0;while(k+1<knots.length&&i>knots[k+1][0])k++;
  const a=knots[k],b=knots[Math.min(k+1,knots.length-1)],t=b[0]>a[0]?(i-a[0])/(b[0]-a[0]):0;
  out.push([a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t]);
 }return out;
}
const measure=createWitnessSampler(),selector=createTubeTargetSelector(policy);
check('one connected indexed contour gives exactly floor/roof/top',()=>{
 const l=strip([[0,0],[2,0],[2,2],[0,2],[0,3],[2,3]]),c=measure.columns(l,[{x:1,z:0}])[0];
 assert.equal(c.covering.length,1);assert.deepEqual(c.covering[0].crossings,[0,2,3]);
 assert.equal(selector.band(c.covering,1.23,7).qualified,true);
});
check('disconnected covering sheets do not become one opening',()=>{
 const l=strip([[0,0],[2,0],[2,2],[0,2],[0,3],[2,3]]);
 l.indices=l.indices.filter((_,i)=>Math.floor(i/6)!==1&&Math.floor(i/6)!==3);l.indexCount=l.indices.length;
 const c=measure.columns(l,[{x:1,z:0}])[0];assert.equal(c.covering.length,3);
 assert.equal(selector.band(c.covering,1.23,7).reason,'multiple-covering-components');
});
check('five crossings stay ambiguous',()=>{
 const l=strip([[0,0],[2,0],[2,2],[0,2],[0,3],[2,3],[2,4],[0,4],[0,5],[2,5]]),c=measure.columns(l,[{x:1,z:0}])[0];
 assert.deepEqual(c.covering[0].crossings,[0,2,3,4,5]);assert.equal(selector.band(c.covering,1,7).qualified,false);
});
check('three crossings without head height are rejected',()=>{
 const l=strip([[0,0],[2,0],[2,1],[0,1],[0,1.1],[2,1.1]]),c=measure.columns(l,[{x:1,z:0}])[0];
 assert.equal(selector.band(c.covering,1.23,7).reason,'insufficient-head-height');
});
const points=[0,0,0,0,0,0,0,1.5,0,0,0,0,0,0,0,0,0,0,0,0,0],board=[.5,0,0],ride={phase:'prone',wave:{valid:true,directionX:1,directionZ:0}};
check('actual opening qualifies in closing phase and locks its front',()=>{
 const l=strip(profile()),r=selector.select(l,board,ride,points,.1,measure.columns);
 assert.equal(r.status,'qualified');assert.equal(r.lockedFront,7);assert.equal(r.firstLock,true);assert.equal(r.target.closing,true);
 assert.equal(r.headHeightDemand.requiredHeight,1.23);assert.equal(r.headHeightDemand.actualStandingHeadTopAboveBoard,null);
});
check('temporary first-standing head-height deficit does not lose geometric mouth',()=>{
 const r=selector.select(strip(profile()),board,{...ride,phase:'standing'},points,.1,measure.columns);
 assert.equal(r.status,'qualified');assert.equal(r.lockedFront,7);assert.equal(r.headHeightDemand.actualStandingHeadTopAboveBoard,1.6);
 assert(Math.abs(r.headHeightDemand.actualStandingHeightDemand-1.7)<1e-12);assert.equal(r.headHeightDemand.preparedPose,false);
 assert.equal(r.headHeightDemand.requiredHeight,1.23);
});
check('locked front disappears: retain loss, never retarget other front',()=>{
 const r=selector.select(strip(profile(),8),board,ride,points,.1,measure.columns);
 assert.equal(r.status,'target-lost');assert.equal(r.lockedFront,7);assert.equal(r.target,null);
 assert.throws(()=>selector.select(strip(profile(),7),board,ride,points,.1,measure.columns),/No selection after/);
});
check('heading sign turns toward positive x and initial prone steering is rate limited',()=>{
 const s=createTubeTargetSelector(policy),r=s.steer({x:10,z:10,boardX:0,boardZ:0},0,1/60);
 assert(r.headingError>0);assert(r.requestedHeadingSteer>0);assert(Math.abs(r.actualInputSteer-.4/60)<1e-12);
 for(let i=0;i<100;i++){const v=s.steer({x:10,z:10,boardX:0,boardZ:0},0,1/60);assert(Math.abs(v.actualInputSteer)<=.2+1e-12);assert(Math.abs(v.actualInputSteer-v.previousInputSteer)<=.4/60+1e-12);}
});
check('heading sign negative x and yaw damping oppose increasing positive yaw',()=>{
 const s=createTubeTargetSelector(policy),first=s.steer({x:-10,z:10,boardX:0,boardZ:0},0,1/60);assert(first.actualInputSteer<0);
 const still=s.steer({x:0,z:10,boardX:0,boardZ:0},.1,1/60);assert(still.yawRate>0);assert(still.requestedHeadingSteer<still.headingError/.35);
});
check('zero remaining detector budget is an incomplete scan, not absence proof',()=>{
 const s=createTubeTargetSelector(policy),r=s.select(strip(profile()),board,ride,points,.1,measure.columns,0);
 assert.equal(r.status,'detector-budget-or-failure');assert.equal(r.budgetExhausted,true);assert.equal(r.lockedFront,null);
});
writeFileSync(W+'/helper-fixtures.json',JSON.stringify({passed:checks.length,failed:0,resourcesStarted:false,checks},null,2)+'\n');
console.log(JSON.stringify({passed:checks.length,failed:0,resourcesStarted:false}));
