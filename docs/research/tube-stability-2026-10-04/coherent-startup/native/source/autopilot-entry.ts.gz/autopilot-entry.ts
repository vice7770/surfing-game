// Candidate import paths for a separately authorized future rebuild; reused bundle is not compiled from this entry.
export { Autopilot, autopilotView } from '/private/tmp/tube-coherent-warmup-20261004/candidate/src/dev/Autopilot';
export { riderPartVolumes } from '/private/tmp/tube-coherent-warmup-20261004/candidate/src/physics/riderPosture';
