// Offline extracted driver-input logic only. No Board, rider, wave, browser, server or media runs.
import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const WORK='/private/tmp/tube-coherent-warmup-native-20261004';
const source=readFileSync(WORK+'/native.mjs','utf8');
const a=source.indexOf('  const input=pilot.next(view,DT),requestedPilotSteer=input.steer;'),b=source.indexOf('  const w=view.ride.wave',a);
assert(a>=0&&b>a);const block=source.slice(a,b);
const factory=new Function(`let standingSteerStarted=false,gentleSteer=0;return function(phase,requested){const DT=1/60,view={ride:{phase}},pilot={next:()=>({steer:requested})},must=(v,m)=>{if(!v)throw Error(m);};${block};return steeringControl;}`);
const control=factory();
assert.equal(control('prone',1).actualInputSteer,1);
const first=control('standing',1);assert(first.firstStandingInput);assert.equal(first.actualInputSteer,0);assert.equal(first.targetLimitedSteer,.2);
let prior=0,max=0;
for(let i=0;i<40;i++){const s=control('standing',1);assert(s.standing&&!s.firstStandingInput);assert(Math.abs(s.actualInputSteer-prior)<=.4/60+1e-12);assert(s.actualInputSteer<=.2+1e-12);max=Math.max(max,Math.abs(s.actualInputSteer));prior=s.actualInputSteer;}
assert.equal(prior,.2);
for(let i=0;i<70;i++){const s=control('standing',-1);assert(Math.abs(s.actualInputSteer-prior)<=.4/60+1e-12);assert(Math.abs(s.actualInputSteer)<=.2+1e-12);prior=s.actualInputSteer;}
assert.equal(prior,-.2);
const prone=control('prone',-.7);assert.equal(prone.actualInputSteer,-.7);assert.equal(prone.targetLimitedSteer,-.7);
assert.equal(control('standing',-.7).actualInputSteer,0);
const frontStart=source.indexOf(' function frontInventory(){'),frontEnd=source.indexOf(' function checkpoint(',frontStart),frontFn=source.slice(frontStart,frontEnd);
const records=new Float32Array([11,12,4,10,.2,0,0,0,0,21,22,4,12,.4,0,0,0,0,31,32,9,20,.7,0,0,0,0]);
const mock={host:{snapshot:{front:records,frontCount:3,status:{seaTime:123}}},barrelLoft:{sliceCount:1,vertexCount:134,indexCount:18,sliceFront:[4],sliceWeight:[1],sliceFormed:[1],sliceJoined:[0],sliceSigma:[11],sliceTau:[.3]}};
const frontBuilder=new Function('mode','must',`${frontFn};return frontInventory();`),inventory=frontBuilder(mock,(v,m)=>assert(v,m));
assert.equal(inventory.raw.recordCount,3);assert.equal(inventory.raw.stride,9);assert.deepEqual(inventory.raw.fieldOffsets,{id:2,sigma:3,tau:4});
assert.deepEqual(inventory.raw.groups.map(g=>[g.front,g.recordCount,g.sigmaMin,g.sigmaMax]),[[4,2,10,12],[9,1,20,20]]);
assert.equal(inventory.drawn.sliceCount,1);assert.equal(inventory.drawn.groups[0].sliceCount,1);assert.equal(inventory.raw.groups[0].recordCount,2);
const receipt={schema:'tube-gentle-input-source-checks/v1',complete:true,sourceOnly:true,resourcesStarted:false,
 steering:{passed:true,blockSha256:createHash('sha256').update(block).digest('hex'),initialStandingActual:0,maximumActual:max,maximumStepDelta:.4/60,nonstandingUnchanged:true},
 frontInventory:{passed:true,functionSha256:createHash('sha256').update(frontFn).digest('hex'),stride:9,rawRecordCount:3,rawCountsIndependentFromDrawn:true},
 scope:'Mock tests of extracted ordinary input filter and read-only front-record grouping only; no physics trajectory, body/geometry acceptance or real front evidence.'};
writeFileSync(WORK+'/gentle-input-source-checks.json',JSON.stringify(receipt,null,2)+'\n');process.stdout.write(JSON.stringify({complete:true,sourceOnly:true,resourcesStarted:false,checks:2})+'\n');
