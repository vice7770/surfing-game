// Extracted read-only startup/counter/checkpoint/PNG logic. No native, sea, physics or media run.
import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const WORK='/private/tmp/tube-coherent-warmup-native-20261004',source=readFileSync(WORK+'/native.mjs','utf8');
const hash=b=>createHash('sha256').update(b).digest('hex'),must=(v,m)=>assert(v,m);
function extract(start,end){const a=source.indexOf(start),b=source.indexOf(end,a);assert(a>=0&&b>a);return source.slice(a,b);}
const counterFn=extract(' function seaCounters(){',' function current(){');
const status={seaTime:123,lipLaunches:2,lipVolume:.25,lipJets:3,lipRollers:4,lipAirborne:5};
const records=new Float32Array([0,0,7,10,.2,0,0,0,0]);
const camera={position:{toArray:()=>[1,2,3]},quaternion:{toArray:()=>[0,0,0,1]},projectionMatrix:{toArray:()=>[1,0,0,1]},fov:50,near:.1,far:1000};
const mode={host:{snapshot:{frontCount:1,front:records,status},outstandingSteps:0},camera:{camera},surfer:{},barrelLoft:null};
const unchanged=JSON.stringify(mode.host.snapshot),snapshot=mode.host.snapshot;
const counters=new Function('mode','must',`${counterFn};return seaCounters;`)(mode,must);
assert.deepEqual(counters(),{rawFrontCount:1,lipLaunches:2,lipVolume:.25,lipJets:3,lipRollers:4,lipAirborne:5});
assert.equal(JSON.stringify(mode.host.snapshot),unchanged);assert.equal(mode.host.snapshot,snapshot);
mode.host.snapshot.frontCount=.5;assert.throws(counters);mode.host.snapshot.frontCount=1;
delete status.lipJets;assert.throws(counters);status.lipJets=3;
const frontFn=extract(' function frontInventory(){',' function checkpoint(');
const inventory=new Function('mode','must',`${frontFn};return frontInventory;`)(mode,must);
const checkpointFn=extract(' function checkpoint(',' let video;');
let renderCalls=0;const d={renderView:()=>{renderCalls++;},canvas:{toDataURL:()=> 'data:image/png;base64,fixture'}};
const checkpointUnchanged=JSON.stringify(snapshot);
const lab={clock:{paused:true}},current=()=>({clocks:{workerSeaTime:123,visualClock:123,waterTime:123,surfaceRevision:1}});
const checkpoint=new Function('mode','d','lab','steps','must','current','frontInventory','seaCounters',`${checkpointFn};return checkpoint;`)(mode,d,lab,0,must,current,inventory,counters);
const initial=checkpoint('initial-prone-after-install-ready');
assert.equal(initial.step,0);assert.equal(initial.seaTime,123);assert.equal(initial.frontInventory.raw.recordCount,initial.seaCounters.rawFrontCount);
assert.deepEqual(initial.seaCounters,counters());assert.equal(mode.host.snapshot,snapshot);assert.equal(JSON.stringify(snapshot),checkpointUnchanged);assert.equal(renderCalls,1);
mode.host.outstandingSteps=1;assert.throws(()=>checkpoint('invalid'));mode.host.outstandingSteps=0;
const initialization=source.indexOf("assert.equal(report.initialBody.ride.phase,'prone'");
const initialCapture=source.indexOf("await capture('initial-prone-after-install-ready')");
assert(initialization>=0&&initialCapture>initialization&&initialCapture<source.indexOf(' for(let i=0;i<1800;i++)'));
assert.equal(source.split("await capture('initial-prone-after-install-ready')").length-1,1);
const pngFn=extract('function png(','function lineage('),writes=[];
const pngBuilder=report=>new Function('assert','writeFileSync','join','OUT','report','hash',`${pngFn};return png;`)(assert,(file,data)=>writes.push([file,data.length]),(a,b)=>a+'/'+b,'memory',report,hash);
const url='data:image/png;base64,'+Buffer.from([137,80,78,71,13,10,26,10,1]).toString('base64');
const report={pngCount:0,pngBytes:0,artifacts:[]},png=pngBuilder(report);
for(let i=0;i<4;i++)png('fixture'+i+'.png',url);assert.equal(writes.length,4);assert.equal(report.pngCount,4);
assert.throws(()=>png('fifth.png',url));assert.equal(writes.length,4);
assert.throws(()=>pngBuilder({pngCount:3,pngBytes:48*1024*1024,artifacts:[]})('overflow.png',url));assert.equal(writes.length,4);
const receipt={schema:'coherent-startup-extracted-evidence-checks/v1',complete:true,sourceOnly:true,resourcesStarted:false,
 checks:{publishedCounterFields:{passed:true,functionSha256:hash(counterFn),rawRecordCountAuthority:'snap.frontCount',statusFields:['lipLaunches','lipVolume','lipJets','lipRollers','lipAirborne'],missingOrInvalidRejected:true,snapshotUnmodified:true},
 initialCheckpoint:{passed:true,functionSha256:hash(checkpointFn),step:0,afterFreshProneInstallReady:true,beforeOrdinaryStepper:true,rawInventoryCounterAgreement:true},
 pngCaps:{passed:true,functionSha256:hash(pngFn),maximumCount:4,maximumEachBytes:12*1024*1024,maximumTotalBytes:48*1024*1024,fifthAndTotalOverflowRejectedBeforeWrite:true}},
 scope:'Extracted source mock checks only; no warmed sea, real counter/front, body trajectory, pixels, movie, startup causality or acceptance evidence.'};
writeFileSync(WORK+'/startup-evidence-source-checks.json',JSON.stringify(receipt,null,2)+'\n');process.stdout.write(JSON.stringify({complete:true,sourceOnly:true,resourcesStarted:false,checks:3})+'\n');
