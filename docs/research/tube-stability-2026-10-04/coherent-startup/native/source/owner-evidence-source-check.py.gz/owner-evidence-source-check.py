"""Extract pure owner cap/counter checks with AST; do not run the owner."""
import ast
import hashlib
import json
from pathlib import Path

WORK=Path('/private/tmp/tube-coherent-warmup-native-20261004')
source=(WORK/'run.py').read_text()
names={'integer','finite_number','artifact_names_check','png_caps_check','sea_counters_check'}
nodes=[node for node in ast.parse(source).body if isinstance(node,ast.FunctionDef) and node.name in names]
assert len(nodes)==len(names)
scope={'MIB':1024*1024,'math':__import__('math')}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'extracted-owner-checks','exec'),scope)
def rejected(fn,*args):
    try:fn(*args)
    except AssertionError:return
    raise AssertionError('Invalid fixture was accepted')
files=['initial.png','standing.png','entry.png','final.png','steps.ndjson','standing-motion.webm']
scope['artifact_names_check'](files)
rejected(scope['artifact_names_check'],files+['extra.png'])
rejected(scope['artifact_names_check'],files[:-1]+['initial.png'])
scope['png_caps_check'](4,4,48*1024*1024)
rejected(scope['png_caps_check'],5,5,1024)
rejected(scope['png_caps_check'],4,4,48*1024*1024+1)
rejected(scope['png_caps_check'],True,True,10)
row={'seaCounters':{'rawFrontCount':2,'lipLaunches':3,'lipVolume':.4,'lipJets':5,'lipRollers':6,'lipAirborne':7},'loft':{'slices':8,'vertices':9,'indices':10}}
before=json.dumps(row,sort_keys=True);scope['sea_counters_check'](row);assert json.dumps(row,sort_keys=True)==before
row['seaCounters']['rawFrontCount']=.5;rejected(scope['sea_counters_check'],row);row['seaCounters']['rawFrontCount']=2
row['seaCounters']['lipVolume']=float('nan');rejected(scope['sea_counters_check'],row)
receipt={'schema':'coherent-startup-owner-extracted-checks/v1','complete':True,'sourceOnly':True,'resourcesStarted':False,'checks':{'uniqueArtifactCap':6,'maximumPngs':4,'maximumPngBytesTotal':48*1024*1024,'invalidCapsRejected':True,'publishedCountersReadOnly':True,'invalidCountersRejected':True},'extractedFunctions':sorted(names),'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Pure owner cap/counter checks only; no owner launch, TCP probe, warmed snapshot, trajectory or cleanup verification.'}
(WORK/'owner-evidence-source-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'complete':True,'sourceOnly':True,'resourcesStarted':False,'checks':2}))
