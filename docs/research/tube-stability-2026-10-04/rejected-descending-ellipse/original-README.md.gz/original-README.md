# Rejected descending-tip paired ellipse — one frozen offline trial

**Do not integrate this recipe.** It makes a descending roof and larger local
captured corridor while preserving original tip64 XY, but fails all-frame
geometric feasibility. No production source, build, native process, Git state,
or user port was changed. The twelve current0.25 candidate source/test files
have identical hashes before and after this task.

## Captured result

Five original native-source projected32..112 outlines are measured in actual
metres. All five stay clean and finite. Crest32, tip64, throat88 and the retained
rest are unchanged. The original crest-to-tip drop1.569–2.030m is preserved.
The roof descends to this low lip rather than lifting it into a shelf.

| Captured row | Original width at1.13m gap | Trial width at1.13m gap | Trial max gap | Trial width at1.60m gap | Analytic sheet thickness |
| --- | ---: | ---: | ---: | ---: | ---: |
|124|0.382m|1.350m|1.644m|0.528m|0.102m|
|125|0.476m|1.420m|1.634m|0.474m|0.132m|
|126|0.484m|1.417m|1.585m|0.000m|0.199m|
|127|0.542m|1.447m|1.600m|0.000m|0.204m|
|128|0.578m|1.474m|1.611m|0.273m|0.198m|

The declared crouched threshold is1.13m above the local retained floor with
at least1.25m continuous horizontal width. All five pass that numerical
threshold. The generous1.60m gap with the same1.25m width fails on every row;
rows126/127 do not even reach1.60m. Each separate parity-air interval is measured
individually; disjoint vertical air is never combined.

This is not rigid body/board clearance. A sloped floor, posture, board footprint,
alongshore travel, moving loft and actual rider path need physical/native checks
for a globally valid future candidate. The current normal menuBig native run
reported by root stood briefly then balance-fell with loft0 on that path, so
it supplies no geometry/body-clearance verdict.

The paired inner70..80 sampled distance is0.101–0.204m, in the declared
0.10–0.35m plausibility band. The structural root at outer36 is still
0.366–0.402m from the opposite run. Mathematical tangent continuity also fails
to give a gentle discretized attachment: point82 turns51.78–70.04 degrees.
These remain visible limitations rather than a whole-sheet smoothness pass.

![Captured comparison](/private/tmp/tube-descending-tip-profile-20261004/captured-profile-comparison.png)

## Exhaustive stored-frame scope and failures

Every one of1,224 raw frames from eight committed assets was attempted,
including early and post-touchdown/refill frames. There are307 active formation
frames. Of the1,224 attempts,1,067 are valid and157 active attempts are invalid.
The original293 held-eligible frames are all included:137 are invalid under this
recipe. No per-frame fallback was introduced.

All157 invalid attempts are pre-touchdown formation frames with
`d0=(crest-tip) dot retained-floor-upper-normal < 0`. This quarter ellipse needs
the crest above the floor-parallel line through the tip. These original profiles
do not satisfy that geometric domain condition even though the earlier global
reach/descending-face formation gate is active. This proves failure of this
particular construction, not impossibility for arbitrary curves with the same
fixed anchors.

| Case | Invalid frame indices | Count |
| --- | --- | ---: |
|pad19-a20-l12|118..131|14|
|pad19-a30-l12|115..133|19|
|pad19-a45-l12|112..137|26|
|periodic-padang19s-l12|147..167|21|
|periodic-point21-a15-l12|74..91|18|
|periodic-point21-a23-l12|91..110 and112|21|
|periodic-point21-a30-l12|123..149|27|
|periodic-reef42-l12|129..139|11|

Four valid originals that were clean become crossed:

| Case/frame | Formation | Thickness in h0 | New proper crossings | Cause |
| --- | ---: | ---: | ---: | --- |
|pad19-a20-l12 /137|0.968028|0.000518107|1|Raw-to-target formation morph folds cap66..67 into return68..69|
|pad19-a20-l12 /138|0.941286|0.000510032|1|Same cap/return morph failure|
|pad19-a30-l12 /135|0.999981|0.000000801|22|Nearly zero positive ellipse depth gives a regular but extremely thin smooth sheet; its separately sampled outer/inner facets cross|
|periodic-padang19s-l12 /173|0.950269|0.000672832|3|Raw-to-target formation morph crosses cap/return|

All four cross in double precision before Float32 storage as well. For the
two pad20 frames and periodicPadang173, the unblended internal target is clean;
the formation morph is responsible. The pad30 internal target already has26
facet crossings. This target is a diagnostic component of the unchanged recipe,
not a second candidate or an attempted full-maturity exception.

All3,648 fixed adjacent-time interpolation samples at.25/.50/.75 were
attempted with transformed endpoints and Float32 interpolation output. There
are498 samples with an invalid endpoint, explicitly recorded rather than
replaced with raw geometry. Of the3,150 evaluable samples,11 become newly
crossed from clean originals. These span pad20 edges136->137,137->138,138->139
and periodicPadang172->173,173->174; exact shares and segment pairs are retained.
No new zero-length segments are present in any valid frame or evaluable
interpolation. All preserved original anchors/rest remain exactly Float32 equal.

The smooth offset regularity proof itself holds in sampled diagnostics:
minimum offset tangent fraction>=0.75585 in valid asset frames, and0.75900
in captures. It cannot guarantee a separately discretized, blended polyline's
topology. Valid adjacent pairs keep tip velocity exactly unchanged because64
is unchanged. Maximum vertex-speed ratio rises to1.37944 at Reef144->145;
invalid frames prevent a continuous all-frame geometry policy.

## Provenance and artifacts

The first image inspection was the actual0.25 native normal sequence under
`/private/tmp/tube-whole-curl-native-review-20261004/` (frames03,07,10), plus root's
movie observations. No raster modification of that native evidence was made.
The new chart is a numeric plot, not a native rendered acceptance image.

* `recipe.md` records the construction and thresholds frozen before evaluation.
* `prototype.py` is the exact trial, with one globally applied formation factor,
  fixed128-interval derivative bounds, paired offset and preserved low tip.
* `evaluate.py` attempts every raw frame and the complete predeclared F32 grid.
* `report.json` / `report.json.gz` retain every frame's domain/geometry results,
  all changed crossing pairs, interpolation failures, source receipts and
  before/after production hashes. No20MB all-profile duplicate was created.
* `review.json`, `failure-profiles.json` and `diagnostics.py` preserve specific
  failures and unchanged-recipe checks. Diagnostic reruns only classify the same
  frozen recipe; no coefficient, gate or curve change followed its failure.
* `summary.json` is the compact result with captured measurements and invalid
  domains. `manifest.json` hashes all scratch artifacts.

Capture source:
`docs/research/tube-stability-2026-10-04/rejected-roof-thinning/inputs/captured-polylines.json.gz`.
Case/eligibility source:
`/private/tmp/tube-monotone-inner-profile-20261004/eligible-cases.json` and the
eight exact asset SHA receipts contained there. The committed raw BRL2 bytes
were decoded directly; the currently transformed production factory was not
used. Cases remain h0 units;7m conversions are illustrative, not scene-scale
proof. Actual captures preserve their original world-ray projection and metres.

Proper crossings omit endpoint contact, collinear overlap and volumetric checks.
The fixed grid does not prove arbitrary cross-case blends or3D alongshore
continuity. Crest31 is unavailable in captured outlines, so outgoing32->33 is
explicitly used there. Tip64 is now the lip's floor-tangent point; the circle's
outermost X may lie one radius forward, a semantic change that would require
consumer review before any future production experiment. No authored clock is
silently asserted to be actual physical impact.

## Explicit next action proposed, not executed

Do not integrate this ellipse. If another offline trial is authorized, replace
its outer curve with a crest-to-lip Hermite centreline that accepts arbitrary
anchor direction while ending at the original lip/floor tangent. Derive the
paired underside from the same discretized outer facets with a global curvature
and representability bound; use a topology-preserving formation construction
rather than a raw-to-target vertex morph. Keep original64 XY,32/88/rest and
the exhaustive all-frame scope. This is a new representation task with a new
frozen recipe, not parameter tuning or frame exceptions for this rejected one.

Moving appearance, rideability and the overall tube goal remain unproven.
