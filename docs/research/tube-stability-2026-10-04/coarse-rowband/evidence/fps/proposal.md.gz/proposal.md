# Proposed checks and run — unexecuted

After root review, one serialized CPU sequence from this directory, with BUILD_ID=306258296 and ROWBAND_FPS_READY_SHA256 bound to reviewed ready.json:

1. `node candidate/node_modules/typescript/bin/tsc --project candidate/tsconfig.json --noEmit`
2. `node build-only.mjs` (candidate only; refuses existing outputs, checks exact447015B/e084 worker)
3. `python3 bind-launch.py` (local metadata only)
4. `node --check native-owned.mjs`
5. `node --check passive-guard.mjs`
6. `node --check survey.mjs`
7. `node --check pair.mjs`
8. `node pair.mjs --run=false`

Preserve original command/start/end/PID/exits/stdout/stderr plus all source/readiness/compiled pins before/after; stop on first failure, no retry or automatic repairs. No numerical/performance imports beyond the explicit strict/build gate. Root chooses/owns the bounded runner after review; no extra archive/check chain is required.

Only after compiled authority and native coverage review plus a separate sole hardware lease:

`ROWBAND_FPS_READY_SHA256=<reviewed> ROWBAND_FPS_BINDINGS_SHA256=<reviewed> node pair.mjs --run=true --out=<fresh owned run>`

Exactly baseline five-warm/90s then, only if baseline valid and owned Chrome/server closed, candidate five-warm/90s. Each arm has175s abort plus5s cleanup reserve (180s hard overall); first failure stops with evidence and no retry. Ports4233/9643 and4234/9644 must be unoccupied. Port4200 stays closed, user5173 untouched. No aeration/worker/fog composition. All masks and source streams remain the ordinary unmodified pipeline.
