# Accepted-e3 and rowband recovery freeze

Independent, atomic regular-file copies preserve the eleven accepted-e3 compiled files, eight existing root source/test files, and eleven proposed rowband source/test payloads before production adoption. All thirty payloads match the bytes and SHA-256 records of their cited authority; no backups are hardlinks or symlinks.

`e3-dist/` is a recovery copy of the existing canonical `dist/` compilation (BUILD_ID306258296, worker447015bytes/e08444a9). `e3-root/` retains the eight original root files that the rowband proposal replaces. `rowband-source/` retains the full eleven proposed owned source/test files. The three added paths (`barrelFallback.ts`, `fallbackRows.ts`, `fallbackRows.test.ts`) have no accepted-e3 original.

`manifest.json` lists original paths, frozen paths, exact bytes/hashes, aliases and external authority references. Existing FPS ready files, manifests, source arms and compiled inputs are untouched. This is recoverability preparation, not new FPS or acceptance evidence; it neither replaces the original authorities nor grants a run or restoration. Root plans to build the adopted runtime into an alternate output directory, retaining the canonical dist.
