# Proposed CPU gate — not executed

Only after parent source review and a serialized CPU lease, from this scratch directory, with `TUBE_ROWBAND_CHECK_READY_SHA256` set to the exact reviewed harness-ready.json hash:

1. `node --check check-authority.mjs`
2. `node --check check.mjs`
3. `node check.mjs --run=false`
4. `node check.mjs --run=true`

The driver has a 120 s overall bound, fresh checks-v2/ output, authority before/after, original stdout/stderr and stage timestamps/PIDs/exits. It stops on the first failure, without automatic repair/retry. The armed operation runs exactly strict TypeScript first, then only if successful the four complete suites: WaterSurface.test.ts, SweptBarrelMesh.test.ts, SweptBarrel.test.ts, and fallbackRows.test.ts. No app build, cost timing, geometry imports outside tests, server, Chrome, GPU or production/Git action.

The shallow check/src identity borrows the previously accepted 247-source closure, overlays only this candidate's four changed source/test paths, and adds the two new helper paths to that closure (249 total links). Other seven retained renderer/test paths are read-only symlinks; dependencies are a readonly installed node_modules link. Source, installed package/Three contracts, configs and the prior authority metadata are all pinned. No copied public assets or numerical fixtures are needed for these suites.

The original source-ready cfed2f907bfe369e5d71f6c94b5b148b2e019d4ca53c5035c7040c7de953624f and its complete first attempt are preserved in failed-first/. The two approved typing repairs plus fresh output-directory changes are frozen by revised readiness; no retry has run. Tests establish CPU conservativeness and lifecycle ownership, not native raster-coverage or throughput acceptance. A native same-state coverage gate must still check newly truncated coarse geometry; Rich repair remains full.
