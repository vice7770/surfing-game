import ast,base64,copy,hashlib,json,math,struct
from pathlib import Path
W=Path('/private/tmp/tube-opening-inventory-20261004');source=(W/'run.py').read_text();names={'integer','finite_number','packed_check','geometry_check'}
nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(nodes)==4
scope={'MIB':1024*1024,'math':math,'base64':base64,'hashlib':hashlib,'struct':struct};exec(compile(ast.Module(body=nodes,type_ignores=[]),'pure-inventory-owner','exec'),scope)
x=json.loads((W/'inventory-fixtures.json').read_text())['mockedInitial']
for value in [x['rawFront']['values'],*x['loft']['arrays'].values()]:value['sha256']=hashlib.sha256(base64.b64decode(value['base64'])).hexdigest()
result=scope['geometry_check'](x)
def rejected(f,*a):
    try:f(*a)
    except (AssertionError,ValueError):return
    raise AssertionError('Bad fixture accepted')
bad=copy.deepcopy(x);bad['rawFront']['values']['bytes']+=1;rejected(scope['geometry_check'],bad)
bad=copy.deepcopy(x);bad['loft']['arrays']['positions']['sha256']='bad';rejected(scope['geometry_check'],bad)
bad=copy.deepcopy(x);value=bad['loft']['arrays']['indices'];body=bytearray(base64.b64decode(value['base64']));struct.pack_into('<I',body,0,268);value['base64']=base64.b64encode(body).decode();value['sha256']=hashlib.sha256(body).hexdigest();rejected(scope['geometry_check'],bad)
bad=copy.deepcopy(x);bad['faceAudit']['rejectionCounts']['boardBehindCrest']=1;rejected(scope['geometry_check'],bad)
receipt={'passed':3,'failed':0,'resourcesStarted':False,'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'checks':['exact packed typed bytes/count/hash','world/index/raw-record bounds and corruption rejection','separate face-rejection count agreement'],'mockGeometryResult':result,'scope':'Extracted pure owner checks over mocks only; no live physics or process/network proof'}
(W/'owner-fixtures.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'passed':3,'failed':0,'resourcesStarted':False}))
