// Diagnostics only: candidates come from actual drawn row strips, then exact indexed columns.
export function createTubeTargetSelector(policy) {
 const S=134,E=3,CREST=32;
 const must=(v,m)=>{if(!v)throw Error(m);};
 let lockedFront=null,lost=false,lastHeading=null,lastSteer=0,targeted=false;
 const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
 function band(covering,requiredHeight,front) {
  if(covering.length!==1)return {qualified:false,reason:covering.length?'multiple-covering-components':'no-covering-component'};
  const c=covering[0],h=c.crossings;
  if(c.component.front!==front)return {qualified:false,reason:'component-front-mismatch'};
  if(h.length!==3||!c.strictlyOrdered)return {qualified:false,reason:'not-three-strict-crossings'};
  if(h[1]-h[0]<requiredHeight)return {qualified:false,reason:'insufficient-head-height'};
  return {qualified:true,floor:h[0],roof:h[1],roofTop:h[2],height:h[1]-h[0],component:c.component,crossings:h};
 }
 function select(l,board,ride,points,headRadius,columns,timeBudgetMilliseconds=Infinity) {
  const scanStarted=performance.now();
  must(!lost,'No selection after locked-front loss');
  const standing=ride.phase==='standing',nominal=policy.nominalCrouchedHeadTopAboveBoard+policy.deckAllowance;
  const dynamic=standing?points[7]-board[1]+headRadius:null;
  const requiredHeight=nominal;
  const actualStandingHeightDemand=standing?Math.max(0,dynamic)+policy.deckAllowance:null;
  const demand={phase:ride.phase,nominalCrouchedHeadTopAboveBoard:policy.nominalCrouchedHeadTopAboveBoard,deckAllowance:policy.deckAllowance,headRadius,
   actualStandingHeadTopAboveBoard:dynamic,actualStandingHeightDemand,requiredHeight,preparedPose:false};
  const wave=ride.wave,normalValid=!!wave?.valid&&Number.isFinite(wave.directionX)&&Number.isFinite(wave.directionZ);
  const coarse=[],rejected={rowEligibility:0,faceEligibility:0,noCoarseAir:0},p=l.positions;
  let rowPairs=0,scannedRows=0;
  const budgetResult=()=>({target:null,status:'detector-budget-or-failure',lockedFront,budgetExhausted:true,headHeightDemand:demand,rowPairsEligible:rowPairs,scannedRows,coarseCandidateCount:coarse.length,exactColumnCount:0,rejected,attempts:[],disabledReason:'Declared per-selector/remaining cumulative wall budget reached; incomplete scan is not no-opening proof'});
  must(l.sliceCount<=300,'Bounded active loft rows');
  for(let a=0;a+1<l.sliceCount;a++){
   if(performance.now()-scanStarted>=timeBudgetMilliseconds)return budgetResult();scannedRows++;
   const b=a+1,front=l.sliceFront[a];
   if(l.sliceJoined[a]!==1||front!==l.sliceFront[b]||(lockedFront!==null&&front!==lockedFront)
    ||[a,b].some(s=>l.slicePhase[s]!==1||!(l.sliceFormed[s]>0)||l.sliceWeight[s]<policy.minimumWeight
      ||!Number.isFinite(l.sliceLife[s])||l.sliceLife[s]<0||l.sliceLife[s]>=policy.maximumOpenLife||l.sliceFade[s]<1)){
    rejected.rowEligibility++;continue;
   }
   rowPairs++;
   let nx=(l.sliceRayX[a]+l.sliceRayX[b])/2,nz=(l.sliceRayZ[a]+l.sliceRayZ[b])/2;
   const n=Math.hypot(nx,nz);if(!(n>0)){rejected.faceEligibility++;continue;}nx/=n;nz/=n;
   const at=(row,j,axis)=>p[3*(row*S+E+j)+axis];
   const crest={x:(at(a,CREST,0)+at(b,CREST,0))/2,y:(at(a,CREST,1)+at(b,CREST,1))/2,z:(at(a,CREST,2)+at(b,CREST,2))/2};
   const boardAhead=(board[0]-crest.x)*nx+(board[2]-crest.z)*nz;
   const boardLateral=(board[0]-crest.x)*nz-(board[2]-crest.z)*nx;
   const normalDot=normalValid?nx*wave.directionX+nz*wave.directionZ:null;
   if(!normalValid||normalDot<policy.minimumWaveNormalDot||boardAhead<0||boardAhead>policy.maximumBoardAheadOfCrest){rejected.faceEligibility++;continue;}
   const contour=[];
   for(let j=0;j<S;j++){
    const u=3*(a*S+j),v=3*(b*S+j),x=(p[u]+p[v])/2,z=(p[u+2]+p[v+2])/2;
    contour.push({along:(x-crest.x)*nx+(z-crest.z)*nz,y:(p[u+1]+p[v+1])/2});
   }
   const stops=[...new Set(contour.map(v=>v.along).filter(Number.isFinite))].sort((x,y)=>x-y);
   const rowCandidates=[];
   for(let k=0;k+1<stops.length;k++){
    if(k%16===0&&performance.now()-scanStarted>=timeBudgetMilliseconds)return budgetResult();
    if(!(stops[k+1]>stops[k]))continue;
    const along=(stops[k]+stops[k+1])/2;if(along<=0)continue;
    const h=[];
    for(let j=0;j+1<contour.length;j++){
     const u=contour[j],v=contour[j+1];
     if(along>Math.min(u.along,v.along)&&along<Math.max(u.along,v.along))h.push(u.y+(v.y-u.y)*(along-u.along)/(v.along-u.along));
    }
    h.sort((x,y)=>x-y);
    if(h.length!==3||!(h[0]<h[1]&&h[1]<h[2])||h[1]-h[0]<requiredHeight)continue;
    const x=crest.x+along*nx,z=crest.z+along*nz,distance=Math.hypot(x-board[0],z-board[2]);
    if(distance>policy.maximumTargetDistance)continue;
    const c={front,rowBracket:[a,b],sigmaBracket:[l.sliceSigma[a],l.sliceSigma[b]],sigma:(l.sliceSigma[a]+l.sliceSigma[b])/2,
     x,z,crest,ray:{x:nx,z:nz},boardAheadOfCandidateCrest:boardAhead,boardLateralFromCandidateCrest:boardLateral,
     riderWaveNormalDot:normalDot,alongAheadOfCrest:along,distance,coarseHeight:h[1]-h[0],coarseAlongInterval:[stops[k],stops[k+1]],intervalWorldWidth:stops[k+1]-stops[k],nominalHeadSphereDiameter:2*headRadius,intervalNarrowerThanHeadDiameter:stops[k+1]-stops[k]<2*headRadius,formedRunBoundarySigmaDistance:l.sliceMouth?Math.min(l.sliceMouth[a],l.sliceMouth[b]):null};
    c.rowEligibility={joined:l.sliceJoined[a],phases:[l.slicePhase[a],l.slicePhase[b]],weights:[l.sliceWeight[a],l.sliceWeight[b]],formed:[l.sliceFormed[a],l.sliceFormed[b]],fades:[l.sliceFade[a],l.sliceFade[b]]};c.lifeBracket=[l.sliceLife[a],l.sliceLife[b]];c.closing=c.lifeBracket.some(v=>v>=policy.closingStarts);rowCandidates.push(c);
   }
   rowCandidates.sort((a,b)=>a.distance-b.distance);
   if(rowCandidates.length)coarse.push(...rowCandidates.slice(0,policy.maximumCoarseColumnsPerRow));else rejected.noCoarseAir++;
  }
  coarse.sort((a,b)=>a.distance-b.distance||a.front-b.front||a.sigma-b.sigma);
  if(performance.now()-scanStarted>=timeBudgetMilliseconds)return budgetResult();
  const short=coarse.slice(0,policy.maximumExactColumns),exact=columns(l,short),attempts=[];let target=null;
  for(let i=0;i<short.length;i++){
   const result=band(exact[i].covering,requiredHeight,short[i].front);
   attempts.push({front:short[i].front,rowBracket:short[i].rowBracket,sigmaBracket:short[i].sigmaBracket,x:short[i].x,z:short[i].z,
    distance:short[i].distance,covering:exact[i].covering.map(c=>({component:c.component,crossings:c.crossings,strictlyOrdered:c.strictlyOrdered})),...result});
   if(result.qualified&&!target)target={...short[i],...result,headHeightDemand:demand,actualStandingHeightDeficit:actualStandingHeightDemand===null?null:Math.max(0,actualStandingHeightDemand-result.height)};
  }
  const previousFront=lockedFront;
  if(target&&lockedFront===null)lockedFront=target.front;
  if(!target&&lockedFront!==null)lost=true;
  return {target,status:target?'qualified':lost?'target-lost':'no-qualified-opening',lockedFront,
   firstLock:previousFront===null&&lockedFront!==null,lockedFrontPresent:lockedFront!==null&&Array.from(l.sliceFront.subarray(0,l.sliceCount)).includes(lockedFront),lossReason:lost?'no-qualified-opening-on-locked-front':null,headHeightDemand:demand,
   rowPairsEligible:rowPairs,coarseCandidateCount:coarse.length,exactColumnCount:short.length,rejected,attempts,
   qualification:'Candidate air column only: one connected active indexed mesh component with exactly 3 strict crossings and enough vertical head height; no full volume or body passage claim'};
 }
 function steer(target,heading,dt) {
  must(Number.isFinite(heading)&&dt>0,'Finite actual heading and positive dt');
  const yawRate=lastHeading===null?0:wrap(heading-lastHeading)/dt;lastHeading=heading;
  const targetHeading=target?Math.atan2(target.x-target.boardX,target.z-target.boardZ):heading;
  const headingError=wrap(targetHeading-heading),requested=target?headingError/policy.headingGain-policy.yawDamping*yawRate:0;
  const limited=Math.max(-policy.maximumAbsoluteSteer,Math.min(policy.maximumAbsoluteSteer,requested));
  const previous=lastSteer;if(target){targeted=true;lastSteer+=Math.max(-policy.steerSlewPerSecond*dt,Math.min(policy.steerSlewPerSecond*dt,limited-lastSteer));}
  else if(!targeted)lastSteer=0;
  return {targetHeading,headingError,yawRate,requestedHeadingSteer:requested,targetLimitedSteer:limited,actualInputSteer:lastSteer,
   previousInputSteer:previous,maximumAbsolute:policy.maximumAbsoluteSteer,slewRatePerSecond:policy.steerSlewPerSecond,targetActive:!!target};
 }
 return {select,steer,band};
}
