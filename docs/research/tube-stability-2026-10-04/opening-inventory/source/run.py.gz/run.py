#!/usr/bin/env python3
"""One finite owner for a GET-only static server, Node, and its fresh Chrome group."""
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import argparse, datetime, hashlib, json, math, os, selectors, signal, socket, subprocess, base64, struct, threading, time, shutil

WORK=Path('/private/tmp/tube-opening-inventory-20261004')
MIB=1024*1024
USER_PORTS=(4310,4311,4312)
def tcp(port):
    sock=socket.socket();sock.settimeout(.25)
    try: sock.connect(('127.0.0.1',port));return False
    except ConnectionRefusedError:return True
    except OSError:return None
    finally:sock.close()
def members(group):
    result=subprocess.run(['ps','-axo','pid=,pgid=,stat='],capture_output=True,text=True,check=True,timeout=.5)
    return [int(p[0]) for line in result.stdout.splitlines() if len(p:=line.split())==3 and int(p[1])==group and not p[2].startswith('Z')]
def bounded_file(path,cap):
    assert path.is_file(),f'Missing artifact: {path.name}'
    assert 0<path.stat().st_size<=cap,f'Artifact byte cap: {path.name}'
    body=path.read_bytes()
    assert 0<len(body)<=cap,f'Artifact changed beyond byte cap: {path.name}'
    return body
def integer(value):return isinstance(value,int) and not isinstance(value,bool)
def clock_equal(a,b):
    return isinstance(a,(int,float)) and isinstance(b,(int,float)) and math.isfinite(a) and math.isfinite(b) and abs(a-b)<1e-7
def finite_number(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
def packed_check(value):
    sizes={'Float32Array':4,'Uint32Array':4,'Int32Array':4,'Uint8Array':1}
    assert value['type'] in sizes and integer(value['elements']) and value['elements']>=0,'Known bounded typed array'
    assert value['bytes']==value['elements']*sizes[value['type']] and 0<=value['bytes']<=4*MIB,'Typed byte cap/count'
    body=base64.b64decode(value['base64'],validate=True)
    assert len(body)==value['bytes'] and base64.b64encode(body).decode()==value['base64'] and hashlib.sha256(body).hexdigest()==value['sha256'],'Exact active typed bytes/hash'
    return body
def geometry_check(snapshot):
    loft=snapshot['loft'];counts=loft['scalars'];v=counts['vertexCount'];i=counts['indexCount'];s=counts['sliceCount']
    assert all(integer(q) for q in (v,i,s)) and 0<=v<=40000 and 0<=i<=300000 and 0<=s<=300 and v==134*s and i%3==0,'Actual loft bounds'
    assert loft['byteOrder']=='little-endian','Exact byte order'
    arrays=loft['arrays'];assert {'positions','indices','sliceFront','sliceSigma','sliceTau','slicePhase','sliceLife','sliceFade','sliceRayX','sliceRayZ','sliceWeight','sliceFormed','sliceJoined'}<=set(arrays),'All required world/topology/eligibility arrays'
    for name,value in arrays.items():
        body=packed_check(value)
        expected=i if name=='indices' else s if name.startswith('slice') else 3*v if name in ('positions','normals') else 4*v if name=='throat' else v
        assert value['elements']==expected,'Full active typed-array extent'
        if name=='indices':assert value['type']=='Uint32Array' and all(q[0]<v for q in struct.iter_unpack('<I',body)),'Actual active index bound'
        if name=='positions':assert value['type']=='Float32Array' and all(math.isfinite(q[0]) for q in struct.iter_unpack('<f',body)),'Finite actual world positions'
    raw=snapshot['rawFront'];assert integer(raw['recordCount']) and 0<=raw['recordCount']<=2048 and raw['stride']==9,'Bounded raw front records'
    assert raw['values']['type']=='Float32Array' and raw['values']['elements']==raw['recordCount']*9,'Complete raw record bytes';packed_check(raw['values'])
    audit=snapshot['faceAudit'];assert audit['eligiblePairs']==len(audit['pairs']) and audit['eligiblePairs']<=299,'Bounded eligible pair evidence'
    keys=['invalidWaveNormal','zeroOrInvalidAverageRay','normalDotBelow','boardBehindCrest','boardBeyondForwardFace']
    assert audit['facePassed']==sum(p['faceEligible'] for p in audit['pairs']),'Eligible face total'
    for key in keys:assert audit['rejectionCounts'][key]==sum(p['rejection'][key] for p in audit['pairs']),'Separate rejection total'
    for pair in audit['pairs']:
        assert pair['faceEligible'] is (not any(pair['rejection'].values())),'Conjunction of individual face gates'
    return {'vertices':v,'indices':i,'slices':s,'rawFrontRecords':raw['recordCount'],'typedArrays':len(arrays),'eligiblePairs':audit['eligiblePairs'],'facePassed':audit['facePassed'],'rejectionCounts':audit['rejectionCounts']}
def validate_capture(native,out,arm):
    assert native['complete'] is True and native['arm']==arm and native['physicsAdvances']==1 and len(native['snapshots'])==2,'Exactly two snapshots/one no-op step'
    step=native['ordinaryStep'];expected={'paddle':False,'popUp':False,'steer':0,'crouch':0,'compress':0,'trim':0,'pocketReflex':False}
    assert step['input']==expected==native['input'] and step['step']==1 and clock_equal(step['after']-step['before'],1/60),'Ordinary neutral input/clock'
    assert native['video'] is None,'No movie in inventory'
    names=[a['file'] for a in native['artifacts']];assert set(names)=={'00-initial-ready-prone.png','01-after-one-noop-step.png','active-snapshots.json'} and len(names)==3,'Only two PNGs and exact geometry inventory'
    receipts=[];total_png=0;geometry=None
    for value in native['artifacts']:
        name=value['file'];assert Path(name).name==name,'Direct owned artifact'
        p=out/name;body=bounded_file(p,16*MIB if name.endswith('.json') else 12*MIB);assert len(body)==value['bytes'] and hashlib.sha256(body).hexdigest()==value['sha256'],'Exact artifact receipt'
        if name.endswith('.png'):assert body[:8]==b'\x89PNG\r\n\x1a\n';total_png+=len(body)
        else:geometry=json.loads(body)
        receipts.append(value)
    assert native['pngCount']==2 and native['pngBytes']==total_png and total_png<=24*MIB,'Two bounded PNGs'
    assert geometry['schema']=='tube-opening-active-geometry/v1' and len(geometry['snapshots'])==2,'Complete retained state'
    snapshots=geometry['snapshots'];assert snapshots[0]['step']==0 and snapshots[1]['step']==1 and snapshots[0]['ride']['phase']=='prone','Initial ordinary fresh prone'
    assert clock_equal(snapshots[1]['seaTime']-snapshots[0]['seaTime'],1/60),'Inventory physics clocks'
    assert [x['label'] for x in snapshots]==['initial-ready-prone','after-one-noop-step'],'Fixed capture labels'
    checks=[geometry_check(x) for x in snapshots]
    for x,brief in zip(snapshots,native['snapshots']):
        for key in ['step','label','seaTime','clocks','boardPose','ride','seaCounters','faceAudit']:assert x[key]==brief[key],'Report/inventory agreement'
    return {'physicsAdvances':1,'snapshots':2,'pngCount':2,'pngBytes':total_png,'artifactReceipts':receipts,'geometry':checks,'readOnlyInventoryIsEntryPass':False}
parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');parser.add_argument('--arm',choices=['baseline','candidate'],required=True);parser.add_argument('--out');args=parser.parse_args()
DIST=WORK/'dist'
PORTS=(4294,9704)
if not args.run:
    print(json.dumps({'sourceOnlyPlan':True,'arm':args.arm,'dist':str(DIST),'wholeSeconds':180,'commandSeconds':168,'cleanupSeconds':7,'maximumPhysicsAdvances':1,'snapshots':2,'maximumPngs':2,'maximumUniqueArtifacts':3,'maximumPngBytesEach':12*MIB,'maximumPngBytesTotal':24*MIB,'maximumReportBytes':32*MIB,'maximumGeometryJsonBytes':16*MIB,'noMovie':True,'noPopupSteeringPlacementOrReset':True,'ports':PORTS,'userPorts':USER_PORTS,'resourcesStarted':False}));raise SystemExit(0)
start=time.monotonic();out=Path(args.out or WORK/(args.arm+'-first')).resolve();owner=out.with_name(out.name+'-owner.json');log=out.with_name(out.name+'-owner.log')
assert out==WORK/'native-first' and not out.exists() and not owner.exists() and not log.exists(),'Only one fresh native-first invocation is prepared'
preparation=None;expected_assets={}
def verify_copy():
    return bool(preparation) and {str(p.relative_to(DIST)) for p in DIST.rglob('*') if p.is_file()}==set(expected_assets) and all((DIST/key).is_file() and (DIST/key).stat().st_size==value['bytes'] and hashlib.sha256((DIST/key).read_bytes()).hexdigest()==value['sha256'] for key,value in expected_assets.items())
def verify_production_inputs():
    if not preparation:return False
    contract=preparation['productionInputs'];candidate=Path(contract['candidateRoot']).resolve();frozen=contract['frozen'];path=Path(frozen['file'])
    if not path.is_file() or path.stat().st_size!=frozen['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=frozen['sha256']:return False
    records=json.loads(path.read_text())
    if len(records)!=contract['count'] or len(records)!=327:return False
    for value in records.values():
        source=Path(value['path']).resolve()
        if not source.is_relative_to(candidate) or not source.is_file() or source.stat().st_size!=value['bytes'] or hashlib.sha256(source.read_bytes()).hexdigest()!=value['sha256']:return False
    for value in contract['extraCandidateChangedFiles']:
        source=(candidate/value['path']).resolve()
        if not source.is_relative_to(candidate) or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=value['candidateSha256']:return False
    for value in [contract['sourcePin'],contract['candidatePatch']]:
        source=Path(value['file'])
        if not source.is_file() or source.stat().st_size!=value['bytes'] or hashlib.sha256(source.read_bytes()).hexdigest()!=value['sha256']:return False
    return True
def verify_sources():
    return bool(preparation) and all(Path(value['file']).is_file() and Path(value['file']).stat().st_size==value['bytes'] and hashlib.sha256(Path(value['file']).read_bytes()).hexdigest()==value['sha256'] for value in preparation['diagnosticSources'].values())
report={'schema':'tube-opening-inventory-owner/v1','arm':args.arm,'physicalStateEqualityClaim':False,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'wholeSeconds':180,'commandSeconds':168,'cleanupSeconds':7,'complete':False,'firstFailure':None,'failures':[],'ports':PORTS,
    'dist':str(DIST),'nativeOutput':str(out),'served':{},'logBytes':0,'nativeGroup':None,'resourcesStarted':False,'preflightComplete':False}
lock=threading.Lock();server=None;proc=None;sel=selectors.DefaultSelector();server_thread=None
def failure(error,phase):
    entry={'phase':phase,'type':type(error).__name__,'message':str(error)}
    with lock:
        if report['firstFailure'] is None:report['firstFailure']=entry['message'];report['firstFailureType']=entry['type'];report['firstFailurePhase']=phase
        if entry not in report['failures']:report['failures'].append(entry)
        report['complete']=False
def save():
    with lock: body=json.dumps(report,separators=(',',':')).encode()
    assert len(body)<=131072,'Owner report cap';owner.write_bytes(body)
def append(body):
    with lock:
        if report['logBytes']+len(body)>1048576:raise RuntimeError('Combined owner/native log cap')
        with log.open('ab') as stream:stream.write(body)
        report['logBytes']+=len(body)
def command_deadline():
    if time.monotonic()-start>=168:raise TimeoutError('Whole command deadline; no retries')
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw):super().__init__(*a,directory=str(DIST),**kw)
    def log_message(self,fmt,*a):
        try:append((fmt%a+'\n').encode())
        except BaseException as error:failure(error,'static-server-log');raise
    def do_HEAD(self):self.send_error(405,'GET only')
    def do_GET(self):
        try:self.get_owned()
        except BaseException as error:failure(error,'static-server');raise
    def get_owned(self):
        path=Path(self.translate_path(self.path)).resolve()
        if path.is_dir():path=path/'index.html'
        if not path.is_relative_to(DIST) or not path.is_file():self.send_error(404);return
        if path.stat().st_size>16*1024*1024:self.send_error(413);return
        body=path.read_bytes();key=str(path.relative_to(DIST))
        assert key in expected_assets,'Only frozen50 assets may be served'
        receipt={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
        with lock:
            assert len(report['served'])<64 or key in report['served'],'Served-file count cap'
            assert key not in report['served'] or report['served'][key]==receipt,'Served artifact changed'
            report['served'][key]=receipt
        self.send_response(200);self.send_header('Content-Type',self.guess_type(str(path)));self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
try:
    save()
    assert (DIST/'index.html').is_file(),'Existing root-built dist required; this owner never copies/rebuilds'
    report['ownedPortsInitiallyClosed']={str(p):tcp(p) for p in PORTS}
    assert all(v is True for v in report['ownedPortsInitiallyClosed'].values()),'Both fresh owned ports must be closed'
    report['userPortsOpenBefore']={str(p):tcp(p) is False for p in USER_PORTS}
    assert all(report['userPortsOpenBefore'].values()),'Existing user4310/4311/4312 must all be open before launch'
    node=shutil.which('node');assert node,'Installed Node required'
    preparation=json.loads((WORK/'preparation.json').read_text());assert preparation.get('complete') is True and preparation.get('frozen') is True and preparation.get('candidateLabel')=='accepted raw/held roof + coherent startup + readonly opening inventory','Root-completed build/source freeze required before launch';expected_assets={**preparation['assets'],**preparation['diagnosticAssets']}
    assert expected_assets and preparation.get('diagnosticSources') and verify_copy() and verify_sources() and verify_production_inputs(),'Prepared copied dist, diagnostic and isolated candidate inputs must match manifest before launch'
    report['preflightComplete']=True;save();command_deadline()
    server=ThreadingHTTPServer(('127.0.0.1',PORTS[0]),Handler);server.daemon_threads=True
    server_thread=threading.Thread(target=server.serve_forever,daemon=True);server_thread.start();report['resourcesStarted']=True
    command=[node,str(WORK/'native.mjs'),'--run=true','--arm='+args.arm,f'--url=http://127.0.0.1:{PORTS[0]}/?diagnostics','--out='+str(out)]
    report['command']=command
    proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
    report['nativeGroup']=proc.pid;save();os.set_blocking(proc.stdout.fileno(),False);sel.register(proc.stdout,selectors.EVENT_READ)
    while proc.poll() is None:
        command_deadline()
        if report['firstFailure'] is not None:raise RuntimeError('Static owner failure; preserve first failure and stop owned capture')
        for key,_ in sel.select(.1):
            try:chunk=os.read(key.fileobj.fileno(),65536)
            except BlockingIOError:continue
            if chunk:append(chunk)
            else:sel.unregister(key.fileobj)
    for key,_ in sel.select(0):
        while True:
            command_deadline()
            try:chunk=os.read(key.fileobj.fileno(),65536)
            except BlockingIOError:break
            if not chunk:break
            append(chunk)
    report['exitCode']=proc.returncode
    if proc.returncode!=0:raise RuntimeError('Native first invocation failed; retain partial output')
    native=json.loads(bounded_file(out/'report.json',32*MIB))
    report['captureValidation']=validate_capture(native,out,args.arm);command_deadline()
    assert report['firstFailure'] is None,'Owner already retained an earlier failure'
    report['complete']=True
except BaseException as error:failure(error,'preflight' if not report['preflightComplete'] else 'command')
finally:
    cleanup=time.monotonic()
    def owned_members():
        try:return members(proc.pid)
        except BaseException as error:failure(error,'owned-group-proof');return None
    def kill_owned(sig):
        try:os.killpg(proc.pid,sig)
        except ProcessLookupError:pass
        except BaseException as error:failure(error,'owned-group-signal')
    if proc is not None:
        remaining=owned_members()
        if remaining is None or remaining:kill_owned(signal.SIGTERM)
        while time.monotonic()-cleanup<2.5:
            remaining=owned_members()
            if remaining==[]:break
            time.sleep(.1)
        if remaining is None or remaining:kill_owned(signal.SIGKILL)
        while time.monotonic()-cleanup<5:
            remaining=owned_members()
            if remaining==[]:break
            time.sleep(.1)
        report['remainingOwnedPids']=owned_members()
        try:proc.wait(timeout=.3)
        except BaseException as error:report['remainingOwnerChild']=True;failure(error,'owned-child-wait')
    if server is not None:
        try:
            if server_thread is not None and server_thread.is_alive():
                stop_thread=threading.Thread(target=server.shutdown,daemon=True);stop_thread.start();stop_thread.join(max(0,cleanup+6-time.monotonic()))
                if stop_thread.is_alive():failure(TimeoutError('Owned server shutdown exceeded cleanup budget'),'server-cleanup')
            server.server_close()
        except BaseException as error:failure(error,'server-cleanup')
    report['closedPorts']={str(p):tcp(p) for p in PORTS}
    report['userPortsOpenAfter']={str(p):tcp(p) is False for p in USER_PORTS}
    report['user4310StillOpen']=report['userPortsOpenAfter']['4310']
    report['user4311StillOpen']=report['userPortsOpenAfter']['4311']
    report['user4312StillOpen']=report['userPortsOpenAfter']['4312']
    report['userServersStayedOpen']=all(report['userPortsOpenAfter'].values())
    for key,check in (('copiedDistUnchanged',verify_copy),('diagnosticSourcesUnchanged',verify_sources),('candidateProductionInputsUnchanged',verify_production_inputs)):
        try:report[key]=check() if preparation is not None else None
        except BaseException as error:report[key]=False;failure(error,key)
    report['independentClosureValid']=(not report['resourcesStarted']) or (report.get('remainingOwnedPids',[])==[] and all(v is True for v in report['closedPorts'].values()))
    if not report['independentClosureValid']:failure(RuntimeError('Owned process/port closure unproven'),'cleanup')
    if not report['userServersStayedOpen']:failure(RuntimeError('Existing user4310/4311/4312 closure observed; neither server was managed'),'cleanup')
    if preparation is not None and (not report['copiedDistUnchanged'] or not report['diagnosticSourcesUnchanged'] or not report['candidateProductionInputsUnchanged']):failure(RuntimeError('Prepared dist or diagnostic source changed'),'cleanup')
    try:sel.close()
    except BaseException as error:failure(error,'selector-cleanup')
    report['cleanupElapsedSeconds']=time.monotonic()-cleanup;report['elapsedSeconds']=time.monotonic()-start
    if report['cleanupElapsedSeconds']>7:failure(TimeoutError('Cleanup exceeded7-second deadline'),'cleanup')
    if report['elapsedSeconds']>180:failure(TimeoutError('Owner exceeded180-second whole deadline'),'cleanup')
    if report['firstFailure'] is not None:report['complete']=False
    save()
print(json.dumps({'complete':report['complete'],'firstFailure':report['firstFailure'],'independentClosureValid':report['independentClosureValid'],'elapsedSeconds':report['elapsedSeconds'],'owner':str(owner)}))
raise SystemExit(0 if report['complete'] else 1)
