function strip(path,front=7,life=.865){
 const count=134,p=new Float32Array(count*2*3),indices=[];
 for(let row=0;row<2;row++)for(let j=0;j<count;j++){
  const c=path[Math.min(j,path.length-1)],o=3*(row*count+j);p[o]=c[0];p[o+1]=c[1];p[o+2]=row-.5;
 }
 for(let j=0;j+1<count;j++){const a=j,b=a+count;indices.push(a,b,a+1,a+1,b,b+1);}
 return {positions:p,indices:new Uint32Array(indices),vertexCount:268,indexCount:indices.length,sliceCount:2,
  sliceFront:new Int32Array([front,front]),sliceSigma:new Float32Array([0,1]),sliceTau:new Float32Array([1,1]),
  sliceJoined:new Uint8Array([1,0]),slicePhase:new Uint8Array([1,1]),sliceFormed:new Float32Array([1,1]),
  sliceWeight:new Float32Array([1,1]),sliceLife:new Float32Array([life,life]),sliceFade:new Float32Array([1,1]),
  sliceRayX:new Float32Array([1,1]),sliceRayZ:new Float32Array([0,0])};
}
function profile(){
 const knots=[[0,-1,0],[3,-1,0],[35,0,3],[67,2,3],[91,0,2],[115,2,0],[130,3,0],[133,3,0]],out=[];
 for(let i=0;i<134;i++){
  let k=0;while(k+1<knots.length&&i>knots[k+1][0])k++;
  const a=knots[k],b=knots[Math.min(k+1,knots.length-1)],t=b[0]>a[0]?(i-a[0])/(b[0]-a[0]):0;
  out.push([a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t]);
 }return out;
}

export {strip,profile};
