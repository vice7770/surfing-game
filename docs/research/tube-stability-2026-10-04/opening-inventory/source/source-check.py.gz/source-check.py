from pathlib import Path
import ast,hashlib,json,subprocess
W=Path('/private/tmp/tube-opening-inventory-20261004');B=Path('/private/tmp/tube-directed-entry-20261004');R=Path('/Users/regina/Desktop/Projects/surfing-game')
def rc(p):
    b=p.read_bytes();return {'file':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
old=json.loads((B/'candidate-source-frozen.json').read_text());new=json.loads((W/'candidate-source-frozen.json').read_text());assert set(old)==set(new) and len(new)==327
for key,v in new.items():assert Path(v['path']).read_bytes()==Path(old[key]['path']).read_bytes() and rc(Path(v['path']))['sha256']==v['sha256']
base=json.loads((B/'preparation.json').read_text());assets={**base['assets'],**base['diagnosticAssets']};assert len(assets)==50
assert {str(p.relative_to(W/'dist')) for p in (W/'dist').rglob('*') if p.is_file()}==set(assets)
for key,v in assets.items():assert (W/'dist'/key).read_bytes()==(B/'dist'/key).read_bytes() and rc(W/'dist'/key)['sha256']==v['sha256']
assert (W/'native-owned.mjs').read_bytes()==(B/'native-owned.mjs').read_bytes()
assert (W/'body-witnesses.mjs').read_bytes()==(B/'body-witnesses.mjs').read_bytes()
native=(W/'native.mjs').read_text();installer=native[native.index('function install('):native.index('\nlet page,exitCode=')]
assert installer.count('d.step(input)')==1 and installer.count('mode.update(1/60)')==1 and "must(steps===0" in installer
for forbidden in ['Autopilot','MediaRecorder','captureStream','retry','place(','reset(','prepare(','setState(','setCue(','applyForce(']:assert forbidden not in installer
assert "const INPUT=Object.freeze({paddle:false,popUp:false,steer:0,crouch:0,compress:0,trim:0,pocketReflex:false})" in native
assert "await capture('initial-ready-prone')" in native and "await capture('after-one-noop-step')" in native
owner=(W/'run.py').read_text();ast.parse(owner);assert 'PORTS=(4294,9704)' in owner and 'USER_PORTS=(4310,4311,4312)' in owner
assert 'os.killpg(proc.pid,sig)' in owner and 'os.killpg(' not in owner.replace('os.killpg(proc.pid,sig)','')
assert "assert key in expected_assets" in owner and "native['physicsAdvances']==1" in owner and "native['video'] is None" in owner
checks={}
for file in ['helper-fixtures.json','inventory-fixtures.json','owner-fixtures.json']:
    x=json.loads((W/file).read_text());assert x['failed']==0 and x['resourcesStarted'] is False;checks[file]={'passed':x['passed'],'receipt':rc(W/file)}
for file in ['native.mjs','inventory.mjs','native-owned.mjs','body-witnesses.mjs','tube-target.mjs','inventory-fixtures.mjs','inherited-math-fixtures.mjs']:
    subprocess.run(['node','--check',str(W/file)],capture_output=True,text=True,check=True)
plan=subprocess.run(['python3',str(W/'run.py'),'--arm','candidate'],capture_output=True,text=True,check=True);p=json.loads(plan.stdout);assert p['resourcesStarted'] is False and p['maximumPhysicsAdvances']==1 and p['ports']==[4294,9704] and p['userPorts']==[4310,4311,4312]
(W/'dry-plan.json').write_text(json.dumps(p,indent=2)+'\n')
# Check every original frozen diagnostic remains byte-identical; completed trace/media are only read.
for v in base['diagnosticSources'].values():assert rc(Path(v['file']))['sha256']==v['sha256']
result={'complete':True,'sourceOnly':True,'resourcesStarted':False,'productionInputs':327,'copiedAssets':50,'contentsUnchanged':True,'originalDiagnosticsStillUnchanged':True,'passedMockGroups':sum(v['passed'] for v in checks.values()),'checks':checks,'dryPlan':rc(W/'dry-plan.json'),'exactOneNoopInputSourceChecked':True,'fullActiveGeometryAndSliceEncoding':True,'noPortProbeByPreparation':True,'goalComplete':False}
(W/'source-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['checks','dryPlan']}))
