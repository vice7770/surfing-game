from pathlib import Path
b=Path('/private/tmp/tube-directed-entry-20261004');w=Path('/private/tmp/tube-opening-inventory-20261004');old=(b/'native.mjs').read_text();start=old.index(" page=await launch({url:args.url");end=old.index(" await page.eval(`(async()=>{const m=await import",start);bootstrap=old[start:end]
header=old[old.index('const started=performance.now(),SETTINGS='):old.index('const FIXED_POLICY=')]
new='''import assert from 'node:assert/strict';
import { mkdirSync,readFileSync,writeFileSync,existsSync } from 'node:fs';
import { join,resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { launch } from './native-owned.mjs';
import { createInventoryCollector } from './inventory.mjs';
const WORK='/private/tmp/tube-opening-inventory-20261004',PORT=4294,CDP=9704,DT=1/60;
const args=Object.fromEntries(process.argv.slice(2).map(a=>{const i=a.indexOf('=');assert(a.startsWith('--')&&i>2);return[a.slice(2,i),a.slice(i+1)];}));
assert.equal(args.run,'true');assert.equal(args.arm,'candidate');assert.equal(args.url,`http://127.0.0.1:${PORT}/?diagnostics`);
const OUT=resolve(args.out??'');assert.equal(OUT,WORK+'/native-first');assert(!existsSync(OUT));mkdirSync(OUT);
process.env.FULL_WRITER_FPS_LAUNCHER_REPORT=join(OUT,'launcher.json');
'''+header+'''
const INPUT=Object.freeze({paddle:false,popUp:false,steer:0,crouch:0,compress:0,trim:0,pocketReflex:false});
const POLICY={minimumWeight:.5,maximumOpenLife:1,minimumWaveNormalDot:.5,maximumBoardAheadOfCrest:14};
const hash=b=>createHash('sha256').update(b).digest('hex');
const report={schema:'tube-opening-inventory-native/v1',arm:args.arm,complete:false,firstFailure:null,source:JSON.parse(readFileSync(join(WORK,'preparation.json'))),settings:SETTINGS,graphics:GRAPHICS,
 input:INPUT,physicsAdvances:0,snapshots:[],artifacts:[],pngCount:0,pngBytes:0,browserErrors:[],video:null,scope:'Initial ordinary ready-prone snapshot plus exactly one ordinary no-op step; no approach, popup, steering, placement, reset, geometry change or entry/quality claim.'};
function save(){const b=Buffer.from(JSON.stringify(report));assert(b.length<=32*1024*1024);writeFileSync(join(OUT,'report.json'),b);}
function saveArtifact(name,b,cap){assert(b.length>0&&b.length<=cap);writeFileSync(join(OUT,name),b);const r={file:name,bytes:b.length,sha256:hash(b)};report.artifacts.push(r);return r;}
function annotatePacked(p){const b=Buffer.from(p.base64,'base64');assert.equal(b.length,p.bytes);assert.equal(b.toString('base64'),p.base64);p.sha256=hash(b);}
function install(createInventoryCollector,policy){
 const d=window.breaklineDiagnostics,mode=d.mode,lab=window.breaklineLab,collect=createInventoryCollector(policy);
 const must=(v,m)=>{if(!v)throw Error(m);};let steps=0;
 function capture(label){must(lab.clock.paused&&mode.host.outstandingSteps===0,'Paused drained snapshot required');
  const snap=mode.host.snapshot,time=snap.status.seaTime;d.renderView(mode.camera.camera);
  const result=collect(mode,steps,label);result.clocks.water=d.water.materialUniforms.waterTime.value;result.clocks.surfaceRevision=d.water.surfaceRevision;
  result.camera={position:mode.camera.camera.position.toArray(),quaternion:mode.camera.camera.quaternion.toArray()};
  result.png=d.canvas.toDataURL('image/png');must(mode.host.snapshot===snap&&snap.status.seaTime===time,'Inventory changed physics snapshot');return result;
 }
 async function oneStep(input){must(steps===0&&lab.clock.paused&&mode.host.outstandingSteps===0,'Exactly one ordinary step allowed');
  const before=mode.host.snapshot.status.seaTime;d.step(input);const started=performance.now();
  while(mode.host.outstandingSteps){must(performance.now()-started<10000,'Single-step drain deadline');await new Promise(r=>setTimeout(r,2));}
  must(Math.abs(mode.host.snapshot.status.seaTime-before-1/60)<1e-7,'One ordinary physical advance');steps++;mode.update(1/60);d.renderView(mode.camera.camera);
  return {step:steps,before,after:mode.host.snapshot.status.seaTime,input:{...input}};
 }
 window.__openingInventory={capture,oneStep};
}
let page,exitCode=0;const snapshots=[];save();
async function capture(label){
 const s=await page.eval(`__openingInventory.capture(${JSON.stringify(label)})`),url=s.png;delete s.png;
 assert(url.startsWith('data:image/png;base64,'));const p=Buffer.from(url.slice(22),'base64');assert(p.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
 assert(report.pngCount<2&&report.pngBytes+p.length<=24*1024*1024);saveArtifact(`${String(report.pngCount).padStart(2,'0')}-${label}.png`,p,12*1024*1024);report.pngCount++;report.pngBytes+=p.length;
 annotatePacked(s.rawFront.values);for(const v of Object.values(s.loft.arrays))annotatePacked(v);snapshots.push(s);
 report.snapshots.push({step:s.step,label:s.label,seaTime:s.seaTime,clocks:s.clocks,boardPose:s.boardPose,ride:s.ride,seaCounters:s.seaCounters,loftCounts:{slices:s.loft.scalars.sliceCount,vertices:s.loft.scalars.vertexCount,indices:s.loft.scalars.indexCount},faceAudit:s.faceAudit});save();
}
try{
'''+bootstrap+'''
 await page.eval(`(${install.toString()}) ((${createInventoryCollector.toString()}),${JSON.stringify(POLICY)})`);
 await capture('initial-ready-prone');assert.equal(snapshots[0].ride.phase,'prone');
 assert(performance.now()-started<140000,'Finite inventory wall deadline');
 report.ordinaryStep=await page.eval(`__openingInventory.oneStep(${JSON.stringify(INPUT)})`);report.physicsAdvances=1;
 await capture('after-one-noop-step');
 assert.equal(snapshots.length,2);assert.equal(snapshots[0].step,0);assert.equal(snapshots[1].step,1);assert(Math.abs(snapshots[1].seaTime-snapshots[0].seaTime-DT)<1e-7);
 saveArtifact('active-snapshots.json',Buffer.from(JSON.stringify({schema:'tube-opening-active-geometry/v1',snapshots,scope:report.scope})),16*1024*1024);
 assert.deepEqual(report.browserErrors,[]);report.complete=true;
}catch(error){report.firstFailure=String(error?.stack??error);exitCode=1;}
finally{
 if(page)try{await page.close();report.chromeClosed=true;}catch(error){report.cleanupFailure=String(error);report.complete=false;exitCode=1;}
 else if(existsSync(join(OUT,'launcher.json')))report.chromeClosed=JSON.parse(readFileSync(join(OUT,'launcher.json'))).ownedChromeClosed;
 report.elapsedSeconds=(performance.now()-started)/1000;save();
}
process.exit(exitCode);
'''
(w/'native.mjs').write_text(new)
