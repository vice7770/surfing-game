from pathlib import Path
w=Path('/private/tmp/tube-opening-inventory-20261004');p=w/'run.py';s=p.read_text();s=s.replace('/private/tmp/tube-directed-entry-20261004','/private/tmp/tube-opening-inventory-20261004').replace('signal, socket, subprocess','signal, socket, subprocess, base64, struct').replace('PORTS=(4293,9703)','PORTS=(4294,9704)').replace("tube-directed-entry-owner/v1","tube-opening-inventory-owner/v1").replace("accepted raw/held roof + coherent startup + directed diagnostic input","accepted raw/held roof + coherent startup + readonly opening inventory")
a=s.index('def steering_check(');b=s.index('parser=argparse.ArgumentParser()',a)
s=s[:a]+'''def packed_check(value):
    sizes={'Float32Array':4,'Uint32Array':4,'Int32Array':4,'Uint8Array':1}
    assert value['type'] in sizes and integer(value['elements']) and value['elements']>=0,'Known bounded typed array'
    assert value['bytes']==value['elements']*sizes[value['type']] and 0<=value['bytes']<=4*MIB,'Typed byte cap/count'
    body=base64.b64decode(value['base64'],validate=True)
    assert len(body)==value['bytes'] and base64.b64encode(body).decode()==value['base64'] and hashlib.sha256(body).hexdigest()==value['sha256'],'Exact active typed bytes/hash'
    return body
def geometry_check(snapshot):
    loft=snapshot['loft'];counts=loft['scalars'];v=counts['vertexCount'];i=counts['indexCount'];s=counts['sliceCount']
    assert all(integer(q) for q in (v,i,s)) and 0<=v<=40000 and 0<=i<=300000 and 0<=s<=300 and v==134*s and i%3==0,'Actual loft bounds'
    assert loft['byteOrder']=='little-endian','Exact byte order'
    arrays=loft['arrays'];assert {'positions','indices','sliceFront','sliceSigma','sliceTau','slicePhase','sliceLife','sliceFade','sliceRayX','sliceRayZ','sliceWeight','sliceFormed','sliceJoined'}<=set(arrays),'All required world/topology/eligibility arrays'
    for name,value in arrays.items():
        body=packed_check(value)
        expected=i if name=='indices' else s if name.startswith('slice') else 3*v if name in ('positions','normals') else 4*v if name=='throat' else v
        assert value['elements']==expected,'Full active typed-array extent'
        if name=='indices':assert value['type']=='Uint32Array' and all(q[0]<v for q in struct.iter_unpack('<I',body)),'Actual active index bound'
        if name=='positions':assert value['type']=='Float32Array' and all(math.isfinite(q[0]) for q in struct.iter_unpack('<f',body)),'Finite actual world positions'
    raw=snapshot['rawFront'];assert integer(raw['recordCount']) and 0<=raw['recordCount']<=2048 and raw['stride']==9,'Bounded raw front records'
    assert raw['values']['type']=='Float32Array' and raw['values']['elements']==raw['recordCount']*9,'Complete raw record bytes';packed_check(raw['values'])
    audit=snapshot['faceAudit'];assert audit['eligiblePairs']==len(audit['pairs']) and audit['eligiblePairs']<=299,'Bounded eligible pair evidence'
    keys=['invalidWaveNormal','zeroOrInvalidAverageRay','normalDotBelow','boardBehindCrest','boardBeyondForwardFace']
    assert audit['facePassed']==sum(p['faceEligible'] for p in audit['pairs']),'Eligible face total'
    for key in keys:assert audit['rejectionCounts'][key]==sum(p['rejection'][key] for p in audit['pairs']),'Separate rejection total'
    for pair in audit['pairs']:
        assert pair['faceEligible'] is (not any(pair['rejection'].values())),'Conjunction of individual face gates'
    return {'vertices':v,'indices':i,'slices':s,'rawFrontRecords':raw['recordCount'],'typedArrays':len(arrays),'eligiblePairs':audit['eligiblePairs'],'facePassed':audit['facePassed'],'rejectionCounts':audit['rejectionCounts']}
def validate_capture(native,out,arm):
    assert native['complete'] is True and native['arm']==arm and native['physicsAdvances']==1 and len(native['snapshots'])==2,'Exactly two snapshots/one no-op step'
    step=native['ordinaryStep'];expected={'paddle':False,'popUp':False,'steer':0,'crouch':0,'compress':0,'trim':0,'pocketReflex':False}
    assert step['input']==expected==native['input'] and step['step']==1 and clock_equal(step['after']-step['before'],1/60),'Ordinary neutral input/clock'
    assert native['video'] is None,'No movie in inventory'
    names=[a['file'] for a in native['artifacts']];assert set(names)=={'00-initial-ready-prone.png','01-after-one-noop-step.png','active-snapshots.json'} and len(names)==3,'Only two PNGs and exact geometry inventory'
    receipts=[];total_png=0;geometry=None
    for value in native['artifacts']:
        name=value['file'];assert Path(name).name==name,'Direct owned artifact'
        p=out/name;body=bounded_file(p,16*MIB if name.endswith('.json') else 12*MIB);assert len(body)==value['bytes'] and hashlib.sha256(body).hexdigest()==value['sha256'],'Exact artifact receipt'
        if name.endswith('.png'):assert body[:8]==b'\\x89PNG\\r\\n\\x1a\\n';total_png+=len(body)
        else:geometry=json.loads(body)
        receipts.append(value)
    assert native['pngCount']==2 and native['pngBytes']==total_png and total_png<=24*MIB,'Two bounded PNGs'
    assert geometry['schema']=='tube-opening-active-geometry/v1' and len(geometry['snapshots'])==2,'Complete retained state'
    snapshots=geometry['snapshots'];assert snapshots[0]['step']==0 and snapshots[1]['step']==1 and snapshots[0]['ride']['phase']=='prone','Initial ordinary fresh prone'
    assert clock_equal(snapshots[1]['seaTime']-snapshots[0]['seaTime'],1/60),'Inventory physics clocks'
    assert [x['label'] for x in snapshots]==['initial-ready-prone','after-one-noop-step'],'Fixed capture labels'
    checks=[geometry_check(x) for x in snapshots]
    for x,brief in zip(snapshots,native['snapshots']):
        for key in ['step','label','seaTime','clocks','boardPose','ride','seaCounters','faceAudit']:assert x[key]==brief[key],'Report/inventory agreement'
    return {'physicsAdvances':1,'snapshots':2,'pngCount':2,'pngBytes':total_png,'artifactReceipts':receipts,'geometry':checks,'readOnlyInventoryIsEntryPass':False}
''' +s[b:]
a=s.index('if not args.run:');b=s.index('start=time.monotonic()',a);s=s[:a]+'''if not args.run:
    print(json.dumps({'sourceOnlyPlan':True,'arm':args.arm,'dist':str(DIST),'wholeSeconds':180,'commandSeconds':168,'cleanupSeconds':7,'maximumPhysicsAdvances':1,'snapshots':2,'maximumPngs':2,'maximumUniqueArtifacts':3,'maximumPngBytesEach':12*MIB,'maximumPngBytesTotal':24*MIB,'maximumReportBytes':32*MIB,'maximumGeometryJsonBytes':16*MIB,'noMovie':True,'noPopupSteeringPlacementOrReset':True,'ports':PORTS,'userPorts':USER_PORTS,'resourcesStarted':False}));raise SystemExit(0)
''' +s[b:]
p.write_text(s)
