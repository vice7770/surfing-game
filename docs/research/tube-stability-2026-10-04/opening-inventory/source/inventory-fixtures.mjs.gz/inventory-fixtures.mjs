import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import vm from 'node:vm';
import { createInventoryCollector } from './inventory.mjs';
import { strip,profile } from './fixtures-geometry.mjs';
const W='/private/tmp/tube-opening-inventory-20261004',policy={minimumWeight:.5,maximumOpenLife:1,minimumWaveNormalDot:.5,maximumBoardAheadOfCrest:14},checks=[];
function check(name,f){f();checks.push({name,passed:true});}
const l=strip(profile()),ride={phase:'prone',resets:0,cue:false,wave:{valid:true,directionX:1,directionZ:0}},front=new Float32Array([0,0,7,0,.8,2.5,7,NaN,NaN,0,1,7,1,.9,2.5,7,NaN,NaN]);
const snap={front,frontCount:2,board:new Float64Array([.5,0,0,0,0,0,1,1]),rider:new Float64Array(33),status:{seaTime:10,ride,lipLaunches:1,lipVolume:1,lipJets:1,lipRollers:0,lipAirborne:1}};
const vector={toArray:()=>[0,0,0]},mode={host:{snapshot:snap,outstandingSteps:0},barrelLoft:l,riderState:{clock:10},camera:{camera:{position:vector,quaternion:vector}},update:()=>{mode.riderState.clock=snap.status.seaTime;}};
const collect=createInventoryCollector(policy),before=Buffer.from(l.positions.buffer).toString('base64');let nominal;
check('slot35 is actual crest and position-forward face is eligible',()=>{
 nominal=collect(mode,0,'initial-ready-prone');assert.equal(nominal.faceAudit.eligiblePairs,1);const p=nominal.faceAudit.pairs[0];assert.deepEqual(p.crest,{x:0,y:3,z:0});assert.equal(p.normalDot,1);assert.equal(p.boardAheadOfCrest,.5);assert.equal(p.faceEligible,true);
});
check('negative local dot and beyond14 are retained separately',()=>{
 snap.board[0]=-1;let r=collect(mode,0,'mock');assert.equal(r.faceAudit.rejectionCounts.boardBehindCrest,1);assert.equal(r.faceAudit.rejectionCounts.boardBeyondForwardFace,0);
 snap.board[0]=20;r=collect(mode,0,'mock');assert.equal(r.faceAudit.rejectionCounts.boardBehindCrest,0);assert.equal(r.faceAudit.rejectionCounts.boardBeyondForwardFace,1);snap.board[0]=.5;
});
check('normal mismatch and invalid wave are retained separately',()=>{
 ride.wave.directionX=0;ride.wave.directionZ=1;let r=collect(mode,0,'mock');assert.equal(r.faceAudit.rejectionCounts.normalDotBelow,1);
 ride.wave.valid=false;r=collect(mode,0,'mock');assert.equal(r.faceAudit.rejectionCounts.invalidWaveNormal,1);assert.equal(r.faceAudit.rejectionCounts.normalDotBelow,0);
 ride.wave.valid=true;ride.wave.directionX=1;ride.wave.directionZ=0;
});
check('full indexed bytes and raw NaN bits are copied exactly without mutation',()=>{
 assert.equal(nominal.loft.arrays.positions.elements,l.vertexCount*3);assert.equal(nominal.loft.arrays.indices.elements,l.indexCount);
 assert(Buffer.from(nominal.loft.arrays.positions.base64,'base64').equals(Buffer.from(l.positions.buffer)));
 assert(Buffer.from(nominal.rawFront.values.base64,'base64').equals(Buffer.from(front.buffer)));assert.equal(Buffer.from(l.positions.buffer).toString('base64'),before);
});
const inputs=[],d={mode,water:{materialUniforms:{waterTime:{value:10}},surfaceRevision:1},canvas:{toDataURL:()=> 'data:image/png;base64,iVBORw0KGgo='},renderView:()=>{},step:input=>{inputs.push({...input});snap.status.seaTime+=1/60;d.water.materialUniforms.waterTime.value=snap.status.seaTime;}};
const source=readFileSync(W+'/native.mjs','utf8'),a=source.indexOf('function install('),b=source.indexOf('\nlet page,exitCode=',a);assert(a>0&&b>a);
const context=vm.createContext({window:{breaklineDiagnostics:d,breaklineLab:{clock:{paused:true}}},performance,setTimeout});
vm.runInContext('('+source.slice(a,b)+')',context)(createInventoryCollector,policy);
const input={paddle:false,popUp:false,steer:0,crouch:0,compress:0,trim:0,pocketReflex:false};
const initial=context.window.__openingInventory.capture('initial-ready-prone');const step=await context.window.__openingInventory.oneStep(input);const final=context.window.__openingInventory.capture('after-one-noop-step');
assert.equal(initial.step,0);assert.equal(final.step,1);assert.deepEqual(inputs,[input]);assert(Math.abs(final.seaTime-initial.seaTime-1/60)<1e-7);assert.equal(step.step,1);
await assert.rejects(()=>context.window.__openingInventory.oneStep(input),/Exactly one ordinary step allowed/);checks.push({name:'extracted installer captures unchanged initial state and permits exactly one neutral physics step',passed:true});
writeFileSync(W+'/inventory-fixtures.json',JSON.stringify({passed:checks.length,failed:0,resourcesStarted:false,checks,mockedInitial:initial,mockedFinal:final},null,2)+'\n');console.log(JSON.stringify({passed:checks.length,failed:0,resourcesStarted:false}));
