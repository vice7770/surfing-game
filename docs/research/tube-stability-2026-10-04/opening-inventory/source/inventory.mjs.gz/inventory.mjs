// Read-only snapshot inventory. No selector, steering controller, popup, placement or retry.
export function createInventoryCollector(policy) {
 const S=134,E=3,C=32,must=(v,m)=>{if(!v)throw Error(m);};
 const pack=(v,n)=>{
  must(Number.isInteger(n)&&n>=0&&n<=v.length,'Active typed-array bound');
  const bytes=new Uint8Array(v.buffer,v.byteOffset,n*v.BYTES_PER_ELEMENT);let binary='';
  for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
  return {type:v.constructor.name,elements:n,bytes:bytes.length,base64:btoa(binary)};
 };
 function collect(mode,step,label){
  const snap=mode.host.snapshot,l=mode.barrelLoft,board=Array.from(snap.board.subarray(0,8)),wave=snap.status.ride.wave;
  must(l&&l.sliceCount<=300&&l.vertexCount<=40000&&l.indexCount<=300000,'Finite actual loft bounds');
  must(snap.frontCount<=2048&&snap.frontCount*9<=snap.front.length,'Published front count bound');
  const arrays={},scalars={};
  for(const[name,value]of Object.entries(l)){
   if(ArrayBuffer.isView(value)){
    const n=name==='indices'?l.indexCount:name.startsWith('slice')?l.sliceCount:name==='positions'||name==='normals'?3*l.vertexCount:name==='throat'?4*l.vertexCount:l.vertexCount;
    arrays[name]=pack(value,n);
   }else if(typeof value==='number')scalars[name]=Number.isFinite(value)?value:null;
  }
  const facePairs=[],normalValid=!!wave.valid&&Number.isFinite(wave.directionX)&&Number.isFinite(wave.directionZ);
  for(let a=0;a+1<l.sliceCount;a++){
   const b=a+1;
   if(l.sliceJoined[a]!==1||l.sliceFront[a]!==l.sliceFront[b]||[a,b].some(s=>l.slicePhase[s]!==1||!(l.sliceFormed[s]>0)||l.sliceWeight[s]<policy.minimumWeight||!Number.isFinite(l.sliceLife[s])||l.sliceLife[s]<0||l.sliceLife[s]>=policy.maximumOpenLife||l.sliceFade[s]<1))continue;
   const rays=[{x:l.sliceRayX[a],z:l.sliceRayZ[a]},{x:l.sliceRayX[b],z:l.sliceRayZ[b]}],nx=(rays[0].x+rays[1].x)/2,nz=(rays[0].z+rays[1].z)/2,n=Math.hypot(nx,nz);
   const at=(row,k)=>l.positions[3*(row*S+E+C)+k];
   const crest={x:(at(a,0)+at(b,0))/2,y:(at(a,1)+at(b,1))/2,z:(at(a,2)+at(b,2))/2};
   const ray=n>0?{x:nx/n,z:nz/n}:null;
   const ahead=ray?(board[0]-crest.x)*ray.x+(board[2]-crest.z)*ray.z:null;
   const lateral=ray?(board[0]-crest.x)*ray.z-(board[2]-crest.z)*ray.x:null;
   const dot=normalValid&&ray?ray.x*wave.directionX+ray.z*wave.directionZ:null;
   const rejection={invalidWaveNormal:!normalValid,zeroOrInvalidAverageRay:!ray,normalDotBelow:dot!==null&&dot<policy.minimumWaveNormalDot,
    boardBehindCrest:ahead!==null&&ahead<0,boardBeyondForwardFace:ahead!==null&&ahead>policy.maximumBoardAheadOfCrest};
   facePairs.push({front:l.sliceFront[a],rows:[a,b],sigma:[l.sliceSigma[a],l.sliceSigma[b]],phase:[l.slicePhase[a],l.slicePhase[b]],life:[l.sliceLife[a],l.sliceLife[b]],
    weight:[l.sliceWeight[a],l.sliceWeight[b]],formed:[l.sliceFormed[a],l.sliceFormed[b]],crest,rays,averageRay:ray,normalValid,normalDot:dot,
    boardAheadOfCrest:ahead,boardLateralFromCrest:lateral,horizontalBoardCrestDistance:Math.hypot(board[0]-crest.x,board[2]-crest.z),rejection,faceEligible:!Object.values(rejection).some(Boolean)});
  }
  const range=key=>{const values=facePairs.map(v=>v[key]).filter(Number.isFinite);return values.length?{minimum:Math.min(...values),maximum:Math.max(...values)}:null;};
  const totals={};for(const key of ['invalidWaveNormal','zeroOrInvalidAverageRay','normalDotBelow','boardBehindCrest','boardBeyondForwardFace'])totals[key]=facePairs.filter(v=>v.rejection[key]).length;
  const endianness=Array.from(new Uint8Array(new Uint32Array([0x01020304]).buffer));must(JSON.stringify(endianness)==='[4,3,2,1]','Expected little-endian native typed arrays');
  return {step,label,seaTime:snap.status.seaTime,clocks:{worker:snap.status.seaTime,visual:mode.riderState.clock},boardPose:board,riderPoints:Array.from(snap.rider.subarray(0,21)),riderWords:Array.from(snap.rider.subarray(21,33)),
   ride:JSON.parse(JSON.stringify(snap.status.ride)),seaCounters:{rawFrontCount:snap.frontCount,lipLaunches:snap.status.lipLaunches,lipVolume:snap.status.lipVolume,lipJets:snap.status.lipJets,lipRollers:snap.status.lipRollers,lipAirborne:snap.status.lipAirborne},
   rawFront:{recordCount:snap.frontCount,stride:9,fields:{x:0,z:1,front:2,sigma:3,tau:4,footHeight:5,footDepth:6,throwZ:7,pace:8},values:pack(snap.front,snap.frontCount*9)},
   loft:{byteOrder:'little-endian',scalars,arrays},faceAudit:{policy,eligiblePairs:facePairs.length,pairs:facePairs,facePassed:facePairs.filter(v=>v.faceEligible).length,rejectionCounts:totals,
    normalDot:range('normalDot'),boardAheadOfCrest:range('boardAheadOfCrest'),boardLateralFromCrest:range('boardLateralFromCrest'),horizontalBoardCrestDistance:range('horizontalBoardCrestDistance')},
   scope:'Existing published state and complete active indexed drawing bytes. Board pose origin is not guaranteed to equal worker combined center of mass. Face audit alone does not identify a gauge crest/front, reachable mouth, opening height, body fit or entry.'};
 }
 return collect;
}
