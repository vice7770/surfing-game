from pathlib import Path
import json, base64, hashlib, struct, math, collections

ROOT = Path('/Users/regina/Desktop/Projects/surfing-game')
WORK = Path('/private/tmp/tube-directed-entry-analysis-20261004')
INVENTORY = Path('/private/tmp/tube-opening-inventory-20261004/native-first/active-snapshots.json')
G = 9.81

def receipt(path):
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def unpack(p):
    b = base64.b64decode(p['base64'])
    assert len(b) == p['bytes'] and hashlib.sha256(b).hexdigest() == p['sha256']
    fmt = {'Float32Array': 'f', 'Uint32Array': 'I', 'Int32Array': 'i', 'Uint8Array': 'B'}[p['type']]
    result = list(struct.unpack('<' + fmt * p['elements'], b))
    assert len(result) == p['elements']
    return result

def beneath(frame, x, y):
    best = float('nan')
    for i in range(88, 127):
        x0, x1 = frame[2*i], frame[2*i+2]
        if x0 == x1 or (x0-x)*(x1-x) > 0:
            continue
        under = frame[2*i+1] + ((x-x0)/(x1-x0))*(frame[2*i+3]-frame[2*i+1])
        if under < y and not under <= best:
            best = under
    return best

def void_height(frame):
    best = 0
    for i in range(64, 89):
        gap = frame[2*i+1] - beneath(frame, frame[2*i], frame[2*i+1])
        if gap > best:
            best = gap
    return best

def load_case(path):
    b = path.read_bytes()
    magic, n = struct.unpack('<II', b[:8])
    assert magic == 0x42524c32
    c = json.loads(b[8:8+n]); offset = 8 + math.ceil(n/4)*4
    floats = struct.unpack('<' + 'f'*((len(b)-offset)//4), b[offset:])
    count = len(floats)//258
    assert len(floats) == count*258
    frames = [floats[i*256:(i+1)*256] for i in range(count)]
    last = min(count-1, math.floor((c['touchdown']-c['tauStart'])/c['tauStep']+1e-6)-1)
    found = False
    for f in range(last, -1, -1):
        frame = frames[f]
        if frame[128]-frame[176] < 0.0234375:
            continue
        if not frame[129]-beneath(frame, frame[128], frame[129]) >= 0.0234375:
            continue
        found = True
        break
    if not found:
        f = max(0, last)
    c['held'] = {'tau': c['tauStart']+f*c['tauStep'], 'voidHeight': void_height(frames[f]), 'clear': found, 'frame': f}
    c['frameCount'] = count; c['asset'] = receipt(path)
    return c

CASES = sorted([load_case(ROOT/'public/barrels'/name) for name in
    ['pad19-a20-l12.bin', 'pad19-a30-l12.bin', 'pad19-a45-l12.bin', 'periodic-padang19s-l12.bin']], key=lambda c: c['nonlinearity'])

def lookup(height, depth, seconds):
    a0 = height/depth; low, high = CASES[0], CASES[-1]; weight = 0; clamped = False
    if a0 <= low['nonlinearity']:
        high = low; clamped = a0 < low['nonlinearity']
    elif a0 >= high['nonlinearity']:
        low = high; clamped = a0 > high['nonlinearity']
    else:
        for l, h in zip(CASES, CASES[1:]):
            if l['nonlinearity'] <= a0 <= h['nonlinearity']:
                low, high = l, h; weight = (a0-l['nonlinearity'])/(h['nonlinearity']-l['nonlinearity']); break
    scale = height/low['nonlinearity'] if low is high else depth
    unit = math.sqrt(scale/G)
    td = low['touchdown']+weight*(high['touchdown']-low['touchdown'])
    clear = min(td, max(low['held']['tau'], high['held']['tau']))
    void = (low['held']['voidHeight']+weight*(high['held']['voidHeight']-low['held']['voidHeight']))*scale
    phase = 'pre' if seconds < 0 else 'open' if seconds <= td*unit else 'post'
    return {'lower': low['id'], 'upper': high['id'], 'weight': weight, 'scale': scale, 'unit': unit,
        'clamped': clamped, 'phase': phase, 'touchdownSeconds': td*unit, 'clearSeconds': clear*unit,
        'heldVoidHeightMetres': void, 'collapseSeconds': math.sqrt(2*void/G),
        'remainingToTouchdownSeconds': td*unit-seconds,
        'forecastToThrowSeconds': -seconds if seconds < 0 else None,
        'throwDepthMetres': 1.56+0.56*min(2.5,max(0.99,height))}

def extent(values):
    return [min(values), max(values)] if values else None

def json_safe(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, dict):
        return {k:json_safe(v) for k,v in value.items()}
    return value

inventory = json.loads(INVENTORY.read_text()); snapshots = []; raw_lists = []
for s in inventory['snapshots']:
    arrays = {name: unpack(a) for name,a in s['loft']['arrays'].items()}
    raw = unpack(s['rawFront']['values']); fields = s['rawFront']['fields']; records = []
    for o in range(0, len(raw), 9):
        r = {name: raw[o+i] for name,i in fields.items()}; r['front'] = int(r['front'])
        r['horizontalDistance'] = math.hypot(r['x']-s['boardPose'][0], r['z']-s['boardPose'][2])
        r['profileLookup'] = lookup(r['footHeight'], r['footDepth'], r['tau'])
        records.append(r)
    raw_lists.append(records)
    groups=[]
    for front in sorted({r['front'] for r in records}):
        rr=[r for r in records if r['front']==front]; rows=[i for i,f in enumerate(arrays['sliceFront']) if f==front]
        groups.append({'front':front,'records':len(rr),'x':extent([r['x'] for r in rr]),'z':extent([r['z'] for r in rr]),
          'distance':extent([r['horizontalDistance'] for r in rr]),'footHeight':extent([r['footHeight'] for r in rr]),
          'tau':extent([r['tau'] for r in rr]),'phaseCounts':dict(collections.Counter(r['profileLookup']['phase'] for r in rr)),
          'touchdown':extent([r['profileLookup']['touchdownSeconds'] for r in rr]),
          'clear':extent([r['profileLookup']['clearSeconds'] for r in rr]),
          'heldVoidHeightMetres':extent([r['profileLookup']['heldVoidHeightMetres'] for r in rr]),
          'collapseSeconds':extent([r['profileLookup']['collapseSeconds'] for r in rr]),
          'remainingToTouchdownSeconds':extent([r['profileLookup']['remainingToTouchdownSeconds'] for r in rr]),
          'drawnRows':len(rows),'drawnPhaseCounts':dict(collections.Counter(arrays['slicePhase'][i] for i in rows)),
          'drawnFormedPositiveRows':sum(arrays['sliceFormed'][i]>0 for i in rows),
          'drawnWeightAtLeastHalfRows':sum(arrays['sliceWeight'][i]>=0.5 for i in rows)})
    snapshots.append({'step':s['step'],'seaTime':s['seaTime'],'boardPose':s['boardPose'], 'ride':s['ride'],
        'faceAudit':s['faceAudit'],'rawRecords':records,'groups':groups,
        'nearestRawRecord':min(records,key=lambda r:r['horizontalDistance']),
        'highestUpcomingRawRecord':max((r for r in records if r['tau']<0),key=lambda r:r['footHeight']),
        'longestForecastUpcomingRawRecord':min(records,key=lambda r:r['tau'])})

# Match identical front and sigma between the two snapshots. They are control samples, not a future trajectory.
delta=[]
for a in raw_lists[0]:
    matching=[b for b in raw_lists[1] if b['front']==a['front'] and abs(a['sigma']-b['sigma'])<1e-6]
    if len(matching)==1:
        b=matching[0]; dt=snapshots[1]['seaTime']-snapshots[0]['seaTime']
        delta.append({'front':a['front'],'sigma':a['sigma'],'dx':b['x']-a['x'],'dz':b['z']-a['z'],
            'crestVx':(b['x']-a['x'])/dt,'crestVz':(b['z']-a['z'])/dt,'tauDelta':b['tau']-a['tau']})

traces=[]
for name in ['tube-coherent-warmup-native-20261004','tube-directed-entry-20261004']:
    p=Path('/private/tmp')/name/'native-first/report.json'; x=json.loads(p.read_text()); rr=x['steps']; initial=x['initialBody']['boardPose']
    standing=[r for r in rr if r['ride']['phase']=='standing']; radius=x['referenceSphereRadii'][2] if isinstance(x['referenceSphereRadii'],list) else None
    # Radii are a keyed dictionary in the actual driver report.
    if radius is None:
        radius=x['referenceSphereRadii'].get('head')
    first=standing[0] if standing else None
    settle=next((r for r in standing if radius is not None and r['riderPoints'][7]+radius-r['boardPose'][1]<=1.18),None)
    traces.append({'name':name,'receipt':receipt(p),'steps':len(rr),'durationSeconds':rr[-1]['physicalSeconds'],
        'phaseCounts':dict(collections.Counter(r['ride']['phase'] for r in rr)),
        'initialBoard':initial[:3],'finalBoard':rr[-1]['boardPose'][:3],
        'maximumZAdvanceMetres':max(r['boardPose'][2]-initial[2] for r in rr),
        'maximumHorizontalDisplacementMetres':max(math.hypot(r['boardPose'][0]-initial[0],r['boardPose'][2]-initial[2]) for r in rr),
        'firstStandingSeconds':first['physicalSeconds'] if first else None,
        'firstStandingBoard':first['boardPose'][:3] if first else None,
        'firstPublishedHeadTopAtMost1_18mSeconds':settle['physicalSeconds'] if settle else None,
        'publishedHeadRadius':radius,'popupSteps':[r['step'] for r in rr if r['input'].get('popUp')],
        'cueRows':sum(r['cue'] for r in rr),'crestBreakingNonzero':sum(r['ride']['wave']['crestBreaking']>0 for r in rr),
        'closestCurlProxyMetres':min((r['ride']['wave']['curlDistance'] for r in rr if r['ride']['wave']['curlDistance'] is not None),default=None),
        'stop':x['stop']})

result={'schema':'tube-opening-causal-offline/v1','runtimeLaunched':False,'originalsModified':False,
    'inventory':receipt(INVENTORY),'cases':CASES,'snapshots':snapshots,'oneStepMatchedControls':delta,'priorOrdinaryTraces':traces,
    'method':'Little-endian typed snapshot bytes verified against every packed SHA256. Library timing/heldFrame math ported literally from accepted ProfileLibrary.ts; no water-query or body-passage claim.',
    'limits':['Negative clocks are causal throw forecasts and may pause as neighbourhood onsets change; they are not guaranteed future ETA.',
      'heldVoidHeightMetres is the accepted provisional collapse model\'s blended sampled void height, not a guarantee of actual connected air, corridor, body fit or the maximum future blended-profile gap.',
      'The two snapshot interval is1/60s; crest motions are one-step observations, not extrapolated future trajectories.',
      'Prior trajectories preserve rider board coordinates but not full evolving loft/world front records. Their curl proxy is not an opening witness.',
      'The highest upcoming raw front is not necessarily joined/formed; raw clocks alone cannot justify normal spawning into its later tube.']}
(WORK/'inventory-analysis.json').write_text(json.dumps(json_safe(result),indent=2,allow_nan=False)+'\n')
print(json.dumps({'caseHeld':[{'id':c['id'],**c['held']} for c in CASES],
    'nearest':snapshots[0]['nearestRawRecord'],'highestUpcoming':snapshots[0]['highestUpcomingRawRecord'],
    'longestForecast':snapshots[0]['longestForecastUpcomingRawRecord'],'traces':traces},indent=2))
