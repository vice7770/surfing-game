import fs from 'node:fs';
import crypto from 'node:crypto';
import { createWitnessSampler } from '/private/tmp/tube-directed-entry-20261004/body-witnesses.mjs';

// Fixed offline scope: every eligible joined-row midpoint contour, then exactly
// the24 tallest three-crossing intervals. No player-face/distance gate and no
// required-height threshold. This is a sampled opening inventory, not a global
// maximum proof, mouth/corridor validation, or body-entry detector.
const source='/private/tmp/tube-opening-inventory-20261004/native-first/active-snapshots.json';
const out='/private/tmp/tube-directed-entry-analysis-20261004/exact-global-columns.json';
const bytes=fs.readFileSync(source), data=JSON.parse(bytes);
const sum=v=>crypto.createHash('sha256').update(v).digest('hex');
const types={Float32Array,Uint32Array,Int32Array,Uint8Array};
function unpack(p){
 const b=Buffer.from(p.base64,'base64');
 if(b.length!==p.bytes||sum(b)!==p.sha256)throw Error('Packed source hash mismatch');
 const copy=new Uint8Array(b.length);copy.set(b);
 const a=new types[p.type](copy.buffer);if(a.length!==p.elements)throw Error('Element mismatch');return a;
}
function scan(s){
 const l={...s.loft.scalars,...Object.fromEntries(Object.entries(s.loft.arrays).map(([k,p])=>[k,unpack(p)]))};
 const p=l.positions,S=134,E=3,CREST=32,candidates=[];let eligible=0;
 for(let a=0;a+1<l.sliceCount;a++){
  const b=a+1,front=l.sliceFront[a];
  if(l.sliceJoined[a]!==1||front!==l.sliceFront[b]||[a,b].some(i=>l.slicePhase[i]!==1||!(l.sliceFormed[i]>0)||l.sliceWeight[i]<.5||!Number.isFinite(l.sliceLife[i])||l.sliceLife[i]<0||l.sliceLife[i]>=1||l.sliceFade[i]<1))continue;
  eligible++;
  let nx=(l.sliceRayX[a]+l.sliceRayX[b])/2,nz=(l.sliceRayZ[a]+l.sliceRayZ[b])/2;const len=Math.hypot(nx,nz);if(!len)continue;nx/=len;nz/=len;
  const at=(row,j,k)=>p[3*(row*S+E+j)+k];
  const crest={x:(at(a,CREST,0)+at(b,CREST,0))/2,z:(at(a,CREST,2)+at(b,CREST,2))/2};
  const contour=[];
  for(let j=0;j<S;j++){
   const u=3*(a*S+j),v=3*(b*S+j),x=(p[u]+p[v])/2,z=(p[u+2]+p[v+2])/2;
   contour.push({along:(x-crest.x)*nx+(z-crest.z)*nz,y:(p[u+1]+p[v+1])/2});
  }
  const stops=[...new Set(contour.map(v=>v.along).filter(Number.isFinite))].sort((a,b)=>a-b);
  for(let k=0;k+1<stops.length;k++){
   const along=(stops[k]+stops[k+1])/2;if(!(along>0)||!(stops[k+1]>stops[k]))continue;
   const hits=[];
   for(let j=0;j+1<contour.length;j++){
    const u=contour[j],v=contour[j+1];if(along>Math.min(u.along,v.along)&&along<Math.max(u.along,v.along))hits.push(u.y+(v.y-u.y)*(along-u.along)/(v.along-u.along));
   }
   hits.sort((a,b)=>a-b);if(hits.length!==3||!(hits[0]<hits[1]&&hits[1]<hits[2]))continue;
   const x=crest.x+along*nx,z=crest.z+along*nz;
   candidates.push({front,rows:[a,b],sigma:[l.sliceSigma[a],l.sliceSigma[b]],tau:[l.sliceTau[a],l.sliceTau[b]],life:[l.sliceLife[a],l.sliceLife[b]],weight:[l.sliceWeight[a],l.sliceWeight[b]],formed:[l.sliceFormed[a],l.sliceFormed[b]],mouthBoundarySigmaDistance:Math.min(l.sliceMouth[a],l.sliceMouth[b]),x,z,ray:[nx,nz],crest,
    coarseHeight:hits[1]-hits[0],coarseCrossings:hits,along,interval:[stops[k],stops[k+1]],intervalWidth:stops[k+1]-stops[k],distanceFromBoard:Math.hypot(x-s.boardPose[0],z-s.boardPose[2])});
  }
 }
 candidates.sort((a,b)=>b.coarseHeight-a.coarseHeight||a.front-b.front||a.rows[0]-b.rows[0]||a.along-b.along);
 const shortlist=candidates.slice(0,24), columns=createWitnessSampler().columns(l,shortlist);
 const exact=shortlist.map((c,i)=>{
  const covering=columns[i].covering.map(v=>({component:v.component,crossings:v.crossings,strictlyOrdered:v.strictlyOrdered}));
  const q=covering.length===1&&covering[0].component.front===c.front&&covering[0].crossings.length===3&&covering[0].strictlyOrdered;
  return {...c,covering,oneConnectedStrictThreeCrossingColumn:q,exactHeight:q?covering[0].crossings[1]-covering[0].crossings[0]:null};
 });
 return {step:s.step,seaTime:s.seaTime,eligibleJoinedRowPairs:eligible,coarseThreeCrossingIntervalCount:candidates.length,coarseCandidateFronts:[...new Set(candidates.map(v=>v.front))],coarseHeightRange:candidates.length?[Math.min(...candidates.map(v=>v.coarseHeight)),candidates[0].coarseHeight]:null,
  coarseHeightAtLeast1_13:candidates.filter(v=>v.coarseHeight>=1.13).length,coarseHeightAtLeast1_23:candidates.filter(v=>v.coarseHeight>=1.23).length,
  exactShortlist:exact,maximumSampledExactHeight:Math.max(0,...exact.map(v=>v.exactHeight??0))};
}
const result={schema:'offline-fixed24-indexed-air-columns/v1',source:{path:source,bytes:bytes.length,sha256:sum(bytes)},helper:{path:'/private/tmp/tube-directed-entry-20261004/body-witnesses.mjs',sha256:sum(fs.readFileSync('/private/tmp/tube-directed-entry-20261004/body-witnesses.mjs'))},scope:'Initial and one-step exact drawn loft only. Global here means player-face/distance gates removed from the frozen row-eligibility rule. Row-midpoint contour intervals sampled;24 tallest intervals exact-verified by unchanged indexed connected-component/half-open crossing machinery. Not an exhaustive surface optimum or future opening/body-fit proof.',snapshots:data.snapshots.map(scan)};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.snapshots.map(({exactShortlist,...s})=>({...s,highestExact:exactShortlist.filter(v=>v.exactHeight!==null).sort((a,b)=>b.exactHeight-a.exactHeight)[0]})),null,2));
