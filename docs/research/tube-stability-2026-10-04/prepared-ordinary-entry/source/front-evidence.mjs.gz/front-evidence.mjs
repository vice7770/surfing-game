// Pure read-only bounded inventory of existing published joined-front records.
// Exact library phase uses frozen accepted Padang header values, not drawn-row
// interpolation. Unjoined private tracks are absent and no crest identity is inferred.
export function createFrontEvidenceCollector(policy) {
 const S=134,CREST=35,G=9.81;
 const must=(v,m)=>{if(!v)throw Error(m);};
 const finiteOrNull=v=>Number.isFinite(v)?v:null;
 function times(height,depth,seconds){
  const cases=policy.libraryCases,a0=height/depth;let lower=cases[0],upper=cases.at(-1),weight=0;
  if(a0<=lower.nonlinearity)upper=lower;
  else if(a0>=upper.nonlinearity)lower=upper;
  else for(let i=0;i+1<cases.length;i++)if(cases[i].nonlinearity<=a0&&a0<=cases[i+1].nonlinearity){lower=cases[i];upper=cases[i+1];weight=(a0-lower.nonlinearity)/(upper.nonlinearity-lower.nonlinearity);break;}
  const scale=lower===upper?height/lower.nonlinearity:depth,unit=Math.sqrt(scale/G);
  const td=lower.touchdown+weight*(upper.touchdown-lower.touchdown),tau=seconds/unit;
  return {phase:tau<0?'pre':tau<=td?'open':'post',touchdownSeconds:td*unit,secondsToTouchdown:td*unit-seconds,secondsToThrowForecast:seconds<0?-seconds:null};
 }
 return function collect(snap,l){
  const begin=performance.now(),r=snap.front,count=snap.frontCount,b=snap.board,w=snap.status.ride.wave;
  must(Number.isInteger(count)&&count>=0&&count<=policy.maximumRawRecords&&count*9<=r.length,'Bounded published raw front records');
  must(b.length>=3&&[b[0],b[1],b[2]].every(Number.isFinite),'Actual finite board pose');
  must(!l||l.sliceCount<=policy.maximumDrawnRows,'Bounded actual drawn rows');
  const approximateGaugeCrest=w?.valid&&Number.isFinite(w.aheadOfCrest)&&Number.isFinite(w.directionX)&&Number.isFinite(w.directionZ)
   ?{x:b[0]-w.aheadOfCrest*w.directionX,z:b[2]-w.aheadOfCrest*w.directionZ}:null;
  const records=[],closestByPhase={pre:null,open:null,post:null};let closestAny=null,nearCount=0;
  for(let k=0;k<count;k++){
   const o=k*9,x=r[o],z=r[o+1],front=r[o+2],sigma=r[o+3],tau=r[o+4],footHeight=r[o+5],footDepth=r[o+6];
   must([x,z,front,sigma,tau,footHeight,footDepth].every(Number.isFinite)&&footHeight>0&&footDepth>0,'Finite positive sized raw front record');
   const horizontalDistance=Math.hypot(x-b[0],z-b[2]),lookup=times(footHeight,footDepth,tau);
   const q={record:k,x,z,front,sigma,tau,footHeight,footDepth,throwZ:finiteOrNull(r[o+7]),pace:finiteOrNull(r[o+8]),horizontalDistance,
    distanceFromApproximateGaugeCrest:approximateGaugeCrest?Math.hypot(x-approximateGaugeCrest.x,z-approximateGaugeCrest.z):null,...lookup};
   records.push(q);if(!closestAny||horizontalDistance<closestAny.horizontalDistance)closestAny=q;
   if(!closestByPhase[q.phase]||horizontalDistance<closestByPhase[q.phase].horizontalDistance)closestByPhase[q.phase]=q;
   if(horizontalDistance<=policy.nearBoardRadius)nearCount++;
  }
  records.sort((a,b)=>a.horizontalDistance-b.horizontalDistance||a.front-b.front||a.sigma-b.sigma);
  const nearBoardRecords=records.filter(q=>q.horizontalDistance<=policy.nearBoardRadius).slice(0,policy.maximumNearBoardRecords);
  let nearestDrawnCrestAnyPhase=null;
  if(l)for(let row=0;row<l.sliceCount;row++){
   const o=3*(row*S+CREST),x=l.positions[o],y=l.positions[o+1],z=l.positions[o+2],distance=Math.hypot(x-b[0],z-b[2]);
   if(!nearestDrawnCrestAnyPhase||distance<nearestDrawnCrestAnyPhase.horizontalDistance)nearestDrawnCrestAnyPhase={row,front:l.sliceFront[row],sigma:l.sliceSigma[row],tau:l.sliceTau[row],phase:l.slicePhase[row],life:finiteOrNull(l.sliceLife[row]),weight:l.sliceWeight[row],formed:l.sliceFormed[row],joinedToNext:l.sliceJoined[row],x,y,z,ray:[l.sliceRayX[row],l.sliceRayZ[row]],horizontalDistance:distance,
    distanceFromApproximateGaugeCrest:approximateGaugeCrest?Math.hypot(x-approximateGaugeCrest.x,z-approximateGaugeCrest.z):null};
  }
  return {rawRecordCount:count,closestAny,closestByPhase,nearBoardRadius:policy.nearBoardRadius,nearBoardCount:nearCount,nearBoardRecords,nearBoardTruncated:nearCount>nearBoardRecords.length,
   nearestDrawnCrestAnyPhase,approximateGaugeCrest,phaseSource:'Frozen accepted Padang library touchdown headers plus raw footHeight/footDepth/tau; actual drawn phase separately retained',
   gaugeCoordinateScope:'Approximate only: published board position differs from gauge combined centre of mass. No prejoin CrestTrack, crest identity, reachable mouth or body-fit claim.',elapsedMilliseconds:performance.now()-begin};
 };
}
