"""Bounded read-only analysis of one completed finite normal-input trial."""
from pathlib import Path
import ast,hashlib,json,math,collections

BASE=Path('/private/tmp/tube-prepared-ordinary-entry-20261004')
OUT=Path('/private/tmp/tube-prepared-ordinary-entry-analysis-20261004')
def receipt(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
INPUTS=[BASE/'native-first/report.json',BASE/'native-first/steps.ndjson',BASE/'native-first-owner.json',BASE/'native-first/launcher.json',BASE/'preparation.json',BASE/'policy.json',BASE/'run.py',BASE/'front-evidence.mjs']
before={str(p):receipt(p) for p in INPUTS}
x=json.loads(INPUTS[0].read_text());steps=x['steps'];owner=json.loads(INPUTS[2].read_text());launcher=json.loads(INPUTS[3].read_text());prep=json.loads(INPUTS[4].read_text())
assert x['complete'] is True and x['firstFailure'] is None and x['chromeClosed'] is True and x['browserErrors']==[]
assert owner['complete'] is True and owner['firstFailure'] is None and owner['failures']==[] and owner['exitCode']==0
assert owner['remainingOwnedPids']==[] and owner['independentClosureValid'] is True
assert owner['closedPorts']=={'4295':True,'9705':True}
assert all(owner['userPortsOpenBefore'][str(p)] and owner['userPortsOpenAfter'][str(p)] for p in (4310,4311,4312))
assert all(owner[k] is True for k in ('userServersStayedOpen','copiedDistUnchanged','diagnosticSourcesUnchanged','candidateProductionInputsUnchanged'))
assert owner['elapsedSeconds']<=180 and owner['cleanupElapsedSeconds']<=7
assert json.loads(INPUTS[1].read_text().splitlines()[0])==steps[0]
assert [json.loads(line) for line in INPUTS[1].read_text().splitlines()]==steps
assert len(steps)==x['stepCount']==owner['captureValidation']['stepCount']==314
assert x['source']==prep

# Re-execute only actual owner pure validators. No owner top level, networking,
# cleanup, browser or native launch is executed by this analysis.
tree=ast.parse((BASE/'run.py').read_text())
names={'bounded_file','integer','clock_equal','finite_number','steering_check','movie_gate','artifact_names_check','png_caps_check','sea_counters_check','front_evidence_check','popup_check','validate_capture','verify_copy','verify_production_inputs','verify_sources'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(nodes)==len(names)
scope={'Path':Path,'hashlib':hashlib,'json':json,'math':math,'MIB':1024*1024,'preparation':prep,'DIST':BASE/'dist','expected_assets':{**prep['assets'],**prep['diagnosticAssets']}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'pure-completed-owner-verifiers','exec'),scope)
capture=scope['validate_capture'](x,BASE/'native-first','candidate')
assert capture==owner['captureValidation']
assert all(scope[n]() for n in ('verify_copy','verify_sources','verify_production_inputs'))
artifact_receipts=[]
for a in x['artifacts']:
 p=BASE/'native-first'/a['file'];r=receipt(p);assert r['bytes']==a['bytes'] and r['sha256']==a['sha256'];artifact_receipts.append(r)

head_radius=x['referenceSphereRadii'][2]
def pose(r):
 b=r['boardPose'];qx,qy,qz,qw=b[3:7]
 up=[2*(qx*qy-qw*qz),1-2*(qx*qx+qz*qz),2*(qy*qz+qw*qx)]
 forward=[2*(qx*qz+qw*qy),2*(qy*qz-qw*qx),1-2*(qx*qx+qy*qy)]
 heading=math.atan2(forward[0],forward[2]);side=[math.cos(heading),0,-math.sin(heading)]
 roll=math.atan2(sum(a*c for a,c in zip(up,side)),up[1])
 return {'step':r.get('step',0),'physicalSeconds':r.get('physicalSeconds',0),'seaTime':r['seaTime'],'phase':r['ride']['phase'],
  'boardPose':b,'riderSevenPoints':r['riderPoints'],'boardUp':up,'boardTiltDegrees':math.degrees(math.acos(max(-1,min(1,up[1])))),
  'boardRollAboutHorizontalBoardHeadingDegrees':math.degrees(roll),'boardHeadingDegrees':math.degrees(heading),'riderBankDegrees':math.degrees(r['ride']['bank']),
  'balance':r['ride']['balance'],'boardY':b[1],'pelvisY':r['riderPoints'][1],'pelvisAboveBoardY':r['riderPoints'][1]-b[1],
  'headCentreY':r['riderPoints'][7],'headTopY':r['riderPoints'][7]+head_radius,'headTopAboveBoardY':r['riderPoints'][7]+head_radius-b[1],
  'boardSpeed':r['ride']['boardSpeed'],'riderSpeed':r['ride']['speed'],'wave':r['ride']['wave'],'popUpReport':r['ride']['popUp'],
  'nearBoardRawCount':r['frontEvidence']['nearBoardCount'],'nearestRaw':r['frontEvidence']['closestAny'],'nearestDrawnCrest':r['frontEvidence']['nearestDrawnCrestAnyPhase']}

standing=[r for r in steps if r['ride']['phase']=='standing'];poses=[pose(r) for r in steps]
first_stand=standing[0];last_stand=standing[-1]
first_crouch=next(r for r in steps if r['input'].get('crouch')==1)
first_top_nominal=next(r for r in standing if pose(r)['headTopAboveBoardY']<=1.13)
first_zero_bank=next(r for r in standing if r['step']>250 and r['ride']['bank']==0)
first_behind=next(r for r in standing if r['ride']['wave']['aheadOfCrest']<0)
local=[];seen=set()
for r in steps:
 for q in r['frontEvidence']['nearBoardRecords']:
  if q['front'] not in seen:local.append({'step':r['step'],'physicalSeconds':r['physicalSeconds'],'record':q,'pose':pose(r)});seen.add(q['front'])
assert seen=={109}
assert all(not r['frontEvidence']['nearBoardTruncated'] for r in steps)

minimum={}
for key,get in {'any':lambda r:r['frontEvidence']['closestAny'],'pre':lambda r:r['frontEvidence']['closestByPhase']['pre'],
 'open':lambda r:r['frontEvidence']['closestByPhase']['open'],'post':lambda r:r['frontEvidence']['closestByPhase']['post'],
 'drawnAnyPhase':lambda r:r['frontEvidence']['nearestDrawnCrestAnyPhase']}.items():
 candidates=[r for r in steps if get(r) is not None];r=min(candidates,key=lambda r:get(r)['horizontalDistance'])
 minimum[key]={'step':r['step'],'physicalSeconds':r['physicalSeconds'],'record':get(r),'pose':pose(r)}

# Near records are complete at every local row (maximum3, no truncation). Away
# from the rider, phase-nearest records are bounded samples rather than a full
# raw inventory, so approximate-gauge distance is not globally optimized.
gauge_samples=[];local109=[]
for r in steps:
 for q in r['frontEvidence']['nearBoardRecords']:
  gauge_samples.append({'step':r['step'],'physicalSeconds':r['physicalSeconds'],'record':q})
  if q['front']==109:local109.append({'step':r['step'],'physicalSeconds':r['physicalSeconds'],**q})
closest_gauge_raw=min(gauge_samples,key=lambda q:q['record']['distanceFromApproximateGaugeCrest'])
drawn_gauge_rows=[r for r in steps if r['frontEvidence']['nearestDrawnCrestAnyPhase'] is not None]
closest_gauge_drawn=min(drawn_gauge_rows,key=lambda r:r['frontEvidence']['nearestDrawnCrestAnyPhase']['distanceFromApproximateGaugeCrest'])
transition_steps=[83,84,96,110,120,210,240,250,255,256,260,268,269,270,275,280,289,295,300,305,306,310,313,314]
timeline=[poses[i-1] for i in transition_steps]
key_events={'firstStanding':pose(first_stand),'firstCrouchInput':{'step':first_crouch['step'],'physicalSeconds':first_crouch['physicalSeconds'],'inputPhase':first_crouch['inputView']['ride']['phase']},
 'firstActualHeadTopAtMostNominal1_13':pose(first_top_nominal),'firstLateBodyBankExactlyZero':pose(first_zero_bank),
 'firstPublishedStandingBehindGaugeCrest':pose(first_behind),'firstLocalJoinedFrontObserved':local[0],'lastStanding':pose(last_stand),'fall':poses[-1]}
def interval(a):return [min(a),max(a)]
result={'schema':'prepared-ordinary-entry-offline-analysis/v1','resourcesStarted':False,'originalsModified':False,'receipts':before,'artifactReceiptsReverified':artifact_receipts,
 'ownerCaptureValidationReexecutedAndMatches':True,'pureFrozenCopySourceAndProductionVerifiersPass':True,
 'closure':{'ownerComplete':owner['complete'],'exitCode':owner['exitCode'],'wholeSeconds':owner['elapsedSeconds'],'cleanupSeconds':owner['cleanupElapsedSeconds'],'remainingOwnedPids':owner['remainingOwnedPids'],'ownedPortsClosed':owner['closedPorts'],'allThreeUserPortsOpenBeforeAfter':True,'proofScope':'Saved completed owner/launcher receipts rechecked; this offline analysis performed no live port probe.'},
 'ordinaryTrial':{'steps':len(steps),'physicalSeconds':steps[-1]['physicalSeconds'],'phaseCounts':dict(collections.Counter(r['ride']['phase'] for r in steps)),
 'popup':owner['captureValidation']['popupControl'],'firstStandingStep':first_stand['step'],'firstStandingSeconds':first_stand['physicalSeconds'],'productionPopUpDurationSeconds':first_stand['ride']['popUp']['duration'],
 'standingToFallElapsedSeconds':steps[-1]['physicalSeconds']-first_stand['physicalSeconds'],'standingRows':len(standing),'cueRows':sum(r['cue'] for r in steps),
 'allSteerInputsZero':all(r['input']['steer']==0 for r in steps),'targetedInputs':0,'targets':dict(collections.Counter(r['tubeTarget']['status'] for r in steps)),
 'rowPairsEligibleTotal':sum(r['tubeTarget']['rowPairsEligible'] for r in steps),'faceRejectedTotal':sum(r['tubeTarget']['rejected']['faceEligibility'] for r in steps),
 'coarseCandidateTotal':sum(r['tubeTarget']['coarseCandidateCount'] for r in steps),'exactColumnTotal':sum(r['tubeTarget']['exactColumnCount'] for r in steps),
 'witnessCounts':dict(collections.Counter((r['witness'] or {}).get('classification','not measured') for r in steps)),
 'maximumBodyWitnessCandidateCount':max(len(p['candidates']) for r in standing for p in r['witness']['points']),
 'entry':x['entry'],'videoTrigger':x['videoTrigger'],'video':x['video'],'stop':x['stop'],
 'maximumShorewardBoardAdvance':max(r['boardPose'][2]-x['initialBody']['boardPose'][2] for r in steps)},
 'actualHeadPreparation':{'referenceRadius':head_radius,'nominalHeadTopAboveBoard':1.13,'earliestCrouchInputStep':first_crouch['step'],'earliestCrouchInputSeconds':first_crouch['physicalSeconds'],
 'firstActualPublishedHeadTopAtMostNominalStep':first_top_nominal['step'],'firstActualPublishedHeadTopAtMostNominalSeconds':first_top_nominal['physicalSeconds'],
 'actualTopAtFirstStanding':pose(first_stand)['headTopAboveBoardY'],'actualTopAtNominalThreshold':pose(first_top_nominal)['headTopAboveBoardY'],
 'allLaterStandingHeadTopsAtMostNominal':all(pose(r)['headTopAboveBoardY']<=1.13 for r in standing if r['step']>=first_top_nominal['step']),
 'scope':'Dynamic published head sphere top only. Threshold crossing is not a full-body prepared posture or settled support/clearance pass; later dropping top can reflect body/board pose changes.'},
 'frontDistanceMinima':minimum,'near40Counts':dict(collections.Counter(r['frontEvidence']['nearBoardCount'] for r in steps)),
 'localJoinedFrontFirstAppearances':local,'local109':{'firstRetainedStep':local109[0]['step'],'lastRetainedStep':local109[-1]['step'],'distinctRetainedRawRows':len(local109),
 'phaseCounts':dict(collections.Counter(q['phase'] for q in local109)),'footHeight':interval([q['footHeight'] for q in local109]),'tau':interval([q['tau'] for q in local109]),
 'secondsToThrowForecast':interval([q['secondsToThrowForecast'] for q in local109]),'secondsToTouchdownForecast':interval([q['secondsToTouchdown'] for q in local109]),
 'finalDrawnGroup':next(q for q in x['checkpoints'][-1]['frontInventory']['drawn']['groups'] if q['front']==109),
 'allLocalNearRecordsRetainedWithoutTruncation':True,'recordsByStep':local109,
 'clockCaution':'Causal negative clocks pause as neighbouring forecasts change. First record tau remained-1.034674 while ordinary physics advanced; countdown is not a guaranteed throw deadline.',
 'libraryCaution':'FootHeight/footDepth exceeds library A0.45, so query clamps and scales by actual footHeight/A0. No formed actual opening or future body-fit proof is obtained from its size/timing alone.'},
 'approximateGaugeAssociation':{'closestRetainedLocalRawRecord':closest_gauge_raw,
 'closestNearestDrawnRow':{'step':closest_gauge_drawn['step'],'physicalSeconds':closest_gauge_drawn['physicalSeconds'],'record':closest_gauge_drawn['frontEvidence']['nearestDrawnCrestAnyPhase']},
 'incomingTrackedFrontIdentityEstablished':False,'spatialAssociation':'Late front109 is spatially near the gauge crest, supporting an incoming local-wave association. Gauge has no retained front ID; published-board rather than combined-COM coordinate and bounded row samples prevent an identity proof.',
 'crestBreakingNonzeroRows':sum(r['ride']['wave']['crestBreaking']>0 for r in steps),'globalGaugeDistanceOptimumEstablished':False},
 'bodyBoardTimeline':timeline,
 'recommendation':{'oneNextWorkItem':'Focused zero-input standing support investigation in AttachedRider/BoardBody around the banking/contact transition and fall, before another ordinary entry trial or spawn relocation.',
 'why':'This normal spawn does eventually develop a nearby substantial joined PRE front while the rider is already crouched. The observed blocker is that the rider falls before that front forms an opening; current records do not identify why the board/body lose stable support.',
 'specificRemainingObservation':'At first late bank0(step256), rapid board roll(step280–300) and last attached step313, retain actual planing/banked/banking state and through-water speed used by planingStep; contact feasible/limit/rawMargin/free centre of pressure; leg extension/rate; sway and postureError. These choose between disabled ankle banking, support clipping and the two balance-separation paths. Pair board surface-relative support data only if needed to attribute hydraulic cause.',
 'sourceScope':'AttachedRider.ts planingStep1503–1512, prepareBank1519+, project2220–2260, finish2055–2126; BoardBody.ts894–917 standing coupling/constraint fallback. Autopilot.ts already pops on production cue, so do not propose adding a duplicate cue gate there.',
 'patchJustifiedNow':False,'spawnRelocationJustifiedNow':False,'identicalUninstrumentedTrialRecommended':False},
 'limits':['All standing body witnesses have no indexed cavity candidate, and local109 remains unformed. No roof collision/tube-entry/hydraulic cause is proved.',
 'Sinking is the production report at the initial stand event, based on that instant relative surface motion; it is not a persistent water-depth measurement or explanation of the later fall.',
 'Balance separation can arise from excessive sway or postureError beyond recoverable range with a recent dominant tip limit. Published status cannot choose the branch.',
 'Board tilt/heading-relative roll derive exactly from published quaternion; rider bank is a different published body angle. Their divergence is observed, not assigned a cause.',
 'Body descending in world space or relative to board does not prove underwater without surface samples at those parts.',
 'First observed localfront109 at269 is a bounded published-inventory observation, not proof of its global creation time.']}
after={str(p):receipt(p) for p in INPUTS};assert after==before
result['originalInputReceiptsUnchangedAfterAnalysis']=True
(OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
summary={'schema':'prepared-ordinary-entry-causal-summary/v1','resourcesStarted':False,'originalsModified':False,'receipts':before,'ownerClosureVerified':True,
 'analysisFile':receipt(OUT/'analysis.json'),'ordinaryTrial':result['ordinaryTrial'],'actualHeadPreparation':result['actualHeadPreparation'],
 'frontDistanceMinima':{k:{'step':v['step'],'physicalSeconds':v['physicalSeconds'],'front':v['record']['front'],'phase':v['record']['phase'],'distance':v['record']['horizontalDistance']} for k,v in minimum.items()},
 'near40Counts':result['near40Counts'],'keyEvents':key_events,'local109Summary':{k:v for k,v in result['local109'].items() if k!='recordsByStep'},
 'approximateGaugeAssociation':result['approximateGaugeAssociation'],'recommendation':result['recommendation'],'limits':result['limits']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'steps':len(steps),'ownerVerified':True,'popupStep':owner['captureValidation']['popupControl']['trigger']['step'],'standingStep':83,'nominalHeadTopStep':first_top_nominal['step'],'firstLocal109Step':local109[0]['step'],'nearestRaw':minimum['any']['record']['horizontalDistance'],'nearestDrawn':minimum['drawnAnyPhase']['record']['horizontalDistance'],'bankZeroStep':first_zero_bank['step'],'fallStep':314,'originalsUnchanged':True,'output':str(OUT/'summary.json')}))
