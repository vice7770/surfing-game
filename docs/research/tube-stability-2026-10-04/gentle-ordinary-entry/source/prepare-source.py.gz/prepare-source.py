#!/usr/bin/env python3
"""Finite source-only freeze; never arms the native owner or manages ports."""
from pathlib import Path
import ast,datetime,hashlib,json,re,shutil,socket,subprocess
ROOT=Path('/Users/regina/Desktop/Projects/surfing-game');WORK=Path('/private/tmp/tube-menu-big-gentle-entry-20261004');OLD=Path('/private/tmp/tube-menu-big-entry-20261004')
checks=[]
def check(name,value):checks.append({'name':name,'passed':bool(value)});assert value,name
def receipt(p):
 b=p.read_bytes();return {'file':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
node=shutil.which('node');check('Node for syntax/mock source checks',bool(node))
for name in ('native.mjs','native-owned.mjs','body-witnesses.mjs','gentle-input-source-check.mjs'):
 r=subprocess.run([node,'--check',str(WORK/name)],capture_output=True,text=True,timeout=10);check(name+' syntax',r.returncode==0)
for name in ('run.py','prepare-source.py'):ast.parse((WORK/name).read_text());check(name+' AST syntax',True)
s=(WORK/'native.mjs').read_text();old=(OLD/'native.mjs').read_text()
for name in ('SETTINGS','EXPECTED_CONFIG','GRAPHICS','POLICY'):
 pattern=rf'{name}=.*?;';check(name+' exact completed Big source',re.search(pattern,s,re.S).group()==re.search(pattern,old,re.S).group())
a='  const w=view.ride.wave';b="  if(pilot.state==='done')";check('Popup gate and standing stance overlay unchanged',s[s.index(a):s.index(b,s.index(a))]==old[old.index(a):old.index(b,old.index(a))])
check('No overrides / rider ordinary start',"await d.start(${JSON.stringify(SETTINGS)},undefined,{rider:true,lab:true})" in s)
check('One ordinary worker request, normal update',s.count('d.step(input)')==1 and 'mode.update(DT);d.renderView(mode.camera.camera)' in s)
check('Same bounds/stopping policy','i<1800' in s and "row.ride.phase==='fallen'||row.ride.phase==='recover'||row.separation||row.ride.resets>report.initialBody.ride.resets" in s)
check('No reset/placement/forced-go calls',not re.search(r'\b(?:pilot|mode|d)\.(?:reset|place|go)\s*\(',s))
check('No camera hunt/view assignment added','lookAt(' not in s and 'setView(' not in s)
check('Explicit steering cap and slew','Math.max(-.2,Math.min(.2,requestedPilotSteer))' in s and 'Math.max(-.4*DT,Math.min(.4*DT,targetLimitedSteer-gentleSteer))' in s and 'if(firstStandingInput)gentleSteer=0' in s)
check('Nullable first eligible movie trigger',"videoStartStep===null&&row.ride.phase==='standing'&&(row.loft?.indices??0)>0&&(finiteCurlNear||witnessQualifies)" in s)
check('No duplicate initial frame','row.step>videoStartStep' in s and 'report.videoRequests.push(initialVideoFrame)' in s)
check('Entry priority prevents partial PNG overflow','partialCandidate=await captureData' in s and 'partialCandidate=null;report.partialCheckpointCandidate={discardedForEntry:true' in s and "if(!report.entry.firstConnectedWitnessEntry&&partialCandidate)" in s)
check('Front inventory exact stride/count/offsets','count=snap.frontCount,stride=9' in s and 'id=records[base+2],sigma=records[base+3],tau=records[base+4]' in s)
r=subprocess.run(['python3',str(WORK/'run.py'),'--arm','candidate'],capture_output=True,text=True,timeout=10);check('Dry owner exit',r.returncode==0);plan=json.loads(r.stdout)
check('No resources in dry plan',plan['sourceOnlyPlan'] and plan['resourcesStarted'] is False)
check('Isolated ports and user ports',plan['ports']==[4291,9701] and plan['userPorts']==[4310,4311])
check('Deadlines preserved',[plan[k] for k in ('wholeSeconds','commandSeconds','cleanupSeconds')]==[180,168,7])
check('Movie and steering policy owner checks',plan['optionalMovieMaximumAdvances']==240 and plan['optionalMovieMaximumRequests']==241 and plan['maximumStandingSteer']==.2 and plan['standingSteerSlewPerSecond']==.4 and plan['captureCompletionIsEntryPass'] is False)
def tcp_proof(port):
 sock=socket.socket();sock.settimeout(.25)
 try:sock.connect(('127.0.0.1',port));return {'closed':False,'reason':'TCP accepted'}
 except ConnectionRefusedError:return {'closed':True,'reason':'Connection refused'}
 except OSError as error:return {'closed':None,'reason':type(error).__name__+': '+str(error)}
 finally:sock.close()
port_proofs={str(port):tcp_proof(port) for port in (4291,9701,4310,4311)}
check('Fresh owned ports currently closed',all(port_proofs[str(p)]['closed'] is True for p in (4291,9701)))
check('User servers currently open; read-only TCP proof',all(port_proofs[str(p)]['closed'] is False for p in (4310,4311)))
r=subprocess.run([node,str(WORK/'gentle-input-source-check.mjs')],capture_output=True,text=True,timeout=10);check('Extracted input/filter schema mocks',r.returncode==0)
prior=json.loads((WORK/'prior-big-preparation.json').read_text());assets=prior['assets'];diagnostic_assets=prior['diagnosticAssets'];all_assets={**assets,**diagnostic_assets}
for key,e in all_assets.items():
 ours=receipt(WORK/'dist'/key);old_receipt=receipt(OLD/'dist'/key);check('Exact frozen asset '+key,ours['bytes']==old_receipt['bytes']==e['bytes'] and ours['sha256']==old_receipt['sha256']==e['sha256'])
check('Exactly50 copied files',len(all_assets)==len([p for p in (WORK/'dist').rglob('*') if p.is_file()])==50)
check('Build ID unchanged',json.loads((WORK/'dist/build.json').read_text())=={'build':'tube-whole-curl-descending-20261004-513ad9d39'})
paths=[p for p in (ROOT/'src').rglob('*') if p.is_file() and not p.name.endswith('.test.ts')]+[p for p in (ROOT/'public').rglob('*') if p.is_file()]
paths += [ROOT/n for n in ('package.json','package-lock.json','index.html','vite.config.ts','tsconfig.json','tsconfig.app.json','tsconfig.node.json') if (ROOT/n).is_file()]
production={str(p.relative_to(ROOT)):{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(paths))}
check('All328 production/public/build hashes unchanged during prepare',production==json.loads((WORK/'production-source-frozen.json').read_text()) and len(production)==328)
(WORK/'production-source-after.json').write_text(json.dumps(production,indent=2)+'\n')
old_entries=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OLD.rglob('*')) if p.is_file()];check('Completed old Big WORK unchanged',old_entries==json.loads((WORK/'prior-big-work-before.json').read_text()));(WORK/'prior-big-work-after.json').write_text(json.dumps(old_entries,indent=2)+'\n')
for src,name in (('preparation.json','prior-big-preparation.json'),('native-first/report.json','prior-big-report.json'),('native-first-owner.json','prior-big-owner.json'),('native-first-owner.log','prior-big-owner.log'),('native-first/launcher.json','prior-big-launcher.json')):check('Exact completed Big receipt '+name,(OLD/src).read_bytes()==(WORK/name).read_bytes())
cdp=prior['diagnosticSources']['browser-cdp'];check('SharedCDP helper unchanged',receipt(Path(cdp['file']))==cdp)
validation={'schema':'tube-gentle-analog-source-checks/v1','complete':True,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceOnly':True,'resourcesStarted':False,'checks':checks,'dryOwnerPlan':plan,'readOnlyTcpProof':port_proofs,'extractedMockChecks':receipt(WORK/'gentle-input-source-checks.json'),'limitations':'Syntax, source/policy, TCP and hash checks only; no new rider/wave dynamics, pixels, movie capability, runtime cleanup or entry verified.'}
(WORK/'source-checks.json').write_text(json.dumps(validation,indent=2)+'\n')
sources={name:receipt(WORK/name) for name in ('native.mjs','run.py','native-owned.mjs','body-witnesses.mjs','autopilot-entry.ts','prepare-source.py','gentle-input-source-check.mjs','README.md','source-checks.json','gentle-input-source-checks.json')};sources['browser-cdp']=cdp
old_report=json.loads((WORK/'prior-big-report.json').read_text());old_owner=json.loads((WORK/'prior-big-owner.json').read_text())
head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True,timeout=5).stdout.strip()
prep={'schema':'tube-menu-big-gentle-entry-preparation/v1','frozen':True,'complete':True,'resourcesStarted':False,'preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'dist':str(WORK/'dist'),'acceptedBaseRevision':prior['acceptedBaseRevision'],'currentHead':head,'experimentalCurlUncommitted':True,'buildId':prior['buildId'],
 'assets':assets,'diagnosticAssets':diagnostic_assets,'diagnosticSources':sources,'productionInputs':{'count':328,'frozenBeforeLaterSourceWork':receipt(WORK/'production-source-frozen.json'),'afterPreparation':receipt(WORK/'production-source-after.json'),'unchangedDuringPreparation':True,'futureProductionWritesDoNotChangeThisCopiedBuild':True},
 'wholeCandidateProductionDiff':receipt(WORK/'production-model.diff'),
 'policy':{**prior['policy'],'trial':'predeclared gentle analog input; completed old Big run retains its original interpretation','standingSteering':{'maximumAbsolute':.2,'slewRatePerSecond':.4,'firstStandingInput':0,'phaseAuthority':'inputView.ride.phase'},'loggedEveryStep':['requestedPilotSteer','targetLimitedSteer','actualInputSteer'],'standingCrouch':1,'compress':0,'trim':0,'pocketReflex':False},
 'actualMenuSea':prior['actualMenuSea'],'expectedActualConfig':prior['expectedActualConfig'],'ports':[4291,9701],'userPorts':[4310,4311],
 'maxSteps':1800,'maxPhysicalSeconds':30,'stop':'first published fall/separation/reset increment or pilot done; no reset/retry','video':{'optional':True,'start':'first post-step standing row with positive drawn loft indices and (finite abs(curlDistance)<=15 or witness partial/contained)','maximumAdditionalSteps':240,'maximumRequests':241,'maximumBytes':16*1024*1024,'nullIfNoTrigger':True,'wallTimeEncoding':True,'fpsClaim':False},
 'checkpointPriority':['first-standing','first-connected-witness-entry; first-partial only if no entry','final'],'pngCap':{'maximumCount':3,'maximumEachBytes':12*1024*1024,'maximumTotalBytes':36*1024*1024},
 'frontInventory':{'rawRecordCount':'snap.frontCount','rawStride':9,'rawFieldOffsets':{'id':2,'sigma':3,'tau':4},'drawnCountsSeparate':True,'readOnly':True},
 'counterEvidence':{'completedRun':str(OLD/'native-first/report.json'),'stepCount':old_report['stepCount'],'firstStanding':old_report.get('firstStanding'),'stop':old_report.get('stop'),'ownerComplete':old_owner['complete'],'entryObserved':bool(old_report['entry']['firstConnectedWitnessEntry']),'interpretation':'No prior tube-entry success; balance-fall evidence motivates a separately declared gentle input trial'},
 'priorBigReceipts':{name:receipt(WORK/name) for name in ('prior-big-preparation.json','prior-big-report.json','prior-big-owner.json','prior-big-owner.log','prior-big-launcher.json','prior-big-work-before.json','prior-big-work-after.json')},
 'sourceOnlyChecks':receipt(WORK/'source-checks.json'),'readOnlyTcpProof':port_proofs,'scope':'Only new scratch preparation and read-only TCP proof. Production/oldBig/user4310/user4311/userdist directories are unmodified; no launch/build/server or port management.',
 'finiteRootCommand':['python3',str(WORK/'run.py'),'--run','--arm','candidate','--out',str(WORK/'native-first')],'goalComplete':False,'adoption':False}
(WORK/'preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
print(json.dumps({'complete':True,'sourceOnly':True,'resourcesStarted':False,'checks':len(checks),'copiedAssets':len(all_assets),'productionInputs':len(production),'oldBigWorkUnchanged':True,'preparation':str(WORK/'preparation.json')}))
