# Remaining commands — not executed or authorized by this file

CWD `/private/tmp/surf-tube-fallback-fps-20261004`.

Source-only preparation proves accepted baseline552 source files and11 production compiled files against retained root-final authorities. Candidate553 files carry exactly six renderer overlays; worker/physics/controls/material source stays accepted. There is no Git extraction or copied source/assets/binary tree. Baseline compilation is reused; candidate alone requires compilation with the same existing BUILD_ID306258296.

After root source review and renderer's separate checks/native gate, prospective sequential CPU checks, stop first failure:

    node candidate/node_modules/typescript/bin/tsc --project candidate/tsconfig.json --noEmit
    env BUILD_ID=306258296 FALLBACK_FPS_READY_SHA256=<reviewed-source-ready-sha> node build-only.mjs

Accepted baseline typing/build/92 checks already have exact complete source authority; no baseline rebuild is proposed. Candidate-only source/runtime typing is separate from the renderer's own focused/lifecycle tests; do not imply those have run here. The build verifies all552/553 source files and baseline11 compiled bytes before/after, candidates eleven outputs and unchanged447015B/e084 worker. It uses configLoader runner, owned cache/fresh dist, copyPublicDirfalse, emptyOutDirfalse. First failure retains command, start/end UTC, PID, exit, separate stdout/stderr and source hashes; no deletion, automatic repair/retry, tolerance/coverage/source change.

Only if strict/build pass, future local binding and syntax/dry plan checks:

    python3 bind-launch.py
    node --check native-owned.mjs
    node --check passive-guard.mjs
    node --check survey.mjs
    node --check pair.mjs
    node pair.mjs --run=false

These do not serve/fetch/launch Chrome. Exact actual compiled manifests and bindings SHA must be reviewed before hardware. Bindings start absent/pending; original source-ready remains unchanged. No fresh fixed-state or retrospective natural trajectory is reused.

Future sole hardware command template, not executable authority:

    env FALLBACK_FPS_READY_SHA256=<reviewed-source-ready-sha> FALLBACK_FPS_BINDINGS_SHA256=<reviewed-actual-compiled-bindings-sha> node pair.mjs --run=true --out=/private/tmp/surf-tube-fallback-fps-20261004/run

Ordinary baseline HTTP4231/CDP9641 then candidate4232/9642, exact de42 survey flags warm5/ride90/native1708x966 initial window/onlyHigh/PadangBig/gpuTimingfalse/edition single-step. Actual native CSS1708x879/DPR2/backing2989x1538 must match exactly without resizing. Read-only soloOneSteptrue both. BUILD_ID306258296 and accepted worker e084 remain equal. Both arms unchanged High/Rich/pixel normals/caustics/mist/far ocean/foam/high particles/frame60; ordinary seed/config/request/grid/mask guards stay. Baseline valid and all owned HTTP/CDP TCP-closed before candidate, play4200 always closed,5173 untouched. Each arm175s abort+5cleanup/180total,360pair, no retry.

Native raw frame/publication intervals and full failures, launch/quality/source guards, served hashes and source before/after are retained. Report actual rendered FPS, freshHz, fixed-step progress and interval tails independently; pipeline component quantiles are not summed/subtracted as request latency; wall bins are not matched sea bins. Performance does not certify stencil/air/moving lifecycle quality, which remains a separate renderer gate. No production adoption/checkpoint/commit or hidden prewarm is proposed.
