import assert from "node:assert/strict";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/baseline/src/wave/barrel/boundedCProfile.ts
const KAPPA$1 = 4 / 3 * Math.tan(Math.PI / 8);
/** Fractions of the actual crest-to-toe height, not the input foot crest height. */
const LIP_OPEN_HEIGHT$1 = .6;
const LIP_FALL_HEIGHT$1 = .8;
const add$1 = (a, b) => [a[0] + b[0], a[1] + b[1]];
const sub$1 = (a, b) => [a[0] - b[0], a[1] - b[1]];
const mul$1 = (a, b) => [a[0] * b, a[1] * b];
const dot$1 = (a, b) => a[0] * b[0] + a[1] * b[1];
const cross$1 = (a, b) => a[0] * b[1] - a[1] * b[0];
const norm$1 = (a) => Math.hypot(...a);
const unit$1 = (a) => {
	const n = norm$1(a);
	if (!n) throw Error("zero tangent");
	return mul$1(a, 1 / n);
};
const mix$1 = (a, b, t) => add$1(mul$1(a, 1 - t), mul$1(b, t));
const round$1 = (a) => [Math.fround(a[0]), Math.fround(a[1])];
const smooth$1 = (x) => {
	x = Math.min(1, Math.max(0, x));
	return x * x * (3 - 2 * x);
};
function bezier$1(c, t) {
	const s = 1 - t;
	return add$1(add$1(mul$1(c[0], s * s * s), mul$1(c[1], 3 * s * s * t)), add$1(mul$1(c[2], 3 * s * t * t), mul$1(c[3], t * t * t)));
}
function derivative$1(c, t) {
	const s = 1 - t;
	return mul$1(add$1(add$1(mul$1(sub$1(c[1], c[0]), s * s), mul$1(sub$1(c[2], c[1]), 2 * s * t)), mul$1(sub$1(c[3], c[2]), t * t)), 3);
}
const at$1 = (p, i) => [p[2 * i], p[2 * i + 1]];
function boundedCParameters$1(profile, authoredTD, tau) {
	return {
		crest: at$1(profile, 32),
		toe: at$1(profile, 112),
		incoming: sub$1(at$1(profile, 32), at$1(profile, 31)),
		outgoing: sub$1(at$1(profile, 113), at$1(profile, 112)),
		authoredTD,
		tau
	};
}
function blendBoundedCParameters$1(a, b, w) {
	return {
		crest: round$1(mix$1(a.crest, b.crest, w)),
		toe: round$1(mix$1(a.toe, b.toe, w)),
		incoming: round$1(mix$1(a.incoming, b.incoming, w)),
		outgoing: round$1(mix$1(a.outgoing, b.outgoing, w)),
		authoredTD: a.authoredTD + w * (b.authoredTD - a.authoredTD),
		tau: a.tau + w * (b.tau - a.tau),
		leafWidthDelta: (a.leafWidthDelta ?? 0) + w * ((b.leafWidthDelta ?? 0) - (a.leafWidthDelta ?? 0))
	};
}
/** Identity core with a C1 shoulder in the requested correction; the bound is the available leaf-reach room. */
function boundedLeafWidthDelta$1(delta, budget) {
	if (!Number.isFinite(delta) || !Number.isFinite(budget) || !(budget > 0)) throw Error("invalid leaf reach correction");
	const magnitude = Math.abs(delta), core = .6 * budget;
	if (magnitude <= core) return delta;
	const shoulder = .4 * budget, excess = magnitude - core;
	return Math.sign(delta) * Math.min(budget, core + shoulder * (excess / (shoulder + excess)));
}
function ordinary$1(z) {
	const A = z.crest, Toe = z.toe, ct = unit$1(z.incoming), tt = unit$1(z.outgoing), W = Toe[0] - A[0], H = A[1] - Toe[1];
	if (W <= 0 || H <= 0 || ct[0] <= 0 || tt[0] <= 0 || z.authoredTD <= 0) throw Error("invalid crest/toe domain");
	const chord = norm$1(sub$1(Toe, A)), ha = Math.min(chord / 3, W / (3 * ct[0])), ht = Math.min(chord / 3, W / (3 * tt[0]));
	const base = [
		A,
		add$1(A, mul$1(ct, ha)),
		sub$1(Toe, mul$1(tt, ht)),
		Toe
	], K0 = bezier$1(base, .5), d0 = unit$1(derivative$1(base, .5));
	const minimumLeafHeight = .4 * H;
	const B = Math.min(.06 * H, W / 16, .1 * Math.min((.85 * W) ** 2 / H, minimumLeafHeight ** 2 / (.85 * W)));
	const reachBudget = Math.min(B, .13 * W - 2 * B), leafWidthDelta = boundedLeafWidthDelta$1(z.leafWidthDelta ?? 0, reachBudget);
	return {
		A,
		Toe,
		ct,
		tt,
		W,
		H,
		base,
		K0,
		d0,
		ha0: ha / 2,
		he0: norm$1(derivative$1(base, .5)) / 6,
		ht0: ht / 2,
		B,
		leafWidthDelta
	};
}
function roof$1(o, g, s, T, post, remaining = 1) {
	const { A, Toe, W, H } = o, angle0 = Math.atan2(o.d0[1], o.d0[0]), angle = post ? -Math.PI / 2 * remaining : (1 - g) * angle0 - g * Math.PI / 2, v = [Math.cos(angle), Math.sin(angle)];
	const L = [Toe[0] - 2 * o.B - .02 * W + o.leafWidthDelta, Toe[1] + LIP_OPEN_HEIGHT$1 * H - LIP_FALL_HEIGHT$1 * H * s];
	let K = mix$1(o.K0, L, g);
	function controls(K) {
		const width = K[0] - A[0], height = A[1] - K[1];
		if (width <= 0 || height <= 0) throw Error("nonpositive leaf domain");
		let hs = (1 - g) * o.ha0 + g * KAPPA$1 * width, he = (1 - g) * o.he0 + g * KAPPA$1 * height;
		const advance = hs * o.ct[0] + he * Math.max(0, v[0]);
		if (advance > .85 * width) {
			hs *= .85 * width / advance;
			he *= .85 * width / advance;
		}
		return [
			A,
			add$1(A, mul$1(o.ct, hs)),
			sub$1(K, mul$1(v, he)),
			K
		];
	}
	if (post) {
		K = add$1(post, [T / 2, T / 2]);
		for (let i = 0; i < 16; i++) {
			const c = controls(K), prev = round$1(bezier$1(c, 27 / 28)), last = unit$1(sub$1(K, prev)), n = [-last[1], last[0]];
			K = add$1(add$1(post, [0, T / 2]), mul$1(n, T / 2));
		}
	}
	const c = controls(K), P = [A];
	for (let i = 1; i < 28; i++) P.push(round$1(bezier$1(c, i / 28)));
	P.push(K);
	const last = unit$1(sub$1(P[28], P[27]));
	return {
		P,
		c,
		last,
		n: [-last[1], last[0]]
	};
}
const eventCache$1 = /* @__PURE__ */ new Map();
function event$1(o) {
	const key = [
		...o.A,
		...o.Toe,
		...o.ct,
		...o.tt,
		o.leafWidthDelta
	].join(",");
	const cached = eventCache$1.get(key);
	if (cached) return cached;
	const gap = (s) => {
		const { P, n } = roof$1(o, 1, s, o.B);
		return P[28][1] - o.B / 2 * (1 + n[1]) - o.Toe[1];
	};
	if (gap(0) <= 0 || gap(1) >= 0) throw Error("impact not bracketed");
	let lo = 0, hi = 1;
	for (let i = 0; i < 32; i++) {
		const m = (lo + hi) / 2;
		if (gap(m) > 0) lo = m;
		else hi = m;
	}
	const seal = (lo + hi) / 2, { P, n } = roof$1(o, 1, seal, o.B), cap = round$1([P[28][0] - o.B / 2 * n[0], o.Toe[1]]);
	lo = 0;
	hi = 1;
	for (let i = 0; i < 32; i++) {
		const m = (lo + hi) / 2;
		if (smooth$1(m) < seal) lo = m;
		else hi = m;
	}
	const result = {
		seal,
		cap,
		fraction: (lo + hi) / 2
	};
	if (eventCache$1.size >= 128) eventCache$1.delete(eventCache$1.keys().next().value);
	eventCache$1.set(key, result);
	return result;
}
function tail$1(A, B, u, v, h0 = norm$1(sub$1(B, A)) / 3, h1 = norm$1(sub$1(B, A)) / 3) {
	const dx = B[0] - A[0];
	if (dx < 0) throw Error("backward tail");
	if (u[0] > 0) h0 = Math.min(h0, dx / (3 * u[0]));
	if (v[0] > 0) h1 = Math.min(h1, dx / (3 * v[0]));
	return [
		A,
		add$1(A, mul$1(u, h0)),
		sub$1(B, mul$1(v, h1)),
		B
	];
}
function arcSample$1(points, count) {
	const lengths = [0];
	for (let i = 1; i < points.length; i++) lengths.push(lengths[i - 1] + norm$1(sub$1(points[i], points[i - 1])));
	const total = lengths.at(-1);
	const out = [];
	let j = 0;
	for (let i = 0; i <= count; i++) {
		const d = total * i / count;
		while (j + 1 < lengths.length - 1 && lengths[j + 1] < d) j++;
		const span = lengths[j + 1] - lengths[j];
		out.push(span ? mix$1(points[j], points[j + 1], (d - lengths[j]) / span) : points[j]);
	}
	return out;
}
function raySegment$1(O, d, P, Q) {
	const e = sub$1(Q, P), den = cross$1(d, e);
	if (Math.abs(den) < 1e-18) return Infinity;
	const a = sub$1(P, O), r = cross$1(a, e) / den, t = cross$1(a, d) / den;
	return r > 0 && t >= 0 && t <= 1 ? r : Infinity;
}
function roots$1(a, b, c) {
	if (Math.abs(a) < 1e-18) return Math.abs(b) > 1e-18 && -c / b > 0 ? [-c / b] : [];
	const disc = b * b - 4 * a * c;
	if (disc < 0) return [];
	const d = Math.sqrt(disc);
	return [(-b - d) / (2 * a), (-b + d) / (2 * a)].filter((r) => r > 0);
}
function rotate$1(a, t) {
	return [a[0] * Math.cos(t) - a[1] * Math.sin(t), a[0] * Math.sin(t) + a[1] * Math.cos(t)];
}
function angleWithin$1(rad, r0, span) {
	let a = Math.atan2(cross$1(r0, rad), dot$1(r0, rad));
	if (a < 0) a += 2 * Math.PI;
	return a <= span + 1e-12 || Math.abs(a - 2 * Math.PI) < 1e-12;
}
function arcBound$1(O, c, r0, span, P, Q) {
	if (!span) return Infinity;
	const candidates = [], e = sub$1(Q, P), ee = dot$1(e, e);
	for (const X of [P, Q]) {
		const x = sub$1(X, O);
		for (const R of roots$1(dot$1(c, c) - 1, -2 * dot$1(c, x), dot$1(x, x))) if (angleWithin$1(sub$1(mul$1(x, 1 / R), c), r0, span)) candidates.push(R);
	}
	if (ee > 0) {
		const n = mul$1([-e[1], e[0]], 1 / Math.sqrt(ee)), d = dot$1(n, sub$1(O, P)), nc = dot$1(n, c);
		for (const sign of [-1, 1]) {
			const den = nc - sign;
			if (Math.abs(den) > 1e-18) {
				const R = -d / den;
				if (R > 0) {
					const centre = add$1(O, mul$1(c, R)), X = sub$1(centre, mul$1(n, sign * R)), t = dot$1(sub$1(X, P), e) / ee;
					if (t >= 0 && t <= 1 && angleWithin$1(mul$1(sub$1(X, centre), 1 / R), r0, span)) candidates.push(R);
				}
			}
		}
	}
	for (const rad of [r0, rotate$1(r0, span)]) candidates.push(raySegment$1(O, add$1(c, rad), P, Q));
	return Math.min(Infinity, ...candidates);
}
function faceBound$1(J, O, dU, cV, P, Q) {
	const candidates = [raySegment$1(J, dU, P, Q), raySegment$1(O, cV, P, Q)];
	if (Math.abs(dU[0]) > 1e-18) for (const X of [P, Q]) {
		const R = (X[0] - J[0]) / dU[0];
		if (R > 0) {
			const U = add$1(J, mul$1(dU, R));
			if (add$1(O, mul$1(cV, R))[1] <= X[1] && X[1] <= U[1]) candidates.push(R);
		}
	}
	return Math.min(...candidates);
}
function root$1(J, vr, angle, qC, yC, T, P, V, bulk, sharedCrest, preservedCarrierStart = 0) {
	const slope = Math.tan(angle), u = mul$1(vr, -1);
	let beta = Math.atan2(u[1], u[0]);
	if (beta < 0) beta += 2 * Math.PI;
	const spanU = 3 * Math.PI / 2 - beta, spanL = Math.PI / 2 + angle;
	if (spanU < 0 || spanL < 0) throw Error("root turn domain");
	const dU = [Math.sin(3 * Math.PI / 2) - Math.sin(beta), -Math.cos(3 * Math.PI / 2) + Math.cos(beta)], dL = [Math.sin(2 * Math.PI + angle) + 1, -Math.cos(2 * Math.PI + angle)], N = J[1] - yC - slope * (J[0] - qC), coef = dU[1] + dL[1] - slope * (dU[0] + dL[0]), O = add$1(J, [0, -N]), cU = [-u[1], u[0]], cV = add$1(dU, [0, -coef]), cL = add$1(cV, [1, 0]);
	if (N <= 0) throw Error("nonpositive root depth");
	let R = Math.min(4 * T, coef < 0 ? N / -coef : Infinity);
	const domainReach = 1 + Math.sin(beta), domainRadius = sharedCrest !== void 0 && domainReach > 0 ? (J[0] - sharedCrest) / domainReach : Infinity;
	R = Math.min(R, domainRadius);
	const guards = [];
	for (let i = 0; i < 28; i++) {
		const n = [-V[i][1], V[i][0]];
		guards.push([sub$1(P[i], mul$1(n, T / 2)), sub$1(P[i + 1], mul$1(n, T / 2))]);
	}
	for (let i = preservedCarrierStart; i < 32; i++) guards.push([add$1(at$1(bulk, i), [0, -T / 2]), add$1(at$1(bulk, i + 1), [0, -T / 2])]);
	for (const [a, b] of guards) R = Math.min(R, arcBound$1(J, cU, mul$1(cU, -1), spanU, a, b), arcBound$1(O, cL, [-1, 0], spanL, a, b), faceBound$1(J, O, dU, cV, a, b));
	if (!Number.isFinite(R) || R < T / 2) throw Error("root thickness domain");
	const D = N + R * coef;
	if (D < -1e-12) throw Error("negative root face");
	const U = add$1(J, mul$1(dU, R));
	if (sharedCrest !== void 0 && R === domainRadius) U[0] = sharedCrest;
	const V0 = add$1(U, [0, -D]), E = add$1(V0, mul$1(dL, R)), points = [J];
	for (let i = 1; i <= 8; i++) points.push(i === 8 && sharedCrest !== void 0 ? U : add$1(J, mul$1([Math.sin(beta + spanU * i / 8) - Math.sin(beta), -Math.cos(beta + spanU * i / 8) + Math.cos(beta)], R)));
	for (let i = 1; i <= 4; i++) points.push(mix$1(U, V0, i / 4));
	for (let i = 1; i <= 4; i++) {
		const a = 3 * Math.PI / 2 + spanL * i / 4;
		points.push(add$1(V0, mul$1([Math.sin(a) + 1, -Math.cos(a)], R)));
	}
	return {
		points,
		E,
		R,
		D,
		domainRadius
	};
}
function ulp32$1(v) {
	const f = new Float32Array([v]), u = new Uint32Array(f.buffer);
	u[0]++;
	return f[0] - Math.fround(v);
}
/** Exact event arithmetic only: clocks do not require the inner sheet, bounded root or floor contour. */
function boundedCLifecycle$1(z) {
	const ev = event$1(ordinary$1(z)), TD = z.authoredTD, impact = TD + .3 * TD * ev.fraction;
	return {
		impactEvent: ev,
		impactTau: impact,
		retiredTau: impact + .3 * TD,
		fullyFormedTau: .4 * TD
	};
}
/** The same F32 cap64 as the full contour, without constructing its unrelated inner root/floor. */
function boundedCCap$1(z, lifecycle) {
	const o = ordinary$1(z), ev = lifecycle ?? event$1(o), TD = z.authoredTD, impact = TD + .3 * TD * ev.fraction, post = z.tau >= impact;
	const g = smooth$1(z.tau / (.4 * TD)), remaining = post ? 1 - smooth$1((z.tau - impact) / (.3 * TD)) : 1, s = post ? ev.seal : smooth$1((z.tau - TD) / (.3 * TD));
	const ulp = ulp32$1(Math.max(...z.crest.map(Math.abs), ...z.toe.map(Math.abs))), requested = o.B * (post ? remaining ** 2 : g * g), loopScale = post ? Math.min(remaining * o.W, remaining ** 2 * o.H) : Math.min(g * o.W, g * o.H), collapsed = requested < 8 * ulp || loopScale <= 64 * ulp, T = collapsed ? 0 : Math.max(requested, 8 * ulp);
	const { P, last } = roof$1(o, post ? 1 : g, s, T, post ? ev.cap : void 0, remaining);
	if (collapsed) return round$1(P[28]);
	const n = [-last[1], last[0]], centre = sub$1(P[28], mul$1(n, T / 2));
	let phi = Math.atan2(-last[1], -n[1]);
	if (phi < 0) phi += 2 * Math.PI;
	if (!(phi > 0 && phi <= Math.PI)) throw Error("cap minimum domain");
	const a = phi * 4 / 4, cap = add$1(centre, mul$1(add$1(mul$1(n, Math.cos(a)), mul$1(last, Math.sin(a))), T / 2));
	return round$1(post ? ev.cap : cap);
}
/** Writes only owned33..111. Domain failures throw; caller may explicitly choose raw library mode, never silently fall back. */
function sampleBoundedC$1(z, profile, velocity = true, lifecycle, sharedRootDomain = false, preservedCarrierStart = 0) {
	const o = ordinary$1(z), ev = lifecycle ?? event$1(o), TD = z.authoredTD, impact = TD + .3 * TD * ev.fraction, retired = impact + .3 * TD, post = z.tau >= impact;
	const g = smooth$1(z.tau / (.4 * TD)), remaining = post ? 1 - smooth$1((z.tau - impact) / (.3 * TD)) : 1, s = post ? ev.seal : smooth$1((z.tau - TD) / (.3 * TD));
	const ulp = ulp32$1(Math.max(...z.crest.map(Math.abs), ...z.toe.map(Math.abs))), requested = o.B * (post ? remaining ** 2 : g * g), loopScale = post ? Math.min(remaining * o.W, remaining ** 2 * o.H) : Math.min(g * o.W, g * o.H), collapsed = requested < 8 * ulp || loopScale <= 64 * ulp, activeG = g, activeRemain = remaining, T = collapsed ? 0 : Math.max(requested, 8 * ulp);
	const { P, c: currentRoof, last } = roof$1(o, post ? 1 : activeG, s, T, post ? ev.cap : void 0, activeRemain), target = Array.from({ length: 113 }, () => [0, 0]);
	for (let i = 0; i <= 28; i++) target[32 + i] = P[i];
	let R = 0, D = 0, envelopeBound = 0, connectorLength = 0, domainRadius;
	const envelopeBudget = .001 * Math.max(o.W, o.H);
	if (collapsed) {
		const K = P[28], angle = post ? 0 : (1 - g) * Math.atan2(o.d0[1], o.d0[0]), pv = [Math.cos(angle), Math.sin(angle)], slope = Math.tan(angle), yC = post ? o.Toe[1] : (1 - g) * o.K0[1] + g * o.Toe[1], C = [K[0], yC];
		if (C[1] > K[1]) throw Error("zero sheet connector not descending");
		const chord = norm$1(sub$1(o.Toe, C)), h0 = (1 - g) * o.he0 + g * chord / 3, h1 = (1 - g) * o.ht0 + g * chord / 3, fc = tail$1(C, o.Toe, pv, o.tt, h0, h1);
		connectorLength = K[1] - C[1];
		for (let i = 61; i <= 68; i++) target[i] = K;
		for (let i = 69; i <= 106; i++) target[i] = [K[0], K[1] + (C[1] - K[1]) * (i - 68) / 38];
		for (let i = 107; i <= 112; i++) target[i] = bezier$1(fc, (i - 106) / 6);
		const referenceT = Math.max(requested, 8 * ulp), reference = post ? roof$1(o, 1, s, referenceT, ev.cap, remaining) : {
			P,
			c: currentRoof
		}, F1 = [reference.P[28][0] - referenceT / 2 + referenceT, yC + slope * referenceT], refChord = norm$1(sub$1(o.Toe, F1)), refFloor = tail$1(F1, o.Toe, pv, o.tt, (1 - g) * o.he0 + g * refChord / 3, (1 - g) * o.ht0 + g * refChord / 3);
		envelopeBound = Math.max(...currentRoof.map((p, i) => norm$1(sub$1(p, reference.c[i]))), ...fc.map((p, i) => norm$1(sub$1(p, refFloor[i]))));
		if (requested > 0 && envelopeBound > envelopeBudget) throw Error("precision collapse spatial budget");
	} else {
		const V = P.slice(1).map((b, i) => unit$1(sub$1(b, P[i]))), N = V.map((v) => [-v[1], v[0]]), offset = [mul$1(N[0], -1)];
		for (let i = 1; i < 28; i++) {
			const den = 1 + dot$1(N[i - 1], N[i]);
			if (den <= 0) throw Error("opposite normals");
			offset.push(mul$1(add$1(N[i - 1], N[i]), -1 / den));
		}
		offset.push(mul$1(N[27], -1));
		const Q = P.map((p, i) => add$1(p, mul$1(offset[i], T)));
		for (let i = 0; i < 28; i++) {
			if (norm$1(sub$1(Q[i + 1], Q[i])) / norm$1(sub$1(P[i + 1], P[i])) < .75) throw Error("offset curvature budget");
			if (Q[i + 1][0] <= Q[i][0]) throw Error("backward offset sheet");
		}
		const factor = post ? activeRemain : activeG, qJ = (1 - factor) * Q[28][0] + factor * (o.A[0] + .28 * o.W);
		if (!(Q[0][0] <= qJ && qJ < Q[28][0])) throw Error("root cut outside sheet");
		let e = 0;
		while (!(Q[e][0] <= qJ && qJ <= Q[e + 1][0])) e++;
		const J = mix$1(Q[e], Q[e + 1], (qJ - Q[e][0]) / (Q[e + 1][0] - Q[e][0])), chain = [Q[28]];
		for (let i = 27; i > e; i--) chain.push(Q[i]);
		chain.push(J);
		const inner = arcSample$1(chain, 12), centre = sub$1(P[28], mul$1(N[27], T / 2));
		let phi = Math.atan2(-V[27][1], -N[27][1]);
		if (phi < 0) phi += 2 * Math.PI;
		if (!(phi > 0 && phi <= Math.PI)) throw Error("cap minimum domain");
		for (let i = 61; i <= 68; i++) {
			const a = i <= 64 ? phi * (i - 60) / 4 : phi + (Math.PI - phi) * (i - 64) / 4;
			target[i] = add$1(centre, mul$1(add$1(mul$1(N[27], Math.cos(a)), mul$1(V[27], Math.sin(a))), T / 2));
		}
		target[68] = Q[28];
		if (post) target[64] = ev.cap;
		for (let i = 69; i <= 80; i++) target[i] = inner[i - 68];
		const angle = post ? 0 : (1 - activeG) * Math.atan2(o.d0[1], o.d0[0]), pv = [Math.cos(angle), Math.sin(angle)], slope = pv[1] / pv[0], qC = P[28][0] - T / 2, yC = post ? o.Toe[1] : (1 - activeG) * o.K0[1] + activeG * o.Toe[1], rr = root$1(J, V[e], angle, qC, yC, T, P, V, profile, sharedRootDomain ? o.A[0] : void 0, preservedCarrierStart);
		R = rr.R;
		D = rr.D;
		if (sharedRootDomain) domainRadius = rr.domainRadius;
		for (let i = 0; i <= 16; i++) target[80 + i] = rr.points[i];
		const F0 = [qC - T, yC - slope * T], F1 = [qC + T, yC + slope * T];
		if (!(rr.E[0] <= F0[0] && F0[0] < F1[0] && F1[0] < o.Toe[0])) throw Error("floor plateau domain");
		const chord = norm$1(sub$1(o.Toe, F1)), h0 = (1 - activeG) * o.he0 + activeG * chord / 3, h1 = (1 - activeG) * o.ht0 + activeG * chord / 3, fc = tail$1(F1, o.Toe, pv, o.tt, h0, h1);
		for (let i = 97; i <= 102; i++) target[i] = mix$1(rr.E, F0, (i - 96) / 6);
		for (let i = 103; i <= 106; i++) target[i] = mix$1(F0, F1, (i - 102) / 4);
		for (let i = 107; i <= 112; i++) target[i] = bezier$1(fc, (i - 106) / 6);
	}
	for (let i = 33; i < 112; i++) {
		profile[2 * i] = target[i][0];
		profile[2 * i + 1] = target[i][1];
		if (!Number.isFinite(profile[2 * i] + profile[2 * i + 1])) throw Error("nonfinite profile");
	}
	const cap = at$1(profile, 64), flow = Math.sqrt(2 * o.H), meta = {
		model: "bounded-analytic-C/v4",
		impactEvent: ev,
		lengthScale: 1,
		timeScale: 1,
		formation: g,
		remaining,
		seal: s,
		authoredSealTau: TD,
		impactTau: impact,
		retiredTau: retired,
		fullyFormedTau: .4 * TD,
		sheetExists: !collapsed,
		precisionCollapsed: collapsed && requested > 0,
		thickness: T,
		requestedThickness: requested,
		cap,
		impactCap: ev.cap,
		rootRadius: R,
		rootVerticalLeg: D,
		precisionEnvelopeBound: envelopeBound,
		precisionEnvelopeBudget: envelopeBudget,
		collapsedConnectorLength: connectorLength,
		capBoundaryVelocity: [0, 0],
		fluidAlong: post ? 0 : last[0] * flow,
		fluidUp: post ? -flow : last[1] * flow,
		partRanges: {
			outer: [32, 60],
			cap: [60, 68],
			inner: [68, 80],
			upperRoot: [80, 88],
			face: [88, 92],
			lowerRoot: [92, 96],
			floor: [96, 112]
		}
	};
	meta.rootRadiusMaximumFromSheetDomain = domainRadius;
	if (velocity) {
		const dt = 1e-5 * TD, a = profile.slice(), b = profile.slice();
		sampleBoundedC$1({
			...z,
			tau: z.tau - dt
		}, a, false, lifecycle, sharedRootDomain, preservedCarrierStart);
		sampleBoundedC$1({
			...z,
			tau: z.tau + dt
		}, b, false, lifecycle, sharedRootDomain, preservedCarrierStart);
		meta.capBoundaryVelocity = [(b[128] - a[128]) / (2 * dt), (b[129] - a[129]) / (2 * dt)];
	}
	return meta;
}
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/baseline/src/wave/barrel/sharedUpperRoot.ts
/** Height of the original forward polygon, explicitly completing a quantized vertical facet with its highest endpoint. */
function roofHeight$1(profile, x) {
	let y = -Infinity;
	for (let i = 32; i < 60; i += 1) {
		const a = profile[2 * i], b = profile[2 * (i + 1)];
		if (b < a) throw new Error("shared upper-root backward roof domain");
		if (x < a || x > b) continue;
		const ay = profile[2 * i + 1], by = profile[2 * (i + 1) + 1];
		y = Math.max(y, a === b ? Math.max(ay, by) : ay + (by - ay) * ((x - a) / (b - a)));
	}
	if (!Number.isFinite(y)) throw new Error("shared upper-root missing roof crossing");
	return y;
}
/** Exact vertical graph difference on the overlapping domain, at the union of both polygons' breakpoints. */
function roofEnvelopeDifference$1(a, b) {
	const left = Math.max(a[64], b[64]), right = Math.min(a[120], b[120]);
	if (left > right) throw new Error("roof envelope lacks common domain");
	let maximum = 0;
	const xs = [left, right];
	for (const p of [a, b]) for (let i = 32; i <= 60; i += 1) if (p[2 * i] >= left && p[2 * i] <= right) xs.push(p[2 * i]);
	for (const x of xs) maximum = Math.max(maximum, Math.abs(roofHeight$1(a, x) - roofHeight$1(b, x)));
	return maximum;
}
/**
* New sampling authority for the complete inner-sheet seam, not a change to v4's controls.
* Unsupported actual domains fail explicitly. Only outer33..59 is resampled, in both resolved and collapsed states so the precision gate cannot switch sampling authorities.
*/
function pairInnerSheet$1(profile, _meta) {
	const original = profile.slice();
	const left = original[176], right = original[136];
	const a = original[64], k = original[120];
	if (!(a <= left && left <= right && right <= k)) throw new Error("shared upper-root lacks complete outer roof domain");
	for (let i = 68; i < 88; i += 1) if (original[2 * i] < original[2 * (i + 1)]) throw new Error("shared upper-root backward return domain");
	const sample = (i, x) => {
		profile[2 * i] = x;
		profile[2 * i + 1] = roofHeight$1(original, profile[2 * i]);
	};
	for (let i = 33; i < 38; i += 1) sample(i, a + (left - a) * ((i - 32) / 6));
	let coalescedStations = 0;
	for (let i = 38; i <= 58; i += 1) {
		const j = 126 - i;
		sample(i, original[2 * j]);
		if (profile[2 * i + 1] < original[2 * j + 1]) throw new Error("shared upper-root negative paired separation");
		if (i > 38 && profile[2 * i] === profile[2 * (i - 1)]) coalescedStations += 1;
	}
	sample(59, right + (k - right) / 2);
	return {
		top: [38, 58],
		underside: [68, 88],
		maximumRoofEnvelopeChange: roofEnvelopeDifference$1(original, profile),
		coalescedStations
	};
}
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/baseline/src/wave/dispersion.ts
/** Linear (Airy) water-wave dispersion, ω² = g k tanh(kh), in SI units. */
const GRAVITY$1 = 9.81;
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/baseline/src/wave/barrel/ProfileLibrary.ts
let carrierRounding$1;
function carrierNextUp$1(value) {
	if (!Number.isFinite(value) || value < 0) throw new Error("Invalid positive carrier bound");
	carrierRounding$1 ??= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	carrierRounding$1.setFloat64(0, value);
	const low = carrierRounding$1.getUint32(4);
	carrierRounding$1.setUint32(4, low === 4294967295 ? 0 : low + 1);
	if (low === 4294967295) carrierRounding$1.setUint32(0, carrierRounding$1.getUint32(0) + 1);
	return carrierRounding$1.getFloat64(0);
}
const LANDMARK$1 = {
	back: 0,
	crest: 32,
	lip: 64,
	throat: 88,
	toe: 112,
	front: 127
};
/**
* The contact's held frame (the advisor, 2026-09-30): the jet off the face and the void open, each by `gap`, h0: 2 cells
* at level 12 on the runs' 48 h0 domain (tools/basilisk/run_padang.sh; the periodic run's cells are 64/4096 h0).
*/
const CLEAR$1 = { gap: 96 / 4096 };
const FLOATS$1 = 256;
const ease$1 = (value) => {
	const t = Math.max(0, Math.min(1, value));
	return t * t * (3 - 2 * t);
};
/**
* Carrier-width adjustment, h0. A centered continuous mean spans one authored frame on each side.
* We do not extend or asymmetrically truncate a case: its first/last interval stays raw, with a zero-slope
* activation over the next interval. Constant and linear frame-width sequences therefore stay unchanged,
* including boundaries. In the fully enabled interior the averaged width is C1 at raw frame knots.
* This changes neither the raw case words nor the actual crest/toe coordinates.
*/
function carrierWidthDelta$1(c, tau) {
	const count = c.frames.length / FLOATS$1;
	if (count < 3) return 0;
	const position = Math.max(0, Math.min(count - 1, (tau - c.tauStart) / c.tauStep));
	const enabled = ease$1(position - 1) * ease$1(count - 2 - position);
	if (enabled === 0) return 0;
	const width = (frame) => c.frames[frame * FLOATS$1 + 2 * LANDMARK$1.toe] - c.frames[frame * FLOATS$1 + 2 * LANDMARK$1.crest];
	const frame = Math.floor(position), share = position - frame;
	const raw = width(frame) + share * (width(frame + 1) - width(frame));
	const high = position + 1;
	let low = position - 1, interval = Math.floor(low), area = 0;
	while (low < high) {
		const end = Math.min(high, interval + 1), a = width(interval), slope = width(interval + 1) - a;
		area += (end - low) * (2 * a + slope * (low + end - 2 * interval)) / 2;
		low = end;
		interval += 1;
	}
	return enabled * (area / 2 - raw);
}
/** A slice whose slope is this far (relative) from every case's is outside the library. */
const SLOPE_TOLERANCE$1 = .2;
/**
* The highest point of frame f's lower surface (the face and on, from the throat to the front end) under (x, y), h0;
* NaN where none lies under it.
*/
function surfaceBeneath$1(frames, f, x, y) {
	const o = f * FLOATS$1;
	let best = NaN;
	for (let i = LANDMARK$1.throat; i < LANDMARK$1.front; i += 1) {
		const x0 = frames[o + 2 * i];
		const x1 = frames[o + 2 * i + 2];
		if (x0 === x1 || (x0 - x) * (x1 - x) > 0) continue;
		const y0 = frames[o + 2 * i + 1];
		const under = y0 + (x - x0) / (x1 - x0) * (frames[o + 2 * i + 3] - y0);
		if (under < y && !(under <= best)) best = under;
	}
	return best;
}
/** Frame f's void height, h0: the most its underside (tip to throat) stands over the lower surface beneath it. */
function voidHeightAt$1(frames, f) {
	const o = f * FLOATS$1;
	let height = 0;
	for (let i = LANDMARK$1.lip; i <= LANDMARK$1.throat; i += 1) {
		const y = frames[o + 2 * i + 1];
		const gap = y - surfaceBeneath$1(frames, f, frames[o + 2 * i], y);
		if (gap > height) height = gap;
	}
	return height;
}
/**
* A case's held frame (the advisor, 2026-09-30): the last frame, at or before one frame before touchdown, whose tip
* stands `CLEAR.gap` over the lower surface beneath it (the jet off the face) and `CLEAR.gap` ahead of its throat (the
* void open, not collapsed onto the face as pad19-a30-l12's last two frames are); its void's height there. With none
* such, the frame before touchdown, unclear.
*/
function heldFrame$1(c) {
	const count = c.frames.length / FLOATS$1;
	const last = Math.min(count - 1, Math.floor((c.touchdown - c.tauStart) / c.tauStep + 1e-6) - 1);
	for (let f = last; f >= 0; f -= 1) {
		const o = f * FLOATS$1;
		const tipX = c.frames[o + 2 * LANDMARK$1.lip];
		const tipY = c.frames[o + 2 * LANDMARK$1.lip + 1];
		if (tipX - c.frames[o + 2 * LANDMARK$1.throat] < CLEAR$1.gap) continue;
		if (!(tipY - surfaceBeneath$1(c.frames, f, tipX, tipY) >= CLEAR$1.gap)) continue;
		return {
			tau: c.tauStart + f * c.tauStep,
			voidHeight: voidHeightAt$1(c.frames, f),
			clear: true
		};
	}
	const f = Math.max(0, last);
	return {
		tau: c.tauStart + f * c.tauStep,
		voidHeight: voidHeightAt$1(c.frames, f),
		clear: false
	};
}
var ProfileLibrary$1 = class {
	cases;
	options;
	bySlope;
	held = /* @__PURE__ */ new Map();
	scratch = new Float32Array(FLOATS$1);
	tipLower = /* @__PURE__ */ new Float64Array(2);
	tipUpper = /* @__PURE__ */ new Float64Array(2);
	times = /* @__PURE__ */ new Float64Array(4);
	analyticPoint = new Float32Array(FLOATS$1);
	analyticOther = new Float32Array(FLOATS$1);
	analyticEarlier = new Float32Array(FLOATS$1);
	analyticLater = new Float32Array(FLOATS$1);
	analyticQueries = /* @__PURE__ */ new Map();
	analyticClocks = /* @__PURE__ */ new Map();
	constructor(cases, options = {}) {
		this.cases = cases;
		this.options = options;
		const groups = /* @__PURE__ */ new Map();
		for (const c of cases) groups.set(c.slope, [...groups.get(c.slope) ?? [], c]);
		this.bySlope = [...groups.values()].map((group) => [...group].sort((a, b) => a.nonlinearity - b.nonlinearity));
		for (const c of cases) this.held.set(c, heldFrame$1(c));
	}
	/** The profile for a slice, in metres, into `out` (PROFILE_POINTS (x, y) pairs). */
	profileAt(query, out) {
		const b = this.bracket(query);
		if (this.options.geometry === "bounded-C") return this.analyticAt(query, b, out);
		const tau = query.seconds / b.unit;
		const times = this.caseTimes(b, tau, query.hold);
		this.frameAt(b.lower, times[0], out);
		if (b.upper !== b.lower) {
			this.frameAt(b.upper, times[1], this.scratch);
			for (let i = 0; i < FLOATS$1; i += 1) out[i] += b.weight * (this.scratch[i] - out[i]);
		}
		for (let i = 0; i < FLOATS$1; i += 1) out[i] *= b.scale;
		const tip = this.tipLower;
		this.tipAt(b.lower, times[2], tip);
		if (b.upper !== b.lower) {
			this.tipAt(b.upper, times[3], this.tipUpper);
			tip[0] += b.weight * (this.tipUpper[0] - tip[0]);
			tip[1] += b.weight * (this.tipUpper[1] - tip[1]);
		}
		const speed = b.scale / b.unit;
		const phase = tau < 0 ? "pre" : tau <= b.touchdown ? "open" : "post";
		return {
			caseId: b.weight < .5 ? b.lower.id : b.upper.id,
			clamped: b.clamped,
			scale: b.scale,
			phase,
			touchdownSeconds: b.touchdown * b.unit,
			frameSeconds: b.frameStep * b.unit,
			tipAlong: tip[0] * speed,
			tipUp: tip[1] * speed,
			clearSeconds: b.clear * b.unit,
			collapseSeconds: b.collapse
		};
	}
	/** One profile point's place in a slice's profile, m (along, up), into `out`: as `profileAt` would place it. */
	pointAt(query, point, out) {
		const b = this.bracket(query);
		if (this.options.geometry === "bounded-C") {
			if (point === LANDMARK$1.lip) {
				const cap = this.analyticCap(query, b, this.analyticPoint, this.analyticClock(query, b).event);
				out[0] = cap[0];
				out[1] = cap[1];
				return;
			}
			if (point <= LANDMARK$1.crest || point >= LANDMARK$1.toe) {
				const carrier = Math.min(query.seconds / b.unit, b.touchdown);
				this.landmarkAt(b.lower, carrier, point, out);
				const x = Math.fround(out[0]), y = Math.fround(out[1]);
				if (b.upper !== b.lower) {
					this.landmarkAt(b.upper, carrier, point, out);
					out[0] = Math.fround(x + b.weight * (Math.fround(out[0]) - x));
					out[1] = Math.fround(y + b.weight * (Math.fround(out[1]) - y));
				} else {
					out[0] = x;
					out[1] = y;
				}
				out[0] = Math.fround(out[0] * b.scale);
				out[1] = Math.fround(out[1] * b.scale);
				return;
			}
			this.analyticAt(query, b, this.analyticPoint);
			out[0] = this.analyticPoint[2 * point];
			out[1] = this.analyticPoint[2 * point + 1];
			return;
		}
		const times = this.caseTimes(b, query.seconds / b.unit, query.hold);
		this.landmarkAt(b.lower, times[0], point, out);
		const x = out[0];
		const y = out[1];
		if (b.upper !== b.lower) {
			this.landmarkAt(b.upper, times[1], point, out);
			out[0] = x + b.weight * (out[0] - x);
			out[1] = y + b.weight * (out[1] - y);
		}
		out[0] *= b.scale;
		out[1] *= b.scale;
	}
	/** How `profileAt` would blend a slice's profile from its cases' frames (`FrameBlend`), into `into`. */
	frameBlend(query, into) {
		const b = this.bracket(query);
		const times = this.caseTimes(b, query.seconds / b.unit, query.hold);
		into.lower = b.lower;
		into.upper = b.upper;
		into.weight = b.weight;
		into.scale = b.scale;
		let position = this.framePosition(b.lower, times[0]);
		into.lowerFrame = Math.floor(position);
		into.lowerNext = Math.min(b.lower.frames.length / FLOATS$1 - 1, into.lowerFrame + 1);
		into.lowerShare = position - into.lowerFrame;
		position = this.framePosition(b.upper, times[1]);
		into.upperFrame = Math.floor(position);
		into.upperNext = Math.min(b.upper.frames.length / FLOATS$1 - 1, into.upperFrame + 1);
		into.upperShare = position - into.upperFrame;
		if (this.options.geometry === "bounded-C") {
			into.analyticProfile ??= new Float32Array(FLOATS$1);
			into.analytic = this.analyticAt(query, b, into.analyticProfile).analytic;
		} else {
			into.analyticProfile = void 0;
			into.analytic = void 0;
		}
		return into;
	}
	/** Where τ (√(h0/g)) falls among a case's frames, as `frameAt` places it: clamped to its first and last. */
	framePosition(c, tau) {
		return Math.min(c.frames.length / FLOATS$1 - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
	}
	/** A slice's scale and times, s, as `profileAt` finds them, without building its profile (the loft's refinement and budget). */
	profileTimes(query) {
		const b = this.bracket(query);
		if (this.options.geometry === "bounded-C") {
			const clock = this.analyticClock(query, b);
			return {
				scale: b.scale,
				clamped: b.clamped,
				touchdownSeconds: clock.impact * b.unit,
				frameSeconds: b.frameStep * b.unit,
				clearSeconds: clock.clear * b.unit,
				collapseSeconds: (clock.retired - clock.impact) * b.unit
			};
		}
		return {
			scale: b.scale,
			clamped: b.clamped,
			touchdownSeconds: b.touchdown * b.unit,
			frameSeconds: b.frameStep * b.unit,
			clearSeconds: b.clear * b.unit,
			collapseSeconds: b.collapse
		};
	}
	/** Raw authored case evidence only. Analytic query lifecycle/void comes from profileAt, not this per-case helper. */
	heldFrameOf(c) {
		return this.held.get(c) ?? heldFrame$1(c);
	}
	/** The cases a slice blends and by how much, and its scale, as `profileAt` blends and scales them (the crash's held overturn, PR 5). */
	caseBlend(query) {
		const b = this.bracket(query);
		return {
			lower: b.lower,
			upper: b.upper,
			weight: b.weight,
			scale: b.scale,
			clamped: b.clamped
		};
	}
	/** C incident-interpolation support only; it never changes an individual pocket's physical lifetime. */
	carrierRetirementBound(slope, a, b) {
		if (this.options.geometry !== "bounded-C") throw new Error("Carrier support requires the bounded C provider");
		const h0 = Math.fround(a.footHeight), h1 = Math.fround(b.footHeight);
		const d0 = Math.fround(a.footDepth), d1 = Math.fround(b.footDepth);
		if (![
			h0,
			h1,
			d0,
			d1
		].every((v) => Number.isFinite(v) && v > 0)) throw new Error("Invalid carrier support foot domain");
		let group = this.bySlope[0];
		for (const candidate of this.bySlope) if (Math.abs(candidate[0].slope - slope) < Math.abs(group[0].slope - slope)) group = candidate;
		const stops = [0, 1];
		for (const c of group) {
			const denominator = h1 - h0 - c.nonlinearity * (d1 - d0);
			if (denominator === 0) continue;
			const t = (c.nonlinearity * d0 - h0) / denominator;
			if (t > 0 && t < 1) stops.push(t);
		}
		stops.sort((x, y) => x - y);
		const probes = [...stops];
		for (let k = 0; k + 1 < stops.length; k += 1) probes.push((stops[k] + stops[k + 1]) / 2);
		let maxScale = 0, maxAuthoredTD = 0;
		for (const t of probes) {
			const q = this.bracket({
				slope,
				footHeight: h0 + t * (h1 - h0),
				footDepth: d0 + t * (d1 - d0)
			});
			maxScale = Math.max(maxScale, q.scale);
			maxAuthoredTD = Math.max(maxAuthoredTD, q.lower.touchdown, q.upper.touchdown);
		}
		const unit = carrierNextUp$1(Math.sqrt(carrierNextUp$1(carrierNextUp$1(maxScale) / GRAVITY$1)));
		const seconds = carrierNextUp$1(carrierNextUp$1(1.6 * carrierNextUp$1(maxAuthoredTD)) * unit);
		if (!Number.isFinite(seconds) || !(seconds > 0)) throw new Error("Nonfinite carrier support bound");
		return {
			seconds,
			maxScale,
			maxAuthoredTD,
			partitions: stops.length - 1
		};
	}
	/** The cases a slice blends (the nearest slope's two bracketing its A0), its scale (h0, m) and τ's unit, s. */
	bracket(query) {
		let group = this.bySlope[0];
		for (const candidate of this.bySlope) if (Math.abs(candidate[0].slope - query.slope) < Math.abs(group[0].slope - query.slope)) group = candidate;
		let clamped = Math.abs(group[0].slope - query.slope) > SLOPE_TOLERANCE$1 * query.slope;
		const a0 = query.footHeight / query.footDepth;
		let lower = group[0];
		let upper = group[group.length - 1];
		let weight = 0;
		if (a0 <= lower.nonlinearity) {
			clamped ||= a0 < lower.nonlinearity;
			upper = lower;
		} else if (a0 >= upper.nonlinearity) {
			clamped ||= a0 > upper.nonlinearity;
			lower = upper;
		} else for (let k = 0; k + 1 < group.length; k += 1) if (group[k].nonlinearity <= a0 && a0 <= group[k + 1].nonlinearity) {
			lower = group[k];
			upper = group[k + 1];
			weight = (a0 - lower.nonlinearity) / (upper.nonlinearity - lower.nonlinearity);
			break;
		}
		const scale = lower === upper ? query.footHeight / lower.nonlinearity : query.footDepth;
		const heldLower = this.heldFrameOf(lower);
		const heldUpper = this.heldFrameOf(upper);
		const voidHeight = (heldLower.voidHeight + weight * (heldUpper.voidHeight - heldLower.voidHeight)) * scale;
		const touchdown = lower.touchdown + weight * (upper.touchdown - lower.touchdown);
		return {
			lower,
			upper,
			weight,
			clamped,
			scale,
			unit: Math.sqrt(scale / GRAVITY$1),
			touchdown,
			frameStep: lower.tauStep + weight * (upper.tauStep - lower.tauStep),
			heldLower: heldLower.tau,
			heldUpper: heldUpper.tau,
			clear: Math.min(touchdown, Math.max(heldLower.tau, heldUpper.tau)),
			collapse: Math.sqrt(2 * voidHeight / GRAVITY$1)
		};
	}
	/** Phase-independent crest-relative reach, including analytic turns/cap and F32 parameter-blend rounding. */
	crestReachBounds(slope) {
		let group = this.bySlope[0];
		for (const candidate of this.bySlope) if (Math.abs(candidate[0].slope - slope) < Math.abs(group[0].slope - slope)) group = candidate;
		let low = 0, high = 0;
		for (const c of group) for (let offset = 0; offset < c.frames.length; offset += FLOATS$1) {
			const crest = c.frames[offset + 2 * LANDMARK$1.crest];
			for (let i = 0; i < 128; i++) {
				const x = c.frames[offset + 2 * i] - crest;
				low = Math.min(low, x);
				high = Math.max(high, x);
			}
			if (this.options.geometry === "bounded-C") {
				const W = c.frames[offset + 2 * LANDMARK$1.toe] - crest;
				const ulp = ulp32$1(Math.max(Math.abs(crest), Math.abs(c.frames[offset + 2 * LANDMARK$1.toe]), Math.abs(c.frames[offset + 2 * LANDMARK$1.crest + 1]), Math.abs(c.frames[offset + 2 * LANDMARK$1.toe + 1])));
				low = Math.min(low, -W - 76 * ulp);
				high = Math.max(high, 1.125 * W + 20 * ulp);
			}
		}
		return new Float64Array([low, high]);
	}
	/** Parameters blend before construction; all analytic hold modes share the same evolving geometry. */
	analyticParameters(query, b, out) {
		const tau = query.seconds / b.unit;
		const carrier = Math.min(tau, b.touchdown);
		const leafEnable = ease$1((b.touchdown - carrier) / b.frameStep);
		this.frameAt(b.lower, carrier, out);
		const lower = boundedCParameters$1(out, b.lower.touchdown, tau);
		lower.leafWidthDelta = leafEnable * carrierWidthDelta$1(b.lower, carrier);
		let parameters = lower;
		if (b.upper !== b.lower) {
			this.frameAt(b.upper, carrier, this.analyticOther);
			const upper = boundedCParameters$1(this.analyticOther, b.upper.touchdown, tau);
			upper.leafWidthDelta = leafEnable * carrierWidthDelta$1(b.upper, carrier);
			parameters = blendBoundedCParameters$1(lower, upper, b.weight);
			for (let i = 0; i < FLOATS$1; i++) out[i] += b.weight * (this.analyticOther[i] - out[i]);
		}
		return parameters;
	}
	analyticShape(query, b, out) {
		const parameters = this.analyticParameters(query, b, out);
		const clockKey = [
			query.slope,
			query.footHeight,
			query.footDepth
		].join(",");
		const meta = sampleBoundedC$1(parameters, out, false, this.analyticClocks.get(clockKey)?.event, true);
		meta.sharedSheet = pairInnerSheet$1(out, meta);
		meta.lengthScale = b.scale;
		meta.timeScale = b.unit;
		for (let i = 0; i < FLOATS$1; i++) out[i] *= b.scale;
		return meta;
	}
	/** Lifecycle uses the identical final carrier/parameter blend; it does not construct a full contour. */
	analyticClock(query, b) {
		const key = [
			query.slope,
			query.footHeight,
			query.footDepth
		].join(",");
		let clock = this.analyticClocks.get(key);
		if (!clock) {
			const final = boundedCLifecycle$1(this.analyticParameters({
				...query,
				seconds: b.touchdown * b.unit
			}, b, this.scratch));
			clock = {
				impact: final.impactTau,
				retired: final.retiredTau,
				clear: final.fullyFormedTau,
				event: final.impactEvent
			};
			if (this.analyticClocks.size >= 64) this.analyticClocks.delete(this.analyticClocks.keys().next().value);
			this.analyticClocks.set(key, clock);
		}
		return clock;
	}
	/** F32 stage order matches analyticShape: raw carrier, parameters, ND cap, then metric cap. */
	analyticCap(query, b, raw, event) {
		const cap = boundedCCap$1(this.analyticParameters(query, b, raw), event);
		return [Math.fround(cap[0] * b.scale), Math.fround(cap[1] * b.scale)];
	}
	analyticAt(query, b, out) {
		const key = [
			query.slope,
			query.footHeight,
			query.footDepth,
			query.seconds
		].join(",");
		const cached = this.analyticQueries.get(key);
		if (cached) {
			out.set(cached.profile);
			return cached.lookup;
		}
		const clock = this.analyticClock(query, b);
		const meta = this.analyticShape(query, b, out);
		meta.impactTau = clock.impact;
		meta.retiredTau = clock.retired;
		const dt = Math.max(1e-8, 1e-5 * b.touchdown * b.unit);
		const earlier = this.analyticCap({
			...query,
			seconds: query.seconds - dt
		}, b, this.analyticEarlier, clock.event);
		const later = this.analyticCap({
			...query,
			seconds: query.seconds + dt
		}, b, this.analyticLater, clock.event);
		const tipAlong = (later[0] - earlier[0]) / (2 * dt);
		const tipUp = (later[1] - earlier[1]) / (2 * dt);
		meta.capBoundaryVelocity = [tipAlong * b.unit / b.scale, tipUp * b.unit / b.scale];
		const phase = query.seconds < 0 ? "pre" : query.seconds <= meta.impactTau * b.unit ? "open" : "post";
		const lookup = {
			caseId: b.weight < .5 ? b.lower.id : b.upper.id,
			clamped: b.clamped,
			scale: b.scale,
			phase,
			touchdownSeconds: meta.impactTau * b.unit,
			frameSeconds: b.frameStep * b.unit,
			tipAlong,
			tipUp,
			clearSeconds: meta.fullyFormedTau * b.unit,
			collapseSeconds: (meta.retiredTau - meta.impactTau) * b.unit,
			analytic: meta
		};
		if (this.analyticQueries.size >= 64) this.analyticQueries.delete(this.analyticQueries.keys().next().value);
		this.analyticQueries.set(key, {
			profile: out.slice(),
			lookup
		});
		return lookup;
	}
	/**
	* Each blended case's τ for the slice's geometry and for its tip's velocity (lower, upper; then their tips), at the
	* slice's τ and hold (`ProfileQuery.hold`).
	*/
	caseTimes(b, tau, hold) {
		const times = this.times;
		const after = tau > b.touchdown;
		const shape = hold !== void 0 && after ? b.touchdown : tau;
		const contact = hold === "contact";
		times[0] = contact ? Math.min(shape, b.heldLower) : shape;
		times[1] = contact ? Math.min(shape, b.heldUpper) : shape;
		times[2] = after && hold !== void 0 ? times[0] : tau;
		times[3] = after && hold !== void 0 ? times[1] : tau;
		return times;
	}
	/** One case's profile point at τ (√(h0/g)), h0, into `out`, linear between frames as `frameAt`. */
	landmarkAt(c, tau, point, out) {
		const count = c.frames.length / FLOATS$1;
		const position = Math.min(count - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
		const f = Math.floor(position);
		const next = Math.min(count - 1, f + 1);
		const t = position - f;
		for (let k = 0; k < 2; k += 1) {
			const a = c.frames[f * FLOATS$1 + 2 * point + k];
			out[k] = a + t * (c.frames[next * FLOATS$1 + 2 * point + k] - a);
		}
	}
	/** One case's profile at τ (√(h0/g)), linear between its two nearest frames, clamped to its first and last. */
	frameAt(c, tau, out) {
		const count = c.frames.length / FLOATS$1;
		const position = Math.min(count - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
		const f = Math.floor(position);
		const next = Math.min(count - 1, f + 1);
		const t = position - f;
		for (let i = 0; i < FLOATS$1; i += 1) {
			const a = c.frames[f * FLOATS$1 + i];
			out[i] = a + t * (c.frames[next * FLOATS$1 + i] - a);
		}
	}
	/** One case's tip velocity at τ, √(g h0), linear between frames as `frameAt` (zero for a BRL1 case). */
	tipAt(c, tau, into) {
		into[0] = 0;
		into[1] = 0;
		if (!c.tipVelocity) return;
		const count = c.tipVelocity.length / 2;
		const position = Math.min(count - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
		const f = Math.floor(position);
		const next = Math.min(count - 1, f + 1);
		const t = position - f;
		into[0] = c.tipVelocity[2 * f] + t * (c.tipVelocity[2 * next] - c.tipVelocity[2 * f]);
		into[1] = c.tipVelocity[2 * f + 1] + t * (c.tipVelocity[2 * next + 1] - c.tipVelocity[2 * f + 1]);
	}
};
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/candidate/src/wave/barrel/boundedCProfile.ts
const KAPPA = 4 / 3 * Math.tan(Math.PI / 8);
/** Fractions of the actual crest-to-toe height, not the input foot crest height. */
const LIP_OPEN_HEIGHT = .6;
const LIP_FALL_HEIGHT = .8;
const add = (a, b) => [a[0] + b[0], a[1] + b[1]];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
const mul = (a, b) => [a[0] * b, a[1] * b];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1];
const cross = (a, b) => a[0] * b[1] - a[1] * b[0];
const norm = (a) => Math.hypot(...a);
const unit = (a) => {
	const n = norm(a);
	if (!n) throw Error("zero tangent");
	return mul(a, 1 / n);
};
const mix = (a, b, t) => add(mul(a, 1 - t), mul(b, t));
const round = (a) => [Math.fround(a[0]), Math.fround(a[1])];
const smooth = (x) => {
	x = Math.min(1, Math.max(0, x));
	return x * x * (3 - 2 * x);
};
function bezier(c, t) {
	const s = 1 - t;
	return add(add(mul(c[0], s * s * s), mul(c[1], 3 * s * s * t)), add(mul(c[2], 3 * s * t * t), mul(c[3], t * t * t)));
}
function derivative(c, t) {
	const s = 1 - t;
	return mul(add(add(mul(sub(c[1], c[0]), s * s), mul(sub(c[2], c[1]), 2 * s * t)), mul(sub(c[3], c[2]), t * t)), 3);
}
const at = (p, i) => [p[2 * i], p[2 * i + 1]];
function boundedCParameters(profile, authoredTD, tau) {
	return {
		crest: at(profile, 32),
		toe: at(profile, 112),
		incoming: sub(at(profile, 32), at(profile, 31)),
		outgoing: sub(at(profile, 113), at(profile, 112)),
		authoredTD,
		tau
	};
}
function blendBoundedCParameters(a, b, w) {
	return {
		crest: round(mix(a.crest, b.crest, w)),
		toe: round(mix(a.toe, b.toe, w)),
		incoming: round(mix(a.incoming, b.incoming, w)),
		outgoing: round(mix(a.outgoing, b.outgoing, w)),
		authoredTD: a.authoredTD + w * (b.authoredTD - a.authoredTD),
		tau: a.tau + w * (b.tau - a.tau),
		leafWidthDelta: (a.leafWidthDelta ?? 0) + w * ((b.leafWidthDelta ?? 0) - (a.leafWidthDelta ?? 0))
	};
}
/** Identity core with a C1 shoulder in the requested correction; the bound is the available leaf-reach room. */
function boundedLeafWidthDelta(delta, budget) {
	if (!Number.isFinite(delta) || !Number.isFinite(budget) || !(budget > 0)) throw Error("invalid leaf reach correction");
	const magnitude = Math.abs(delta), core = .6 * budget;
	if (magnitude <= core) return delta;
	const shoulder = .4 * budget, excess = magnitude - core;
	return Math.sign(delta) * Math.min(budget, core + shoulder * (excess / (shoulder + excess)));
}
function ordinary(z) {
	const A = z.crest, Toe = z.toe, ct = unit(z.incoming), tt = unit(z.outgoing), W = Toe[0] - A[0], H = A[1] - Toe[1];
	if (W <= 0 || H <= 0 || ct[0] <= 0 || tt[0] <= 0 || z.authoredTD <= 0) throw Error("invalid crest/toe domain");
	const chord = norm(sub(Toe, A)), ha = Math.min(chord / 3, W / (3 * ct[0])), ht = Math.min(chord / 3, W / (3 * tt[0]));
	const base = [
		A,
		add(A, mul(ct, ha)),
		sub(Toe, mul(tt, ht)),
		Toe
	], K0 = bezier(base, .5), d0 = unit(derivative(base, .5));
	const minimumLeafHeight = .4 * H;
	const B = Math.min(.06 * H, W / 16, .1 * Math.min((.85 * W) ** 2 / H, minimumLeafHeight ** 2 / (.85 * W)));
	const reachBudget = Math.min(B, .13 * W - 2 * B), leafWidthDelta = boundedLeafWidthDelta(z.leafWidthDelta ?? 0, reachBudget);
	return {
		A,
		Toe,
		ct,
		tt,
		W,
		H,
		base,
		K0,
		d0,
		ha0: ha / 2,
		he0: norm(derivative(base, .5)) / 6,
		ht0: ht / 2,
		B,
		leafWidthDelta
	};
}
function roof(o, g, s, T, post, remaining = 1) {
	const { A, Toe, W, H } = o, angle0 = Math.atan2(o.d0[1], o.d0[0]), angle = post ? -Math.PI / 2 * remaining : (1 - g) * angle0 - g * Math.PI / 2, v = [Math.cos(angle), Math.sin(angle)];
	const L = [Toe[0] - 2 * o.B - .02 * W + o.leafWidthDelta, Toe[1] + LIP_OPEN_HEIGHT * H - LIP_FALL_HEIGHT * H * s];
	let K = mix(o.K0, L, g);
	function controls(K) {
		const width = K[0] - A[0], height = A[1] - K[1];
		if (width <= 0 || height <= 0) throw Error("nonpositive leaf domain");
		let hs = (1 - g) * o.ha0 + g * KAPPA * width, he = (1 - g) * o.he0 + g * KAPPA * height;
		const advance = hs * o.ct[0] + he * Math.max(0, v[0]);
		if (advance > .85 * width) {
			hs *= .85 * width / advance;
			he *= .85 * width / advance;
		}
		return [
			A,
			add(A, mul(o.ct, hs)),
			sub(K, mul(v, he)),
			K
		];
	}
	if (post) {
		K = add(post, [T / 2, T / 2]);
		for (let i = 0; i < 16; i++) {
			const c = controls(K), prev = round(bezier(c, 27 / 28)), last = unit(sub(K, prev)), n = [-last[1], last[0]];
			K = add(add(post, [0, T / 2]), mul(n, T / 2));
		}
	}
	const c = controls(K), P = [A];
	for (let i = 1; i < 28; i++) P.push(round(bezier(c, i / 28)));
	P.push(K);
	const last = unit(sub(P[28], P[27]));
	return {
		P,
		c,
		last,
		n: [-last[1], last[0]]
	};
}
const eventCache = /* @__PURE__ */ new Map();
function event(o) {
	const key = [
		...o.A,
		...o.Toe,
		...o.ct,
		...o.tt,
		o.leafWidthDelta
	].join(",");
	const cached = eventCache.get(key);
	if (cached) return cached;
	const gap = (s) => {
		const { P, n } = roof(o, 1, s, o.B);
		return P[28][1] - o.B / 2 * (1 + n[1]) - o.Toe[1];
	};
	if (gap(0) <= 0 || gap(1) >= 0) throw Error("impact not bracketed");
	let lo = 0, hi = 1;
	for (let i = 0; i < 32; i++) {
		const m = (lo + hi) / 2;
		if (gap(m) > 0) lo = m;
		else hi = m;
	}
	const seal = (lo + hi) / 2, { P, n } = roof(o, 1, seal, o.B), cap = round([P[28][0] - o.B / 2 * n[0], o.Toe[1]]);
	lo = 0;
	hi = 1;
	for (let i = 0; i < 32; i++) {
		const m = (lo + hi) / 2;
		if (smooth(m) < seal) lo = m;
		else hi = m;
	}
	const result = {
		seal,
		cap,
		fraction: (lo + hi) / 2
	};
	if (eventCache.size >= 128) eventCache.delete(eventCache.keys().next().value);
	eventCache.set(key, result);
	return result;
}
function tail(A, B, u, v, h0 = norm(sub(B, A)) / 3, h1 = norm(sub(B, A)) / 3) {
	const dx = B[0] - A[0];
	if (dx < 0) throw Error("backward tail");
	if (u[0] > 0) h0 = Math.min(h0, dx / (3 * u[0]));
	if (v[0] > 0) h1 = Math.min(h1, dx / (3 * v[0]));
	return [
		A,
		add(A, mul(u, h0)),
		sub(B, mul(v, h1)),
		B
	];
}
function arcSample(points, count) {
	const lengths = [0];
	for (let i = 1; i < points.length; i++) lengths.push(lengths[i - 1] + norm(sub(points[i], points[i - 1])));
	const total = lengths.at(-1);
	const out = [];
	let j = 0;
	for (let i = 0; i <= count; i++) {
		const d = total * i / count;
		while (j + 1 < lengths.length - 1 && lengths[j + 1] < d) j++;
		const span = lengths[j + 1] - lengths[j];
		out.push(span ? mix(points[j], points[j + 1], (d - lengths[j]) / span) : points[j]);
	}
	return out;
}
function raySegment(O, d, P, Q) {
	const e = sub(Q, P), den = cross(d, e);
	if (Math.abs(den) < 1e-18) return Infinity;
	const a = sub(P, O), r = cross(a, e) / den, t = cross(a, d) / den;
	return r > 0 && t >= 0 && t <= 1 ? r : Infinity;
}
function roots(a, b, c) {
	if (Math.abs(a) < 1e-18) return Math.abs(b) > 1e-18 && -c / b > 0 ? [-c / b] : [];
	const disc = b * b - 4 * a * c;
	if (disc < 0) return [];
	const d = Math.sqrt(disc);
	return [(-b - d) / (2 * a), (-b + d) / (2 * a)].filter((r) => r > 0);
}
function rotate(a, t) {
	return [a[0] * Math.cos(t) - a[1] * Math.sin(t), a[0] * Math.sin(t) + a[1] * Math.cos(t)];
}
function angleWithin(rad, r0, span) {
	let a = Math.atan2(cross(r0, rad), dot(r0, rad));
	if (a < 0) a += 2 * Math.PI;
	return a <= span + 1e-12 || Math.abs(a - 2 * Math.PI) < 1e-12;
}
function arcBound(O, c, r0, span, P, Q) {
	if (!span) return Infinity;
	const candidates = [], e = sub(Q, P), ee = dot(e, e);
	for (const X of [P, Q]) {
		const x = sub(X, O);
		for (const R of roots(dot(c, c) - 1, -2 * dot(c, x), dot(x, x))) if (angleWithin(sub(mul(x, 1 / R), c), r0, span)) candidates.push(R);
	}
	if (ee > 0) {
		const n = mul([-e[1], e[0]], 1 / Math.sqrt(ee)), d = dot(n, sub(O, P)), nc = dot(n, c);
		for (const sign of [-1, 1]) {
			const den = nc - sign;
			if (Math.abs(den) > 1e-18) {
				const R = -d / den;
				if (R > 0) {
					const centre = add(O, mul(c, R)), X = sub(centre, mul(n, sign * R)), t = dot(sub(X, P), e) / ee;
					if (t >= 0 && t <= 1 && angleWithin(mul(sub(X, centre), 1 / R), r0, span)) candidates.push(R);
				}
			}
		}
	}
	for (const rad of [r0, rotate(r0, span)]) candidates.push(raySegment(O, add(c, rad), P, Q));
	return Math.min(Infinity, ...candidates);
}
function faceBound(J, O, dU, cV, P, Q) {
	const candidates = [raySegment(J, dU, P, Q), raySegment(O, cV, P, Q)];
	if (Math.abs(dU[0]) > 1e-18) for (const X of [P, Q]) {
		const R = (X[0] - J[0]) / dU[0];
		if (R > 0) {
			const U = add(J, mul(dU, R));
			if (add(O, mul(cV, R))[1] <= X[1] && X[1] <= U[1]) candidates.push(R);
		}
	}
	return Math.min(...candidates);
}
function root(J, vr, angle, qC, yC, T, P, V, bulk, sharedCrest, preservedCarrierStart = 0) {
	const slope = Math.tan(angle), u = mul(vr, -1);
	let beta = Math.atan2(u[1], u[0]);
	if (beta < 0) beta += 2 * Math.PI;
	const spanU = 3 * Math.PI / 2 - beta, spanL = Math.PI / 2 + angle;
	if (spanU < 0 || spanL < 0) throw Error("root turn domain");
	const dU = [Math.sin(3 * Math.PI / 2) - Math.sin(beta), -Math.cos(3 * Math.PI / 2) + Math.cos(beta)], dL = [Math.sin(2 * Math.PI + angle) + 1, -Math.cos(2 * Math.PI + angle)], N = J[1] - yC - slope * (J[0] - qC), coef = dU[1] + dL[1] - slope * (dU[0] + dL[0]), O = add(J, [0, -N]), cU = [-u[1], u[0]], cV = add(dU, [0, -coef]), cL = add(cV, [1, 0]);
	if (N <= 0) throw Error("nonpositive root depth");
	let R = Math.min(4 * T, coef < 0 ? N / -coef : Infinity);
	const domainReach = 1 + Math.sin(beta), domainRadius = sharedCrest !== void 0 && domainReach > 0 ? (J[0] - sharedCrest) / domainReach : Infinity;
	R = Math.min(R, domainRadius);
	const guards = [];
	for (let i = 0; i < 28; i++) {
		const n = [-V[i][1], V[i][0]];
		guards.push([sub(P[i], mul(n, T / 2)), sub(P[i + 1], mul(n, T / 2))]);
	}
	for (let i = preservedCarrierStart; i < 32; i++) guards.push([add(at(bulk, i), [0, -T / 2]), add(at(bulk, i + 1), [0, -T / 2])]);
	for (const [a, b] of guards) R = Math.min(R, arcBound(J, cU, mul(cU, -1), spanU, a, b), arcBound(O, cL, [-1, 0], spanL, a, b), faceBound(J, O, dU, cV, a, b));
	if (!Number.isFinite(R) || R < T / 2) throw Error("root thickness domain");
	const D = N + R * coef;
	if (D < -1e-12) throw Error("negative root face");
	const U = add(J, mul(dU, R));
	if (sharedCrest !== void 0 && R === domainRadius) U[0] = sharedCrest;
	const V0 = add(U, [0, -D]), E = add(V0, mul(dL, R)), points = [J];
	for (let i = 1; i <= 8; i++) points.push(i === 8 && sharedCrest !== void 0 ? U : add(J, mul([Math.sin(beta + spanU * i / 8) - Math.sin(beta), -Math.cos(beta + spanU * i / 8) + Math.cos(beta)], R)));
	for (let i = 1; i <= 4; i++) points.push(mix(U, V0, i / 4));
	for (let i = 1; i <= 4; i++) {
		const a = 3 * Math.PI / 2 + spanL * i / 4;
		points.push(add(V0, mul([Math.sin(a) + 1, -Math.cos(a)], R)));
	}
	return {
		points,
		E,
		R,
		D,
		domainRadius
	};
}
function ulp32(v) {
	const f = new Float32Array([v]), u = new Uint32Array(f.buffer);
	u[0]++;
	return f[0] - Math.fround(v);
}
/** Exact event arithmetic only: clocks do not require the inner sheet, bounded root or floor contour. */
function boundedCLifecycle(z) {
	const ev = event(ordinary(z)), TD = z.authoredTD, impact = TD + .3 * TD * ev.fraction;
	return {
		impactEvent: ev,
		impactTau: impact,
		retiredTau: impact + .3 * TD,
		fullyFormedTau: .4 * TD
	};
}
function boundedCCap(z, lifecycle, trace) {
	const o = ordinary(z), ev = lifecycle ?? event(o), TD = z.authoredTD, impact = TD + .3 * TD * ev.fraction, post = z.tau >= impact;
	const g = smooth(z.tau / (.4 * TD)), remaining = post ? 1 - smooth((z.tau - impact) / (.3 * TD)) : 1, s = post ? ev.seal : smooth((z.tau - TD) / (.3 * TD));
	const ulp = ulp32(Math.max(...z.crest.map(Math.abs), ...z.toe.map(Math.abs))), requested = o.B * (post ? remaining ** 2 : g * g), loopScale = post ? Math.min(remaining * o.W, remaining ** 2 * o.H) : Math.min(g * o.W, g * o.H), collapsed = requested < 8 * ulp || loopScale <= 64 * ulp, T = collapsed ? 0 : Math.max(requested, 8 * ulp);
	const roofSample = roof(o, post ? 1 : g, s, T, post ? ev.cap : void 0, remaining), { P, last } = roofSample;
	if (trace) Object.assign(trace, {
		parameters: z,
		ordinary: o,
		impactTau: impact,
		post,
		formation: g,
		remaining,
		seal: s,
		ulp,
		requestedThickness: requested,
		loopScale,
		collapsed,
		thickness: T,
		roofControls: roofSample.c,
		roofPoints: P,
		last
	});
	if (collapsed) {
		const result = round(P[28]);
		if (trace) Object.assign(trace, {
			normal: null,
			phi: null,
			unroundedCap: P[28],
			capWords: result
		});
		return result;
	}
	const n = [-last[1], last[0]], centre = sub(P[28], mul(n, T / 2));
	let phi = Math.atan2(-last[1], -n[1]);
	if (phi < 0) phi += 2 * Math.PI;
	if (!(phi > 0 && phi <= Math.PI)) throw Error("cap minimum domain");
	const a = phi * 4 / 4, cap = add(centre, mul(add(mul(n, Math.cos(a)), mul(last, Math.sin(a))), T / 2));
	const unrounded = post ? ev.cap : cap, result = round(unrounded);
	if (trace) Object.assign(trace, {
		normal: n,
		phi,
		unroundedCap: unrounded,
		capWords: result
	});
	return result;
}
/** Writes only owned33..111. Domain failures throw; caller may explicitly choose raw library mode, never silently fall back. */
function sampleBoundedC(z, profile, velocity = true, lifecycle, sharedRootDomain = false, preservedCarrierStart = 0) {
	const o = ordinary(z), ev = lifecycle ?? event(o), TD = z.authoredTD, impact = TD + .3 * TD * ev.fraction, retired = impact + .3 * TD, post = z.tau >= impact;
	const g = smooth(z.tau / (.4 * TD)), remaining = post ? 1 - smooth((z.tau - impact) / (.3 * TD)) : 1, s = post ? ev.seal : smooth((z.tau - TD) / (.3 * TD));
	const ulp = ulp32(Math.max(...z.crest.map(Math.abs), ...z.toe.map(Math.abs))), requested = o.B * (post ? remaining ** 2 : g * g), loopScale = post ? Math.min(remaining * o.W, remaining ** 2 * o.H) : Math.min(g * o.W, g * o.H), collapsed = requested < 8 * ulp || loopScale <= 64 * ulp, activeG = g, activeRemain = remaining, T = collapsed ? 0 : Math.max(requested, 8 * ulp);
	const { P, c: currentRoof, last } = roof(o, post ? 1 : activeG, s, T, post ? ev.cap : void 0, activeRemain), target = Array.from({ length: 113 }, () => [0, 0]);
	for (let i = 0; i <= 28; i++) target[32 + i] = P[i];
	let R = 0, D = 0, envelopeBound = 0, connectorLength = 0, domainRadius;
	const envelopeBudget = .001 * Math.max(o.W, o.H);
	if (collapsed) {
		const K = P[28], angle = post ? 0 : (1 - g) * Math.atan2(o.d0[1], o.d0[0]), pv = [Math.cos(angle), Math.sin(angle)], slope = Math.tan(angle), yC = post ? o.Toe[1] : (1 - g) * o.K0[1] + g * o.Toe[1], C = [K[0], yC];
		if (C[1] > K[1]) throw Error("zero sheet connector not descending");
		const chord = norm(sub(o.Toe, C)), h0 = (1 - g) * o.he0 + g * chord / 3, h1 = (1 - g) * o.ht0 + g * chord / 3, fc = tail(C, o.Toe, pv, o.tt, h0, h1);
		connectorLength = K[1] - C[1];
		for (let i = 61; i <= 68; i++) target[i] = K;
		for (let i = 69; i <= 106; i++) target[i] = [K[0], K[1] + (C[1] - K[1]) * (i - 68) / 38];
		for (let i = 107; i <= 112; i++) target[i] = bezier(fc, (i - 106) / 6);
		const referenceT = Math.max(requested, 8 * ulp), reference = post ? roof(o, 1, s, referenceT, ev.cap, remaining) : {
			P,
			c: currentRoof
		}, F1 = [reference.P[28][0] - referenceT / 2 + referenceT, yC + slope * referenceT], refChord = norm(sub(o.Toe, F1)), refFloor = tail(F1, o.Toe, pv, o.tt, (1 - g) * o.he0 + g * refChord / 3, (1 - g) * o.ht0 + g * refChord / 3);
		envelopeBound = Math.max(...currentRoof.map((p, i) => norm(sub(p, reference.c[i]))), ...fc.map((p, i) => norm(sub(p, refFloor[i]))));
		if (requested > 0 && envelopeBound > envelopeBudget) throw Error("precision collapse spatial budget");
	} else {
		const V = P.slice(1).map((b, i) => unit(sub(b, P[i]))), N = V.map((v) => [-v[1], v[0]]), offset = [mul(N[0], -1)];
		for (let i = 1; i < 28; i++) {
			const den = 1 + dot(N[i - 1], N[i]);
			if (den <= 0) throw Error("opposite normals");
			offset.push(mul(add(N[i - 1], N[i]), -1 / den));
		}
		offset.push(mul(N[27], -1));
		const Q = P.map((p, i) => add(p, mul(offset[i], T)));
		for (let i = 0; i < 28; i++) {
			if (norm(sub(Q[i + 1], Q[i])) / norm(sub(P[i + 1], P[i])) < .75) throw Error("offset curvature budget");
			if (Q[i + 1][0] <= Q[i][0]) throw Error("backward offset sheet");
		}
		const factor = post ? activeRemain : activeG, qJ = (1 - factor) * Q[28][0] + factor * (o.A[0] + .28 * o.W);
		if (!(Q[0][0] <= qJ && qJ < Q[28][0])) throw Error("root cut outside sheet");
		let e = 0;
		while (!(Q[e][0] <= qJ && qJ <= Q[e + 1][0])) e++;
		const J = mix(Q[e], Q[e + 1], (qJ - Q[e][0]) / (Q[e + 1][0] - Q[e][0])), chain = [Q[28]];
		for (let i = 27; i > e; i--) chain.push(Q[i]);
		chain.push(J);
		const inner = arcSample(chain, 12), centre = sub(P[28], mul(N[27], T / 2));
		let phi = Math.atan2(-V[27][1], -N[27][1]);
		if (phi < 0) phi += 2 * Math.PI;
		if (!(phi > 0 && phi <= Math.PI)) throw Error("cap minimum domain");
		for (let i = 61; i <= 68; i++) {
			const a = i <= 64 ? phi * (i - 60) / 4 : phi + (Math.PI - phi) * (i - 64) / 4;
			target[i] = add(centre, mul(add(mul(N[27], Math.cos(a)), mul(V[27], Math.sin(a))), T / 2));
		}
		target[68] = Q[28];
		if (post) target[64] = ev.cap;
		for (let i = 69; i <= 80; i++) target[i] = inner[i - 68];
		const angle = post ? 0 : (1 - activeG) * Math.atan2(o.d0[1], o.d0[0]), pv = [Math.cos(angle), Math.sin(angle)], slope = pv[1] / pv[0], qC = P[28][0] - T / 2, yC = post ? o.Toe[1] : (1 - activeG) * o.K0[1] + activeG * o.Toe[1], rr = root(J, V[e], angle, qC, yC, T, P, V, profile, sharedRootDomain ? o.A[0] : void 0, preservedCarrierStart);
		R = rr.R;
		D = rr.D;
		if (sharedRootDomain) domainRadius = rr.domainRadius;
		for (let i = 0; i <= 16; i++) target[80 + i] = rr.points[i];
		const F0 = [qC - T, yC - slope * T], F1 = [qC + T, yC + slope * T];
		if (!(rr.E[0] <= F0[0] && F0[0] < F1[0] && F1[0] < o.Toe[0])) throw Error("floor plateau domain");
		const chord = norm(sub(o.Toe, F1)), h0 = (1 - activeG) * o.he0 + activeG * chord / 3, h1 = (1 - activeG) * o.ht0 + activeG * chord / 3, fc = tail(F1, o.Toe, pv, o.tt, h0, h1);
		for (let i = 97; i <= 102; i++) target[i] = mix(rr.E, F0, (i - 96) / 6);
		for (let i = 103; i <= 106; i++) target[i] = mix(F0, F1, (i - 102) / 4);
		for (let i = 107; i <= 112; i++) target[i] = bezier(fc, (i - 106) / 6);
	}
	for (let i = 33; i < 112; i++) {
		profile[2 * i] = target[i][0];
		profile[2 * i + 1] = target[i][1];
		if (!Number.isFinite(profile[2 * i] + profile[2 * i + 1])) throw Error("nonfinite profile");
	}
	const cap = at(profile, 64), flow = Math.sqrt(2 * o.H), meta = {
		model: "bounded-analytic-C/v4",
		impactEvent: ev,
		lengthScale: 1,
		timeScale: 1,
		formation: g,
		remaining,
		seal: s,
		authoredSealTau: TD,
		impactTau: impact,
		retiredTau: retired,
		fullyFormedTau: .4 * TD,
		sheetExists: !collapsed,
		precisionCollapsed: collapsed && requested > 0,
		thickness: T,
		requestedThickness: requested,
		cap,
		impactCap: ev.cap,
		rootRadius: R,
		rootVerticalLeg: D,
		precisionEnvelopeBound: envelopeBound,
		precisionEnvelopeBudget: envelopeBudget,
		collapsedConnectorLength: connectorLength,
		capBoundaryVelocity: [0, 0],
		fluidAlong: post ? 0 : last[0] * flow,
		fluidUp: post ? -flow : last[1] * flow,
		partRanges: {
			outer: [32, 60],
			cap: [60, 68],
			inner: [68, 80],
			upperRoot: [80, 88],
			face: [88, 92],
			lowerRoot: [92, 96],
			floor: [96, 112]
		}
	};
	meta.rootRadiusMaximumFromSheetDomain = domainRadius;
	if (velocity) {
		const dt = 1e-5 * TD, a = profile.slice(), b = profile.slice();
		sampleBoundedC({
			...z,
			tau: z.tau - dt
		}, a, false, lifecycle, sharedRootDomain, preservedCarrierStart);
		sampleBoundedC({
			...z,
			tau: z.tau + dt
		}, b, false, lifecycle, sharedRootDomain, preservedCarrierStart);
		meta.capBoundaryVelocity = [(b[128] - a[128]) / (2 * dt), (b[129] - a[129]) / (2 * dt)];
	}
	return meta;
}
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/candidate/src/wave/barrel/sharedUpperRoot.ts
/** Height of the original forward polygon, explicitly completing a quantized vertical facet with its highest endpoint. */
function roofHeight(profile, x) {
	let y = -Infinity;
	for (let i = 32; i < 60; i += 1) {
		const a = profile[2 * i], b = profile[2 * (i + 1)];
		if (b < a) throw new Error("shared upper-root backward roof domain");
		if (x < a || x > b) continue;
		const ay = profile[2 * i + 1], by = profile[2 * (i + 1) + 1];
		y = Math.max(y, a === b ? Math.max(ay, by) : ay + (by - ay) * ((x - a) / (b - a)));
	}
	if (!Number.isFinite(y)) throw new Error("shared upper-root missing roof crossing");
	return y;
}
/** Exact vertical graph difference on the overlapping domain, at the union of both polygons' breakpoints. */
function roofEnvelopeDifference(a, b) {
	const left = Math.max(a[64], b[64]), right = Math.min(a[120], b[120]);
	if (left > right) throw new Error("roof envelope lacks common domain");
	let maximum = 0;
	const xs = [left, right];
	for (const p of [a, b]) for (let i = 32; i <= 60; i += 1) if (p[2 * i] >= left && p[2 * i] <= right) xs.push(p[2 * i]);
	for (const x of xs) maximum = Math.max(maximum, Math.abs(roofHeight(a, x) - roofHeight(b, x)));
	return maximum;
}
/**
* New sampling authority for the complete inner-sheet seam, not a change to v4's controls.
* Unsupported actual domains fail explicitly. Only outer33..59 is resampled, in both resolved and collapsed states so the precision gate cannot switch sampling authorities.
*/
function pairInnerSheet(profile, _meta) {
	const original = profile.slice();
	const left = original[176], right = original[136];
	const a = original[64], k = original[120];
	if (!(a <= left && left <= right && right <= k)) throw new Error("shared upper-root lacks complete outer roof domain");
	for (let i = 68; i < 88; i += 1) if (original[2 * i] < original[2 * (i + 1)]) throw new Error("shared upper-root backward return domain");
	const sample = (i, x) => {
		profile[2 * i] = x;
		profile[2 * i + 1] = roofHeight(original, profile[2 * i]);
	};
	for (let i = 33; i < 38; i += 1) sample(i, a + (left - a) * ((i - 32) / 6));
	let coalescedStations = 0;
	for (let i = 38; i <= 58; i += 1) {
		const j = 126 - i;
		sample(i, original[2 * j]);
		if (profile[2 * i + 1] < original[2 * j + 1]) throw new Error("shared upper-root negative paired separation");
		if (i > 38 && profile[2 * i] === profile[2 * (i - 1)]) coalescedStations += 1;
	}
	sample(59, right + (k - right) / 2);
	return {
		top: [38, 58],
		underside: [68, 88],
		maximumRoofEnvelopeChange: roofEnvelopeDifference(original, profile),
		coalescedStations
	};
}
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/candidate/src/wave/dispersion.ts
/** Linear (Airy) water-wave dispersion, ω² = g k tanh(kh), in SI units. */
const GRAVITY = 9.81;
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/candidate/src/wave/barrel/ProfileLibrary.ts
let carrierRounding;
function carrierNextUp(value) {
	if (!Number.isFinite(value) || value < 0) throw new Error("Invalid positive carrier bound");
	carrierRounding ??= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	carrierRounding.setFloat64(0, value);
	const low = carrierRounding.getUint32(4);
	carrierRounding.setUint32(4, low === 4294967295 ? 0 : low + 1);
	if (low === 4294967295) carrierRounding.setUint32(0, carrierRounding.getUint32(0) + 1);
	return carrierRounding.getFloat64(0);
}
const LANDMARK = {
	back: 0,
	crest: 32,
	lip: 64,
	throat: 88,
	toe: 112,
	front: 127
};
/**
* The contact's held frame (the advisor, 2026-09-30): the jet off the face and the void open, each by `gap`, h0: 2 cells
* at level 12 on the runs' 48 h0 domain (tools/basilisk/run_padang.sh; the periodic run's cells are 64/4096 h0).
*/
const CLEAR = { gap: 96 / 4096 };
const FLOATS = 256;
const ease = (value) => {
	const t = Math.max(0, Math.min(1, value));
	return t * t * (3 - 2 * t);
};
function carrierWidthDelta(c, tau, trace) {
	const count = c.frames.length / FLOATS;
	if (count < 3) {
		if (trace) Object.assign(trace, {
			position: null,
			enabled: 0,
			rawWidth: null,
			meanWidth: null,
			adjustment: 0
		});
		return 0;
	}
	const position = Math.max(0, Math.min(count - 1, (tau - c.tauStart) / c.tauStep));
	const enabled = ease(position - 1) * ease(count - 2 - position);
	if (enabled === 0) {
		if (trace) Object.assign(trace, {
			position,
			enabled,
			rawWidth: null,
			meanWidth: null,
			adjustment: 0
		});
		return 0;
	}
	const width = (frame) => c.frames[frame * FLOATS + 2 * LANDMARK.toe] - c.frames[frame * FLOATS + 2 * LANDMARK.crest];
	const frame = Math.floor(position), share = position - frame;
	const raw = width(frame) + share * (width(frame + 1) - width(frame));
	const high = position + 1;
	let low = position - 1, interval = Math.floor(low), area = 0;
	while (low < high) {
		const end = Math.min(high, interval + 1), a = width(interval), slope = width(interval + 1) - a;
		area += (end - low) * (2 * a + slope * (low + end - 2 * interval)) / 2;
		low = end;
		interval += 1;
	}
	const adjustment = enabled * (area / 2 - raw);
	if (trace) Object.assign(trace, {
		position,
		enabled,
		rawWidth: raw,
		meanWidth: area / 2,
		adjustment
	});
	return adjustment;
}
/** A slice whose slope is this far (relative) from every case's is outside the library. */
const SLOPE_TOLERANCE = .2;
/**
* The highest point of frame f's lower surface (the face and on, from the throat to the front end) under (x, y), h0;
* NaN where none lies under it.
*/
function surfaceBeneath(frames, f, x, y) {
	const o = f * FLOATS;
	let best = NaN;
	for (let i = LANDMARK.throat; i < LANDMARK.front; i += 1) {
		const x0 = frames[o + 2 * i];
		const x1 = frames[o + 2 * i + 2];
		if (x0 === x1 || (x0 - x) * (x1 - x) > 0) continue;
		const y0 = frames[o + 2 * i + 1];
		const under = y0 + (x - x0) / (x1 - x0) * (frames[o + 2 * i + 3] - y0);
		if (under < y && !(under <= best)) best = under;
	}
	return best;
}
/** Frame f's void height, h0: the most its underside (tip to throat) stands over the lower surface beneath it. */
function voidHeightAt(frames, f) {
	const o = f * FLOATS;
	let height = 0;
	for (let i = LANDMARK.lip; i <= LANDMARK.throat; i += 1) {
		const y = frames[o + 2 * i + 1];
		const gap = y - surfaceBeneath(frames, f, frames[o + 2 * i], y);
		if (gap > height) height = gap;
	}
	return height;
}
/**
* A case's held frame (the advisor, 2026-09-30): the last frame, at or before one frame before touchdown, whose tip
* stands `CLEAR.gap` over the lower surface beneath it (the jet off the face) and `CLEAR.gap` ahead of its throat (the
* void open, not collapsed onto the face as pad19-a30-l12's last two frames are); its void's height there. With none
* such, the frame before touchdown, unclear.
*/
function heldFrame(c) {
	const count = c.frames.length / FLOATS;
	const last = Math.min(count - 1, Math.floor((c.touchdown - c.tauStart) / c.tauStep + 1e-6) - 1);
	for (let f = last; f >= 0; f -= 1) {
		const o = f * FLOATS;
		const tipX = c.frames[o + 2 * LANDMARK.lip];
		const tipY = c.frames[o + 2 * LANDMARK.lip + 1];
		if (tipX - c.frames[o + 2 * LANDMARK.throat] < CLEAR.gap) continue;
		if (!(tipY - surfaceBeneath(c.frames, f, tipX, tipY) >= CLEAR.gap)) continue;
		return {
			tau: c.tauStart + f * c.tauStep,
			voidHeight: voidHeightAt(c.frames, f),
			clear: true
		};
	}
	const f = Math.max(0, last);
	return {
		tau: c.tauStart + f * c.tauStep,
		voidHeight: voidHeightAt(c.frames, f),
		clear: false
	};
}
var ProfileLibrary = class {
	cases;
	options;
	bySlope;
	held = /* @__PURE__ */ new Map();
	scratch = new Float32Array(FLOATS);
	tipLower = /* @__PURE__ */ new Float64Array(2);
	tipUpper = /* @__PURE__ */ new Float64Array(2);
	times = /* @__PURE__ */ new Float64Array(4);
	analyticPoint = new Float32Array(FLOATS);
	analyticOther = new Float32Array(FLOATS);
	analyticEarlier = new Float32Array(FLOATS);
	analyticLater = new Float32Array(FLOATS);
	analyticQueries = /* @__PURE__ */ new Map();
	analyticClocks = /* @__PURE__ */ new Map();
	constructor(cases, options = {}) {
		this.cases = cases;
		this.options = options;
		const groups = /* @__PURE__ */ new Map();
		for (const c of cases) groups.set(c.slope, [...groups.get(c.slope) ?? [], c]);
		this.bySlope = [...groups.values()].map((group) => [...group].sort((a, b) => a.nonlinearity - b.nonlinearity));
		for (const c of cases) this.held.set(c, heldFrame(c));
	}
	/** The profile for a slice, in metres, into `out` (PROFILE_POINTS (x, y) pairs). */
	profileAt(query, out) {
		const b = this.bracket(query);
		if (this.options.geometry === "bounded-C") return this.analyticAt(query, b, out);
		const tau = query.seconds / b.unit;
		const times = this.caseTimes(b, tau, query.hold);
		this.frameAt(b.lower, times[0], out);
		if (b.upper !== b.lower) {
			this.frameAt(b.upper, times[1], this.scratch);
			for (let i = 0; i < FLOATS; i += 1) out[i] += b.weight * (this.scratch[i] - out[i]);
		}
		for (let i = 0; i < FLOATS; i += 1) out[i] *= b.scale;
		const tip = this.tipLower;
		this.tipAt(b.lower, times[2], tip);
		if (b.upper !== b.lower) {
			this.tipAt(b.upper, times[3], this.tipUpper);
			tip[0] += b.weight * (this.tipUpper[0] - tip[0]);
			tip[1] += b.weight * (this.tipUpper[1] - tip[1]);
		}
		const speed = b.scale / b.unit;
		const phase = tau < 0 ? "pre" : tau <= b.touchdown ? "open" : "post";
		return {
			caseId: b.weight < .5 ? b.lower.id : b.upper.id,
			clamped: b.clamped,
			scale: b.scale,
			phase,
			touchdownSeconds: b.touchdown * b.unit,
			frameSeconds: b.frameStep * b.unit,
			tipAlong: tip[0] * speed,
			tipUp: tip[1] * speed,
			clearSeconds: b.clear * b.unit,
			collapseSeconds: b.collapse
		};
	}
	/** One profile point's place in a slice's profile, m (along, up), into `out`: as `profileAt` would place it. */
	pointAt(query, point, out) {
		const b = this.bracket(query);
		if (this.options.geometry === "bounded-C") {
			if (point === LANDMARK.lip) {
				const cap = this.analyticCap(query, b, this.analyticPoint, this.analyticClock(query, b).event);
				out[0] = cap[0];
				out[1] = cap[1];
				return;
			}
			if (point <= LANDMARK.crest || point >= LANDMARK.toe) {
				const carrier = Math.min(query.seconds / b.unit, b.touchdown);
				this.landmarkAt(b.lower, carrier, point, out);
				const x = Math.fround(out[0]), y = Math.fround(out[1]);
				if (b.upper !== b.lower) {
					this.landmarkAt(b.upper, carrier, point, out);
					out[0] = Math.fround(x + b.weight * (Math.fround(out[0]) - x));
					out[1] = Math.fround(y + b.weight * (Math.fround(out[1]) - y));
				} else {
					out[0] = x;
					out[1] = y;
				}
				out[0] = Math.fround(out[0] * b.scale);
				out[1] = Math.fround(out[1] * b.scale);
				return;
			}
			this.analyticAt(query, b, this.analyticPoint);
			out[0] = this.analyticPoint[2 * point];
			out[1] = this.analyticPoint[2 * point + 1];
			return;
		}
		const times = this.caseTimes(b, query.seconds / b.unit, query.hold);
		this.landmarkAt(b.lower, times[0], point, out);
		const x = out[0];
		const y = out[1];
		if (b.upper !== b.lower) {
			this.landmarkAt(b.upper, times[1], point, out);
			out[0] = x + b.weight * (out[0] - x);
			out[1] = y + b.weight * (out[1] - y);
		}
		out[0] *= b.scale;
		out[1] *= b.scale;
	}
	/** How `profileAt` would blend a slice's profile from its cases' frames (`FrameBlend`), into `into`. */
	frameBlend(query, into) {
		const b = this.bracket(query);
		const times = this.caseTimes(b, query.seconds / b.unit, query.hold);
		into.lower = b.lower;
		into.upper = b.upper;
		into.weight = b.weight;
		into.scale = b.scale;
		let position = this.framePosition(b.lower, times[0]);
		into.lowerFrame = Math.floor(position);
		into.lowerNext = Math.min(b.lower.frames.length / FLOATS - 1, into.lowerFrame + 1);
		into.lowerShare = position - into.lowerFrame;
		position = this.framePosition(b.upper, times[1]);
		into.upperFrame = Math.floor(position);
		into.upperNext = Math.min(b.upper.frames.length / FLOATS - 1, into.upperFrame + 1);
		into.upperShare = position - into.upperFrame;
		if (this.options.geometry === "bounded-C") {
			into.analyticProfile ??= new Float32Array(FLOATS);
			into.analytic = this.analyticAt(query, b, into.analyticProfile).analytic;
		} else {
			into.analyticProfile = void 0;
			into.analytic = void 0;
		}
		return into;
	}
	/** Where τ (√(h0/g)) falls among a case's frames, as `frameAt` places it: clamped to its first and last. */
	framePosition(c, tau) {
		return Math.min(c.frames.length / FLOATS - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
	}
	/** A slice's scale and times, s, as `profileAt` finds them, without building its profile (the loft's refinement and budget). */
	profileTimes(query) {
		const b = this.bracket(query);
		if (this.options.geometry === "bounded-C") {
			const clock = this.analyticClock(query, b);
			return {
				scale: b.scale,
				clamped: b.clamped,
				touchdownSeconds: clock.impact * b.unit,
				frameSeconds: b.frameStep * b.unit,
				clearSeconds: clock.clear * b.unit,
				collapseSeconds: (clock.retired - clock.impact) * b.unit
			};
		}
		return {
			scale: b.scale,
			clamped: b.clamped,
			touchdownSeconds: b.touchdown * b.unit,
			frameSeconds: b.frameStep * b.unit,
			clearSeconds: b.clear * b.unit,
			collapseSeconds: b.collapse
		};
	}
	/** Raw authored case evidence only. Analytic query lifecycle/void comes from profileAt, not this per-case helper. */
	heldFrameOf(c) {
		return this.held.get(c) ?? heldFrame(c);
	}
	/** The cases a slice blends and by how much, and its scale, as `profileAt` blends and scales them (the crash's held overturn, PR 5). */
	caseBlend(query) {
		const b = this.bracket(query);
		return {
			lower: b.lower,
			upper: b.upper,
			weight: b.weight,
			scale: b.scale,
			clamped: b.clamped
		};
	}
	/** C incident-interpolation support only; it never changes an individual pocket's physical lifetime. */
	carrierRetirementBound(slope, a, b) {
		if (this.options.geometry !== "bounded-C") throw new Error("Carrier support requires the bounded C provider");
		const h0 = Math.fround(a.footHeight), h1 = Math.fround(b.footHeight);
		const d0 = Math.fround(a.footDepth), d1 = Math.fround(b.footDepth);
		if (![
			h0,
			h1,
			d0,
			d1
		].every((v) => Number.isFinite(v) && v > 0)) throw new Error("Invalid carrier support foot domain");
		let group = this.bySlope[0];
		for (const candidate of this.bySlope) if (Math.abs(candidate[0].slope - slope) < Math.abs(group[0].slope - slope)) group = candidate;
		const stops = [0, 1];
		for (const c of group) {
			const denominator = h1 - h0 - c.nonlinearity * (d1 - d0);
			if (denominator === 0) continue;
			const t = (c.nonlinearity * d0 - h0) / denominator;
			if (t > 0 && t < 1) stops.push(t);
		}
		stops.sort((x, y) => x - y);
		const probes = [...stops];
		for (let k = 0; k + 1 < stops.length; k += 1) probes.push((stops[k] + stops[k + 1]) / 2);
		let maxScale = 0, maxAuthoredTD = 0;
		for (const t of probes) {
			const q = this.bracket({
				slope,
				footHeight: h0 + t * (h1 - h0),
				footDepth: d0 + t * (d1 - d0)
			});
			maxScale = Math.max(maxScale, q.scale);
			maxAuthoredTD = Math.max(maxAuthoredTD, q.lower.touchdown, q.upper.touchdown);
		}
		const unit = carrierNextUp(Math.sqrt(carrierNextUp(carrierNextUp(maxScale) / GRAVITY)));
		const seconds = carrierNextUp(carrierNextUp(1.6 * carrierNextUp(maxAuthoredTD)) * unit);
		if (!Number.isFinite(seconds) || !(seconds > 0)) throw new Error("Nonfinite carrier support bound");
		return {
			seconds,
			maxScale,
			maxAuthoredTD,
			partitions: stops.length - 1
		};
	}
	/** The cases a slice blends (the nearest slope's two bracketing its A0), its scale (h0, m) and τ's unit, s. */
	bracket(query) {
		let group = this.bySlope[0];
		for (const candidate of this.bySlope) if (Math.abs(candidate[0].slope - query.slope) < Math.abs(group[0].slope - query.slope)) group = candidate;
		let clamped = Math.abs(group[0].slope - query.slope) > SLOPE_TOLERANCE * query.slope;
		const a0 = query.footHeight / query.footDepth;
		let lower = group[0];
		let upper = group[group.length - 1];
		let weight = 0;
		if (a0 <= lower.nonlinearity) {
			clamped ||= a0 < lower.nonlinearity;
			upper = lower;
		} else if (a0 >= upper.nonlinearity) {
			clamped ||= a0 > upper.nonlinearity;
			lower = upper;
		} else for (let k = 0; k + 1 < group.length; k += 1) if (group[k].nonlinearity <= a0 && a0 <= group[k + 1].nonlinearity) {
			lower = group[k];
			upper = group[k + 1];
			weight = (a0 - lower.nonlinearity) / (upper.nonlinearity - lower.nonlinearity);
			break;
		}
		const scale = lower === upper ? query.footHeight / lower.nonlinearity : query.footDepth;
		const heldLower = this.heldFrameOf(lower);
		const heldUpper = this.heldFrameOf(upper);
		const voidHeight = (heldLower.voidHeight + weight * (heldUpper.voidHeight - heldLower.voidHeight)) * scale;
		const touchdown = lower.touchdown + weight * (upper.touchdown - lower.touchdown);
		return {
			lower,
			upper,
			weight,
			clamped,
			scale,
			unit: Math.sqrt(scale / GRAVITY),
			touchdown,
			frameStep: lower.tauStep + weight * (upper.tauStep - lower.tauStep),
			heldLower: heldLower.tau,
			heldUpper: heldUpper.tau,
			clear: Math.min(touchdown, Math.max(heldLower.tau, heldUpper.tau)),
			collapse: Math.sqrt(2 * voidHeight / GRAVITY)
		};
	}
	/** Phase-independent crest-relative reach, including analytic turns/cap and F32 parameter-blend rounding. */
	crestReachBounds(slope) {
		let group = this.bySlope[0];
		for (const candidate of this.bySlope) if (Math.abs(candidate[0].slope - slope) < Math.abs(group[0].slope - slope)) group = candidate;
		let low = 0, high = 0;
		for (const c of group) for (let offset = 0; offset < c.frames.length; offset += FLOATS) {
			const crest = c.frames[offset + 2 * LANDMARK.crest];
			for (let i = 0; i < 128; i++) {
				const x = c.frames[offset + 2 * i] - crest;
				low = Math.min(low, x);
				high = Math.max(high, x);
			}
			if (this.options.geometry === "bounded-C") {
				const W = c.frames[offset + 2 * LANDMARK.toe] - crest;
				const ulp = ulp32(Math.max(Math.abs(crest), Math.abs(c.frames[offset + 2 * LANDMARK.toe]), Math.abs(c.frames[offset + 2 * LANDMARK.crest + 1]), Math.abs(c.frames[offset + 2 * LANDMARK.toe + 1])));
				low = Math.min(low, -W - 76 * ulp);
				high = Math.max(high, 1.125 * W + 20 * ulp);
			}
		}
		return new Float64Array([low, high]);
	}
	/** Parameters blend before construction; all analytic hold modes share the same evolving geometry. */
	analyticParameters(query, b, out) {
		const tau = query.seconds / b.unit;
		const carrier = Math.min(tau, b.touchdown);
		const leafEnable = ease((b.touchdown - carrier) / b.frameStep);
		this.frameAt(b.lower, carrier, out);
		const lower = boundedCParameters(out, b.lower.touchdown, tau);
		lower.leafWidthDelta = leafEnable * carrierWidthDelta(b.lower, carrier);
		let parameters = lower;
		if (b.upper !== b.lower) {
			this.frameAt(b.upper, carrier, this.analyticOther);
			const upper = boundedCParameters(this.analyticOther, b.upper.touchdown, tau);
			upper.leafWidthDelta = leafEnable * carrierWidthDelta(b.upper, carrier);
			parameters = blendBoundedCParameters(lower, upper, b.weight);
			for (let i = 0; i < FLOATS; i++) out[i] += b.weight * (this.analyticOther[i] - out[i]);
		}
		return parameters;
	}
	analyticShape(query, b, out) {
		const parameters = this.analyticParameters(query, b, out);
		const clockKey = [
			query.slope,
			query.footHeight,
			query.footDepth
		].join(",");
		const meta = sampleBoundedC(parameters, out, false, this.analyticClocks.get(clockKey)?.event, true);
		meta.sharedSheet = pairInnerSheet(out, meta);
		meta.lengthScale = b.scale;
		meta.timeScale = b.unit;
		for (let i = 0; i < FLOATS; i++) out[i] *= b.scale;
		return meta;
	}
	/** Lifecycle uses the identical final carrier/parameter blend; it does not construct a full contour. */
	analyticClock(query, b) {
		const key = [
			query.slope,
			query.footHeight,
			query.footDepth
		].join(",");
		let clock = this.analyticClocks.get(key);
		if (!clock) {
			const final = boundedCLifecycle(this.analyticParameters({
				...query,
				seconds: b.touchdown * b.unit
			}, b, this.scratch));
			clock = {
				impact: final.impactTau,
				retired: final.retiredTau,
				clear: final.fullyFormedTau,
				event: final.impactEvent
			};
			if (this.analyticClocks.size >= 64) this.analyticClocks.delete(this.analyticClocks.keys().next().value);
			this.analyticClocks.set(key, clock);
		}
		return clock;
	}
	/** Offline-only trace at the identical bracket/parameter/event path; no provider coefficients or query semantics change. */
	inspectCapReach(query) {
		if (this.options.geometry !== "bounded-C") throw Error("Bounded-C trace required");
		const b = this.bracket(query), raw = new Float32Array(FLOATS), parameters = this.analyticParameters(query, b, raw);
		const clock = this.analyticClock(query, b), trace = {}, cap = boundedCCap(parameters, clock.event, trace);
		const carrier = Math.min(query.seconds / b.unit, b.touchdown), lower = {}, upper = {};
		const lowerDelta = carrierWidthDelta(b.lower, carrier, lower), upperDelta = carrierWidthDelta(b.upper, carrier, upper);
		return {
			bracket: {
				lower: b.lower.id,
				upper: b.upper.id,
				weight: b.weight,
				scale: b.scale,
				unit: b.unit,
				authoredHoldTau: b.touchdown,
				authoredHoldSeconds: b.touchdown * b.unit,
				frameStep: b.frameStep,
				clamped: b.clamped
			},
			carrier: {
				queryTau: query.seconds / b.unit,
				carrierTau: carrier,
				carrierSeconds: carrier * b.unit,
				holdTaper: ease((b.touchdown - carrier) / b.frameStep),
				lower,
				upper,
				meanRequestedDeltaBeforeHold: lowerDelta + b.weight * (upperDelta - lowerDelta),
				exactBlendedRequestedDelta: parameters.leafWidthDelta ?? 0
			},
			clocks: {
				impactTau: clock.impact,
				retiredTau: clock.retired,
				fullyFormedTau: clock.clear,
				event: clock.event
			},
			preservedNDWords: [
				31,
				32,
				112,
				113
			].map((point) => ({
				point,
				words: Array.from(raw.subarray(2 * point, 2 * point + 2))
			})),
			trace,
			metricCapWords: [Math.fround(cap[0] * b.scale), Math.fround(cap[1] * b.scale)]
		};
	}
	/** F32 stage order matches analyticShape: raw carrier, parameters, ND cap, then metric cap. */
	analyticCap(query, b, raw, event) {
		const cap = boundedCCap(this.analyticParameters(query, b, raw), event);
		return [Math.fround(cap[0] * b.scale), Math.fround(cap[1] * b.scale)];
	}
	analyticAt(query, b, out) {
		const key = [
			query.slope,
			query.footHeight,
			query.footDepth,
			query.seconds
		].join(",");
		const cached = this.analyticQueries.get(key);
		if (cached) {
			out.set(cached.profile);
			return cached.lookup;
		}
		const clock = this.analyticClock(query, b);
		const meta = this.analyticShape(query, b, out);
		meta.impactTau = clock.impact;
		meta.retiredTau = clock.retired;
		const dt = Math.max(1e-8, 1e-5 * b.touchdown * b.unit);
		const earlier = this.analyticCap({
			...query,
			seconds: query.seconds - dt
		}, b, this.analyticEarlier, clock.event);
		const later = this.analyticCap({
			...query,
			seconds: query.seconds + dt
		}, b, this.analyticLater, clock.event);
		const tipAlong = (later[0] - earlier[0]) / (2 * dt);
		const tipUp = (later[1] - earlier[1]) / (2 * dt);
		meta.capBoundaryVelocity = [tipAlong * b.unit / b.scale, tipUp * b.unit / b.scale];
		const phase = query.seconds < 0 ? "pre" : query.seconds <= meta.impactTau * b.unit ? "open" : "post";
		const lookup = {
			caseId: b.weight < .5 ? b.lower.id : b.upper.id,
			clamped: b.clamped,
			scale: b.scale,
			phase,
			touchdownSeconds: meta.impactTau * b.unit,
			frameSeconds: b.frameStep * b.unit,
			tipAlong,
			tipUp,
			clearSeconds: meta.fullyFormedTau * b.unit,
			collapseSeconds: (meta.retiredTau - meta.impactTau) * b.unit,
			analytic: meta
		};
		if (this.analyticQueries.size >= 64) this.analyticQueries.delete(this.analyticQueries.keys().next().value);
		this.analyticQueries.set(key, {
			profile: out.slice(),
			lookup
		});
		return lookup;
	}
	/**
	* Each blended case's τ for the slice's geometry and for its tip's velocity (lower, upper; then their tips), at the
	* slice's τ and hold (`ProfileQuery.hold`).
	*/
	caseTimes(b, tau, hold) {
		const times = this.times;
		const after = tau > b.touchdown;
		const shape = hold !== void 0 && after ? b.touchdown : tau;
		const contact = hold === "contact";
		times[0] = contact ? Math.min(shape, b.heldLower) : shape;
		times[1] = contact ? Math.min(shape, b.heldUpper) : shape;
		times[2] = after && hold !== void 0 ? times[0] : tau;
		times[3] = after && hold !== void 0 ? times[1] : tau;
		return times;
	}
	/** One case's profile point at τ (√(h0/g)), h0, into `out`, linear between frames as `frameAt`. */
	landmarkAt(c, tau, point, out) {
		const count = c.frames.length / FLOATS;
		const position = Math.min(count - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
		const f = Math.floor(position);
		const next = Math.min(count - 1, f + 1);
		const t = position - f;
		for (let k = 0; k < 2; k += 1) {
			const a = c.frames[f * FLOATS + 2 * point + k];
			out[k] = a + t * (c.frames[next * FLOATS + 2 * point + k] - a);
		}
	}
	/** One case's profile at τ (√(h0/g)), linear between its two nearest frames, clamped to its first and last. */
	frameAt(c, tau, out) {
		const count = c.frames.length / FLOATS;
		const position = Math.min(count - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
		const f = Math.floor(position);
		const next = Math.min(count - 1, f + 1);
		const t = position - f;
		for (let i = 0; i < FLOATS; i += 1) {
			const a = c.frames[f * FLOATS + i];
			out[i] = a + t * (c.frames[next * FLOATS + i] - a);
		}
	}
	/** One case's tip velocity at τ, √(g h0), linear between frames as `frameAt` (zero for a BRL1 case). */
	tipAt(c, tau, into) {
		into[0] = 0;
		into[1] = 0;
		if (!c.tipVelocity) return;
		const count = c.tipVelocity.length / 2;
		const position = Math.min(count - 1, Math.max(0, (tau - c.tauStart) / c.tauStep));
		const f = Math.floor(position);
		const next = Math.min(count - 1, f + 1);
		const t = position - f;
		into[0] = c.tipVelocity[2 * f] + t * (c.tipVelocity[2 * next] - c.tipVelocity[2 * f]);
		into[1] = c.tipVelocity[2 * f + 1] + t * (c.tipVelocity[2 * next + 1] - c.tipVelocity[2 * f + 1]);
	}
};
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/baseline/src/wave/barrel/profileFormat.ts
const MAGIC = 1112689714;
/** "BRL1": the frames alone, before the tip's velocities (Part B, PR 4). */
const LEGACY = 1112689713;
function decodeCase(bytes) {
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	const magic = bytes.byteLength < 8 ? 0 : view.getUint32(0, true);
	if (magic !== MAGIC && magic !== LEGACY) throw new Error("Not a barrel case");
	const length = view.getUint32(4, true);
	const meta = JSON.parse(new TextDecoder().decode(bytes.subarray(8, 8 + length)));
	const start = 8 + Math.ceil(length / 4) * 4;
	const floats = new Float32Array(bytes.slice(start).buffer);
	if (magic === LEGACY) return {
		...meta,
		frames: floats
	};
	const count = floats.length / 258;
	return {
		...meta,
		frames: floats.slice(0, count * 2 * 128),
		tipVelocity: floats.slice(count * 2 * 128)
	};
}
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/front-format.ts
const FRONT_FIELD = {
	x: 0,
	z: 1,
	front: 2,
	sigma: 3,
	tau: 4,
	footHeight: 5,
	footDepth: 6,
	throwZ: 7,
	pace: 8
};
//#endregion
//#region ../../../../../private/tmp/tube-cap-reach-hold-analysis-proposal-20261005/analyze.ts
/** SOURCE-ONLY proposal. Root must review, bundle and execute; this file has not run. */
const W = "/private/tmp/tube-cap-reach-hold-analysis-proposal-20261005";
const INPUT = W + "/input-pins.json";
const OUTPUT = W + "/reach-decomposition.json";
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
function pinned(pin) {
	const b = readFileSync(pin.file);
	assert.equal(b.length, pin.bytes, pin.file);
	assert.equal(sha(b), pin.sha256, pin.file);
	return b;
}
function finite(value, path = "report") {
	if (typeof value === "number") assert(Number.isFinite(value), "Nonfinite " + path);
	else if (Array.isArray(value)) value.forEach((v, k) => finite(v, path + "[" + k + "]"));
	else if (value !== null && typeof value === "object") Object.entries(value).forEach(([k, v]) => finite(v, path + "." + k));
}
const inputs = JSON.parse(readFileSync(INPUT, "utf8"));
const report = {
	schema: "bounded-cap-reach-hold-decomposition/v1",
	complete: false,
	firstFailure: null,
	scope: "Fixed generic fixture; literal provider trace and equal-span finite differences only. No native/body/globalC1 inference.",
	executionAuthority: "Executing tool/agent must be attributed by a separate root receipt.",
	inputs: [],
	limits: inputs.limits,
	rows: [],
	secants: null,
	hold: null
};
assert(!existsSync(OUTPUT), "First-only analysis output");
const wordView = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(4));
function word(value) {
	assert(Number.isFinite(value));
	wordView.setFloat32(0, value, true);
	return wordView.getUint32(0, true);
}
function ordered(value) {
	const bits = word(value);
	return bits & 2147483648 ? 2147483648 - (bits & 2147483647) : 2147483648 + bits;
}
function wordComparison(a, b) {
	assert.equal(a.length, b.length);
	return a.map((v, k) => ({
		a: v,
		b: b[k],
		aWord: word(v),
		bWord: word(b[k]),
		wordExact: word(v) === word(b[k]),
		absoluteError: Math.abs(v - b[k]),
		ulpDistance: Math.abs(ordered(v) - ordered(b[k]))
	}));
}
const profileBytes = (v) => new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
const scaleTerms = (v, scale) => Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x * scale]));
const sum = (v) => Object.values(v).reduce((s, x) => s + x, 0);
const differences = (a, b, span) => Object.fromEntries(Object.keys(a).map((k) => [k, {
	left: a[k],
	right: b[k],
	difference: b[k] - a[k],
	secant: (b[k] - a[k]) / span
}]));
const ulp64 = (x) => {
	assert(x > 0 && Number.isFinite(x));
	const d = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	d.setFloat64(0, x, true);
	d.setBigUint64(0, d.getBigUint64(0, true) + 1n, true);
	return d.getFloat64(0, true) - x;
};
try {
	const readiness = JSON.parse(readFileSync(W + "/readiness.json", "utf8"));
	for (const p of readiness.files) pinned(p);
	for (const m of inputs.copiedExactProviderModules) pinned(m.original);
	for (const p of inputs.evidence) pinned(p);
	pinned(inputs.barrelIndex);
	report.inputs = [
		{
			file: INPUT,
			bytes: readFileSync(INPUT).length,
			sha256: sha(readFileSync(INPUT))
		},
		...inputs.evidence,
		...inputs.copiedExactProviderModules.map((m) => m.original),
		inputs.barrelIndex,
		...inputs.assets
	];
	const saved = JSON.parse(readFileSync(W + "/evidence/fixture-decomposition.json", "utf8"));
	assert.equal(saved.schema, "root-angular-fixture-decomposition/v1");
	assert.equal(saved.productionChanged, false);
	const records = new Float32Array(saved.rawFrontPacket);
	assert.deepEqual(Array.from(records), saved.rawFrontPacket);
	assert.equal(records.length, 81);
	assert(records.every(Number.isFinite));
	const cases = inputs.assets.map((p) => decodeCase(new Uint8Array(pinned(p))));
	assert.equal(cases.length, 8);
	const original = new ProfileLibrary$1(cases, { geometry: "bounded-C" }), observed = new ProfileLibrary(cases, { geometry: "bounded-C" });
	const slope = saved.query.slope, level = .5, start = 4.75, end = 5.25, h = 1 / 64;
	assert.equal(inputs.limits.gridStart, start);
	assert.equal(inputs.limits.gridEnd, end);
	assert.equal(inputs.limits.gridStep, h);
	assert.equal(inputs.limits.gridCount, 33);
	for (let k = 1; k < 9; k++) for (const field of [
		"front",
		"footHeight",
		"footDepth"
	]) assert.equal(records[k * 9 + FRONT_FIELD[field]], records[FRONT_FIELD[field]], "Constant actual packet " + field);
	const sample = (x) => {
		assert(x >= start && x <= end, "No domain expansion");
		let k = 0;
		while (k + 1 < 8 && records[(k + 1) * 9 + FRONT_FIELD.x] < x) k++;
		const a = k * 9, b = (k + 1) * 9, share = (x - records[a]) / (records[b] - records[a]);
		assert(share >= 0 && share <= 1, "Declared interval only");
		const field = (offset) => records[a + offset] + share * (records[b + offset] - records[a + offset]);
		return {
			x,
			z: field(FRONT_FIELD.z),
			sigma: field(FRONT_FIELD.sigma),
			tau: field(FRONT_FIELD.tau),
			footHeight: field(FRONT_FIELD.footHeight),
			footDepth: field(FRONT_FIELD.footDepth),
			packetLeft: k,
			share
		};
	};
	const first = sample(start), last = sample(end);
	assert.equal(first.packetLeft, last.packetLeft, "One affine packet segment");
	const initialQuery = {
		slope,
		footHeight: first.footHeight,
		footDepth: first.footDepth,
		seconds: first.tau,
		hold: "drawing"
	};
	const initial = observed.inspectCapReach(initialQuery), holdSeconds = initial.bracket.authoredHoldSeconds;
	const a = first.packetLeft * 9, b = a + 9;
	const holdX = records[a] + (holdSeconds - records[a + FRONT_FIELD.tau]) / (records[b + FRONT_FIELD.tau] - records[a + FRONT_FIELD.tau]) * (records[b] - records[a]);
	assert(holdX >= start && holdX <= end, "Exact hold must already lie in fixed range");
	const holdPacket = sample(holdX), inverseResidual = holdPacket.tau - holdSeconds;
	assert(Math.abs(inverseResidual) <= 8 * ulp64(holdSeconds), "Hold inversion exceeds declared 8 binary64 ULPs");
	report.fixture = {
		rawFrontPacket: saved.rawFrontPacket,
		recordedOriginalQuery: saved.query,
		recordedOriginalTimes: saved.times,
		actualInterpolatedControls: {
			slope,
			footHeight: first.footHeight,
			footDepth: first.footDepth
		},
		flatWaterLevel: level
	};
	report.hold = {
		x: holdX,
		storedXIfMeshed: Math.fround(holdX),
		authoredHoldTau: initial.bracket.authoredHoldTau,
		unit: initial.bracket.unit,
		authoredHoldSeconds: holdSeconds,
		packetSegment: [first.packetLeft, first.packetLeft + 1],
		inversePacketAge: holdPacket.tau,
		inverseResidualSeconds: inverseResidual,
		inverseResidualULPs: inverseResidual / ulp64(holdSeconds),
		queryConvention: "Exact published authoredHoldTau*unit clock used for the hold-only sample; inversion residual is explicit. No simulation clock assignment.",
		equalSpanConvention: "Grid intervals of identical 1/64m span immediately before/after hold. Not invented centred hold±h provider samples."
	};
	function inspect(x, exactHold = false) {
		const raw = sample(x), query = {
			slope,
			footHeight: raw.footHeight,
			footDepth: raw.footDepth,
			seconds: exactHold ? holdSeconds : raw.tau,
			hold: "drawing"
		};
		const op = /* @__PURE__ */ new Float32Array(256), cp = /* @__PURE__ */ new Float32Array(256);
		const originalLookup = original.profileAt(query, op), candidateLookup = observed.profileAt(query, cp);
		assert.deepEqual(profileBytes(cp), profileBytes(op), "Instrumented complete profile changed");
		const cap = /* @__PURE__ */ new Float64Array(2), crest = /* @__PURE__ */ new Float64Array(2), toe = /* @__PURE__ */ new Float64Array(2);
		original.pointAt(query, LANDMARK$1.lip, cap);
		original.pointAt(query, LANDMARK$1.crest, crest);
		original.pointAt(query, LANDMARK$1.toe, toe);
		const observation = observed.inspectCapReach(query), t = observation.trace, o = t.ordinary;
		assert(o && t.normal && t.last && t.unroundedCap && t.capWords && t.phi !== null && t.phi !== void 0);
		assert.equal(t.formation, 1, "Only mature branch; no fallback");
		assert.equal(t.post, false, "Pre-impact fixed domain only");
		assert.equal(t.collapsed, false, "Resolved branch only");
		assert.equal(t.thickness, o.B, "Actual mature thickness");
		const staged = observation.metricCapWords, capCheck = wordComparison(staged, Array.from(cap));
		const capFullCheck = wordComparison(Array.from(cap), Array.from(op.subarray(2 * LANDMARK$1.lip, 2 * LANDMARK$1.lip + 2)));
		const crestFullCheck = wordComparison(Array.from(crest), Array.from(op.subarray(2 * LANDMARK$1.crest, 2 * LANDMARK$1.crest + 2)));
		assert(capCheck.every((v) => v.wordExact) && capFullCheck.every((v) => v.wordExact) && crestFullCheck.every((v) => v.wordExact), "Literal reconstruction/public point/full words differ");
		assert.equal(originalLookup.touchdownSeconds, candidateLookup.touchdownSeconds);
		assert.equal(originalLookup.clearSeconds, candidateLookup.clearSeconds);
		const scale = observation.bracket.scale, T = t.thickness, n = t.normal, lastDirection = t.last, phi = t.phi;
		const zND = {
			carrierWidth: .98 * o.W,
			thicknessRetreat: -2 * o.B,
			boundedCorrection: o.leafWidthDelta,
			normalXOffset: -T / 2 * n[0],
			actualArcXTerm: T / 2 * (n[0] * Math.cos(phi) + lastDirection[0] * Math.sin(phi))
		};
		zND.endpointAssemblyRemainder = t.unroundedCap[0] - o.A[0] - sum(zND);
		const yND = {
			toeY: o.Toe[1],
			openHeight: .6 * o.H,
			fallingHeight: -.8 * o.H * t.seal,
			normalYOffset: -T / 2 * n[1],
			actualArcYTerm: T / 2 * (n[1] * Math.cos(phi) + lastDirection[1] * Math.sin(phi))
		};
		yND.endpointAssemblyRemainder = t.unroundedCap[1] - sum(yND);
		const unroundedWorld = [
			x,
			level + t.unroundedCap[1] * scale,
			raw.z - o.A[0] * scale + t.unroundedCap[0] * scale
		];
		const ordinaryWorldUnstored = [
			x,
			level + cap[1],
			raw.z - crest[0] + cap[0]
		], world = ordinaryWorldUnstored.map(Math.fround);
		const termsZ = {
			rawCrestZ: raw.z,
			...scaleTerms(zND, scale),
			crestMetricStage: o.A[0] * scale - crest[0],
			capNDWordStage: (t.capWords[0] - t.unroundedCap[0]) * scale,
			capMetricWordStage: cap[0] - t.capWords[0] * scale,
			worldF32Stage: world[2] - ordinaryWorldUnstored[2]
		};
		const termsY = {
			waterLevel: level,
			...scaleTerms(yND, scale),
			capNDWordStage: (t.capWords[1] - t.unroundedCap[1]) * scale,
			capMetricWordStage: cap[1] - t.capWords[1] * scale,
			worldF32Stage: world[1] - ordinaryWorldUnstored[1]
		};
		termsZ.finalAssemblyRemainder = world[2] - sum(termsZ);
		termsY.finalAssemblyRemainder = world[1] - sum(termsY);
		const scalars = {
			rawWidthND: o.W,
			rawHeightND: o.H,
			B_ND: o.B,
			reachBudgetND: Math.min(o.B, .13 * o.W - 2 * o.B),
			meanRequestedDeltaBeforeHoldND: observation.carrier.meanRequestedDeltaBeforeHold,
			requestedDeltaAfterHoldND: observation.carrier.exactBlendedRequestedDelta,
			boundedCorrectionND: o.leafWidthDelta,
			normalX: n[0],
			normalXOffsetND: -T / 2 * n[0],
			holdTaper: observation.carrier.holdTaper,
			rawWidthMetric: o.W * scale,
			rawHeightMetric: o.H * scale,
			B_Metric: o.B * scale,
			meanRequestedDeltaBeforeHoldMetric: observation.carrier.meanRequestedDeltaBeforeHold * scale,
			requestedDeltaAfterHoldMetric: observation.carrier.exactBlendedRequestedDelta * scale,
			boundedCorrectionMetric: o.leafWidthDelta * scale,
			normalXOffsetMetric: -T / 2 * n[0] * scale
		};
		const row = {
			x,
			kind: exactHold ? "exact-published-hold" : "fixed-grid",
			rawSample: raw,
			query,
			bracket: observation.bracket,
			carrier: observation.carrier,
			clocks: observation.clocks,
			scalars,
			trace: observation.trace,
			preservedNDWords: observation.preservedNDWords,
			reconstructed: {
				ndCapWords: t.capWords,
				metricCapWords: staged,
				unroundedWorldCap: unroundedWorld,
				ordinaryUnstoredWorldCap: ordinaryWorldUnstored,
				storedWorldCap: world
			},
			ordinaryProvider: {
				metricCapWords: Array.from(cap),
				metricCrestWords: Array.from(crest),
				metricToeWords: Array.from(toe),
				profileSHA256: sha(profileBytes(op)),
				lookup: {
					phase: originalLookup.phase,
					clearSeconds: originalLookup.clearSeconds,
					impactSeconds: originalLookup.touchdownSeconds,
					collapseSeconds: originalLookup.collapseSeconds
				}
			},
			verification: {
				completeInstrumentedProfileWordsExact: true,
				capCheck,
				capFullCheck,
				crestFullCheck
			},
			terms: {
				zND,
				yND,
				zMetric: scaleTerms(zND, scale),
				yMetric: scaleTerms(yND, scale),
				storedWorldZ: termsZ,
				storedWorldY: termsY
			}
		};
		finite(row);
		return row;
	}
	const grid = Array.from({ length: 33 }, (_, k) => inspect(start + k * h));
	report.rows.push(...grid);
	const holdRow = inspect(holdX, true);
	report.rows.push(holdRow);
	assert.equal(report.rows.length, 34);
	function interval(left, right) {
		const span = right.x - left.x;
		assert.equal(span, h, "Equal declared span");
		return {
			x: [left.x, right.x],
			span,
			scalars: differences(left.scalars, right.scalars, span),
			worldY: differences(left.terms.storedWorldY, right.terms.storedWorldY, span),
			worldZ: differences(left.terms.storedWorldZ, right.terms.storedWorldZ, span),
			observedStoredCapSecant: left.reconstructed.storedWorldCap.map((v, axis) => (right.reconstructed.storedWorldCap[axis] - v) / span)
		};
	}
	function pair(left, right) {
		assert.equal(left.span, right.span);
		return {
			left,
			right,
			storedCapSecantDifference: right.observedStoredCapSecant.map((v, k) => v - left.observedStoredCapSecant[k]),
			scalarSecantDifferences: Object.fromEntries(Object.keys(left.scalars).map((k) => [k, right.scalars[k].secant - left.scalars[k].secant])),
			worldZSecantDifferences: Object.fromEntries(Object.keys(left.worldZ).map((k) => [k, right.worldZ[k].secant - left.worldZ[k].secant])),
			worldYSecantDifferences: Object.fromEntries(Object.keys(left.worldY).map((k) => [k, right.worldY[k].secant - left.worldY[k].secant]))
		};
	}
	const centre = 16;
	assert.equal(grid[centre].x, 5);
	const lower = Math.floor((holdX - start) / h), upper = Math.ceil((holdX - start) / h);
	assert(lower >= 1 && upper + 1 < grid.length, "Hold equal-span bracket inside fixed grid");
	report.secants = {
		span: h,
		x5: pair(interval(grid[15], grid[centre]), interval(grid[centre], grid[17])),
		authoredHold: pair(interval(grid[lower - 1], grid[lower]), interval(grid[upper], grid[upper + 1])),
		authoredHoldGridBracket: [grid[lower].x, grid[upper].x],
		exactHold: holdRow.x,
		interpretation: "Equal-span finite differences at one fixed resolution. Hold-side intervals bracket, rather than invent, centred hold±h samples. No derivative discontinuity proof."
	};
	report.complete = true;
} catch (error) {
	report.firstFailure = error instanceof Error ? error.name + ": " + error.message : String(error);
	report.complete = false;
}
finite(report);
const bytes = Buffer.from(JSON.stringify(report, null, 2) + "\n");
assert(bytes.length <= inputs.limits.reportBytes, "Finite JSON report cap");
writeFileSync(OUTPUT, bytes);
console.log(JSON.stringify({
	complete: report.complete,
	firstFailure: report.firstFailure,
	rows: report.rows.length,
	output: {
		file: OUTPUT,
		bytes: bytes.length,
		sha256: sha(bytes)
	},
	noNativeOrDerivativeKinkClaim: true
}));
if (!report.complete) process.exitCode = 1;
//#endregion
export {};
